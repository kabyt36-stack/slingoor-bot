import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { HourlyGoal } from '../src/goal.js';

const at = (h, m) => new Date(2026, 10, 12, h, m, 0).getTime();
const file = () => path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'goal-')), 'goal.json');

test('hourly goal: hit at 1:35 -> no new buys until 2:00, then buying again', () => {
  let now = at(13, 10);
  let pnl = 0.02;
  const hits = [];
  const f = file();
  const g = new HourlyGoal({ file: f, sol: 0.05, pnl: () => pnl, now: () => now, onHit: (x) => hits.push(x) });
  assert.equal(g.reached(), false, 'under the goal: keeps buying');
  now = at(13, 35);
  pnl = 0.064;
  assert.equal(g.reached(), true, 'goal hit');
  assert.equal(hits.length, 1);
  assert.equal(new Date(hits[0].until).getHours(), 14, 'paused until 2:00');
  assert.equal(new Date(hits[0].until).getMinutes(), 0);
  // a held coin keeps running and sells for more profit: still counted, still paused, no second alert
  pnl = 0.12;
  now = at(13, 50);
  assert.equal(g.reached(), true);
  assert.equal(hits.length, 1);
  assert.match(g.line()[0], /hit at 1:35 PM ✅ \(this hour \+0\.120\)/);
  // dipping back under the goal later in the same hour doesn't restart buying
  pnl = 0.01;
  assert.equal(g.reached(), true);
  // restart keeps it
  assert.equal(new HourlyGoal({ file: f, pnl: () => pnl, now: () => now }).reached(), true);
  // next hour: buying again
  now = at(14, 0);
  pnl = 0;
  assert.equal(g.reached(), false);
});

test('hourly goal: off by default, /goal off stops it, setting it under what this hour already made stops buys now', () => {
  let pnl = 0.08;
  const g = new HourlyGoal({ file: file(), pnl: () => pnl, now: () => at(9, 20) });
  assert.equal(g.reached(), false, 'no goal');
  assert.deepEqual(g.line(), []);
  g.set(0.05);
  assert.equal(g.reached(), true, 'already +0.08 this hour');
  g.set(0);
  assert.equal(g.reached(), false, 'off');
});
