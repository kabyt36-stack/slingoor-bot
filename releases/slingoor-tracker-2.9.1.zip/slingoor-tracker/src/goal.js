// V2.9.1 hourly PnL goal: once this clock hour's closed trades (all wallets) reach the goal, the bot
// makes no NEW buys until the next hour starts (1:35 hit -> buying again at 2:00). Coins it already
// holds keep every sell rule, so a coin still running up still sells for profit (and that counts too).
import fs from 'node:fs';
import path from 'node:path';

export const hourKey = (t) => {
  const d = new Date(t);
  return `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}-${d.getHours()}`;
};

export class HourlyGoal {
  constructor({ file, sol = 0, pnl, onHit = () => {}, now = () => Date.now() }) {
    this.file = file;
    this.pnl = pnl; // () => SOL made by closed trades since the start of this hour
    this.onHit = onHit;
    this.now = now;
    this.d = { sol, hitHour: null, hitAt: null };
    try {
      this.d = { ...this.d, ...JSON.parse(fs.readFileSync(file, 'utf8')) };
    } catch {}
  }

  save() {
    try {
      fs.mkdirSync(path.dirname(this.file), { recursive: true });
      fs.writeFileSync(this.file, JSON.stringify(this.d));
    } catch {}
  }

  get sol() {
    return this.d.sol;
  }

  hourPnl() {
    return this.pnl() || 0;
  }

  // true = goal reached this hour: don't buy
  reached() {
    if (!(this.d.sol > 0)) return false;
    const key = hourKey(this.now());
    if (this.d.hitHour === key) return true;
    const p = this.hourPnl();
    if (p + 1e-9 < this.d.sol) return false;
    this.d.hitHour = key;
    this.d.hitAt = this.now();
    this.save();
    const next = new Date(this.now());
    next.setMinutes(60, 0, 0);
    this.onHit({ pnl: p, goal: this.d.sol, until: next.getTime() });
    return true;
  }

  set(sol) {
    this.d = { sol: sol > 0 ? sol : 0, hitHour: null, hitAt: null };
    this.save();
    this.reached(); // already past the new goal this hour -> stops now
  }

  line() {
    if (!(this.d.sol > 0)) return [];
    const p = this.hourPnl();
    const hit = this.d.hitHour === hourKey(this.now());
    const t = (ms) => new Date(ms).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
    return [`🎯 Hourly goal ${this.d.sol} SOL: ${hit ? `hit at ${t(this.d.hitAt)} ✅ (this hour ${p >= 0 ? '+' : '-'}${Math.abs(p).toFixed(3)})` : `this hour ${p >= 0 ? '+' : '-'}${Math.abs(p).toFixed(3)}`}`];
  }
}
