import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { Rotator } from '../src/rotate.js';
import { GhostBook } from '../src/ghost.js';

const H = 3600000;
const file = () => path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'rot-')), 'r.json');
const R = (coins, gains, losses, last10) => ({ coins, pnl: gains - losses, gains, losses, last10 });

test('auto-rotate tiers on the last 30 trades: hot (+31 vs -3) full size, neutral (break-even or up) smaller, cold (lost more than won) stopped; new wallets wait', () => {
  let now = 1000 * H;
  const res = {
    t1: R(30, 31, 3, 2), // very positive -> hot
    schoen: R(30, 1.0, 0.8, 0.1), // 30 trades, up a bit, winners not 2x the losers -> proven (V2.11.15)
    dilly: R(30, 1, 3, -0.5), // copied, lost more than won -> cold, stopped
    sling: R(12, 2, 0.1, 1), // 12 trades, up -> neutral (needs 20 for hot)
    few: R(6, 2, 0, 1), // 6 trades: not enough
    newbie: R(30, 20, 1, 3), // great but tracked under 2 days
    cupsey: R(30, 2, 7, 0.4), // copied: lost 7, won 2 -> stopped (Khalil: cupsey loses you 5)
    killua: R(30, 5, 5, 0), // copied, break-even -> stays, as neutral (Khalil: dilly +5 / -5 is okay)
  };
  const r = new Rotator({ file: file(), now: () => now, recent: (n) => res[n], traders: () => Object.keys(res), start: ['dilly', 'cupsey', 'killua'] });
  for (const n of Object.keys(res)) {
    if (n === 'newbie') continue;
    now -= 49 * H;
    r.seen(n);
    now += 49 * H;
  }
  r.seen('newbie');
  const out = r.run();
  assert.deepEqual(out.added.map((x) => x.name), ['t1']);
  assert.deepEqual(out.neutral.map((x) => x.name).sort(), ['killua', 'sling']);
  assert.deepEqual(out.proven.map((x) => x.name), ['schoen']);
  assert.equal(out.neutral.find((x) => x.name === 'killua').from, 'hot', 'killua was copied as hot before');
  assert.deepEqual(out.dropped.map((x) => x.name).sort(), ['cupsey', 'dilly'], 'lost more than they won: stopped');
  assert.deepEqual(r.copying.sort(), ['killua', 'schoen', 'sling', 't1']);
  assert.equal(r.tier('t1'), 'hot');
  assert.equal(r.tier('schoen'), 'proven');
  assert.equal(r.tier('killua'), 'neutral');
  assert.equal(r.tier('dilly'), null);
  // schoen keeps winning -> hot (no waiting)
  res.schoen = R(30, 3, 1, 0.5);
  const o2 = r.run();
  assert.deepEqual(o2.added.map((x) => x.name), ['schoen']);
  assert.equal(r.tier('schoen'), 'hot');
  // a hot one that cools to break-even goes back to neutral; one that turns red is stopped
  res.t1 = R(30, 4, 4, 0);
  res.sling = R(14, 1, 2, -1);
  const o3 = r.run();
  assert.deepEqual(o3.neutral.map((x) => [x.name, x.from]), [['t1', 'hot']]);
  assert.deepEqual(o3.dropped.map((x) => x.name), ['sling']);
  // dilly back on track -> proven, then hot
  res.dilly = R(30, 3, 2.5, 0.5);
  assert.deepEqual(r.run().proven.map((x) => x.name), ['dilly']);
  assert.equal(r.tier('dilly'), 'proven');
  res.dilly = R(30, 9, 2, 3);
  assert.deepEqual(r.run().added.map((x) => x.name), ['dilly']);
  // newbie after 2 days
  now += 48 * H;
  assert.deepEqual(r.run().added.map((x) => x.name), ['newbie']);
  const st = r.statusText();
  assert.match(st, /Copying now<\/b> \(picked automatically\): 🔥 <b>[a-z, ]+<\/b> · 🟡 /);
  assert.match(st, /<b>t1<\/b>: 🟡 neutral — copied smaller/);
  assert.match(st, /<b>dilly<\/b>: 🔥 hot — copied · last 30: \+7\.000 \(won \+9\.000, lost -2\.000\)/);
  assert.match(st, /<b>few<\/b>: ⚪ not enough trades yet \(6\/10\)/);
  assert.match(st, /<b>cupsey<\/b>: 🧊 cold/);
  // restart keeps the picks and tiers
  const again = new Rotator({ file: r.file, recent: (n) => res[n], traders: () => Object.keys(res) });
  assert.deepEqual(again.copying.sort(), r.copying.sort());
  assert.equal(again.tier('t1'), 'neutral');
});

test('V2.11.2 an old rotate file (before tiers): everyone copied counts as hot; one copied with under 10 trades keeps his tier', () => {
  const f = file();
  fs.writeFileSync(f, JSON.stringify({ on: true, copying: ['dilly'], firstSeen: { dilly: 1 }, log: [] }));
  const r = new Rotator({ file: f, recent: () => R(4, 0.1, 0.2, 0), traders: () => ['dilly'] });
  assert.equal(r.tier('dilly'), 'hot');
  r.run();
  assert.equal(r.tier('dilly'), 'hot', 'not enough trades to judge: kept as he was');
});

test('ghost lastTrades: his last 30 coins, all 4 pretend wallets, winners vs losers, newest 10', () => {
  let now = 5_000_000;
  const g = new GhostBook({ file: file(), now: () => now, fee: 0, entryPenaltyPct: 0 });
  // 35 coins: the 5 oldest are big losers (outside the last 30), then 25 winners, then 5 losers
  const run = (i, exit) => {
    g.open('t1', `M${i}`, 1);
    now += 1000;
    g.price(`M${i}`, exit);
    g.hisSell('t1', `M${i}`, 100, true);
  };
  for (let i = 0; i < 5; i++) run(i, 0.5);
  for (let i = 5; i < 30; i++) run(i, 1.2);
  for (let i = 30; i < 35; i++) run(i, 0.9);
  const r = g.lastTrades('t1', 30);
  assert.equal(r.coins, 30);
  assert.equal(r.won, 25);
  // a 1.2x coin: sides sold at +25%? no (1.2 < 1.25) -> all 4 sold at his exit: 0.1*0.2 + 3*0.05*(1.2/1.02-1)
  const win = 0.1 * 0.2 + 3 * 0.05 * (1.2 / 1.02 - 1);
  const loss = 0.1 * 0.1 + 3 * 0.05 * (1 - 0.9 / 1.02);
  assert.ok(Math.abs(r.gains - 25 * win) < 1e-4, `${r.gains}`);
  assert.ok(Math.abs(r.losses - 5 * loss) < 1e-4, `${r.losses}`);
  assert.ok(r.last10 < r.pnl, 'newest 10 include the 5 losers');
});

test("V2.11.1 wallets sent tonight don't wait; after that new wallets wait 2 days again", async () => {
  const { loadConfig } = await import('../src/config.js');
  const f = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'cfg-')), 'settings.txt');
  fs.writeFileSync(f, 'TELEGRAM_BOT_TOKEN=1:x\n');
  const cfg = loadConfig(f);
  assert.equal(cfg.copy.rotateNewMs, 48 * H);
  assert.equal(cfg.copy.rotateNoWaitUntil, Date.parse('2026-11-13T04:13:00Z'));
  let now = Date.parse('2026-11-13T02:10:00Z'); // Nov 12, 9:10pm ET
  const res = { t1: R(20, 3, 1, 1), t2: R(20, 3, 1, 1) };
  const r = new Rotator({ file: file(), now: () => now, recent: (n) => res[n], traders: () => ['t1', 't2'], newMs: cfg.copy.rotateNewMs, noWaitUntil: cfg.copy.rotateNoWaitUntil });
  r.seen('t1'); // sent tonight
  now = Date.parse('2026-11-14T15:00:00Z');
  r.seen('t2'); // sent the day after
  assert.deepEqual(r.run().added.map((x) => x.name), ['t1'], 'tonight: no wait; later: 2 days');
  assert.match(r.statusText(), /<b>t2<\/b>: 🆕 new — usable in 48h/);
});

test('V2.11.3 wallets Khalil sent (t1 ...) are followed even with an older settings.txt TRADERS list', async () => {
  const { loadConfig } = await import('../src/config.js');
  const f = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'cfg-')), 'settings.txt');
  fs.writeFileSync(f, 'TELEGRAM_BOT_TOKEN=1:x\nTRADERS=dilly:G9gmk9msvd6wT4hDJFm64vKra5z82YvD9je9WqjBvnuk\n');
  const cfg = loadConfig(f);
  assert.ok(cfg.traders.some((t) => t.name === 'henry' && t.wallets.includes('CuDe51GPh5qGsmYBJDxSsufhQQhA618uDbkaXFZ4pztL')));
  assert.equal(cfg.traderOf('CuDe51GPh5qGsmYBJDxSsufhQQhA618uDbkaXFZ4pztL'), 'henry', 't1 is henry (Khalil)');
  assert.ok(cfg.wallets.includes('CuDe51GPh5qGsmYBJDxSsufhQQhA618uDbkaXFZ4pztL'));
  assert.equal(cfg.traderOf('FPrWHsHS2SVqSpCZrsdqfiND2un8d4rQN1tNQJ8febNs'), 't2');
});

test('V2.11.4 farmers (cupsey, t3): 100+ holders and under $40k market cap, even when settings.txt has older lines', async () => {
  const { loadConfig } = await import('../src/config.js');
  const f = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'cfg-')), 'settings.txt');
  fs.writeFileSync(f, 'TELEGRAM_BOT_TOKEN=1:x\nTRADER_MIN_HOLDERS=bot:20\nTRADER_MAX_MC=\n');
  const cfg = loadConfig(f);
  assert.equal(cfg.traderOf('CyaE1VxvBrahnPWkqm5VsdCvyS2QmNht2UFrKJHga54o'), 't3');
  assert.equal(cfg.copy.traderMinHolders.t3, 100);
  assert.equal(cfg.copy.traderMinHolders.cupsey, 100);
  assert.equal(cfg.copy.traderMinHolders.bot, 20);
  assert.equal(cfg.copy.traderMaxMc.t3, 40000);
  assert.equal(cfg.copy.traderMaxMc.cupsey, 40000);
  assert.equal(cfg.copy.traderMaxMc.t1, undefined);
  assert.ok(cfg.chainOnlyWallets.includes('CyaE1VxvBrahnPWkqm5VsdCvyS2QmNht2UFrKJHga54o'), 'chain only: no pump.fun feeds');
  assert.ok(!cfg.chainOnlyWallets.includes('G9gmk9msvd6wT4hDJFm64vKra5z82YvD9je9WqjBvnuk'));
  assert.equal(cfg.copy.traderMinHolders.t27, 100, 't27 is a farmer too');
  assert.equal(Array.from({ length: 48 }, (_, i) => cfg.traders.find((t) => t.name === (i ? `t${i + 1}` : 'henry'))?.wallets.length).filter((n) => n === 1).length, 48, 'all 48 wallets you sent are followed');
});

test('V2.11.5 a trader cold 7 days in a row is marked for removal; any good stretch resets the clock', () => {
  let now = 1000 * H;
  const res = { t5: R(30, 1, 4, -1), t6: R(30, 1, 4, -1) };
  const r = new Rotator({ file: file(), now: () => now, recent: (n) => res[n], traders: () => ['t5', 't6'], newMs: 0, retireMs: 7 * 24 * H });
  assert.deepEqual(r.run().retire, []);
  now += 4 * 24 * H;
  res.t6 = R(30, 3, 2, 1); // t6 has a good stretch (neutral)
  r.run();
  res.t6 = R(30, 1, 4, -1);
  now += 3 * 24 * H;
  assert.deepEqual(r.run().retire.map((x) => x.name), ['t5'], 't5: 7 days cold; t6 cold again only 3 days');
  assert.ok(r.run().retire.every((x) => x.coldMs >= 7 * 24 * H));
  assert.deepEqual(new Rotator({ file: file(), recent: (n) => res[n], traders: () => ['t5'], newMs: 0 }).run().retire, [], 'retireMs 0: never');
});

test('V2.11.8 decu: on, normal sizes (even with an old settings.txt), and a farmer', async () => {
  const { loadConfig } = await import('../src/config.js');
  const f = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'cfg-')), 'settings.txt');
  fs.writeFileSync(f, 'TELEGRAM_BOT_TOKEN=1:x\nTRADER_BUY_SOL=decu:0.05\n');
  const cfg = loadConfig(f);
  assert.equal(cfg.copy.traderBuySol.decu, undefined, 'normal wallet sizes');
  assert.deepEqual(cfg.copy.tradersOffDefault, []);
  assert.equal(cfg.copy.traderMinHolders.decu, 100);
  assert.equal(cfg.copy.traderMaxMc.decu, 40000);
  assert.equal(cfg.targetOnlyAlerts, true);
});

test('V2.11.9 up to 10 side wallets: wallet-key-2.txt ... wallet-key-11.txt, even with an older settings.txt that lists 2-4', async () => {
  const { quickKeyFiles } = await import('../src/config.js');
  const ten = Array.from({ length: 10 }, (_, i) => `wallet-key-${i + 2}.txt`);
  assert.deepEqual(quickKeyFiles('wallet-key-2.txt,wallet-key-3.txt,wallet-key-4.txt'), ten);
  assert.deepEqual(quickKeyFiles(ten.join(',')), ten);
  assert.deepEqual(quickKeyFiles('my-side.txt'), ['my-side.txt'], 'your own list is kept as is');
});

test('V2.11.14 short trader list: one line each, best first, no-trade ones counted', () => {
  const res = { t3: R(28, 4, 0.56, 1), bot: R(30, 0.6, 1.3, -0.2), t9: R(8, 0.5, 0.2, 0.1), t11: R(0, 0, 0, 0), t12: R(0, 0, 0, 0), dilly: R(30, 0.85, 0.5, 0.1) };
  const r = new Rotator({ file: file(), recent: (n) => res[n], traders: () => Object.keys(res), newMs: 0, start: [] });
  r.run();
  assert.equal(r.compactText(), ['👻 <b>Traders</b> (last 30 pretend trades)', '🔥 <b>t3</b> +3.44 (28)', '✅ <b>dilly</b> +0.35 (30)', '⚪ <b>t9</b> +0.30 (8)', '🧊 <b>bot</b> -0.70 (30)', '⚪ 2 more with no trades yet'].join('\n'));
});
