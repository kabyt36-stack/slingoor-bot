// V2.7 paper trading: everything works like the real bot (same signals, same rules, same timing) but
// no transaction is ever sent. Buys and sells are filled at REAL Jupiter quotes at that moment, against
// fake balances that reset to PAPER_START_SOL every time paper mode is turned on.
import fs from 'node:fs';
import path from 'node:path';
import { log } from './log.js';
import { chaseCheck } from './copytrade.js';

const SOL_MINT = 'So11111111111111111111111111111111111111112';
const FEE_SOL = 0.0001; // fallback fee per trade when the real priority-fee cap isn't known
const RENT_SOL = 0.00203928; // a new coin account costs this; the real bot gets it back after selling out
// Real trades land ~1s after the bot decides; the price can move in between. Paper waits the same
// time and fills at the price THEN, and fails like a real trade would if it moved past the slippage.
// V2.8.8: 1.5s, the slow end of what real trades take (sent + landed), so paper never fills faster than real
const LAND_MS = Math.max(0, +(process.env.PAPER_LAND_MS ?? 1500));
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// PAPER_START_SOL: label:SOL, comma separated (main, W2, W3...)
export function parseStart(text) {
  const out = {};
  for (const p of String(text || '').split(/[\s,]+/).filter(Boolean)) {
    const [k, v] = p.split(':');
    if (k && +v >= 0) out[k.trim()] = +v;
  }
  return out;
}

export class PaperBook {
  constructor(file) {
    this.file = file;
    this.d = { wallets: {}, startedAt: null, start: {} };
    try {
      this.d = { ...this.d, ...JSON.parse(fs.readFileSync(file, 'utf8')) };
    } catch {}
  }

  save() {
    try {
      fs.mkdirSync(path.dirname(this.file), { recursive: true });
      fs.writeFileSync(this.file + '.tmp', JSON.stringify(this.d));
      fs.renameSync(this.file + '.tmp', this.file);
    } catch (err) {
      log.warn('paper book save failed', err.message);
    }
  }

  // every time paper mode is switched on: back to the starting amounts, no coins
  reset(start) {
    this.d = { wallets: {}, startedAt: Date.now(), start: { ...start } };
    for (const [label, sol] of Object.entries(start)) this.d.wallets[label] = { sol, tokens: {} };
    this.save();
  }

  w(label) {
    return (this.d.wallets[label] ||= { sol: this.d.start?.[label] ?? 0, tokens: {} });
  }

  // V2.11.10 a SOL transfer between two paper wallets, like a real one (network fee 0.000005 SOL)
  transfer(from, to, sol, fee = 0.000005) {
    const a = this.w(from);
    if (!(sol > 0) || a.sol < sol + fee) return false;
    a.sol = Math.round((a.sol - sol - fee) * 1e9) / 1e9;
    const b = this.w(to);
    b.sol = Math.round((b.sol + sol) * 1e9) / 1e9;
    (this.d.transfers ||= []).push({ from, to, sol, at: Date.now() });
    if (this.d.transfers.length > 500) this.d.transfers.splice(0, this.d.transfers.length - 500);
    this.save();
    return true;
  }

  // V2.11.10 main = bank: every side wallet above its starting SOL sends the extra (its profit) to main and
  // keeps trading with its starting amount. Returns [{ label, sol }] of what moved.
  // V2.11.35 a side wallet with less SOL than `below` is topped back up to its starting SOL from main, as long as
  // main keeps at least `keep` (its own starting SOL). Returns [{ label, sol }] of what moved.
  refill(labels, { below, keep = 0, fee = 0.000005, from = 'main' } = {}) {
    const moved = [];
    for (const l of labels) {
      const start = this.d.start?.[l];
      const have = this.d.wallets[l]?.sol ?? 0;
      if (!(start > 0) || !(have < below)) continue;
      const need = Math.round((start - have) * 1e6) / 1e6;
      const spare = (this.d.wallets[from]?.sol ?? 0) - keep - fee;
      const sol = Math.floor(Math.min(need, spare) * 1e6) / 1e6;
      if (sol >= 0.01 && this.transfer(from, l, sol, fee)) moved.push({ label: l, sol });
    }
    return moved;
  }

  bankProfits(labels, { minSol = 0.01, fee = 0.000005, to = 'main' } = {}) {
    const moved = [];
    for (const l of labels) {
      const start = this.d.start?.[l];
      const have = this.d.wallets[l]?.sol;
      if (!(start >= 0) || !(have > 0)) continue;
      const extra = Math.floor((have - start - fee) * 1e6 + 1e-6) / 1e6; // (+1e-6: float rounding)
      if (extra >= minSol && this.transfer(l, to, extra, fee)) moved.push({ label: l, sol: extra });
    }
    return moved;
  }
}

// Stands in for the RPC for OUR wallet's balances; everything else goes to the real RPC.
export class PaperRpc {
  constructor(rpc, book, label, owner) {
    this.real = rpc;
    this.book = book;
    this.label = label;
    this.owner = owner;
  }

  get maxTxVersion() {
    return this.real.maxTxVersion;
  }

  async getTokenBalance(owner, mint, ...rest) {
    if (owner !== this.owner) return this.real.getTokenBalance(owner, mint, ...rest);
    const t = this.book.w(this.label).tokens[mint];
    return t ? { ui: t.ui, raw: t.raw, decimals: t.decimals } : { ui: 0, raw: '0', decimals: 6 };
  }

  getTransaction(sig, opts) {
    if (String(sig).startsWith('paper-')) return Promise.resolve(null);
    return this.real.getTransaction(sig, opts);
  }

  async call(method, params = [], opts) {
    if (method === 'getBalance' && params[0] === this.owner) return { value: Math.round(this.book.w(this.label).sol * 1e9) };
    if (method === 'getTokenAccountsByOwner' && params[0] === this.owner) {
      const value = [];
      for (const [mint, t] of Object.entries(this.book.w(this.label).tokens)) {
        if (params[1]?.mint && params[1].mint !== mint) continue;
        if (params[1]?.programId && t.programId && params[1].programId !== t.programId) continue;
        value.push({ pubkey: `paper-${mint.slice(0, 20)}`, account: { lamports: 0, data: { parsed: { info: { mint, owner: this.owner, state: 'initialized', tokenAmount: { amount: String(t.raw), decimals: t.decimals, uiAmount: t.ui } } } } } });
      }
      return { value };
    }
    if (method === 'sendTransaction') return `paper-${Date.now()}`;
    return this.real.call(method, params, opts);
  }
}

// Stands in for the Swapper: fills at real Jupiter quotes, never sends anything.
export class PaperSwapper {
  constructor(real, book, label, rpc, { landMs = LAND_MS, curve = null } = {}) {
    this.landMs = landMs;
    // V2.11.15 (mint) -> { vs, vt } pump.fun bonding-curve reserves (lamports, raw tokens) or null. When Jupiter has
    // no route, the real bot trades on the curve through PumpPortal — paper does the same with the curve math,
    // instead of getting stuck ("COPY SELL DELAYED") on coins the real bot can sell.
    this.curve = curve;
    this.real = real;
    this.book = book;
    this.label = label;
    this.rpc = rpc; // the real RPC (token decimals)
    this.dec = new Map();
    this.n = 0;
  }

  get kp() {
    return this.real.kp;
  }

  // V2.8.8: every paper trade pays the most the real bot can pay: its priority-fee cap + the base network fee
  // (was a flat 0.0001, lower than real trades usually cost)
  get fee() {
    const p = this.real?.priorityFee;
    return p > 0 ? p + 0.000005 : FEE_SOL;
  }

  async decimals(mint) {
    if (this.dec.has(mint)) return this.dec.get(mint);
    const r = await this.rpc.call('getTokenSupply', [mint]).catch(() => null);
    const d = r?.value?.decimals ?? 6;
    this.dec.set(mint, d);
    return d;
  }

  build() {
    return Promise.resolve(null); // nothing to pre-build
  }

  async send() {
    return { sig: `paper-${Date.now()}-${++this.n}`, ms: 0 };
  }

  // V2.11.15 coins Jupiter can't price: valued on the bonding curve (like the sell would be)
  async quoteSellSol(mint, raw) {
    const v = await Promise.resolve(this.real.quoteSellSol(mint, raw)).catch((err) => (err?.noRoute ? null : Promise.reject(err)));
    if (v != null) return v;
    const q = await this._curveFill({ noRoute: true }, { mint, side: 'sell', amountIn: raw }).catch(() => null);
    return q ? Number(q.outAmount) / 1e9 : null;
  }

  // V2.11.15 Jupiter has no route: fill on the pump.fun bonding curve like PumpPortal would (1.25% fees)
  async _curveFill(err, { mint, side, amountIn }) {
    if (!err?.noRoute || !this.curve) throw err;
    const c = await Promise.resolve(this.curve(mint)).catch(() => null);
    if (!c || !(c.vs > 0n) || !(c.vt > 0n)) throw err;
    const inAfterFee = (BigInt(amountIn) * 9875n) / 10000n;
    const out = side === 'buy' ? (c.vt * inAfterFee) / (c.vs + inAfterFee) : (c.vs * inAfterFee) / (c.vt + inAfterFee);
    if (!(out > 0n)) throw err;
    return { outAmount: String(out), curve: true };
  }

  // quote now (what the real bot would sign), then the fill price ~1s later (when it would land)
  async _fill(q1url, slipPct, check = null, curveReq = null) {
    let q1;
    try {
      q1 = await this.real._jup(q1url).then((q) => {
        if (!q?.outAmount) throw Object.assign(new Error('no route (paper quote)'), { noRoute: true });
        return q;
      });
    } catch (err) {
      if (!curveReq) throw err;
      const q = await this._curveFill(err.noRoute ? err : Object.assign(err, { noRoute: /route|TRADABLE|tradable/i.test(err.message) }), curveReq);
      check?.(q);
      return q;
    }
    if (!q1?.outAmount) throw Object.assign(new Error('no route (paper quote)'), { noRoute: true });
    check?.(q1); // V2.9.6 the same don't-chase check the real bot makes on its quote
    if (!this.landMs) return q1;
    await sleep(this.landMs);
    const q2 = await this.real._jup(q1url).catch(() => q1);
    const out2 = BigInt(q2?.outAmount || q1.outAmount);
    const min = (BigInt(q1.outAmount) * BigInt(Math.round((100 - slipPct) * 100))) / 10000n;
    if (out2 < min) throw Object.assign(new Error('transaction failed on-chain: price moved more than your slippage (paper)'), { onChain: true, paperSlip: true });
    return { ...q2, outAmount: String(out2) };
  }

  async trade(req) {
    const { action, mint, amount, slippage } = req;
    const t0 = Date.now();
    const w = this.book.w(this.label);
    const slipPct = slippage || this.real.slippage || 10;
    const slip = `slippageBps=${Math.round(slipPct * 100)}`;
    if (action === 'buy') {
      const sol = +amount;
      if (!(sol > 0)) throw new Error('bad buy amount');
      const newAcct = !w.tokens[mint];
      const cost = sol + this.fee + (newAcct ? RENT_SOL : 0);
      if (w.sol < cost) throw Object.assign(new Error(`paper wallet ${this.label} has only ${w.sol.toFixed(3)} SOL`), { noFunds: true });
      let q;
      try {
        q = await this._fill(`/quote?inputMint=${SOL_MINT}&outputMint=${mint}&amount=${Math.round(sol * 1e9)}&${slip}&restrictIntermediateTokens=true`, slipPct, (q1) => chaseCheck(req, { inAmount: Math.round(sol * 1e9), outAmount: +q1.outAmount }), { mint, side: 'buy', amountIn: Math.round(sol * 1e9) });
      } catch (err) {
        if (err.paperSlip) {
          w.sol -= this.fee; // a failed real transaction still pays its fee
          this.book.save();
        }
        throw err;
      }
      const d = await this.decimals(mint);
      const raw = BigInt(q.outAmount);
      const ui = Number(raw) / 10 ** d;
      const cur = w.tokens[mint] || { raw: '0', ui: 0, decimals: d };
      w.tokens[mint] = { raw: String(BigInt(cur.raw) + raw), ui: cur.ui + ui, decimals: d };
      w.sol -= cost;
      this.book.save();
      // like the real bot's numbers: the account rent is not part of the trade price
      return { sig: `paper-${Date.now()}-${++this.n}`, solDelta: -(sol + this.fee), tokenDelta: ui, ms: Date.now() - t0, venue: 'paper', sentAt: t0 };
    }
    // sell: "50%" of what this paper wallet holds
    const cur = w.tokens[mint];
    if (!cur || BigInt(cur.raw) <= 0n) throw Object.assign(new Error('nothing to sell (paper)'), { nothing: true });
    const pct = Math.min(100, Math.max(1, parseFloat(String(amount)) || 100));
    const raw = pct >= 100 ? BigInt(cur.raw) : (BigInt(cur.raw) * BigInt(Math.round(pct * 100))) / 10000n;
    let q;
    try {
      q = await this._fill(`/quote?inputMint=${mint}&outputMint=${SOL_MINT}&amount=${raw}&${slip}&restrictIntermediateTokens=true`, slipPct, null, { mint, side: 'sell', amountIn: raw });
    } catch (err) {
      if (err.paperSlip) {
        w.sol -= this.fee;
        this.book.save();
      }
      throw err;
    }
    const got = Number(q.outAmount) / 1e9 - this.fee;
    const left = BigInt(cur.raw) - raw;
    const ui = Number(raw) / 10 ** cur.decimals;
    if (left > 0n) w.tokens[mint] = { raw: String(left), ui: Math.max(0, cur.ui - ui), decimals: cur.decimals };
    else delete w.tokens[mint];
    // sold out: the real bot closes the empty account and gets the rent back
    w.sol += got + (left > 0n ? 0 : RENT_SOL);
    this.book.save();
    return { sig: `paper-${Date.now()}-${++this.n}`, solDelta: got, tokenDelta: -ui, ms: Date.now() - t0, venue: 'paper', sentAt: t0 };
  }
}

// End-of-day report for paper (and real) trading: per trader, rating and a replace hint
export function traderReport(trips, { sign }) {
  const by = {};
  for (const t of trips) {
    const k = t.leader || '?';
    const r = (by[k] ||= { n: 0, won: 0, pnl: 0, best: -Infinity, worst: Infinity });
    r.n++;
    if (t.pnl > 0) r.won++;
    r.pnl += t.pnl;
    r.best = Math.max(r.best, t.pnl);
    r.worst = Math.min(r.worst, t.pnl);
  }
  const rate = (r) => {
    const wr = r.n ? r.won / r.n : 0;
    if (r.pnl > 0 && wr >= 0.6) return 'A';
    if (r.pnl > 0 && wr >= 0.45) return 'B';
    if (r.pnl > 0) return 'C';
    if (wr >= 0.4) return 'D';
    return 'F';
  };
  const lines = [];
  const ranked = Object.entries(by).sort((a, b) => b[1].pnl - a[1].pnl);
  for (const [name, r] of ranked) {
    const g = rate(r);
    const hint = g === 'F' && r.n >= 3 ? ' → consider replacing' : g === 'D' && r.n >= 5 ? ' → watch closely' : '';
    lines.push(`${g === 'A' ? '🟢' : g === 'B' ? '🟡' : g === 'C' ? '🟠' : '🔴'} <b>${name}</b> [${g}] ${sign(r.pnl)} SOL · ${r.won}/${r.n} won${hint}`);
  }
  return { lines, ranked };
}
