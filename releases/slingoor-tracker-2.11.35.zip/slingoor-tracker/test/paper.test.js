import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
process.env.PAPER_LAND_MS = '0';
const { PaperBook, PaperRpc, PaperSwapper, traderReport } = await import('../src/paper.js');

const tmp = () => path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'paper-')), 'book.json');
const SOLM = 'So11111111111111111111111111111111111111112';

function setup() {
  const book = new PaperBook(tmp());
  book.reset({ main: 0.5, W2: 0.2 });
  const sent = [];
  const realRpc = { call: async (m) => (m === 'sendTransaction' ? sent.push(1) : m === 'getTokenSupply' ? { value: { decimals: 6 } } : null), getTokenBalance: async () => ({ ui: 999 }) };
  let pricePerTokenSol = 0.000001; // 1 SOL = 1M tokens
  const real = {
    slippage: 10,
    kp: { publicKey: 'ME' },
    _jup: async (q) => {
      const p = new URLSearchParams(q.split('?')[1]);
      const amt = Number(p.get('amount'));
      if (p.get('inputMint') === SOLM) return { outAmount: String(Math.floor((amt / 1e9 / pricePerTokenSol) * 1e6)) };
      return { outAmount: String(Math.floor((amt / 1e6) * pricePerTokenSol * 1e9)) };
    },
    quoteSellSol: async () => null,
  };
  return { book, rpc: new PaperRpc(realRpc, book, 'main', 'ME'), sw: new PaperSwapper(real, book, 'main', realRpc), sent, setPx: (v) => (pricePerTokenSol = v) };
}

test('paper: buys and sells fill at real quotes against the fake balance; nothing is ever sent', async () => {
  const { book, rpc, sw, sent, setPx } = setup();
  const b = await sw.trade({ action: 'buy', mint: 'C1', amount: 0.1 });
  assert.ok(Math.abs(b.solDelta + 0.1001) < 1e-9);
  assert.ok(Math.abs(b.tokenDelta - 100000) < 1e-6);
  assert.ok(Math.abs((await rpc.call('getBalance', ['ME'])).value / 1e9 - (0.3999 - 0.00203928)) < 1e-6, 'main paper SOL went down (incl. new account rent)');
  assert.equal((await rpc.getTokenBalance('ME', 'C1')).ui, 100000);
  assert.equal((await rpc.getTokenBalance('OTHER', 'C1')).ui, 999, 'other wallets: real RPC');
  setPx(0.000002); // price doubled
  const s1 = await sw.trade({ action: 'sell', mint: 'C1', amount: '50%' });
  assert.ok(Math.abs(s1.solDelta - (0.1 - 0.0001)) < 1e-9);
  const s2 = await sw.trade({ action: 'sell', mint: 'C1', amount: '100%' });
  assert.ok(s2.solDelta > 0);
  assert.equal((await rpc.getTokenBalance('ME', 'C1')).ui, 0);
  assert.ok(book.w('main').sol > 0.5, 'doubled: paper profit');
  assert.ok(Math.abs(book.w('main').sol - (0.5 - 0.1001 + 0.0999 + 0.0999)) < 1e-6, 'rent came back after selling out');
  assert.equal(sent.length, 0);
  assert.equal((await rpc.call('getBalance', ['ME'])).value > 0, true);
});

test('paper: not enough fake SOL -> the buy fails; reset puts every wallet back to its starting amount', async () => {
  const { book, sw } = setup();
  await assert.rejects(sw.trade({ action: 'buy', mint: 'C2', amount: 0.9 }), /only 0\.500 SOL/);
  book.w('main').sol = 0.01;
  book.reset({ main: 0.5, W2: 0.2, W3: 0.2, W4: 0.1 });
  assert.deepEqual(Object.fromEntries(Object.entries(book.d.wallets).map(([k, v]) => [k, v.sol])), { main: 0.5, W2: 0.2, W3: 0.2, W4: 0.1 });
});

test('trader report card: rating per trader and a replace hint for losers', () => {
  const sign = (n) => `${n >= 0 ? '+' : '-'}${Math.abs(n).toFixed(3)}`;
  const trips = [
    ...[0.05, 0.04, 0.03, -0.01].map((pnl) => ({ leader: 'schoen', pnl })),
    ...[-0.02, -0.03, -0.01].map((pnl) => ({ leader: 'killua', pnl })),
  ];
  const { lines } = traderReport(trips, { sign });
  assert.match(lines[0], /schoen<\/b> \[A\] \+0\.110 SOL · 3\/4 won/);
  assert.match(lines[1], /killua<\/b> \[F\] -0\.060 SOL · 0\/3 won → consider replacing/);
});

test('paper fills like a real trade: price ~1s later, fails past slippage (fee still paid), rent on new coin', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'pp-'));
  const book = new PaperBook(path.join(dir, 'b.json'));
  book.reset({ main: 1 });
  let outs = [];
  const real = { slippage: 10, _jup: async () => ({ outAmount: String(outs.shift()) }), kp: null };
  const rpc = { call: async () => ({ value: { decimals: 6 } }) };
  const sw = new PaperSwapper(real, book, 'main', rpc, { landMs: 5 });
  // moved 5% against us: still inside 10% slippage, filled at the later (worse) price
  outs = [1_000_000, 950_000];
  const r = await sw.trade({ action: 'buy', mint: 'M', amount: 0.1 });
  assert.equal(book.w('main').tokens.M.raw, '950000');
  assert.ok(Math.abs(book.w('main').sol - (1 - 0.1001 - 0.00203928)) < 1e-9);
  assert.ok(Math.abs(r.solDelta + 0.1001) < 1e-9);
  // moved 20%: fails on-chain like the real one, only the fee is lost
  outs = [1_000_000, 800_000];
  const before = book.w('main').sol;
  await assert.rejects(sw.trade({ action: 'buy', mint: 'M', amount: 0.1 }), (e) => e.onChain && /slippage/.test(e.message));
  assert.ok(Math.abs(book.w('main').sol - (before - 0.0001)) < 1e-9);
  // retry with bigger slippage (what the bot does) goes through
  outs = [1_000_000, 800_000];
  await sw.trade({ action: 'buy', mint: 'M', amount: 0.1, slippage: 25 });
  assert.equal(book.w('main').tokens.M.raw, '1750000');
});

test('V2.8.8 paper pays the real fee cap on every trade (not a flat 0.0001)', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'pf-'));
  const book = new PaperBook(path.join(dir, 'b.json'));
  book.reset({ main: 1 });
  const real = { slippage: 10, priorityFee: 0.0005, _jup: async () => ({ outAmount: '1000000' }), kp: null };
  const sw = new PaperSwapper(real, book, 'main', { call: async () => ({ value: { decimals: 6 } }) }, { landMs: 0 });
  const b = await sw.trade({ action: 'buy', mint: 'M', amount: 0.1 });
  assert.ok(Math.abs(b.solDelta + 0.100505) < 1e-9, `${b.solDelta}`);
  const s1 = await sw.trade({ action: 'sell', mint: 'M', amount: '100%' });
  assert.ok(Math.abs(s1.solDelta - (1e6 / 1e9 - 0.000505)) < 1e-9);
});

test('V2.9.6 paper makes the same don\'t-chase check as real (no paper buy above his price + 15%)', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'pc-'));
  const book = new PaperBook(path.join(dir, 'b.json'));
  book.reset({ main: 1 });
  const real = { slippage: 10, _jup: async () => ({ outAmount: String(800000e6) }), kp: null };
  const sw = new PaperSwapper(real, book, 'main', { call: async () => ({ value: { decimals: 6 } }) }, { landMs: 0 });
  await assert.rejects(sw.trade({ action: 'buy', mint: 'M', amount: 0.1, maxPriceSol: 1.15e-7, chasePct: 15 }), (e) => e.chased);
  assert.equal(book.w('main').sol, 1, 'nothing spent');
  real._jup = async () => ({ outAmount: String(950000e6) });
  await sw.trade({ action: 'buy', mint: 'M', amount: 0.1, maxPriceSol: 1.15e-7, chasePct: 15 });
  assert.ok(book.w('main').tokens.M);
});

test('V2.11.10 paper transfers: like a real one (fee); bank: side wallets send main what they made above their start', async () => {
  const { PaperBook } = await import('../src/paper.js');
  const b = new PaperBook(path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'pb-')), 'b.json'));
  b.reset({ main: 0, W2: 0.1, W3: 0.1, W4: 0.1 });
  b.w('W2').sol = 0.3;
  b.w('W3').sol = 0.105;
  b.w('W4').sol = 0.05; // lost money: nothing to send
  const moved = b.bankProfits(['W2', 'W3', 'W4']);
  assert.deepEqual(moved, [{ label: 'W2', sol: 0.199995 }]);
  assert.ok(Math.abs(b.w('W2').sol - 0.1) < 1e-9, 'W2 back to its starting 0.1');
  assert.ok(Math.abs(b.w('main').sol - 0.199995) < 1e-9);
  assert.equal(b.transfer('W4', 'main', 1), false, "can't send more than it has");
  assert.equal(b.d.transfers.length, 1);
});

test('V2.11.15 paper: coin Jupiter has no route for is bought / sold on the pump.fun curve (like PumpPortal), not stuck', async () => {
  const { PaperBook, PaperSwapper } = await import('../src/paper.js');
  const book = new PaperBook(path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'pb-')), 'b.json'));
  book.reset({ W2: 0.2 });
  const noRoute = async () => {
    throw Object.assign(new Error('Jupiter 400: TOKEN_NOT_TRADABLE'), { noRoute: true });
  };
  const real = { _jup: noRoute, quoteSellSol: noRoute, slippage: 10, priorityFee: 0.0001 };
  const rpc = { call: async () => ({ value: { decimals: 6 } }) };
  const curve = { vs: 30_000_000_000n, vt: 1_073_000_000_000_000n }; // a fresh pump.fun curve
  const sw = new PaperSwapper(real, book, 'W2', rpc, { landMs: 0, curve: async () => curve });
  const b = await sw.trade({ action: 'buy', mint: 'PCAT', amount: 0.05 });
  const inAfterFee = (50_000_000n * 9875n) / 10000n;
  const tokens = (curve.vt * inAfterFee) / (curve.vs + inAfterFee);
  assert.ok(Math.abs(b.tokenDelta - Number(tokens) / 1e6) < 1e-6);
  const v = await sw.quoteSellSol('PCAT', book.w('W2').tokens.PCAT.raw);
  assert.ok(v > 0.04 && v < 0.05, `valued on the curve: ${v}`);
  const s2 = await sw.trade({ action: 'sell', mint: 'PCAT', amount: '100%' });
  assert.ok(s2.solDelta > 0.04, `sold on the curve: ${s2.solDelta}`);
  assert.equal(book.w('W2').tokens.PCAT, undefined);
  // graduated / unknown coin (no curve): still no route, like the real bot
  const sw2 = new PaperSwapper(real, book, 'W2', rpc, { landMs: 0, curve: async () => null });
  await assert.rejects(sw2.trade({ action: 'buy', mint: 'X', amount: 0.05 }), /TOKEN_NOT_TRADABLE/);
});

test('V2.11.35 refill: a side wallet too low to buy is topped back up to its start from main; main keeps its own start', async () => {
  const { PaperBook } = await import('../src/paper.js');
  const f = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'pb-')), 'b.json');
  const b = new PaperBook(f);
  b.reset({ main: 0.2, W2: 0.25, W3: 0.25, W4: 0.25 });
  b.d.wallets.main.sol = 0.5;
  b.d.wallets.W2.sol = 0.1;
  b.d.wallets.W3.sol = 0.2; // still enough for a buy
  b.d.wallets.W4.sol = 0.05;
  const m = b.refill(['W2', 'W3', 'W4'], { below: 0.125, keep: 0.2 });
  assert.deepEqual(m.map((x) => x.label), ['W2', 'W4']);
  assert.equal(m[0].sol, 0.15);
  assert.ok(m[1].sol > 0.149 && m[1].sol < 0.15, 'W4 gets what main can spare (main stays at its 0.2 start)');
  assert.equal(b.d.wallets.W2.sol, 0.25);
  assert.ok(b.d.wallets.main.sol >= 0.2, 'main keeps its start');
  assert.equal(b.d.wallets.W3.sol, 0.2, 'not touched');
});
