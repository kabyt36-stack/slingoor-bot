import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { Digest, URGENT_RE, oneLine } from '../src/digest.js';

const tmp = () => path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'dg-')), 'summary.json');
const at = (h, m) => new Date(2026, 10, 7, h, m, 5).getTime();

test('instant alerts: bot enters a coin, every sell it makes, failed sell, 8h warning, cooks; routine ones wait for the summary', () => {
  for (const s of ['🤖 <b>COPY SELL FAILED</b> <b>$X</b> ❌', '🤖 <b>COPY SELL DELAYED</b>', '⏰ <b>$X</b> gets sold in ~30 min (8h limit).', '🔥 <b>COOKED 3.1x</b> on', '🍳 <b>MINI COOK 1.95x — SOLD 50%</b>', '🤖 <b>COPY BUY</b> <b>$X</b> ✅\n💰 Spent', '🤖 <b>COPY BUY</b> <b>$X</b> ✅ (landed late)', '⏰ <b>8H UP — SOLD ALL</b> <b>$X</b> ✅\n💸 Got 0.07 SOL\n📊 Trip: in 0.09 → out 0.07', '🤖 <b>COPY SELL — ALL OUT</b> <b>$X</b> ✅\n📊 Trip: in', '🤖 <b>COPY SELL 50%</b> <b>$X</b> ✅\n👤 He sold ~50%\n💸 Got <b>0.05 SOL</b>\n👜 Still holding', '🎯 <b>TAKE PROFIT 4x — SOLD 25%</b> <b>$X</b> ✅\n📈 Up 4x\n💸 Got <b>0.1 SOL</b>', '🤖 <b>COPY SELL 40%</b> <b>$X</b> ✅ (landed late)'])
    assert.match(s, URGENT_RE, s);
  for (const s of ['⏳ <b>COPY BUY WAITING</b> <b>$X</b>', '🤖 <b>COPY BUY SKIPPED</b> <b>$X</b>', '⏭ <b>BOT SKIPPED</b>', '♻️ Got back <b>0.004 SOL</b>', '🤖 <b>COPY BUY FAILED</b>'])
    assert.doesNotMatch(s, URGENT_RE, s);
});

test('oneLine keeps the header and the money line, drops the address', () => {
  assert.equal(oneLine('🤖 <b>COPY BUY</b> <b>$X</b> ✅\n💰 Spent <b>0.1 SOL</b> → 1K tokens\n<code>MINT</code>'), '🤖 <b>COPY BUY</b> <b>$X</b> · 💰 Spent <b>0.1 SOL</b> → 1K tokens');
  assert.equal(oneLine('⏭ <b>BOT SKIPPED</b> <b>$Y</b>\n❓ Why: old coin\n<code>M</code>'), '⏭ <b>BOT SKIPPED</b> <b>$Y</b> · ❓ Why: old coin');
});

test('hourly summary: collects his trades per coin + bot actions, sends once at the start of the hour, survives a restart', async () => {
  const file = tmp();
  let now = at(9, 20);
  const sent = [];
  const mk = () => new Digest({ file, name: 'slingoor', send: async (h) => sent.push(h), status: async () => ['👛 Bot wallet: <b>0.66 SOL</b>'], now: () => now });
  let d = mk();
  assert.equal(await d.tick(), false, 'first run only starts collecting');
  d.trade({ kind: 'ENTRY', mint: 'A', sym: '$AAA', sol: 5, side: 'BUY' });
  d.trade({ kind: 'ADD', mint: 'A', sym: '$AAA', sol: 2, side: 'BUY' });
  d.trade({ kind: 'EXIT', mint: 'B', sym: '$B<b>', sol: 12, side: 'SELL' });
  d.note('🤖 <b>COPY BUY</b> <b>$AAA</b> ✅\n💰 Spent <b>0.1 SOL</b>\n<code>A</code>');
  d.launch('$NEW');
  now = at(9, 59);
  assert.equal(await d.tick(), false, 'not yet');
  d = mk(); // restart (auto-update) keeps what was collected
  now = at(10, 0);
  assert.equal(await d.tick(), true);
  assert.equal(await d.tick(), false, 'once per hour');
  assert.equal(sent.length, 1);
  const s = sent[0];
  assert.match(s, /Hourly summary/);
  assert.match(s, /\$AAA<\/b> new buy 7\.00 SOL \(2×\)/);
  assert.match(s, /\$B&lt;b&gt;<\/b> sold all \(12\.0 SOL\)/, 'symbols are escaped');
  assert.match(s, /Launched <b>\$NEW<\/b>/);
  assert.match(s, /COPY BUY<\/b> <b>\$AAA<\/b> · 💰 Spent/);
  assert.match(s, /Bot wallet: <b>0\.66 SOL/);
  now = at(11, 0);
  await d.tick();
  assert.match(sent[1], /no trades this hour/);
  assert.match(sent[1], /nothing to do this hour/);
});

test('hourly summary lists each trader separately (sling + cupsey)', async () => {
  const file = tmp();
  let now = at(9, 20);
  const sent = [];
  const d = new Digest({ file, name: 'slingoor', others: ['cupsey'], send: async (h) => sent.push(h), now: () => now });
  await d.tick();
  d.trade({ kind: 'ENTRY', mint: 'A', trader: 'cupsey', sym: '$CUP', sol: 3, side: 'BUY' });
  d.trade({ kind: 'ENTRY', mint: 'A', trader: 'slingoor', sym: '$CUP', sol: 1, side: 'BUY' });
  now = at(10, 0);
  await d.tick();
  const s = sent[0];
  assert.match(s, /👤 <b>slingoor<\/b>:\n• <b>\$CUP<\/b> new buy 1\.00 SOL/);
  assert.match(s, /👤 <b>cupsey<\/b>:\n• <b>\$CUP<\/b> new buy 3\.00 SOL/);
  now = at(11, 0);
  await d.tick();
  assert.match(sent[1], /slingoor: no trades this hour/);
  assert.match(sent[1], /cupsey: no trades this hour/);
});
