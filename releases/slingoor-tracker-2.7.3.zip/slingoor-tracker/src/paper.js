// V2.7 paper trading: everything works like the real bot (same signals, same rules, same timing) but
// no transaction is ever sent. Buys and sells are filled at REAL Jupiter quotes at that moment, against
// fake balances that reset to PAPER_START_SOL every time paper mode is turned on.
import fs from 'node:fs';
import path from 'node:path';
import { log } from './log.js';

const SOL_MINT = 'So11111111111111111111111111111111111111112';
const FEE_SOL = 0.0001; // network + priority fee per trade, roughly what the real bot pays

// PAPER_START_SOL: label:SOL, comma separated (main, W2, W3...)
export function parseStart(text) {
  const out = {};
  for (const p of String(text || '').split(/[\s,]+/).filter(Boolean)) {
    const [k, v] = p.split(':');
    if (k && +v >= 0) out[k.trim()] = +v;
  }
  return out;
}

export class PaperBook {
  constructor(file) {
    this.file = file;
    this.d = { wallets: {}, startedAt: null, start: {} };
    try {
      this.d = { ...this.d, ...JSON.parse(fs.readFileSync(file, 'utf8')) };
    } catch {}
  }

  save() {
    try {
      fs.mkdirSync(path.dirname(this.file), { recursive: true });
      fs.writeFileSync(this.file + '.tmp', JSON.stringify(this.d));
      fs.renameSync(this.file + '.tmp', this.file);
    } catch (err) {
      log.warn('paper book save failed', err.message);
    }
  }

  // every time paper mode is switched on: back to the starting amounts, no coins
  reset(start) {
    this.d = { wallets: {}, startedAt: Date.now(), start: { ...start } };
    for (const [label, sol] of Object.entries(start)) this.d.wallets[label] = { sol, tokens: {} };
    this.save();
  }

  w(label) {
    return (this.d.wallets[label] ||= { sol: this.d.start?.[label] ?? 0, tokens: {} });
  }
}

// Stands in for the RPC for OUR wallet's balances; everything else goes to the real RPC.
export class PaperRpc {
  constructor(rpc, book, label, owner) {
    this.real = rpc;
    this.book = book;
    this.label = label;
    this.owner = owner;
  }

  get maxTxVersion() {
    return this.real.maxTxVersion;
  }

  async getTokenBalance(owner, mint, ...rest) {
    if (owner !== this.owner) return this.real.getTokenBalance(owner, mint, ...rest);
    const t = this.book.w(this.label).tokens[mint];
    return t ? { ui: t.ui, raw: t.raw, decimals: t.decimals } : { ui: 0, raw: '0', decimals: 6 };
  }

  getTransaction(sig, opts) {
    if (String(sig).startsWith('paper-')) return Promise.resolve(null);
    return this.real.getTransaction(sig, opts);
  }

  async call(method, params = [], opts) {
    if (method === 'getBalance' && params[0] === this.owner) return { value: Math.round(this.book.w(this.label).sol * 1e9) };
    if (method === 'getTokenAccountsByOwner' && params[0] === this.owner) {
      const value = [];
      for (const [mint, t] of Object.entries(this.book.w(this.label).tokens)) {
        if (params[1]?.mint && params[1].mint !== mint) continue;
        if (params[1]?.programId && t.programId && params[1].programId !== t.programId) continue;
        value.push({ pubkey: `paper-${mint.slice(0, 20)}`, account: { lamports: 0, data: { parsed: { info: { mint, owner: this.owner, state: 'initialized', tokenAmount: { amount: String(t.raw), decimals: t.decimals, uiAmount: t.ui } } } } } });
      }
      return { value };
    }
    if (method === 'sendTransaction') return `paper-${Date.now()}`;
    return this.real.call(method, params, opts);
  }
}

// Stands in for the Swapper: fills at real Jupiter quotes, never sends anything.
export class PaperSwapper {
  constructor(real, book, label, rpc) {
    this.real = real;
    this.book = book;
    this.label = label;
    this.rpc = rpc; // the real RPC (token decimals)
    this.dec = new Map();
    this.n = 0;
  }

  get kp() {
    return this.real.kp;
  }

  async decimals(mint) {
    if (this.dec.has(mint)) return this.dec.get(mint);
    const r = await this.rpc.call('getTokenSupply', [mint]).catch(() => null);
    const d = r?.value?.decimals ?? 6;
    this.dec.set(mint, d);
    return d;
  }

  build() {
    return Promise.resolve(null); // nothing to pre-build
  }

  async send() {
    return { sig: `paper-${Date.now()}-${++this.n}`, ms: 0 };
  }

  quoteSellSol(mint, raw) {
    return this.real.quoteSellSol(mint, raw);
  }

  async trade({ action, mint, amount }) {
    const t0 = Date.now();
    const w = this.book.w(this.label);
    const slip = `slippageBps=${Math.round((this.real.slippage || 10) * 100)}`;
    if (action === 'buy') {
      const sol = +amount;
      if (!(sol > 0)) throw new Error('bad buy amount');
      if (w.sol < sol + FEE_SOL) throw Object.assign(new Error(`paper wallet ${this.label} has only ${w.sol.toFixed(3)} SOL`), { noFunds: true });
      const q = await this.real._jup(`/quote?inputMint=${SOL_MINT}&outputMint=${mint}&amount=${Math.round(sol * 1e9)}&${slip}&restrictIntermediateTokens=true`);
      if (!q?.outAmount) throw Object.assign(new Error('no route (paper quote)'), { noRoute: true });
      const d = await this.decimals(mint);
      const raw = BigInt(q.outAmount);
      const ui = Number(raw) / 10 ** d;
      const cur = w.tokens[mint] || { raw: '0', ui: 0, decimals: d };
      w.tokens[mint] = { raw: String(BigInt(cur.raw) + raw), ui: cur.ui + ui, decimals: d };
      w.sol -= sol + FEE_SOL;
      this.book.save();
      return { sig: `paper-${Date.now()}-${++this.n}`, solDelta: -(sol + FEE_SOL), tokenDelta: ui, ms: Date.now() - t0, venue: 'paper', sentAt: t0 };
    }
    // sell: "50%" of what this paper wallet holds
    const cur = w.tokens[mint];
    if (!cur || BigInt(cur.raw) <= 0n) throw Object.assign(new Error('nothing to sell (paper)'), { nothing: true });
    const pct = Math.min(100, Math.max(1, parseFloat(String(amount)) || 100));
    const raw = pct >= 100 ? BigInt(cur.raw) : (BigInt(cur.raw) * BigInt(Math.round(pct * 100))) / 10000n;
    const q = await this.real._jup(`/quote?inputMint=${mint}&outputMint=${SOL_MINT}&amount=${raw}&${slip}&restrictIntermediateTokens=true`);
    if (!q?.outAmount) throw Object.assign(new Error('no route (paper quote)'), { noRoute: true });
    const got = Number(q.outAmount) / 1e9 - FEE_SOL;
    const left = BigInt(cur.raw) - raw;
    const ui = Number(raw) / 10 ** cur.decimals;
    if (left > 0n) w.tokens[mint] = { raw: String(left), ui: Math.max(0, cur.ui - ui), decimals: cur.decimals };
    else delete w.tokens[mint];
    w.sol += got;
    this.book.save();
    return { sig: `paper-${Date.now()}-${++this.n}`, solDelta: got, tokenDelta: -ui, ms: Date.now() - t0, venue: 'paper', sentAt: t0 };
  }
}

// End-of-day report for paper (and real) trading: per trader, rating and a replace hint
export function traderReport(trips, { sign }) {
  const by = {};
  for (const t of trips) {
    const k = t.leader || '?';
    const r = (by[k] ||= { n: 0, won: 0, pnl: 0, best: -Infinity, worst: Infinity });
    r.n++;
    if (t.pnl > 0) r.won++;
    r.pnl += t.pnl;
    r.best = Math.max(r.best, t.pnl);
    r.worst = Math.min(r.worst, t.pnl);
  }
  const rate = (r) => {
    const wr = r.n ? r.won / r.n : 0;
    if (r.pnl > 0 && wr >= 0.6) return 'A';
    if (r.pnl > 0 && wr >= 0.45) return 'B';
    if (r.pnl > 0) return 'C';
    if (wr >= 0.4) return 'D';
    return 'F';
  };
  const lines = [];
  const ranked = Object.entries(by).sort((a, b) => b[1].pnl - a[1].pnl);
  for (const [name, r] of ranked) {
    const g = rate(r);
    const hint = g === 'F' && r.n >= 3 ? ' → consider replacing' : g === 'D' && r.n >= 5 ? ' → watch closely' : '';
    lines.push(`${g === 'A' ? '🟢' : g === 'B' ? '🟡' : g === 'C' ? '🟠' : '🔴'} <b>${name}</b> [${g}] ${sign(r.pnl)} SOL · ${r.won}/${r.n} won${hint}`);
  }
  return { lines, ranked };
}
