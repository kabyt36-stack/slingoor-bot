import { withTimeout } from './util.js';

// V2.11.53 (Khalil, Nov 14 2:40pm): same-name coins and late chases.
// Every tracked trader's trade (copied or not) is noted here, shared by all wallets.
//  - Late chase: a buy into a coin that already ran LATE_CHASE_X (10x) within LATE_CHASE_MINUTES (5) — from the lowest
//    price a tracked trader paid in that window, or from launch when the coin is that young — is not copied, unless
//    LATE_CHASE_OK_TRADERS (2) other tracked traders bought at about that price in the last minute.
//  - Copycats: a coin with the same name as an older coin the traders bought needs its own website (the real source)
//    to be bought. A coin whose newer same-name version has passed its market cap isn't bought, and a held one is sold.
//    The original is never sold just because copies show up (they're newer and smaller).
const LAUNCH_MC_SOL = 28; // pump.fun market cap at launch (~28 SOL)

export function nameKey(name) {
  const k = String(name || '')
    .toLowerCase()
    .normalize('NFKD')
    .replace(/[^a-z0-9]/g, '');
  return k.length >= 3 ? k : null;
}

export class CoinBook {
  constructor({ coins, getSolPrice, cfg = {}, now = () => Date.now() }) {
    this.coins = coins;
    this.getSolPrice = getSolPrice || (() => 0);
    this.cfg = cfg;
    this.now = now;
    this.trades = new Map(); // mint -> [{ who, px, at, buy }]
    this.infos = new Map(); // mint -> { p, info }
    this.byName = new Map(); // nameKey -> Set(mint)
  }

  // a tracked trader traded a coin (px = SOL per token he paid / got)
  note(mint, who, px, buy = true) {
    if (!mint) return;
    const t = this.now();
    const arr = this.trades.get(mint) || [];
    arr.push({ who, px: px > 0 ? px : null, at: t, buy });
    while (arr.length > 60 || (arr.length && t - arr[0].at > 30 * 60000)) arr.shift();
    this.trades.set(mint, arr);
    if (this.trades.size > 1500) this.trades.delete(this.trades.keys().next().value);
    if (buy) this.info(mint);
  }

  // name / launch time / website (cached lookup; started on the trader's buy so the copy never waits for it)
  info(mint) {
    const hit = this.infos.get(mint);
    if (hit) return hit.info ? Promise.resolve(hit.info) : hit.p;
    const p = Promise.resolve(this.coins?.get?.(mint, { fresh: false }))
      .catch(() => null)
      .then((c) => {
        const info = c?.name ? { name: c.name, createdAt: c.createdAt || null, website: c.website || null, mc: c.mc || null, firstSeen: this.now() } : null;
        if (!info) {
          this.infos.delete(mint);
          return null;
        }
        this.infos.set(mint, { info });
        const k = nameKey(info.name);
        if (k) {
          const s = this.byName.get(k) || new Set();
          s.add(mint);
          this.byName.set(k, s);
        }
        if (this.infos.size > 1500) {
          const [old] = this.infos.keys();
          this.infos.delete(old);
        }
        return info;
      });
    this.infos.set(mint, { p });
    return p;
  }

  known(mint) {
    return this.infos.get(mint)?.info || null;
  }

  lastPx(mint, maxAgeMs = 15 * 60000) {
    const arr = this.trades.get(mint);
    for (let i = (arr?.length || 0) - 1; i >= 0; i--) if (arr[i].px > 0 && this.now() - arr[i].at < maxAgeMs) return arr[i].px;
    return null;
  }

  // market cap in SOL right now: a tracked trade's price in the last 5 min, else a market cap looked up in the last
  // 2 min (null = not known well enough: an old number could sell the original by mistake)
  mcSol(mint) {
    const px = this.lastPx(mint, 5 * 60000);
    if (px) return px * 1e9;
    const c = this.coins?.peek?.(mint);
    const sol = this.getSolPrice();
    return c?.mc > 0 && c.mcAt && this.now() - c.mcAt < 2 * 60000 && sol > 0 ? c.mc / sol : null;
  }

  _born(i) {
    return i.createdAt || i.firstSeen;
  }

  // the coin's other same-name versions: { older: [mint], newer: [mint] }
  versions(mint) {
    const i = this.known(mint);
    const k = i && nameKey(i.name);
    const out = { older: [], newer: [] };
    if (!k) return out;
    for (const m of this.byName.get(k) || []) {
      if (m === mint) continue;
      const o = this.known(m);
      if (!o) continue;
      (this._born(o) < this._born(i) ? out.older : out.newer).push(m);
    }
    return out;
  }

  // a newer same-name version whose market cap is now bigger than this coin's (null = none)
  overtakenBy(mint) {
    const mine = this.mcSol(mint);
    if (!(mine > 0)) return null;
    for (const m of this.versions(mint).newer) {
      const mc = this.mcSol(m);
      if (mc > mine) return m;
    }
    return null;
  }

  // why this buy shouldn't be copied (null = fine)
  async check(mint, who, px, { waitMs = 200 } = {}) {
    const c = this.cfg;
    const t = this.now();
    px = px > 0 ? px : this.lastPx(mint);
    const info = this.known(mint) || (await withTimeout(this.info(mint), waitMs, null).catch(() => null));
    // late chase
    const X = c.lateChaseX || 0;
    if (X > 1 && px > 0) {
      const winMs = (c.lateChaseMinutes || 5) * 60000;
      const arr = (this.trades.get(mint) || []).filter((x) => x.buy && x.px > 0 && t - x.at <= winMs);
      let base = arr.length ? Math.min(...arr.map((x) => x.px)) : null;
      let from = 'the lowest a tracked trader paid';
      if (info?.createdAt && t - info.createdAt <= winMs) {
        const launch = LAUNCH_MC_SOL / 1e9;
        if (!base || launch < base) {
          base = launch;
          from = 'launch';
        }
      }
      const x = base ? px / base : 0;
      if (x >= X) {
        const others = new Set(arr.filter((y) => y.who !== who && t - y.at <= 60000 && y.px >= px * 0.7).map((y) => y.who));
        if (others.size < (c.lateChaseOkTraders ?? 2))
          return `late chase: up ${x.toFixed(0)}x from ${from} in under ${c.lateChaseMinutes || 5} min (only ${others.size} other trader${others.size === 1 ? '' : 's'} buying up here)`;
      }
    }
    // same-name versions
    if (c.versionCheck && info) {
      const by = this.overtakenBy(mint);
      if (by) return `old version: a newer coin with the same name (${by.slice(0, 6)}) has passed it`;
      const { older } = this.versions(mint);
      if (older.length && !info.website) return `copycat: an older coin has the same name and this one links no source website`;
    }
    return null;
  }
}
