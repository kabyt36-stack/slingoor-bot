// Failure / stress tests against the real bot process: restarts, crashes, Telegram errors,
// rate limits, junk data, corrupt state, and fast trade bursts. Needs WS_LIB (path to `ws`).
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { startWorld, W, sleep, iso } from './mock.js';
import { loadConfig } from '../src/config.js';
import { checkTelegramHtml } from './tg-html.js';

const WS_LIB = process.env.WS_LIB;
const A = 'CoinAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAApump';
const B = 'CoinBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBpump';
const coin = (mint, name, symbol) => ({ mint, name, symbol, usd_market_cap: 50000, complete: false, program: 'pump', created_timestamp: Date.now() - 3600e3 });

async function ready(w) {
  await w.waitFor('feeds live', () => /trades feed live/.test(w.out) && /Callout feed live/.test(w.out) && /Launch feed live/.test(w.out));
  await w.waitFor('chain subscribed', () => w.WS.subs.logsSubscribe);
}

test('restart: nothing is alerted twice, and what happened while it was off is caught up', { skip: !WS_LIB, timeout: 90000 }, async () => {
  const w = await startWorld(WS_LIB);
  try {
    w.M.coins[A] = coin(A, 'Big Booty Coin', 'BBC');
    w.M.callouts.push({ calloutId: 'old', coinMint: A, marketCap: 1, createdAt: Date.now() - 7200e3, thesis: 'old', updateCount: 0 });
    w.startBot();
    await ready(w);
    w.tgPush('/start');
    await w.waitFor('registered', () => w.sent(/You're set/).length);

    w.addTrade({ tx: 'T1', isBuy: true, mint: A, baseAmount: 1000, amountSol: 2, amountUsd: 192 });
    await w.waitFor('entry alert', () => w.sent(/NEW ENTRY.*\$BBC/).length);
    w.M.callouts.push({ calloutId: 'C1', coinMint: A, marketCap: 50000, createdAt: Date.now(), thesis: 'first call', updateCount: 0 });
    await w.waitFor('callout alert', () => w.sent(/CALLOUT<\/b>.*\$BBC/).length);
    await sleep(800); // let the state file catch up

    await w.stopBot('SIGKILL'); // hard crash, no clean shutdown
    // while it's down: he sells everything and makes another callout
    w.M.balances[A] = 0;
    w.addTrade({ tx: 'T2', isBuy: false, mint: A, baseAmount: 1000, amountSol: 3.5, amountUsd: 336 });
    w.M.callouts.push({ calloutId: 'C2', coinMint: A, marketCap: 80000, createdAt: Date.now(), thesis: 'second call', updateCount: 0 });

    w.startBot();
    await w.waitFor('caught-up exit', () => w.sent(/FULLY SOLD OUT.*\$BBC/).length);
    await w.waitFor('caught-up callout', () => w.sent(/second call/).length);
    await w.waitFor('back-online notice', () => w.sent(/Tracker online/).length);
    await sleep(4000);
    assert.equal(w.sent(/NEW ENTRY/).length, 1, 'entry must not repeat after restart');
    assert.equal(w.sent(/first call/).length, 1, 'old callout must not repeat');
    assert.equal(w.sent(/“old”/).length, 0);
    assert.equal(w.sent(/FULLY SOLD OUT/).length, 1);
    assert.ok(w.TG.sent.filter((s) => s.text.includes('$BBC')).every((s) => s.chat_id === '111'));
  } finally {
    await w.close();
  }
});

test('Telegram errors: bad formatting, rate limit, blocked chat and group upgrade never lose alerts', { skip: !WS_LIB, timeout: 90000 }, async () => {
  const w = await startWorld(WS_LIB);
  try {
    for (const [m, n, s] of [[A, 'Alpha <Coin> & Co', 'ALP'], [B, 'Beta Coin', 'BETA']]) w.M.coins[m] = coin(m, n, s);
    w.startBot();
    await ready(w);
    w.tgPush('/start');
    await w.waitFor('registered', () => w.sent(/You're set/).length && w.sent(/Tracker status/).length);

    // 1) Telegram rejects the formatting -> resent as plain text
    w.TG.failNext.push({ status: 400, body: { ok: false, error_code: 400, description: "Bad Request: can't parse entities: Unsupported start tag" } });
    w.addTrade({ tx: 'X1', isBuy: true, mint: A, baseAmount: 10, amountSol: 1, amountUsd: 96 });
    const plain = await w.waitFor('plain-text fallback', () => w.TG.sent.find((s) => /NEW ENTRY/.test(s.text) && !s.parse_mode));
    assert.match(plain.text, /Alpha <Coin> & Co/);
    assert.doesNotMatch(plain.text, /<b>/);

    // 2) rate limited -> waits and delivers
    w.TG.failNext.push({ status: 429, body: { ok: false, error_code: 429, description: 'Too Many Requests: retry after 1', parameters: { retry_after: 1 } } });
    w.addTrade({ tx: 'X2', isBuy: true, mint: B, baseAmount: 10, amountSol: 1, amountUsd: 96 });
    await w.waitFor('delivered after 429', () => w.sent(/NEW ENTRY.*\$BETA/).length, 10000);

    // 3) a failed chat doesn't stop the bot
    w.TG.failNext.push({ status: 403, body: { ok: false, error_code: 403, description: 'Forbidden: bot was blocked by the user' } });
    w.M.balances[A] = 0;
    w.addTrade({ tx: 'X3', isBuy: false, mint: A, baseAmount: 10, amountSol: 2, amountUsd: 192 });
    await sleep(2500);
    w.M.balances[B] = 0;
    w.addTrade({ tx: 'X4', isBuy: false, mint: B, baseAmount: 10, amountSol: 2, amountUsd: 192 });
    await w.waitFor('next alert after 403', () => w.sent(/FULLY SOLD OUT.*\$BETA/).length);

    // 4) group upgraded to supergroup -> follows the new chat id
    w.TG.failNext.push({ status: 400, body: { ok: false, error_code: 400, description: 'Bad Request: group chat was upgraded to a supergroup chat', parameters: { migrate_to_chat_id: -100777 } } });
    w.addTrade({ tx: 'X5', isBuy: true, mint: A, baseAmount: 10, amountSol: 1, amountUsd: 96 });
    await w.waitFor('resent to new chat', () => w.TG.sent.find((s) => s.chat_id === '-100777' && /NEW ENTRY.*ALP/.test(s.text)));
    w.addTrade({ tx: 'X6', isBuy: true, mint: B, baseAmount: 10, amountSol: 1, amountUsd: 96 });
    await w.waitFor('later alerts go to new chat', () => w.TG.sent.find((s) => s.chat_id === '-100777' && /BETA/.test(s.text)));
    await sleep(800);
    const st = JSON.parse(fs.readFileSync(path.join(w.tmp, 'state.json'), 'utf8'));
    assert.deepEqual(st.chats, ['-100777']);
    for (const s of w.TG.sent.filter((x) => x.parse_mode)) assert.deepEqual(checkTelegramHtml(s.text), []);
  } finally {
    await w.close();
  }
});

test('rate limits and junk data: callout limit does not stall trades, RPC limit falls back to pump.fun feed, garbage on the socket is ignored', { skip: !WS_LIB, timeout: 90000 }, async () => {
  const w = await startWorld(WS_LIB);
  try {
    w.M.coins[A] = coin(A, 'Alpha', 'ALP');
    w.startBot();
    await ready(w);
    w.tgPush('/start');
    await w.waitFor('registered', () => w.sent(/You're set/).length);

    // pump.fun throttles callouts -> the trades feed must keep working
    w.M.fail.calloutList = 429;
    await w.waitFor('callout endpoint paused', () => /limiting \/callout/.test(w.out), 10000);
    w.addTrade({ tx: 'R1', isBuy: true, mint: A, baseAmount: 10, amountSol: 1, amountUsd: 96 });
    await w.waitFor('trade alert during callout throttling', () => w.sent(/NEW ENTRY.*\$ALP/).length, 6000);

    // junk on the websocket
    const s = w.WS.sock;
    s.send('not json at all {');
    s.send(JSON.stringify({ jsonrpc: '2.0', method: 'somethingElse', params: {} }));
    s.send(JSON.stringify({ jsonrpc: '2.0', method: 'logsNotification', params: { subscription: 99999, result: { context: { slot: 1 }, value: { signature: 'x', logs: [] } } } }));
    s.send(JSON.stringify({ jsonrpc: '2.0', method: 'logsNotification', params: { subscription: w.WS.subs.logsSubscribe, result: { context: { slot: 2 }, value: null } } }));
    s.send(JSON.stringify({ jsonrpc: '2.0', method: 'accountNotification', params: { subscription: w.WS.subs.accountSubscribe } }));

    // RPC refuses getTransaction -> the same trade still arrives via pump.fun
    w.M.fail.rpcTx = 1;
    w.notifyLogs('R2', 5000, ['Program 6Vo3245eszAb5wuqEMw8mGdbfRUdKbHhDHP5LcaGuTAB invoke [1]']);
    w.notifyAccount(5000);
    w.M.balances[A] = 0;
    w.addTrade({ tx: 'R2', isBuy: false, mint: A, baseAmount: 10, amountSol: 2, amountUsd: 192 });
    await w.waitFor('exit via pump.fun feed while RPC is limited', () => w.sent(/FULLY SOLD OUT.*\$ALP/).length, 10000);
    assert.equal(w.bot.exitCode, null, 'bot still running');
    assert.doesNotMatch(w.out, /Crashed|Unhandled/);
  } finally {
    await w.close();
  }
});

test('corrupt state file: starts clean without flooding old history', { skip: !WS_LIB, timeout: 60000 }, async () => {
  const w = await startWorld(WS_LIB);
  try {
    w.M.coins[A] = coin(A, 'Alpha', 'ALP');
    w.M.callouts.push({ calloutId: 'c-old', coinMint: A, marketCap: 1, createdAt: Date.now() - 60e3, thesis: 'recent but before install', updateCount: 0 });
    w.addTrade({ tx: 'old1', isBuy: true, mint: A, baseAmount: 1, amountSol: 1, amountUsd: 1, timestamp: iso(Date.now() - 30e3) });
    w.M.created.push({ mint: B, name: 'Beta', symbol: 'B', created_timestamp: Date.now() - 60e3 });
    fs.writeFileSync(path.join(w.tmp, 'state.json'), '{"chats":["111"], "seenTra'); // truncated file
    w.startBot();
    await ready(w);
    w.tgPush('/start');
    await w.waitFor('registered', () => w.sent(/You're set/).length);
    await sleep(6000);
    assert.equal(w.sent(/NEW ENTRY|CALLOUT<\/b>|LAUNCHED/).length, 0, 'history must not be alerted');
    assert.equal(w.bot.exitCode, null);
  } finally {
    await w.close();
  }
});

test('burst: 20 coins traded fast (entry, adds, partial, full exit each) -> exactly 3 correct alerts per coin', { skip: !WS_LIB, timeout: 120000 }, async () => {
  const w = await startWorld(WS_LIB);
  try {
    w.startBot();
    await ready(w);
    w.tgPush('/start');
    await w.waitFor('registered', () => w.sent(/You're set/).length);
    const mints = Array.from({ length: 20 }, (_, i) => `Burst${String(i).padStart(2, '0')}AAAAAAAAAAAAAAAAAAAAAAAAAAAAApump`);
    let slot = 1000;
    const sec = () => iso(Math.floor(Date.now() / 1000) * 1000); // pump.fun timestamps are whole seconds
    for (const [i, m] of mints.entries()) {
      w.M.coins[m] = coin(m, `Burst Coin ${i}`, `BC${i}`);
      w.M.balances[m] = 0; // final state after the round trip
      const t = sec();
      const row = (tx, isBuy, amt, sol) => ({ tx, isBuy, mint: m, baseAmount: amt, amountSol: sol, amountUsd: sol * 96, timestamp: t, slotIndexId: String(slot++).padStart(26, '0') });
      // added newest-first like pump.fun's API, all in the same second
      w.M.trades.push(row(`${m}-buy1`, true, 100, 1), row(`${m}-buy2`, true, 100, 1), row(`${m}-buy3`, true, 100, 1), row(`${m}-sell1`, false, 150, 2), row(`${m}-sell2`, false, 150, 2.5));
      await sleep(1300);
    }
    await w.waitFor('all exits', () => w.sent(/FULLY SOLD OUT/).length >= 20, 40000);
    await sleep(5000);
    for (const [i, m] of mints.entries()) {
      const msgs = w.TG.sent.filter((s) => s.text.includes(m));
      const kinds = msgs.map((s) => (s.text.match(/NEW ENTRY|ADDED MORE|SOLD \d+%|FULLY SOLD OUT/) || ['?'])[0]);
      assert.deepEqual(kinds, ['NEW ENTRY', 'SOLD 50%', 'FULLY SOLD OUT'], `coin ${i}: ${kinds}`);
      const entryEdits = w.TG.edits.filter((e) => e.message_id === msgs[0].message_id);
      assert.match(entryEdits.at(-1).text, /3 buys/, `coin ${i} merged buys`);
      assert.match(msgs[2].text, /in 3\.00 SOL → out 4\.50 SOL = <b>\+1\.50 SOL<\/b>/, `coin ${i} trip`);
    }
    assert.doesNotMatch(w.out, /Crashed|Unhandled|failed:/);
  } finally {
    await w.close();
  }
});

test('settings file written by TextEdit (BOM, Windows line endings, smart quotes, comments) is read correctly', () => {
  const f = path.join(fs.mkdtempSync(path.join(process.env.TMPDIR || '/tmp', 'cfg-')), 'settings.txt');
  fs.writeFileSync(f, '﻿# hi\r\nTELEGRAM_BOT_TOKEN=“123456:ABC-def_ghi”\r\nTARGET_WALLETS= 5YRgrP3mjGzrzirYYN5HAQH19cTYREYwGxW6XRJQUzij , \r\nMIN_ALERT_SOL=0.5   # skip dust\r\nALERT_ADDS=OFF\r\nTELEGRAM_BOT_TOKEN=123456:ABC-def_ghi\r\n');
  const saved = { ...process.env };
  for (const k of ['TELEGRAM_BOT_TOKEN', 'TARGET_WALLETS', 'MIN_ALERT_SOL', 'ALERT_ADDS']) delete process.env[k];
  try {
    const c = loadConfig(f);
    assert.equal(c.telegramToken, '123456:ABC-def_ghi');
    assert.deepEqual(c.wallets, [W]);
    assert.equal(c.minAlertSol, 0.5);
    assert.equal(c.alerts.add, false);
    assert.equal(c.alerts.entry, true);
  } finally {
    Object.assign(process.env, saved);
  }
});

test('a buy paid in USDC through a relayer (his SOL balance unchanged) is still caught on-chain', { skip: !WS_LIB, timeout: 60000 }, async () => {
  const { realTxs, buildTx } = await import('./helpers.js');
  const fx = realTxs();
  const USDC = 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v';
  const w = await startWorld(WS_LIB);
  try {
    w.M.balances[USDC] = 20; // he has a USDC account -> the bot watches it
    // real relayer-style tx: he signs as account #1, someone else pays the fee, he spends USDC
    const c = structuredClone(fx.txs.pumpSell.c);
    c.ptb = [[5, A, 'Token', '1000000', 6], [9, USDC, 'Token', '20000000', 6]];
    c.qtb = [[5, A, 'Token', '5000000', 6], [9, USDC, 'Token', '17000000', 6]];
    c.inv = ['6Vo3245eszAb5wuqEMw8mGdbfRUdKbHhDHP5LcaGuTAB'];
    w.M.txs.USDCBUY = buildTx(c, W, 'USDCBUY');
    w.M.coins[A] = coin(A, 'Alpha', 'ALP');
    w.startBot();
    await ready(w);
    w.tgPush('/start');
    await w.waitFor('registered', () => w.sent(/You're set/).length);
    const usdcAcct = `Acct${USDC.slice(0, 8)}`;
    await w.waitFor('USDC account watched', () => (w.WS.accountSubs || {})[usdcAcct]);
    w.notifyLogs('USDCBUY', 777, ['Program 6Vo3245eszAb5wuqEMw8mGdbfRUdKbHhDHP5LcaGuTAB invoke [1]']);
    w.notifyAccount(777, usdcAcct); // only his USDC account changed, not his SOL
    const m = await w.waitFor('alert', () => w.sent(/ADDED MORE.*\$ALP/)[0]);
    assert.match(m.text, /Bought <b>\$3<\/b>/);
    assert.match(m.text, /via on-chain stream/);
  } finally {
    await w.close();
  }
});

test('watchdog: the real bot is restarted after it dies and Telegram is told', { skip: !WS_LIB, timeout: 90000 }, async () => {
  const { ROOT } = await import('../src/config.js');
  const data = path.join(ROOT, 'data');
  for (const f of ['notices.json', 'heartbeat.json']) fs.rmSync(path.join(data, f), { force: true });
  const w = await startWorld(WS_LIB);
  try {
    w.startBot({ SUPERVISE: '1' });
    await ready(w);
    w.tgPush('/start');
    await w.waitFor('registered', () => w.sent(/You're set/).length);
    w.tgPush('/version');
    await w.waitFor('version reply', () => w.sent(/Auto-restart and auto-update are on/).length);
    const hb = await w.waitFor('heartbeat', () => {
      try {
        return JSON.parse(fs.readFileSync(path.join(data, 'heartbeat.json'), 'utf8'));
      } catch {
        return null;
      }
    });
    process.kill(hb.pid, 'SIGKILL'); // the bot dies; the supervisor (w.bot) keeps running
    await w.waitFor('crash notice in Telegram', () => w.sent(/crashed and restarted itself/).length, 30000);
    await w.waitFor('back online', () => w.sent(/Tracker online/).length >= 1, 30000);
    const hb2 = JSON.parse(fs.readFileSync(path.join(data, 'heartbeat.json'), 'utf8'));
    assert.notEqual(hb2.pid, hb.pid);
  } finally {
    await w.close();
  }
});

test("pump.fun bag list blocked by Cloudflare (403): his bags are read from the chain instead", { skip: !WS_LIB, timeout: 60000 }, async () => {
  const w = await startWorld(WS_LIB);
  try {
    w.M.fail.profile = true;
    w.M.coins[A] = coin(A, 'Big Booty Coin', 'BBC');
    w.M.coins[B] = coin(B, 'Tiny Bag', 'TINY');
    w.M.balances[A] = 30000000;
    w.M.balances[B] = 1000;
    w.M.token2022 = [B]; // new pump coins are Token-2022
    // pump.fun's coin API is behind the same Cloudflare check, so names come from DexScreener then
    w.M.dexCoins = { [A]: { name: 'Big Booty Coin', symbol: 'BBC', mc: 50000 }, [B]: { name: 'Tiny Bag', symbol: 'TINY', mc: 50000 } };
    w.startBot();
    await ready(w);
    await w.waitFor('fallback log', () => /reading his bags from the chain instead/.test(w.out));
    await w.waitFor('meta learned', () => /Meta learned from [1-9]/.test(w.out));
    assert.ok(!/Could not load his bags/.test(w.out));
    w.tgPush('/start');
    await w.waitFor('registered', () => w.sent(/You're set/).length);
    w.tgPush('/bags');
    const r = await w.waitFor('bags reply', () => w.sent(/biggest bags/)[0]);
    assert.match(r.text, /\$BBC<\/b> Big Booty Coin — \$1\.50K/);
    assert.ok(r.text.indexOf('$BBC') < r.text.indexOf('$TINY'), 'biggest first');
    checkTelegramHtml(r.text);
  } finally {
    await w.close();
  }
});

test('pump.fun blocks this computer completely (Cloudflare): his trades still alert from the chain, with market cap from the curve', { skip: !WS_LIB, timeout: 90000 }, async () => {
  const { b58decode } = await import('../src/solana.js');
  const w = await startWorld(WS_LIB);
  try {
    w.M.fail.cloudflare = true;
    const E = 'E6piJqfGAVmpcjJPa4UszecfHXqACeXusEeAYvmY31LM';
    w.M.dexCoins = { [E]: { name: 'Chain Coin', symbol: 'CHN' } }; // DexScreener knows the name but no market cap yet
    w.startBot();
    await w.waitFor('chain subscribed', () => w.WS.subs.logsSubscribe);
    w.tgPush('/start');
    await w.waitFor('registered', () => w.sent(/You're set/).length);
    await w.waitFor('cloudflare warning', () => /blocking this computer \(Cloudflare check\)/.test(w.out), 20000);
    await sleep(3000); // let the SOL price come in from the DexScreener fallback
    const ev = Buffer.alloc(401);
    Buffer.from([189, 219, 127, 211, 78, 230, 97, 238]).copy(ev, 0);
    Buffer.from(b58decode(E)).copy(ev, 8);
    ev.writeBigUInt64LE(2_000_000_000n, 40);
    ev.writeBigUInt64LE(50_000_000_000_000n, 48);
    ev[56] = 1;
    Buffer.from(b58decode(W)).copy(ev, 57);
    ev.writeBigUInt64LE(40_000_000_000n, 97); // 40 SOL virtual
    ev.writeBigUInt64LE(800_000_000_000_000n, 105); // 800M tokens -> 50 SOL mcap -> $7,500 at $150
    w.notifyLogs('CfSig' + '1'.repeat(80), 1234, [`Program 6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P invoke [1]`, 'Program log: Instruction: Buy', `Program data: ${ev.toString('base64')}`, 'Program 6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P success']);
    const a = await w.waitFor('entry alert', () => w.sent(/NEW ENTRY.*\$CHN/)[0], 15000);
    assert.match(a.text, /Bought <b>2\.00 SOL/);
    assert.match(a.text, /\$7\.50K/, a.text);
    checkTelegramHtml(a.text);
    const calls = w.M.pumpCalls.length;
    await sleep(6000);
    assert.ok(w.M.pumpCalls.length - calls <= 2, `backs off pump.fun while blocked (${w.M.pumpCalls.length - calls} calls in 6s)`);
    assert.equal((w.out.match(/blocking this computer/g) || []).length, 1, 'warns once, not every minute');
    w.tgPush('/status');
    await w.waitFor('status', () => w.sent(/Cloudflare/).length);
  } finally {
    await w.close();
  }
});

test('chain-only mode (USE_PUMPFUN=off): no pump.fun calls at all; his buys and sells still alert with market cap', { skip: !WS_LIB, timeout: 120000 }, async () => {
  const { b58decode } = await import('../src/solana.js');
  const w = await startWorld(WS_LIB);
  try {
    const E = 'E6piJqfGAVmpcjJPa4UszecfHXqACeXusEeAYvmY31LM';
    w.M.dexCoins = { [E]: { name: 'Chain Coin', symbol: 'CHN' } };
    w.startBot({ USE_PUMPFUN: 'off' });
    await w.waitFor('chain subscribed', () => w.WS.subs.logsSubscribe);
    await w.waitFor('chain-only log', () => /pump\.fun not used/.test(w.out));
    w.tgPush('/start');
    await w.waitFor('registered', () => w.sent(/You're set/).length);
    await sleep(2500);
    const ev = (isBuy, tok) => {
      const b = Buffer.alloc(401);
      Buffer.from([189, 219, 127, 211, 78, 230, 97, 238]).copy(b, 0);
      Buffer.from(b58decode(E)).copy(b, 8);
      b.writeBigUInt64LE(2_000_000_000n, 40);
      b.writeBigUInt64LE(BigInt(tok), 48);
      b[56] = isBuy ? 1 : 0;
      Buffer.from(b58decode(W)).copy(b, 57);
      b.writeBigUInt64LE(40_000_000_000n, 97);
      b.writeBigUInt64LE(800_000_000_000_000n, 105);
      return [`Program 6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P invoke [1]`, `Program data: ${b.toString('base64')}`, `Program 6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P success`];
    };
    w.notifyLogs('OffBuy' + '1'.repeat(80), 2000, ev(true, 50_000_000_000_000));
    const a = await w.waitFor('entry alert', () => w.sent(/NEW ENTRY.*\$CHN/)[0], 15000);
    assert.match(a.text, /\$7\.50K/);
    w.M.balances[E] = 20_000_000; // he sold 30M of 50M
    w.notifyLogs('OffSell' + '1'.repeat(79), 2001, ev(false, 30_000_000_000_000));
    await w.waitFor('partial sell alert', () => w.sent(/SOLD 60%.*\$CHN/).length, 15000);
    w.tgPush('/status');
    await w.waitFor('status', () => w.sent(/pump\.fun: not used/).length);
    w.tgPush('/callouts');
    await w.waitFor('callouts off reply', () => w.sent(/Callouts come only from pump\.fun/).length);
    assert.equal(w.M.pumpCalls.length, 0, `no pump.fun calls: ${w.M.pumpCalls.slice(0, 5)}`);
  } finally {
    await w.close();
  }
});

test('missed time: after the bot was off (or the Mac slept), Telegram says when and that trades were not copied', { skip: !WS_LIB, timeout: 60000 }, async () => {
  const { ROOT } = await import('../src/config.js');
  const data = path.join(ROOT, 'data');
  fs.mkdirSync(data, { recursive: true });
  const w = await startWorld(WS_LIB);
  try {
    // first run registers the chat, then the bot is stopped
    w.startBot();
    await w.waitFor('chain subscribed', () => w.WS.subs.logsSubscribe);
    w.tgPush('/start');
    await w.waitFor('registered', () => w.sent(/You're set/).length);
    await w.stopBot();
    fs.writeFileSync(path.join(data, 'last-alive.json'), JSON.stringify({ at: Date.now() - 35 * 60000 }));
    w.startBot();
    const m = await w.waitFor('missed-time warning', () => w.sent(/The bot was off/)[0], 20000);
    assert.match(m.text, /35 min/);
    assert.match(m.text, /not<\/b> copied/);
    checkTelegramHtml(m.text);
  } finally {
    await w.close();
    fs.rmSync(path.join(data, 'last-alive.json'), { force: true });
  }
});

test('a pasted Helius URL in HELIUS_API_KEY still works (only the key is used)', async () => {
  const { loadConfig } = await import('../src/config.js');
  const KEY = '11111111-2222-3333-4444-555555555555'; // fake
  const f = path.join(fs.mkdtempSync(path.join((await import('node:os')).tmpdir(), 'cfg-')), 'settings.txt');
  fs.writeFileSync(f, `TELEGRAM_BOT_TOKEN=1:a\nHELIUS_API_KEY= "https://mainnet.helius-rpc.com/?api-key=${KEY}"\n`);
  const c = loadConfig(f);
  assert.equal(c.rpcUrl, `https://mainnet.helius-rpc.com/?api-key=${KEY}`);
  assert.equal(c.wsUrl, `wss://mainnet.helius-rpc.com/?api-key=${KEY}`);
  // the Helius link put in RPC_URL (key empty): the live stream must use Helius too, not the public server
  fs.writeFileSync(f, `TELEGRAM_BOT_TOKEN=1:a\nHELIUS_API_KEY=\nRPC_URL=https://mainnet.helius-rpc.com/?api-key=${KEY}\n`);
  const c2 = loadConfig(f);
  assert.equal(c2.wsUrl, `wss://mainnet.helius-rpc.com/?api-key=${KEY}`);
  assert.equal(c2.isPublicRpc, false);
  // any other custom RPC without WS_URL: stream from the same server
  fs.writeFileSync(f, `TELEGRAM_BOT_TOKEN=1:a\nRPC_URL=https://rpc.example.com/abc\n`);
  assert.equal(loadConfig(f).wsUrl, 'wss://rpc.example.com/abc');
});

test('two copies of the bot: the second one stops (no doubled trades) and says why in Telegram', { skip: !WS_LIB, timeout: 60000 }, async () => {
  const { spawn } = await import('node:child_process');
  const w = await startWorld(WS_LIB);
  let second;
  try {
    w.startBot();
    await w.waitFor('chain subscribed', () => w.WS.subs.logsSubscribe);
    w.tgPush('/start');
    await w.waitFor('registered', () => w.sent(/You're set/).length);
    // a second copy with the same lock (like one in another folder)
    second = spawn(process.execPath, ['bot.js'], { cwd: path.resolve(path.dirname(new URL(import.meta.url).pathname), '..'), env: { ...w.lastEnv } });
    let out = '';
    second.stdout.on('data', (d) => (out += d));
    second.stderr.on('data', (d) => (out += d));
    const code = await new Promise((r) => second.on('exit', r));
    assert.equal(code, 2, out);
    assert.match(out, /Another copy of the bot is already running/);
    await w.waitFor('telegram warning', () => w.sent(/Two copies of the bot were running/).length);
    assert.ok(w.bot.exitCode === null, 'the first copy keeps running');
  } finally {
    try { second?.kill(); } catch {}
    await w.close();
  }
});
