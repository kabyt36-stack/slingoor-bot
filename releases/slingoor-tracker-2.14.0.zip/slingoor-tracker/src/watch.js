// V2.13.0 (Khalil, Nov 16 7:51am: "disable copy trading every hour just alert me on the narrative and the biggest
// coin of the day alert me at 12 am and pm. Tell me coins that just got 2x 3x 4x etc big cooks. If the coin is not a rug")
// Watches every coin a tracked trader buys (from his buy price) with DexScreener (free, no RPC credits):
//  - 🚀 alert when it reaches 2x, 3x, 4x... of where the traders bought — only if it isn't a rug
//  - 🧭 every hour: the narratives the traders bought this hour and how they're doing
//  - 🏆 at 12am and 12pm: the biggest coin of the last 12 hours
import fs from 'node:fs';
import path from 'node:path';
import { classify, tagText } from './narrative.js';
import { fetchJson } from './util.js';
import { log } from './log.js';

const STEPS = [2, 3, 4, 5, 6, 7, 8, 9, 10, 15, 20, 30, 50, 100];
const e = (s) => String(s ?? '').replace(/[&<>]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' })[c]);
const usd = (n) => (n >= 1e6 ? `$${(n / 1e6).toFixed(1)}M` : n >= 1e3 ? `$${Math.round(n / 1e3)}k` : `$${Math.round(n || 0)}`);

export class CoinWatch {
  constructor({ file = null, send = () => {}, now = () => Date.now(), fetchPairs = null, minLiqUsd = 5000, minMcUsd = 15000, maxCoins = 150 } = {}) {
    this.file = file;
    this.send = send;
    this.now = now;
    this.minLiqUsd = minLiqUsd;
    this.minMcUsd = minMcUsd;
    this.maxCoins = maxCoins;
    this.fetchPairs = fetchPairs || ((mints) => fetchJson(`https://api.dexscreener.com/latest/dex/tokens/${mints.join(',')}`, { timeout: 6000 }).then((j) => j?.pairs || []));
    this.d = { coins: {}, lastHour: null, lastHalf: null };
    try {
      if (file && fs.existsSync(file)) this.d = { ...this.d, ...JSON.parse(fs.readFileSync(file, 'utf8')) };
    } catch {}
  }

  save() {
    if (!this.file) return;
    try {
      fs.mkdirSync(path.dirname(this.file), { recursive: true });
      fs.writeFileSync(this.file, JSON.stringify(this.d));
    } catch {}
  }

  // a tracked trader bought: px = SOL per token he paid
  buy(mint, who, px) {
    if (!mint) return;
    const t = this.now();
    let c = this.d.coins[mint];
    if (!c) {
      c = this.d.coins[mint] = { at: t, base: px > 0 ? px : null, peak: 0, step: 0, who: [], buys: 0, last: null, mc: 0, peakMc: 0, baseMc: 0, rug: false, dead: false };
      const all = Object.entries(this.d.coins);
      if (all.length > 400) for (const [k] of all.sort((a, b) => a[1].at - b[1].at).slice(0, all.length - 400)) delete this.d.coins[k];
    }
    if (px > 0 && (!c.base || px < c.base)) c.base = px; // the cheapest tracked buy is the start
    if (who && !c.who.includes(who)) c.who.push(who);
    c.buys++;
    c.lastBuy = t;
  }

  // every ~minute: prices for the coins bought in the last 24h
  async poll() {
    const t = this.now();
    const live = Object.entries(this.d.coins)
      .filter(([, c]) => !c.dead && t - c.at < 24 * 3600000)
      .sort((a, b) => b[1].at - a[1].at)
      .slice(0, this.maxCoins)
      .map(([m]) => m);
    for (let i = 0; i < live.length; i += 5) {
      const chunk = live.slice(i, i + 5);
      const pairs = await this.fetchPairs(chunk).catch(() => []);
      const best = {};
      for (const p of pairs) {
        const m = p.baseToken?.address;
        if (!chunk.includes(m) || !(p.quoteToken?.symbol === 'SOL' || p.quoteToken?.address === 'So11111111111111111111111111111111111111112')) continue;
        if (!best[m] || (+p.liquidity?.usd || 0) > (+best[m].liquidity?.usd || 0)) best[m] = p;
      }
      for (const m of chunk) if (best[m]) this._price(m, best[m]);
    }
    this.save();
  }

  _price(mint, p) {
    const c = this.d.coins[mint];
    const px = +p.priceNative;
    if (!(px > 0)) return;
    c.name = p.baseToken?.name || c.name;
    c.sym = p.baseToken?.symbol || c.sym;
    c.tags ||= classify({ name: c.name, symbol: c.sym }).tags;
    const mc = +p.marketCap || +p.fdv || 0;
    const liq = +p.liquidity?.usd || 0;
    if (!c.base) c.base = px;
    if (!c.baseMc && mc) c.baseMc = (mc * c.base) / px;
    c.last = px;
    c.mc = mc;
    c.liq = liq;
    const x = px / c.base;
    if (x > c.peak) {
      c.peak = x;
      c.peakMc = mc;
    }
    // a rug: the money left the pool, or it fell 70%+ from its top
    c.rug = liq < this.minLiqUsd || (c.peak >= 2 && x < c.peak * 0.3);
    if (liq < 1000 || (x < 0.2 && this.now() - c.at > 30 * 60000)) c.dead = true;
    const next = STEPS.find((s) => s > (c.step || 0) && x >= s);
    if (next && !c.rug && mc >= this.minMcUsd) {
      // jump straight to the highest step reached (one alert, not 2x 3x 4x at once)
      c.step = STEPS.filter((s) => x >= s).at(-1);
      this.send(this.cookText(mint, c, x));
    }
  }

  cookText(mint, c, x) {
    const tags = c.tags?.length ? tagText(c.tags) : 'no clear narrative';
    return `🚀 <b>${Math.floor(x * 10) / 10}x</b> <a href="https://pump.fun/coin/${mint}">$${e(c.sym || mint.slice(0, 6))}</a> — ${usd(c.baseMc)} → <b>${usd(c.mc)}</b>\n${e(tags)} · bought by ${e(c.who.slice(0, 4).join(', '))}`;
  }

  // the narratives bought in the last hour
  hourText(sinceMs = 3600000) {
    const t = this.now();
    const coins = Object.entries(this.d.coins).filter(([, c]) => (c.lastBuy || c.at) >= t - sinceMs);
    if (!coins.length) return null;
    const per = {};
    for (const [m, c] of coins) {
      const tags = c.tags?.length ? c.tags : ['none'];
      for (const tag of tags) {
        const g = (per[tag] ||= { n: 0, buys: 0, best: null });
        g.n++;
        g.buys += c.buys;
        const x = c.last && c.base ? c.last / c.base : 0;
        if (!c.rug && (!g.best || x > g.best.x)) g.best = { m, sym: c.sym, x };
      }
    }
    const top = Object.entries(per).sort((a, b) => b[1].buys - a[1].buys).slice(0, 5);
    const lines = [`🧭 <b>Narratives this hour</b> (${coins.length} coins the traders bought)`];
    for (const [tag, g] of top) {
      const label = tag === 'none' ? '▫️ no clear narrative' : tagText([tag]);
      const best = g.best?.sym && g.best.x > 0 ? ` · best <a href="https://pump.fun/coin/${g.best.m}">$${e(g.best.sym)}</a> ${g.best.x.toFixed(1)}x` : '';
      lines.push(`${e(label)} — ${g.n} coin${g.n === 1 ? '' : 's'}, ${g.buys} buys${best}`);
    }
    return lines.join('\n');
  }

  // the biggest coin of the last 12 hours that isn't a rug
  bestText(sinceMs = 12 * 3600000) {
    const t = this.now();
    const c0 = Object.entries(this.d.coins)
      .filter(([, c]) => c.at >= t - sinceMs && !c.rug && c.peak >= 1.5 && c.peakMc >= this.minMcUsd)
      .sort((a, b) => b[1].peak - a[1].peak)[0];
    if (!c0) return '🏆 <b>Biggest coin (last 12h)</b>: none ran 1.5x+ without rugging.';
    const [m, c] = c0;
    const now = c.last && c.base ? c.last / c.base : 0;
    return `🏆 <b>Biggest coin (last 12h)</b>: <a href="https://pump.fun/coin/${m}">$${e(c.sym || m.slice(0, 6))}</a> — peaked <b>${c.peak.toFixed(1)}x</b> (${usd(c.baseMc)} → ${usd(c.peakMc)}), now ${now.toFixed(1)}x (${usd(c.mc)})\n${e(c.tags?.length ? tagText(c.tags) : 'no clear narrative')} · bought by ${e(c.who.slice(0, 4).join(', '))}`;
  }

  // every 20s: the hourly narrative message at :00, the biggest coin at 12am and 12pm
  tick() {
    const d = new Date(this.now());
    const hourKey = `${d.toDateString()} ${d.getHours()}`;
    if (d.getMinutes() === 0 && this.d.lastHour !== hourKey) {
      this.d.lastHour = hourKey;
      const h = this.hourText();
      if (h) this.send(h);
      if (d.getHours() === 0 || d.getHours() === 12) this.send(this.bestText());
      this.save();
    }
  }

  start() {
    const loop = async () => {
      await this.poll().catch((err) => log.warn(`Coin watch: ${err.message}`));
      setTimeout(loop, 60000).unref?.();
    };
    setTimeout(loop, 15000).unref?.();
    setInterval(() => this.tick(), 20000).unref?.();
  }
}
