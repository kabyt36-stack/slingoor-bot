// V2.12.9 (Khalil, Nov 15 2pm: "If a trader keeps adding to a coin monitor it ... every day is different")
// Counts each trader's buys of each coin. From his Nth buy (within the window from his first), a coin no wallet
// holds is checked again as a new entry (at most once a minute) — unless the price is already maxX above his first.
export class AddWatch {
  constructor({ cfg = {}, now = () => Date.now() } = {}) {
    this.cfg = { buys: 3, ms: 30 * 60000, maxX: 5, retryMs: 60000, ...Object.fromEntries(Object.entries(cfg).filter(([, v]) => v != null)) };
    this.now = now;
    this.seen = new Map(); // 'trader|mint' -> { n, px, at, tried }
  }

  // kind 'ENTRY' | 'ADD'; returns { check, n } | { late, x } | null
  note(who, mint, px, kind, held) {
    if (!(this.cfg.buys > 0)) return null;
    const t = this.now();
    const k = `${who}|${mint}`;
    let a = this.seen.get(k);
    if (kind === 'ENTRY' || !a || t - a.at > this.cfg.ms) a = { n: 0, px: px > 0 ? px : null, at: t, tried: -Infinity };
    a.n++;
    if (!(a.px > 0) && px > 0) a.px = px;
    this.seen.set(k, a);
    if (this.seen.size > 3000) this.seen.delete(this.seen.keys().next().value);
    if (kind !== 'ADD' || held || a.n < this.cfg.buys || t - a.tried < this.cfg.retryMs) return null;
    a.tried = t;
    const x = a.px > 0 && px > 0 ? px / a.px : null;
    if (x != null && x >= this.cfg.maxX) return { late: true, x, n: a.n };
    return { check: true, n: a.n };
  }
}
