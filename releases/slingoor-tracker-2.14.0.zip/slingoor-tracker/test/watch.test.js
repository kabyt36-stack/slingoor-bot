import { test } from 'node:test';
import assert from 'node:assert/strict';
import { CoinWatch } from '../src/watch.js';

const pair = (m, px, { liq = 20000, mc = 50000, name = 'Frog King', sym = 'FROG' } = {}) => ({ baseToken: { address: m, name, symbol: sym }, quoteToken: { symbol: 'SOL' }, priceNative: String(px), liquidity: { usd: liq }, marketCap: mc });

test('V2.13.0 coin watch: 2x/3x alerts from the traders\' buy price, never for a rug; hourly narratives; biggest coin at 12pm', async () => {
  let t = new Date(2026, 10, 16, 11, 30).getTime();
  const sent = [];
  let px = { A: 1e-7, B: 1e-7 };
  let liq = { A: 20000, B: 20000 };
  const w = new CoinWatch({
    now: () => t,
    send: (h) => sent.push(h),
    fetchPairs: async (ms) => ms.map((m) => pair(m, px[m], { liq: liq[m], mc: px[m] * 1e9 * 150 * 1e3, sym: m === 'A' ? 'FROG' : 'RUGZ', name: m === 'A' ? 'Frog King' : 'Rug Coin' })),
  });
  w.buy('A', 'cupsey', 1e-7);
  w.buy('A', 'henry', 1.2e-7);
  w.buy('B', 'dilly', 1e-7);
  await w.poll();
  assert.equal(sent.length, 0, 'no move yet');
  px = { A: 2.1e-7, B: 2.5e-7 };
  liq.B = 2000; // B's pool was pulled: a rug
  await w.poll();
  assert.equal(sent.length, 1, 'only the coin that is not a rug');
  assert.match(sent[0], /🚀 <b>2(\.\d)?x<\/b> .*\$FROG.*bought by cupsey, henry/s);
  await w.poll();
  assert.equal(sent.length, 1, 'once per step');
  px.A = 4.5e-7; // jumps past 3x and 4x: one alert at 4x
  await w.poll();
  assert.equal(sent.length, 2);
  assert.match(sent[1], /🚀 <b>4(\.\d)?x<\/b>/);
  // 12:00: the hourly narratives and the biggest coin of the last 12h
  t = new Date(2026, 10, 16, 12, 0, 5).getTime();
  w.tick();
  assert.match(sent[2], /🧭 <b>Narratives this hour<\/b> \(2 coins/);
  assert.match(sent[3], /🏆 <b>Biggest coin \(last 12h\)<\/b>: .*\$FROG.*peaked <b>4\.5x<\/b>/s);
  assert.doesNotMatch(sent[3], /RUGZ/, 'a rug is never the biggest coin');
  w.tick();
  assert.equal(sent.length, 4, 'once per hour');
});
