import test from 'node:test';
import assert from 'node:assert/strict';
import { DevWatcher, parseDevs } from '../src/devs.js';
import { isAddress } from '../src/util.js';

const W = '5hAgYC8TJCcEZV7LTXAzkTrm7YL29YXyQQJPCNrG84zM';

test('DEVS setting: name:wallet:mode', () => {
  assert.deepEqual(parseDevs(`pat:${W}:instant, nig:${W}:dip`, isAddress), [
    { name: 'pat', wallet: W, mode: 'instant' },
    { name: 'nig', wallet: W, mode: 'dip' },
  ]);
  assert.throws(() => parseDevs(`x:${W}:yolo`, isAddress), /unknown mode/);
  assert.equal(parseDevs(`r:${W}:rug`, isAddress)[0].mode, 'rug');
  assert.throws(() => parseDevs('x:notawallet:dip', isAddress), /invalid wallet/);
});

function watcher(prices, holders = () => 0, cfg = {}) {
  let now = 0;
  const ready = [];
  const w = new DevWatcher({ rpc: {}, countHolders: async () => holders(), onReady: (s) => ready.push(s), cfg, now: () => now, everyMs: 1e9 });
  let i = 0;
  w.priceOf = async () => prices[Math.min(i++, prices.length - 1)];
  return { w, ready, setNow: (t) => (now = t) };
}
const sig = { ev: { mint: 'M1', wallet: W }, kind: 'ENTRY' };

test('dip dev (nig / ya): buys only after the price falls 20% from its high', async () => {
  const { w, ready } = watcher([1, 1.2, 1.0, 0.95]);
  w.watch(sig, { name: 'nig', mode: 'dip' });
  for (let k = 0; k < 3; k++) await w.tick();
  assert.equal(ready.length, 0, '1.0 is only 17% under the 1.2 high');
  await w.tick();
  assert.equal(ready.length, 1, '0.95 is 21% under -> buy');
  assert.equal(ready[0].devReady, true);
  w.stop();
});

test('momentum dev (claudia): buys at 40+ holders AND price up 30% from launch', async () => {
  let h = 10;
  const { w, ready } = watcher([1, 1.35, 1.4, 1.45], () => h);
  w.watch(sig, { name: 'claudia', mode: 'momentum' });
  await w.tick();
  await w.tick();
  assert.equal(ready.length, 0, 'up 35% but only 10 holders');
  h = 45;
  await w.tick();
  assert.equal(ready.length, 1);
  w.stop();
});

test('dev watcher gives up after the watch window', async () => {
  const { w, ready, setNow } = watcher([1, 1, 1]);
  w.watch(sig, { name: 'nig', mode: 'dip' });
  await w.tick();
  setNow(21 * 60000);
  await w.tick();
  assert.equal(ready.length, 0);
  assert.equal(w.w.size, 0);
});

test('V2.14.0 dev-only dip: buys the dip only after real buying (+30% run); no run in 3 min = the dev will zero it, not bought', async () => {
  const a = watcher([1, 1.1, 0.85, 0.8], () => 0, { motionPct: 30, motionMs: 3 * 60000 });
  a.w.watch(sig, { name: 'pat', mode: 'dip' });
  for (let k = 0; k < 4; k++) await a.w.tick();
  assert.equal(a.ready.length, 0, 'only +10%: a dip without buyers is not bought');
  a.setNow(3 * 60000 + 1);
  await a.w.tick();
  assert.equal(a.w.w.size, 0, 'no motion in 3 min: dropped');
  const b = watcher([1, 1.4, 1.2, 1.1], () => 0, { motionPct: 30 });
  b.w.watch(sig, { name: 'pat', mode: 'dip' });
  for (let k = 0; k < 3; k++) await b.w.tick();
  assert.equal(b.ready.length, 0, '1.2 is only 14% under the 1.4 high');
  await b.w.tick();
  assert.equal(b.ready.length, 1, 'ran +40%, then 21% under the high: bought');
  b.w.stop();
});

test('V2.14.0 DEV_COPY_ONLY: only those wallets are followed as devs (dip), a trader wallet in the list moves to the dev', async () => {
  const { loadConfig } = await import('../src/config.js');
  const T = 'G9gmk9msvd6wT4hDJFm64vKra5z82YvD9je9WqjBvnuk';
  const fs = await import('node:fs');
  const os = await import('node:os');
  const path = await import('node:path');
  const f = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'cfg-')), 'settings.txt');
  const cfgOf = (kv) => {
    fs.writeFileSync(f, ['TELEGRAM_BOT_TOKEN=1:x', ...Object.entries(kv).map(([k, v]) => `${k}=${v}`)].join('\n') + '\n');
    return loadConfig(f);
  };
  const c = cfgOf({ TARGET_WALLET: W, TRADERS: `dilly:${T}`, DEV_COPY_ONLY: `dilly:${T}:dip`, COPY_TRADE: 'on', ALERT_MODE: 'on', COPY_PRIVATE_KEY_FILE: '' });
  assert.equal(c.copy.enabled, true, 'dev-only copying works in alert mode');
  assert.equal(c.copy.devOnly, true);
  const devs = c.traders.filter((t) => t.isDev);
  assert.deepEqual(devs.map((t) => [t.name, t.devMode]), [['dilly', 'dip']]);
  assert.equal(c.traders.filter((t) => !t.isDev && t.wallets.includes(T)).length, 0);
  assert.equal(c.traderOf(T), 'dilly');
  const off = cfgOf({ TARGET_WALLET: W, COPY_TRADE: 'on', ALERT_MODE: 'on', DEV_COPY_ONLY: 'off' });
  assert.equal(off.copy.enabled, false, 'alert mode without dev-only: no copying');
});
