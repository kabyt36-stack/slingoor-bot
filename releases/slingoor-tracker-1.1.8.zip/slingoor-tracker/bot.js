#!/usr/bin/env node
// slingoor tracker — Telegram alerts for a pump.fun trader's buys, full sells, callouts and launches,
// with narrative ("meta") matching against the coins he usually plays.
import fs from 'node:fs';
import path from 'node:path';
import { loadConfig, ROOT } from './src/config.js';
import { log, setLogFile } from './src/log.js';
import { State } from './src/state.js';
import { Telegram } from './src/telegram.js';
import { PumpApi } from './src/pumpapi.js';
import { Rpc } from './src/rpc.js';
import { Coins } from './src/coins.js';
import { MetaProfile, tagText } from './src/narrative.js';
import { Tracker } from './src/tracker.js';
import { ChainWatcher } from './src/chainwatch.js';
import { PumpTradesPoller, CalloutPoller, LaunchPoller } from './src/pollers.js';
import { metaSummary, metaBlock, coinLine, mcLine, linkButtons } from './src/format.js';
import { escHtml as e, fmtUsd, fmtAgo, fmtNum, fmtSol, shortAddr, sleep, isAddress, redact } from './src/util.js';
import { loadKeypair, signTx, verifyTxSignature } from './src/solana.js';
import { Swapper, CopyTrader } from './src/copytrade.js';
import { RentReclaimer } from './src/reclaim.js';

const TEST_MINT = 'C5xph2yL6gMdxmuLGxJBkGpmuDFfyi5fqkBNhvL6pump'; // $BTC, used to test building a swap (never sent)
// one-line description of how buys are sized
const sizeText = (c) =>
  c.sizeMode === 'scale'
    ? `buys scaled to his (1 SOL → ${fmtSol(c.scaleAt1)}, max ${fmtSol(c.maxBuySol)} SOL, ≤${c.maxWalletPct}% of wallet per buy)`
    : `${fmtSol(c.buySol)} SOL per buy`;

const startedAt = Date.now();
const VERSION = (() => {
  try {
    return JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8')).version;
  } catch {
    return '?';
  }
})();
const SUPERVISED = process.env.SUPERVISED === '1';
// Exit code 2 = a settings problem: the start script won't auto-restart on it.
const CONFIG_ERROR = 2;

// `node bot.js --check` tests every connection once and prints the result (used by 1-Setup).
async function selfCheck(cfg) {
  const results = [];
  const step = async (name, fn, critical = true) => {
    try {
      const detail = await fn();
      results.push({ ok: true, name, detail, critical });
      console.log(`  ✅ ${name}${detail ? ` — ${detail}` : ''}`);
    } catch (err) {
      results.push({ ok: false, name, critical });
      console.log(`  ${critical ? '❌' : '⚠️ '} ${name} — ${redact(err.message).slice(0, 160)}`);
    }
  };
  console.log('\nChecking connections…');
  await step('Node.js version', async () => {
    if (typeof WebSocket === 'undefined') throw new Error(`Node ${process.versions.node} is too old, need 22+`);
    return process.versions.node;
  });
  await step('Telegram bot token', async () => {
    if (!cfg.telegramToken) throw new Error('TELEGRAM_BOT_TOKEN is empty in settings.txt');
    const me = await new Telegram({ token: cfg.telegramToken, apiBase: cfg.telegramApi }).getMe();
    return `@${me.username}`;
  });
  const pump = new PumpApi({ base: cfg.pumpApi, profileBase: cfg.profileApi, dexApi: cfg.dexApi, enabled: cfg.usePumpfun });
  let userId = null;
  if (cfg.usePumpfun) await step('pump.fun profile', async () => {
    const u = await pump.getUser(cfg.wallets[0]);
    userId = u.userId;
    return `@${u.username} · ${fmtNum(u.followers || 0)} followers`;
  }, false);
  if (userId) {
    await step('pump.fun callouts', async () => {
      try {
        return `${(await pump.getCallouts(userId, 5)).length} recent callouts readable`;
      } catch {
        const { tokens } = await pump.getHoldings(cfg.wallets[0], 1, 20);
        const ps = await pump.getPositions(cfg.wallets[0], tokens.map((t) => t.token_mint));
        return `callout list is blocked right now — reading them from his positions instead (${ps.filter((p) => p.callout).length} found)`;
      }
    }, false);
    await step('pump.fun trades feed', async () => `${(await pump.getUserTrades(userId, 5)).trades.length} recent trades readable`, false);
  }
  const rpc = new Rpc(cfg.rpcUrl);
  await step('Solana RPC', async () => `slot ${await rpc.call('getSlot', [])}`);
  await step('Solana live stream (websocket)', () =>
    new Promise((resolve, reject) => {
      const ws = new WebSocket(cfg.wsUrl);
      const t = setTimeout(() => {
        try {
          ws.close();
        } catch {}
        reject(new Error('no answer in 10s'));
      }, 10000);
      ws.onopen = () => ws.send(JSON.stringify({ jsonrpc: '2.0', id: 1, method: 'accountSubscribe', params: [cfg.wallets[0], { commitment: 'confirmed', encoding: 'base64' }] }));
      ws.onmessage = (m) => {
        clearTimeout(t);
        ws.close();
        const j = JSON.parse(m.data);
        j.error ? reject(new Error(j.error.message)) : resolve('subscribed');
      };
      ws.onerror = () => {
        clearTimeout(t);
        reject(new Error('could not connect'));
      };
    }),
  );
  if (cfg.copy.enabled) {
    let kp = null;
    await step('Copy trading wallet', async () => {
      if (!cfg.copy.privateKey) throw new Error('COPY_TRADE is on but no private key (run "3 - Copy Trade Setup")');
      kp = loadKeypair(cfg.copy.privateKey);
      if (cfg.wallets.includes(kp.publicKey)) throw new Error('that key is for the wallet you are tracking — use your own wallet');
      const bal = await rpc.call('getBalance', [kp.publicKey, { commitment: 'confirmed' }]);
      const sol = (bal?.value ?? 0) / 1e9;
      const first = cfg.copy.sizeMode === 'scale' ? cfg.copy.scaleAt1 : cfg.copy.buySol;
      const need = first + cfg.copy.keepSol + cfg.copy.priorityFee + 0.003;
      return `${kp.publicKey} · ${fmtSol(sol)} SOL${sol < need ? ` — ⚠️ low: a typical ${fmtSol(first)} SOL copy buy needs ${fmtSol(need)} SOL (smaller buys still work: max ${cfg.copy.maxWalletPct}% of the wallet each)` : ''}`;
    });
    if (kp) {
      await step('Copy trading: build + sign a test swap (not sent)', async () => {
        const sw = new Swapper({ rpc, kp, jupBase: cfg.copy.jupBase, jupKey: cfg.copy.jupKey, portalBase: cfg.copy.portalBase, slippage: cfg.copy.slippage, priorityFee: cfg.copy.priorityFee });
        const bytes = await sw._jupBuild({ inputMint: 'So11111111111111111111111111111111111111112', outputMint: TEST_MINT, amount: Math.round((cfg.copy.sizeMode === 'scale' ? cfg.copy.scaleAt1 : cfg.copy.buySol) * 1e9) }, { allowSimError: true });
        const { bytes: signed } = signTx(bytes, kp);
        if (!verifyTxSignature(signed, kp.publicKey)) throw new Error('signature check failed');
        // ask the Solana network to check our signature (nothing is sent or spent)
        const sim = await rpc.call('simulateTransaction', [Buffer.from(signed).toString('base64'), { encoding: 'base64', sigVerify: true, commitment: 'confirmed' }]);
        if (/Signature/i.test(JSON.stringify(sim?.value?.err || ''))) throw new Error('the network rejected our signature');
        return 'Jupiter + signing work (Solana accepted the signature)';
      });
    }
  }
  const bad = results.filter((r) => !r.ok && r.critical);
  const warn = results.filter((r) => !r.ok && !r.critical);
  console.log('');
  if (bad.length) console.log('❌ Fix the items above, then run the check again.');
  else if (warn.length) console.log('⚠️  Trades will still be caught on-chain, but pump.fun callouts/feeds are not reachable right now.');
  else console.log('✅ Everything works. Start the bot and send /start to it in Telegram.');
  process.exit(bad.length ? 1 : 0);
}

async function main() {
  let cfg;
  try {
    cfg = loadConfig();
  } catch (err) {
    console.error(`Settings problem: ${err.message}`);
    process.exit(CONFIG_ERROR);
  }
  if (process.argv.includes('--check')) return selfCheck(cfg);
  setLogFile(cfg.logFile);
  log.info(`Starting tracker for ${cfg.targetName} (${cfg.wallets.map((w) => shortAddr(w)).join(', ')})`);

  if (typeof WebSocket === 'undefined' || typeof fetch === 'undefined') {
    log.error('This bot needs Node.js 22 or newer. Run 1-Setup again.');
    process.exit(CONFIG_ERROR);
  }
  if (!cfg.telegramToken) {
    log.error('TELEGRAM_BOT_TOKEN is empty. Open settings.txt (or run 1-Setup) and paste your bot token from @BotFather.');
    process.exit(CONFIG_ERROR);
  }

  // copy-trading key is checked before anything else, so a bad key stops the bot right away
  let copyKp = null;
  if (cfg.copy.enabled) {
    try {
      copyKp = loadKeypair(cfg.copy.privateKey);
    } catch (err) {
      log.error(`Copy trading is on but the wallet key can't be used: ${err.message}. Run "3 - Copy Trade Setup" again, or set COPY_TRADE=off.`);
      process.exit(CONFIG_ERROR);
    }
    if (cfg.wallets.includes(copyKp.publicKey)) {
      log.error("The copy-trading key is for the wallet you're tracking. Use your own wallet's key.");
      process.exit(CONFIG_ERROR);
    }
  }

  const state = new State(cfg.stateFile);
  stateRef = state;
  const tg = new Telegram({ token: cfg.telegramToken, apiBase: cfg.telegramApi });
  for (let i = 0; ; i++) {
    try {
      const me = await tg.getMe();
      log.info(`Telegram bot: @${me.username}`);
      break;
    } catch (err) {
      if (/401|Unauthorized|404/i.test(err.message)) {
        log.error('Telegram rejected the bot token. Check TELEGRAM_BOT_TOKEN in settings.txt.');
        process.exit(CONFIG_ERROR);
      }
      log.warn('Telegram not reachable yet:', err.message);
      await sleep(Math.min(30000, 2000 * (i + 1)));
    }
  }

  const pump = new PumpApi({ base: cfg.pumpApi, profileBase: cfg.profileApi, dexApi: cfg.dexApi, enabled: cfg.usePumpfun });
  const rpc = new Rpc(cfg.rpcUrl, cfg.isPublicRpc ? { minGapMs: 250, concurrency: 2 } : { minGapMs: 40, concurrency: 4 });
  const coins = new Coins({ pump, dexApi: cfg.dexApi, rpcUrl: cfg.rpcUrl });
  const profile = new MetaProfile({ selfWords: cfg.selfWords });
  // Separate lane for the quick balance checks that decide "new entry or add?" / "fully out?", so they
  // never queue behind the chain watcher's transaction downloads (which back off when rate-limited).
  const fastRpc = new Rpc(cfg.rpcUrl, cfg.isPublicRpc ? { minGapMs: 100, concurrency: 2 } : { minGapMs: 20, concurrency: 4 });
  const tracker = new Tracker({ cfg, state, tg, pump, rpc: fastRpc, coins, profile });
  const users = {}; // wallet -> {userId, username, followers}

  // ---------- Copy trading ----------
  let copier = null;
  if (cfg.copy.enabled) {
    const kp = copyKp;
    const tradeRpc = new Rpc(cfg.rpcUrl, cfg.isPublicRpc ? { minGapMs: 120, concurrency: 3 } : { minGapMs: 20, concurrency: 6 });
    const swapper = new Swapper({ rpc: tradeRpc, kp, jitoUrls: cfg.copy.jitoUrls, jupBase: cfg.copy.jupBase, jupKey: cfg.copy.jupKey, portalBase: cfg.copy.portalBase, slippage: cfg.copy.slippage, priorityFee: cfg.copy.priorityFee });
    copier = new CopyTrader({
      cfg: cfg.copy,
      rpc: tradeRpc,
      kp,
      swapper,
      pump,
      coins,
      broadcast: (html, buttons) => tracker.broadcast(html, buttons),
      getSolPrice: () => tracker.solPrice,
      file: cfg.copy.file,
    });
    tracker.onSignal = (sig) => copier.onSignal(sig);
    tracker.onMaybeEntry = (ev) => copier.onMaybeEntry(ev);
    copier.start();
    if (cfg.copy.reclaimRent) {
      const reclaimer = new RentReclaimer({
        rpc,
        swapper,
        owner: kp.publicKey,
        isBusy: (m) => copier.isBusy(m),
        isOurs: (m) => copier.traded.has(m),
        notify: (html) => tracker.broadcast(html),
        minAgeMs: Math.max(0, +(process.env.RECLAIM_MIN_AGE_MS ?? 120000)),
      });
      const every = Math.max(5000, +(process.env.RECLAIM_EVERY_MS ?? 600000));
      setTimeout(() => {
        reclaimer.run().catch((err) => log.warn('rent reclaim failed', err.message));
        setInterval(() => reclaimer.run().catch((err) => log.warn('rent reclaim failed', err.message)), every);
      }, Math.min(every, 120000));
    }
    log.info(`Copy trading LIVE with wallet ${kp.publicKey}: ${sizeText(cfg.copy)}, adds ${cfg.copy.copyAdds ? 'on' : 'off'}, mirror sells ${cfg.copy.mirrorSells ? 'on' : 'off'}, TP ${cfg.copy.tpPercent}% at ${cfg.copy.tpX}x${copier.paused ? ' (currently PAUSED — /resume in Telegram)' : ''}`);
  }
  const pollers = [];

  // ---------- Telegram commands ----------
  const isAllowed = (chatId) => (cfg.chatIds.length ? cfg.chatIds.includes(chatId) : state.chats.includes(chatId));

  async function statusText() {
    const lines = [`📡 <b>Tracker status — ${e(cfg.targetName)}</b>`];
    for (const w of cfg.wallets) {
      const u = users[w];
      lines.push(`👛 <code>${w}</code>${u ? `\n     pump.fun @${e(u.username)}${u.followers ? ` · ${fmtNum(u.followers)} followers` : ''}` : ''}`);
    }
    const s = chain.stats;
    const rpcName = cfg.rpcUrl.includes('helius') ? 'Helius' : cfg.isPublicRpc ? 'public Solana RPC' : 'custom RPC';
    lines.push(
      `${chain.connected ? '🟢' : '🔴'} On-chain stream (${rpcName}): ${chain.connected ? `connected ${fmtAgo(Date.now() - chain.connectedAt)}` : 'reconnecting…'} · ${fmtNum(s.notifications)} mentions · ${s.fetched} checked · ${s.his} his txs${s.fast ? ` · ${s.fast} read straight from the stream` : ''}${s.reconnects > 3 ? ` · ${s.reconnects} reconnects` : ''}`,
    );
    const rc = chain.recentCatches;
    if (rc.length) {
      const lags = rc.map((x) => x.lagMs).sort((a, b) => a - b);
      lines.push(`⚡ Chain speed: his last ${rc.length} txs caught a median ${fmtAgo(lags[Math.floor(lags.length / 2)])} after they landed`);
    }
    for (const p of pollers) {
      const l = p.loop;
      const ok = l.lastOkAt && Date.now() - l.lastOkAt < Math.max(30000, l.intervalMs * 4);
      const via = p.via === 'positions' ? ' (via his positions — pump.fun callout list is blocking us)' : '';
      lines.push(`${ok ? '🟢' : l.lastOkAt ? '🟠' : '🔴'} ${l.name}: ${l.lastOkAt ? `ok ${fmtAgo(Date.now() - l.lastOkAt)} ago` : 'not working yet'}${via}${!ok && l.lastError ? ` (${e(l.lastError.slice(0, 80))})` : ''}`);
    }
    if (!cfg.usePumpfun) lines.push('⚪️ pump.fun: not used — everything comes from the chain (callouts off)');
    else if (!pollers.length) lines.push('🟠 pump.fun feeds: waiting for pump.fun profile lookup' + (pump.lastError ? ` (${e(pump.lastError.slice(0, 80))})` : ''));
    const top = profile.topTags(3).map((t) => `${tagText([t.tag])} ${Math.round(t.share * 100)}%`).join(', ');
    lines.push(`🧠 Meta learned from ${profile.coins.size} coins${top ? ` — ${top}` : ''}`);
    const c = tracker.counts;
    lines.push(`📬 Since start: ${c.entries} entries · ${c.adds} adds · ${c.partials} partial sells · ${c.exits} full exits · ${c.callouts} callouts · ${c.launches} launches`);
    if (copier) lines.push(`🤖 Copy trading: ${copier.paused ? '⏸ paused' : '🟢 live'} · ${copier.stats.buys} buys · ${copier.stats.sells} sells · ${Object.values(copier.positions).filter((p) => p.tokens > 0).length} open (/copy)`);
    lines.push(`⏱ Up ${fmtAgo(Date.now() - startedAt)} · v${VERSION}${SUPERVISED ? ' · auto-restart + auto-update on' : ''}`);
    return lines.join('\n');
  }

  async function checkCoin(chatId, mint) {
    const coin = await coins.get(mint, { timeoutMs: 5000 });
    if (!coin?.name) return tg.send(chatId, `Couldn't find that coin (<code>${e(mint)}</code>).`);
    const m = profile.match({ ...coin, mint });
    const holding = await tracker.holdingFor(cfg.wallets[0], mint);
    const lines = [`🔎 ${coinLine(coin, mint)}`];
    const mc = mcLine(coin);
    if (mc) lines.push(mc);
    if (holding) lines.push(holding.held ? `👜 ${e(cfg.targetName)} is holding it${holding.pnlPct != null ? ` (${holding.pnlPct.toFixed(0)}%)` : ''}` : holding.exited ? `👜 ${e(cfg.targetName)} traded it and is out` : `👜 ${e(cfg.targetName)} doesn't hold it`);
    lines.push('', ...metaBlock(m), '', `<code>${mint}</code>`);
    return tg.send(chatId, lines.join('\n'), linkButtons(mint));
  }

  async function handleMessage(msg) {
    const chatId = String(msg.chat.id);
    const text = msg.text.trim();
    const [rawCmd, ...args] = text.split(/\s+/);
    const cmd = rawCmd.split('@')[0].toLowerCase();

    if (cmd === '/id') return tg.send(chatId, `This chat's id: <code>${chatId}</code>`);
    if (cmd === '/start') {
      if (!isAllowed(chatId)) {
        if (!cfg.chatIds.length && !state.chats.length) {
          state.chats.push(chatId);
          state.saveNow();
          log.info(`Chat ${chatId} registered for alerts`);
        } else {
          return tg.send(chatId, '🔒 This tracker is private. To add this chat, put its id (send /id) in TELEGRAM_CHAT_ID in settings.txt and restart.');
        }
      }
      await tg.send(
        chatId,
        `✅ <b>You're set.</b> Alerts for <b>${e(cfg.targetName)}</b> will land in this chat:\n` +
          '🟢 new entries · ➕ adds · 🟠 partial sells · 🔴 full sell-outs · 📣 callouts · 🚀 launches\n' +
          'Every buy is tagged with its narrative and how well it matches his meta.\n\n' +
          'Commands: /status /meta /bags /recent /callouts /check &lt;CA&gt; /test /help' +
          (copier ? `\n\n🤖 <b>Copy trading is ${copier.paused ? 'PAUSED' : 'LIVE'}</b> — /copy for details, /pause to stop buying.` : ''),
      );
      return tg.send(chatId, await statusText());
    }
    if (!isAllowed(chatId)) return;

    switch (cmd) {
      case '/help':
        return tg.send(
          chatId,
          [
            '<b>Commands</b>',
            '/status — is everything connected',
            "/meta — the narratives he plays (his meta)",
            '/bags — his biggest current bags',
            '/recent — last alerts',
            '/callouts — his latest pump.fun callouts and how they did',
            '/check &lt;CA&gt; — does a coin fit his meta? (or just paste a CA)',
            '/test — send a sample alert',
            '/id — show this chat id',
            '/version — bot version · /update — check for an update now',
            ...(copier
              ? ['', '<b>Copy trading</b>', '/copy — your wallet, settings and open copy positions', '/pause — stop copying new buys (sells still follow him)', '/resume — start copying again', '/sell &lt;CA&gt; [percent] — sell a copy position yourself (default 100%)']
              : []),
          ].join('\n'),
        );
      case '/status':
        return tg.send(chatId, await statusText());
      case '/meta':
        return tg.send(chatId, metaSummary(profile, cfg.targetName));
      case '/recent': {
        const r = state.recent.slice(-15).reverse();
        return tg.send(chatId, r.length ? `<b>Last alerts</b>\n${r.map((x) => `${fmtAgo(Date.now() - x.t)} ago — ${e(x.line)}`).join('\n')}` : 'No alerts yet.');
      }
      case '/bags': {
        const bags = await loadBags(cfg.wallets[0], { maxPages: 1, maxRpcCoins: 25 }).catch(() => []);
        if (!bags.length) return tg.send(chatId, "Couldn't load his bags right now.");
        const lines = [`👜 <b>${e(cfg.targetName)}'s biggest bags</b>`];
        for (const t of bags.slice(0, 15)) {
          const m = profile.match({ name: t.name, symbol: t.symbol, mint: t.mint });
          lines.push(`${m.level === 3 ? '🔥' : m.level === 2 ? '🟢' : '▫️'} <b>$${e(t.symbol || '?')}</b> ${e(t.name || '')} — ${t.value ? fmtUsd(t.value) : 'value n/a'}`);
        }
        return tg.send(chatId, lines.join('\n'));
      }
      case '/callouts': {
        if (!cfg.usePumpfun) return tg.send(chatId, '📣 Callouts come only from pump.fun, which this bot no longer uses (USE_PUMPFUN=off in settings.txt).');
        const u = users[cfg.wallets[0]];
        if (!u) return tg.send(chatId, 'pump.fun profile not loaded yet.');
        const cp = pollers.find((p) => p instanceof CalloutPoller);
        const list = (await pump.getCallouts(u.userId, 6).catch(() => null)) || (cp?.lastList || []).slice(0, 6);
        const lines = [`📣 <b>${e(cfg.targetName)}'s latest callouts</b>`];
        for (const c of list) {
          const coin = await coins.get(c.coinMint, { fresh: false, timeoutMs: 2000 });
          lines.push(`• <b>$${e(coin?.symbol || shortAddr(c.coinMint))}</b> ${fmtAgo(Date.now() - c.createdAt)} ago @ ${fmtUsd(c.marketCap)} → now ${(+c.multiple || 0).toFixed(2)}x · peak ${(+c.maxMultiplier || 0).toFixed(1)}x`);
        }
        return tg.send(chatId, list.length ? lines.join('\n') : "Couldn't load callouts right now.");
      }
      case '/version':
        return tg.send(chatId, `🏷 Version <b>v${e(VERSION)}</b>${SUPERVISED ? '\n♻️ Auto-restart and auto-update are on (checks every 10 min). /update to check now.' : '\n⚠️ Started without the watchdog — use “2 - Start Bot” or “Auto-start ON” from the latest package for auto-restart and auto-update.'}`);
      case '/update':
        if (!SUPERVISED) return tg.send(chatId, '⚠️ Auto-update needs the watchdog: start the bot with “2 - Start Bot” or “Auto-start ON” from the latest package.');
        try {
          fs.mkdirSync(path.join(ROOT, 'data'), { recursive: true });
          fs.writeFileSync(path.join(ROOT, 'data', 'update-now'), String(Date.now()));
        } catch {}
        return tg.send(chatId, '🔎 Checking for an update… if there is one it gets tested on your Mac first (about a minute), then the bot restarts on it.');
      case '/copy':
        if (!copier) return tg.send(chatId, '🤖 Copy trading is off. Run "3 - Copy Trade Setup" to turn it on.');
        return tg.send(chatId, await copier.statusText());
      case '/pause':
        if (!copier) return tg.send(chatId, '🤖 Copy trading is off.');
        copier.setPaused(true);
        return tg.send(chatId, '⏸ <b>Copy trading paused.</b> No new buys. Coins you already hold still sell when he sells (and at take profit). /resume to start again.');
      case '/resume':
        if (!copier) return tg.send(chatId, '🤖 Copy trading is off.');
        copier.setPaused(false);
        return tg.send(chatId, `▶️ <b>Copy trading is live again.</b> Next buy of his gets copied: ${sizeText(cfg.copy)}.`);
      case '/sell': {
        if (!copier) return tg.send(chatId, '🤖 Copy trading is off.');
        if (!isAddress(args[0])) return tg.send(chatId, 'Usage: /sell &lt;coin address&gt; [percent]   e.g. /sell 7xKX…pump 50');
        const pct = args[1] ? Math.round(+String(args[1]).replace('%', '')) : 100;
        if (!(pct >= 1 && pct <= 100)) return tg.send(chatId, 'Percent must be 1–100.');
        const bal = await copier.tokenBalance(args[0]).catch(() => null);
        if (bal === 0) return tg.send(chatId, "Your wallet doesn't hold that coin.");
        await tg.send(chatId, `⏳ Selling ${pct}% of <code>${e(args[0])}</code>…`);
        copier.manualSell(args[0], pct);
        return;
      }
      case '/check':
        if (!isAddress(args[0])) return tg.send(chatId, 'Usage: /check &lt;coin address&gt;');
        return checkCoin(chatId, args[0]);
      case '/test': {
        const html =
          `🧪 <b>TEST ALERT</b> (this is what a buy alert looks like)\n\n🟢 <b>${e(cfg.targetName.toUpperCase())} NEW ENTRY</b> <b>$BTC</b> — Big Titty Coin\n💰 Bought <b>2.50 SOL</b>\n` +
          metaBlock(profile.match({ name: 'Big Titty Coin', symbol: 'BTC', mint: 'test' })).join('\n');
        return tg.send(chatId, html);
      }
      default:
        if (isAddress(cmd) || isAddress(text)) return checkCoin(chatId, isAddress(cmd) ? rawCmd : text);
    }
  }

  // ---------- Sources ----------
  const chain = new ChainWatcher({ wsUrl: cfg.wsUrl, rpc, wallets: cfg.wallets });
  chain.on('trade', (ev) => tracker.handleTrade(ev));
  chain.on('launch', (l) => tracker.handleLaunch(l).catch((err) => log.error('launch alert failed', err.message)));
  chain.start();
  tg.poll(handleMessage);
  log.info(`RPC: ${redact(cfg.rpcUrl)}${cfg.isPublicRpc ? ' (public — add a free Helius key in settings.txt for faster, more reliable alerts)' : ''}`);

  // coins to check for callouts if pump.fun's callout list is unavailable: newest activity first, then biggest bags
  const watchMints = () =>
    Object.entries(state.positions)
      .filter(([, p]) => p.ui > 0 || Date.now() - (p.lastAt || 0) < 6 * 3600000)
      .sort((a, b) => (b[1].lastAt || 0) - (a[1].lastAt || 0) || (b[1].valueUsd || 0) - (a[1].valueUsd || 0))
      .map(([m]) => m);

  const startPollersFor = (wallet, u) => {
    // one trades/callout feed per pump.fun account, one launch feed per wallet
    if (!pollers.some((p) => p.userId === u.userId && p instanceof PumpTradesPoller)) {
      const tp = new PumpTradesPoller({ pump, state, userId: u.userId, wallet, intervalMs: cfg.tradesPollMs });
      tp.on('trade', (ev) => tracker.handleTrade(ev));
      tp.on('solPrice', (p) => {
        if (!tracker.solPrice) tracker.solPrice = p;
      });
      const cp = new CalloutPoller({ pump, state, userId: u.userId, wallet, intervalMs: cfg.calloutPollMs, listEveryMs: cfg.calloutListMs, watchMints });
      cp.on('callout', (c, w) => tracker.handleCallout(c, w).catch((err) => log.error('callout alert failed', err.message)));
      cp.on('calloutUpdate', (c, w, txt) => tracker.handleCallout(c, w, { isUpdate: true, updateText: txt }).catch((err) => log.error('update alert failed', err.message)));
      pollers.push(tp, cp);
      tp.start();
      cp.start();
    }
    const lp = new LaunchPoller({ pump, state, wallet, intervalMs: cfg.launchPollMs });
    lp.on('launch', (l) => tracker.handleLaunch(l).catch((err) => log.error('launch alert failed', err.message)));
    pollers.push(lp);
    lp.start();
  };

  const resolveUsers = async () => {
    for (const w of cfg.wallets) {
      if (users[w]) continue;
      try {
        const u = await pump.getUser(w);
        if (!u?.userId) throw new Error('no pump.fun profile for this wallet');
        users[w] = { userId: u.userId, username: u.username || shortAddr(w), followers: u.followers };
        state.callers[w] = users[w];
        log.info(`pump.fun profile: @${users[w].username} (${fmtNum(u.followers || 0)} followers)`);
        startPollersFor(w, users[w]);
      } catch (err) {
        if (!err.cloudflare) log.warn(`pump.fun profile lookup for ${shortAddr(w)} failed: ${err.message} — retrying in 60s`);
      }
    }
    if (cfg.wallets.some((w) => !users[w])) setTimeout(resolveUsers, 60000);
  };
  if (cfg.usePumpfun) await resolveUsers();
  else log.info('pump.fun not used: trades, launches and coin info come from the chain, DexScreener and Helius (callouts off)');

  // ---------- His bags ----------
  // pump.fun's bag list (profile-api) is behind Cloudflare and sometimes blocks home connections
  // ("Just a moment..."). Then his bags are read straight from the chain instead.
  let bagsBlockedLogged = false;
  async function loadBags(wallet, { maxPages = 25, maxRpcCoins = 60 } = {}) {
    const out = [];
    try {
      for (let page = 1; page <= maxPages; page++) {
        const { tokens, totalPages } = await pump.getHoldings(wallet, page, 20);
        for (const t of tokens) out.push({ mint: t.token_mint, name: t.token_name, symbol: t.token_symbol, image: t.token_image, balance: +t.balance || 0, value: +t.value || 0 });
        if (page >= totalPages) break;
      }
      return out;
    } catch (err) {
      if (out.length) return out;
      if (!bagsBlockedLogged && !err.disabled) {
        bagsBlockedLogged = true;
        log.info(`pump.fun bag list unavailable (${/403|Just a moment/i.test(err.message) ? 'blocked by Cloudflare' : err.message.slice(0, 60)}); reading his bags from the chain instead`);
      }
    }
    const accts = [];
    for (const programId of ['TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA', 'TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb']) {
      const r = await rpc.call('getTokenAccountsByOwner', [wallet, { programId }, { encoding: 'jsonParsed', commitment: 'confirmed' }]).catch(() => null);
      for (const a of r?.value || []) {
        const info = a.account?.data?.parsed?.info;
        const ui = +info?.tokenAmount?.uiAmount || 0;
        if (info?.mint && ui > 0) accts.push({ mint: info.mint, balance: ui });
      }
    }
    const QUOTES = new Set(['EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v', 'Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB', 'So11111111111111111111111111111111111111112', 'USD1ttGY1N17NEEHLmELoaybftRBUSErhqYiQzvEmuB']);
    // biggest balances first (pump coins all have 1B supply, so balance is a fair first guess at size)
    const pick = accts.filter((a) => !QUOTES.has(a.mint)).sort((a, b) => b.balance - a.balance).slice(0, maxRpcCoins);
    let i = 0;
    await Promise.all(
      Array.from({ length: 4 }, async () => {
        while (i < pick.length) {
          const a = pick[i++];
          const c = await coins.get(a.mint, { fresh: false, timeoutMs: 5000 }).catch(() => null);
          if (!c?.name) continue;
          out.push({ mint: a.mint, name: c.name, symbol: c.symbol, image: c.image, balance: a.balance, value: c.mc ? (a.balance * c.mc) / 1e9 : 0 });
        }
      }),
    );
    return out.sort((a, b) => b.value - a.value);
  }

  // ---------- Learn his meta ----------
  const learnMeta = async () => {
    // Build from scratch each time so old data doesn't pile up, then swap it in.
    const next = new MetaProfile({ selfWords: cfg.selfWords });
    for (const w of cfg.wallets) {
      // 1) current bags, weighted by size
      try {
        for (const t of await loadBags(w)) {
          next.add({ mint: t.mint, name: t.name, symbol: t.symbol, valueUsd: t.value }, 1 + Math.log10(1 + t.value / 1000), 'bag');
          coins.remember(t.mint, { name: t.name, symbol: t.symbol, image: t.image });
          const p = tracker.pos(t.mint);
          if (!p.tracked) p.ui = t.balance; // starting bag sizes
          p.valueUsd = t.value;
        }
      } catch (err) {
        log.warn('Could not load his bags:', err.message);
      }
      if (!cfg.usePumpfun) continue;
      // 2) coins he launched
      try {
        const { coins: created } = await pump.getCreatedCoins(w, 100, 0);
        for (const c of created) next.add({ mint: c.mint, name: c.name, symbol: c.symbol, twitter: c.twitter, nsfw: c.nsfw }, 1, 'launch');
      } catch {}
      const u = users[w];
      if (!u) continue;
      // 3) coins from his recent trades
      try {
        const { coins: tc } = await pump.getUserTrades(u.userId, 100);
        for (const c of Object.values(tc)) {
          next.add({ mint: c.mint, name: c.name, symbol: c.symbol }, 0.5, 'trade');
          coins.remember(c.mint, { name: c.name, symbol: c.symbol });
        }
      } catch {}
      // 4) his callouts (needs a name lookup per coin)
      try {
        const cp = pollers.find((p) => p instanceof CalloutPoller);
        const calls = (await pump.getCallouts(u.userId, 100).catch(() => null)) || cp?.lastList || [];
        for (const c of calls) {
          const coin = await coins.get(c.coinMint, { fresh: false, timeoutMs: 4000 });
          if (coin?.name) next.add({ mint: c.coinMint, name: coin.name, symbol: coin.symbol, twitter: coin.twitter, nsfw: coin.nsfw }, 1, 'callout');
        }
      } catch {}
    }
    if (next.coins.size) {
      // keep coins learned live since the last rebuild
      for (const [mint, c] of profile.coins) if (!next.coins.has(mint)) next.coins.set(mint, c);
      profile.coins = next.coins;
      profile._recount();
    }
    tracker.prunePositions();
    state.save();
    const top = profile.topTags(4).map((t) => `${t.tag} ${Math.round(t.share * 100)}%`).join(', ');
    log.info(`Meta learned from ${profile.coins.size} coins: ${top}`);
  };
  learnMeta().catch((err) => log.warn('meta learning failed', err.message));
  setInterval(() => learnMeta().catch(() => {}), 6 * 3600 * 1000);

  // ---------- SOL price ----------
  const refreshSol = async () => {
    const p = await pump.getSolPrice().catch(() => null);
    if (p) tracker.solPrice = p;
  };
  refreshSol();
  setInterval(refreshSol, 60000);

  // ---------- Startup notice + health ----------
  for (const chatId of tracker.chats()) {
    tg.send(chatId, `✅ <b>Tracker online</b> (v${e(VERSION)}) — watching <b>${e(cfg.targetName)}</b> (${cfg.wallets.map((w) => `<code>${shortAddr(w)}</code>`).join(', ')}). Send /status anytime.${copier ? `\n🤖 Copy trading <b>${copier.paused ? 'PAUSED' : 'LIVE'}</b>: ${sizeText(cfg.copy)}, wallet <code>${shortAddr(copier.kp.publicKey)}</code> — /copy` : ''}`).catch(() => {});
  }
  if (!tracker.chats().length) log.info('No Telegram chat yet: open your bot in Telegram and send /start');

  // ---------- Watchdog heartbeat + messages from the supervisor ----------
  const dataDir = path.join(ROOT, 'data');
  const beat = () => {
    try {
      fs.mkdirSync(dataDir, { recursive: true });
      const f = path.join(dataDir, 'heartbeat.json');
      fs.writeFileSync(f + '.tmp', JSON.stringify({ at: Date.now(), pid: process.pid, version: VERSION, chain: chain.connected }));
      fs.renameSync(f + '.tmp', f);
    } catch {}
  };
  // Missed time: the Mac slept or the bot was off. Trades in that window can't be copied, so say so.
  const aliveFile = path.join(dataDir, 'last-alive.json');
  const hhmm = (t) => new Date(t).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
  const warnGap = (from, to, why) => {
    if (to - from < 120000) return;
    const mins = Math.round((to - from) / 60000);
    log.warn(`Missed ${mins} min (${why}): ${new Date(from).toISOString()} -> ${new Date(to).toISOString()}`);
    const text = `⚠️ <b>The bot was ${why} for ${mins >= 120 ? `${Math.round(mins / 60)}h` : `${mins} min`}</b> (${hhmm(from)} → ${hhmm(to)}). ${e(cfg.targetName)}'s trades in that time were <b>not</b> copied.${/asleep/.test(why) ? '\nKeep the Mac plugged in and the lid open while the bot runs.' : ''}`;
    for (const chatId of tracker.chats()) tg.send(chatId, text).catch(() => {});
  };
  try {
    const prev = JSON.parse(fs.readFileSync(aliveFile, 'utf8'));
    if (prev?.at) warnGap(prev.at, startedAt, 'off (or the Mac was asleep)');
  } catch {}
  let lastTick = Date.now();
  setInterval(() => {
    const now = Date.now();
    if (now - lastTick > 90000) warnGap(lastTick, now, 'asleep with the Mac'); // timers stop while the Mac sleeps
    lastTick = now;
    try {
      fs.writeFileSync(aliveFile, JSON.stringify({ at: now }));
    } catch {}
  }, 10000);
  beat();
  setInterval(beat, 20000);
  const deliverNotices = () => {
    const f = path.join(dataDir, 'notices.json');
    let list = [];
    try {
      list = JSON.parse(fs.readFileSync(f, 'utf8'));
      fs.rmSync(f, { force: true });
    } catch {
      return;
    }
    for (const n of list.slice(-10)) for (const chatId of tracker.chats()) tg.send(chatId, n.text).catch(() => {});
  };
  deliverNotices();
  setInterval(deliverNotices, 15000);

  let warnedAt = 0;
  setInterval(() => {
    const s = chain.stats;
    log.info(
      `alive · chain ${chain.connected ? 'up' : 'DOWN'} (${s.notifications} mentions, ${s.fetched} checked, ${s.his} his)${cfg.usePumpfun ? ` · pump ${pump.ok} ok/${pump.fail} err` : ''} · rpc ${rpc.ok} ok/${rpc.fail} err`,
    );
    const pumpDown = !pollers.length || pollers.every((p) => !p.loop.lastOkAt || Date.now() - p.loop.lastOkAt > 120000);
    // everything down for 10 minutes: a fresh start usually fixes stuck sockets/DNS
    if (!chain.connected && pumpDown && Date.now() - startedAt > 600000 && Date.now() - (chain.lastMsgAt || startedAt) > 600000) {
      log.warn('Chain stream and pump.fun feeds down for 10+ minutes; restarting the bot');
      try {
        state.saveNow();
        copier?.save();
      } catch {}
      process.exit(1);
    }
    if (!chain.connected && pumpDown && Date.now() - warnedAt > 3600000 && Date.now() - startedAt > 120000) {
      warnedAt = Date.now();
      for (const chatId of tracker.chats()) tg.send(chatId, '⚠️ Both the chain stream and pump.fun feeds are down right now — alerts may be missed. Check your internet / /status.').catch(() => {});
    }
  }, 60000);

  const shutdown = () => {
    log.info('Shutting down…');
    state.saveNow();
    chain.stop();
    copier?.stop();
    copier?.save();
    tg.stop();
    pollers.forEach((p) => p.stop());
    process.exit(0);
  };
  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
}

let stateRef = null;
process.on('unhandledRejection', (err) => log.error('Unhandled:', err?.stack || err));
process.on('uncaughtException', (err) => {
  log.error('Crashed:', err?.stack || err);
  try {
    stateRef?.saveNow(); // so nothing gets alerted twice after the automatic restart
  } catch {}
  process.exit(1);
});
main().catch((err) => {
  log.error('Fatal:', err.stack || err.message);
  process.exit(1);
});
