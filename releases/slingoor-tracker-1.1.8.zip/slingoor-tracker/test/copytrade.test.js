// Copy trading: key handling + signing (checked with Node's own ed25519 verify), the copy logic
// against fakes, and a full run of the real bot.js buying/selling against mock PumpPortal + RPC.
import test from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { b58encode, b58decode, loadKeypair, signTx, verifyTxSignature, parseTx } from '../src/solana.js';
import { CopyTrader } from '../src/copytrade.js';
import { startWorld, W, sleep, iso } from './mock.js';

const WS_LIB = process.env.WS_LIB;

export function newKey() {
  const { privateKey, publicKey } = crypto.generateKeyPairSync('ed25519');
  const seed = privateKey.export({ format: 'der', type: 'pkcs8' }).subarray(-32);
  const pub = publicKey.export({ format: 'der', type: 'spki' }).subarray(-32);
  const secret = Buffer.concat([seed, pub]);
  return { b58: b58encode(secret), json: JSON.stringify([...secret]), pub: b58encode(pub) };
}

// A v0 transaction shaped like the ones PumpPortal returns: one signer (us), unsigned.
export function unsignedTx(payerB58, extraKeys = 3, versioned = true) {
  const parts = [Buffer.from([1]), Buffer.alloc(64)];
  if (versioned) parts.push(Buffer.from([0x80]));
  parts.push(Buffer.from([1, 0, 1]), Buffer.from([1 + extraKeys]), Buffer.from(b58decode(payerB58)));
  for (let i = 0; i < extraKeys; i++) parts.push(crypto.randomBytes(32));
  parts.push(crypto.randomBytes(32), Buffer.from([0])); // blockhash, no instructions
  if (versioned) parts.push(Buffer.from([0]));
  return new Uint8Array(Buffer.concat(parts));
}

test('wallet keys: Phantom base58 and solana-keygen JSON both load to the right address', () => {
  const k = newKey();
  assert.equal(loadKeypair(k.b58).publicKey, k.pub);
  assert.equal(loadKeypair(` "${k.b58}"\n`).publicKey, k.pub);
  assert.equal(loadKeypair(k.json).publicKey, k.pub);
  assert.throws(() => loadKeypair(k.b58.slice(0, 40)), /wrong length/);
  assert.throws(() => loadKeypair(k.b58.replace(/.$/, k.b58.endsWith('a') ? 'b' : 'a')), /damaged|wrong length/);
  assert.throws(() => loadKeypair('0OIl+/'), /not allowed/);
  assert.throws(() => loadKeypair(''), /no private key/);
  // base58 round trip incl. leading zeros
  for (const bytes of [new Uint8Array([0, 0, 1, 2, 255]), crypto.randomBytes(32), crypto.randomBytes(64)]) assert.deepEqual(b58decode(b58encode(bytes)), Uint8Array.from(bytes));
});

test('signing: signature lands in our slot and verifies; foreign transactions are refused', () => {
  const k = newKey();
  const kp = loadKeypair(k.b58);
  for (const versioned of [true, false]) {
    const tx = unsignedTx(k.pub, 5, versioned);
    const { bytes, sig } = signTx(tx, kp);
    assert.ok(verifyTxSignature(bytes, k.pub));
    assert.equal(b58encode(bytes.subarray(1, 65)), sig);
    assert.deepEqual(bytes.subarray(65), tx.subarray(65), 'message must not change');
    assert.equal(parseTx(bytes).versioned, versioned);
    // tampering breaks it
    const bad = Uint8Array.from(bytes);
    bad[bad.length - 3] ^= 1;
    assert.equal(verifyTxSignature(bad, k.pub), false);
  }
  const other = newKey();
  assert.throws(() => signTx(unsignedTx(other.pub), kp), /not for our wallet/);
});

// ---------- logic with fakes ----------
function harness({ cfg = {}, bal = 5 } = {}) {
  const k = newKey();
  const kp = loadKeypair(k.b58);
  const sent = [];
  const trades = [];
  const tokens = {}; // mint -> our balance
  const world = { solBal: bal, fail: null, delay: 0, mc: {} };
  const swapper = {
    async trade(req) {
      const { knownRaw, ...plainReq } = req;
      trades.push(plainReq);
      if (world.delay) await sleep(world.delay);
      if (world.fail) {
        const f = world.fail;
        world.fail = null;
        if (f.landed && req.action === 'buy') tokens[req.mint] = (tokens[req.mint] || 0) + 1000;
        throw Object.assign(new Error(f.msg), f);
      }
      if (req.action === 'buy') {
        tokens[req.mint] = (tokens[req.mint] || 0) + 1000;
        world.solBal -= req.amount;
        return { sig: 'S' + trades.length, solDelta: -req.amount - 0.001, tokenDelta: 1000 };
      }
      const pct = parseFloat(req.amount) / 100;
      const base = req.knownRaw != null ? Math.min(tokens[req.mint] || 0, Number(req.knownRaw) / 1e6) : tokens[req.mint] || 0;
      const sold = base * pct;
      tokens[req.mint] -= sold;
      const got = sold * 0.0003;
      return { sig: 'S' + trades.length, solDelta: got, tokenDelta: -sold };
    },
  };
  const rpc = {
    call: async (m) => (m === 'getBalance' ? { value: world.solBal * 1e9 } : null),
    getTokenBalance: async (_o, mint) => ({ ui: tokens[mint] || 0, raw: BigInt(Math.round((tokens[mint] || 0) * 1e6)) }),
  };
  const pump = { getCoin: async (m) => (world.mc[m] ? { market_cap: world.mc[m], total_supply: 1e15 } : null) };
  const coins = { get: async (m) => ({ symbol: m.slice(0, 3) }) };
  const c = new CopyTrader({
    cfg: { enabled: true, buySol: 0.1, slippage: 25, priorityFee: 0.001, mirrorSells: true, tpX: 2, tpPercent: 25, maxOpen: 10, dailyLimitSol: 0, minHisBuySol: 0, maxDelayMs: 30000, keepSol: 0.02, tpCheckMs: 1e9, ...cfg },
    rpc,
    kp,
    swapper,
    pump,
    coins,
    broadcast: async (html) => sent.push(html),
    getSolPrice: () => 100,
    file: `/tmp/copytest-${process.pid}-${Math.random()}.json`,
  });
  const ev = (mint, extra = {}) => ({ mint, time: Date.now(), wallet: W, ...extra });
  const flush = async () => {
    await sleep(5);
    await Promise.all([...c.locks.values()]);
  };
  return { c, sent, trades, tokens, world, ev, flush };
}

test('copy logic: buy on his entry, mirror his partial sell, sell all when he exits, trip PnL', async () => {
  const h = harness();
  h.c.onSignal({ ev: h.ev('AAA1'), kind: 'ENTRY', pre: 0, post: 500, sol: 3 });
  h.c.onSignal({ ev: h.ev('AAA1'), kind: 'ENTRY', pre: 0, post: 500, sol: 3 }); // same entry seen twice (chain + feed)
  h.c.onSignal({ ev: h.ev('AAA1'), kind: 'ADD', pre: 500, post: 900, sol: 2 }); // adds are not copied
  await h.flush();
  assert.equal(h.trades.length, 1);
  assert.deepEqual(h.trades[0], { action: 'buy', mint: 'AAA1', amount: 0.1, denominatedInSol: true });
  assert.match(h.sent[0], /COPY BUY.*AAA.*✅/s);
  assert.match(h.sent[0], /0\.101 SOL/);

  h.c.onSignal({ ev: h.ev('AAA1'), kind: 'PARTIAL', pre: 900, post: 540, sol: 1 }); // he sold 40%
  await h.flush();
  assert.deepEqual(h.trades[1], { action: 'sell', mint: 'AAA1', amount: '40%', denominatedInSol: false });
  assert.match(h.sent[1], /COPY SELL 40%/);
  assert.equal(h.tokens.AAA1, 600);

  h.c.onSignal({ ev: h.ev('AAA1'), kind: 'EXIT', pre: 540, post: 0, sol: 2 });
  await h.flush();
  assert.equal(h.trades[2].amount, '100%');
  assert.match(h.sent[2], /ALL OUT/);
  assert.match(h.sent[2], /Trip: in 0\.101/);
  assert.equal(h.c.positions.AAA1, undefined);
  // a later sell of his does nothing for us
  h.c.onSignal({ ev: h.ev('AAA1'), kind: 'EXIT', pre: 10, post: 0, sol: 0.1 });
  await h.flush();
  assert.equal(h.trades.length, 3);
});

test('copy logic: his quick exit waits for our buy to land, then sells', async () => {
  const h = harness();
  h.world.delay = 150;
  h.c.onSignal({ ev: h.ev('FAST'), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  h.c.onSignal({ ev: h.ev('FAST'), kind: 'EXIT', pre: 1, post: 0, sol: 1 });
  await h.flush();
  assert.deepEqual(h.trades.map((t) => t.action), ['buy', 'sell']);
  assert.equal(h.tokens.FAST, 0);
});

test('copy logic: skips — stale signal, paused, low SOL, position limit, daily limit, small buys', async () => {
  let h = harness();
  h.c.onSignal({ ev: h.ev('OLD1', { time: Date.now() - 120000 }), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  h.c.setPaused(true);
  h.c.onSignal({ ev: h.ev('PAUS'), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await h.flush();
  assert.equal(h.trades.length, 0);
  assert.match(h.c.lastSkip.why, /paused/);

  h = harness({ bal: 0.05 });
  await h.c.refreshBalance(); // the bot keeps this fresh in the background
  h.c.onSignal({ ev: h.ev('POOR'), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await h.flush();
  assert.equal(h.trades.length, 0);
  assert.match(h.sent[0], /SKIPPED.*not enough SOL/s);

  h = harness({ cfg: { maxOpen: 2 } });
  for (const m of ['M1', 'M2', 'M3']) h.c.onSignal({ ev: h.ev(m), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await h.flush();
  assert.equal(h.trades.length, 2);
  assert.ok(h.sent.some((x) => /SKIPPED.*COPY_MAX_OPEN_POSITIONS/s.test(x)));

  h = harness({ cfg: { dailyLimitSol: 0.15 } });
  for (const m of ['D1', 'D2', 'D3']) h.c.onSignal({ ev: h.ev(m), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await h.flush();
  assert.equal(h.trades.length, 1, '0.101 spent, the next 0.1 would pass 0.15');
  assert.ok(h.sent.some((x) => /SKIPPED.*daily limit/s.test(x)));

  h = harness({ cfg: { minHisBuySol: 0.5 } });
  h.c.onSignal({ ev: h.ev('TINY'), kind: 'ENTRY', pre: 0, post: 1, sol: 0.2 });
  await h.flush();
  assert.equal(h.trades.length, 0);
});

test('copy logic: take profit sells 25% once at 2x; mirror off still exits fully', async () => {
  const h = harness();
  h.c.onSignal({ ev: h.ev('TPC1'), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await h.flush();
  // 1000 tokens, cost 0.101 SOL. market cap in SOL with 1B supply: value = 1000 * mc / 1e9
  h.world.mc.TPC1 = 150000; // 0.15 SOL = 1.49x
  await h.c.checkTakeProfit();
  await h.flush();
  assert.equal(h.trades.length, 1);
  h.world.mc.TPC1 = 210000; // 0.21 SOL = 2.08x
  await h.c.checkTakeProfit();
  await h.flush();
  assert.deepEqual(h.trades[1], { action: 'sell', mint: 'TPC1', amount: '25%', denominatedInSol: false });
  assert.match(h.sent.at(-1), /TAKE PROFIT 2x/);
  h.world.mc.TPC1 = 400000;
  await h.c.checkTakeProfit();
  await h.flush();
  assert.equal(h.trades.length, 2, 'take profit happens once per coin');

  const g = harness({ cfg: { mirrorSells: false } });
  g.c.onSignal({ ev: g.ev('NOMI'), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  g.c.onSignal({ ev: g.ev('NOMI'), kind: 'PARTIAL', pre: 10, post: 5, sol: 1 });
  g.c.onSignal({ ev: g.ev('NOMI'), kind: 'MOVED', pre: 5, post: 2, sol: 0 });
  g.c.onSignal({ ev: g.ev('NOMI'), kind: 'MOVED', pre: 2, post: 0, sol: 0 });
  await g.flush();
  assert.deepEqual(g.trades.map((t) => t.amount), [0.1, '100%']);
});

test('copy logic: a buy that timed out but landed late is never bought twice; failed sells tell you', async () => {
  const h = harness();
  h.world.fail = { msg: 'not confirmed in 60s', expired: true, landed: true, sig: 'LATE' };
  h.c.onSignal({ ev: h.ev('LATE'), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await h.flush();
  await sleep(3200);
  await h.flush();
  assert.equal(h.trades.length, 1);
  assert.match(h.sent[0], /landed late/);
  assert.equal(h.c.positions.LATE.tokens, 1000);

  const g = harness();
  g.c.onSignal({ ev: g.ev('SFAI'), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await g.flush();
  const orig = g.c.swapper.trade;
  g.c.swapper.trade = async () => {
    throw new Error('PumpPortal 500: down');
  };
  g.c.onSignal({ ev: g.ev('SFAI'), kind: 'EXIT', pre: 1, post: 0, sol: 1 });
  await g.flush();
  g.c.swapper.trade = orig;
  assert.match(g.sent.at(-1), /COPY SELL FAILED.*\/sell SFAI 100/s);
  assert.ok(g.c.positions.SFAI, 'position kept so you can retry');
}, { timeout: 20000 });

test('copy logic: a coin Jupiter can buy but not sell -> warns right after the buy, retries the sell until it works', async () => {
  // without a Jupiter key the check is skipped (free requests are kept for trades)
  const k0 = harness({ cfg: { sellCheckDelayMs: 10 } });
  let checked = 0;
  k0.c.swapper.canSell = async () => (checked++, false);
  k0.c.onSignal({ ev: k0.ev('NOKEY'), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await k0.flush();
  await sleep(60);
  assert.equal(checked, 0);
  assert.ok(!k0.sent.some((x) => /HEADS UP/.test(x)));

  const h = harness({ cfg: { sellRetryMs: 60, sellRetryMax: 20, sellCheckDelayMs: 10, forceSellCheck: true } });
  let sellable = false;
  h.c.swapper.canSell = async () => sellable;
  h.c.onSignal({ ev: h.ev('V3C1'), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await h.flush();
  await sleep(80);
  assert.match(h.sent.at(-1), /HEADS UP.*can't sell this coin type/s);
  const orig = h.c.swapper.trade;
  let fails = 3;
  h.c.swapper.trade = async (req) => {
    if (req.action === 'sell' && fails-- > 0) throw Object.assign(new Error('Jupiter 400: No routes found'), { noRoute: true });
    return orig(req);
  };
  h.c.onSignal({ ev: h.ev('V3C1'), kind: 'EXIT', pre: 1, post: 0, sol: 1 });
  await h.flush();
  assert.match(h.sent.at(-1), /COPY SELL DELAYED.*Padre/s);
  for (let i = 0; i < 40 && h.c.positions.V3C1; i++) await sleep(25);
  await h.flush();
  assert.equal(h.c.positions.V3C1, undefined, 'sold once a route appeared');
  assert.match(h.sent.at(-1), /ALL OUT/);
  assert.equal(h.sent.filter((x) => /DELAYED/.test(x)).length, 1, 'only one delay message');
  assert.equal(h.sent.filter((x) => /FAILED/.test(x)).length, 0);

  // a newer sell signal replaces a pending retry (no double selling)
  const g = harness({ cfg: { sellRetryMs: 200, sellRetryMax: 5, sellCheckDelayMs: 1e6 } });
  g.c.onSignal({ ev: g.ev('V3C2'), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await g.flush();
  const o2 = g.c.swapper.trade;
  let f2 = 1;
  g.c.swapper.trade = async (req) => {
    if (req.action === 'sell' && f2-- > 0) throw Object.assign(new Error('No routes found'), { noRoute: true });
    return o2(req);
  };
  g.c.onSignal({ ev: g.ev('V3C2'), kind: 'PARTIAL', pre: 10, post: 6, sol: 1 }); // 40%, fails -> retry pending
  await g.flush();
  g.c.onSignal({ ev: g.ev('V3C2'), kind: 'EXIT', pre: 6, post: 0, sol: 1 }); // he's out before the retry
  await g.flush();
  await sleep(300);
  await g.flush();
  assert.deepEqual(g.trades.filter((t) => t.action === 'sell').map((t) => t.amount), ['100%'], 'the stale 40% retry never ran after he exited');
  assert.equal(g.c.positions.V3C2, undefined);
});

test('speed: the buy is built while his entry is being confirmed, sent with no extra wait; adds drop it', async () => {
  const h = harness();
  const builds = [];
  let usedPrebuilt = 0;
  h.c.swapper.build = async (req) => {
    builds.push(req.mint);
    await sleep(40); // Jupiter quote + swap
    return new Uint8Array([1, 2, 3]);
  };
  const origTrade = h.c.swapper.trade;
  h.c.swapper.trade = async (req, prebuilt) => {
    if (prebuilt) usedPrebuilt++;
    return origTrade(req);
  };
  // entry: maybe-entry fires first (build starts), then the check says ENTRY
  h.c.onMaybeEntry(h.ev('PRE1'));
  await sleep(10);
  h.c.onSignal({ ev: h.ev('PRE1'), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await h.flush();
  assert.equal(usedPrebuilt, 1, 'sent the transaction that was built in advance');
  assert.deepEqual(builds, ['PRE1']);
  // add: built in advance but never sent
  h.c.onMaybeEntry(h.ev('PRE2'));
  h.c.onSignal({ ev: h.ev('PRE2'), kind: 'ADD', pre: 5, post: 6, sol: 1 });
  await h.flush();
  await sleep(60);
  assert.equal(h.trades.filter((t) => t.mint === 'PRE2').length, 0);
  assert.equal(h.c.prebuilt.has('PRE2'), false);
  // paused: nothing is built
  h.c.setPaused(true);
  h.c.onMaybeEntry(h.ev('PRE3'));
  assert.equal(builds.includes('PRE3'), false);
});

test('sells use our saved token amount (no balance lookup); if it was out of date, the rest is swept', async () => {
  const h = harness();
  h.c.onSignal({ ev: h.ev('RAW1'), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await h.flush();
  h.c.positions.RAW1.raw = '500000000'; // we think we hold 500, really 1000 (e.g. tokens arrived from elsewhere)
  h.c.onSignal({ ev: h.ev('RAW1'), kind: 'EXIT', pre: 1, post: 0, sol: 1 });
  await h.flush(); // includes the sweep (waits 2.5s, looks again, sells the rest)
  assert.deepEqual(h.trades.filter((t) => t.action === 'sell').map((t) => t.amount), ['100%', '100%'], 'saved-amount sell, then the sweep');
  assert.equal(h.sent.filter((x) => /ALL OUT/.test(x)).length, 1, 'one "all out" message');
  assert.equal(h.tokens.RAW1, 0, 'the rest was swept');
  assert.equal(h.c.positions.RAW1, undefined);
  assert.match(h.sent.at(-1), /ALL OUT/);
}, { timeout: 15000 });

test('sending: goes to the RPC and Jito at once; if the RPC refuses, Jito alone is enough', async () => {
  const { Swapper } = await import('../src/copytrade.js');
  const k = newKey();
  const kp = loadKeypair(k.b58);
  const realFetch = globalThis.fetch;
  const jito = [];
  globalThis.fetch = async (url, init) => {
    jito.push({ url: String(url), body: JSON.parse(init.body), at: Date.now() });
    return new Response(JSON.stringify({ jsonrpc: '2.0', id: 1, result: 'ok' }), { status: 200 });
  };
  try {
    let landed = false;
    const rpcCalls = [];
    const rpc = {
      call: async (m, params) => {
        rpcCalls.push({ m, at: Date.now() });
        if (m === 'sendTransaction') throw Object.assign(new Error('rate limited'), { status: 429 });
        if (m === 'getSignatureStatuses') return { value: [landed ? { confirmationStatus: 'confirmed', err: null } : null] };
        return null;
      },
    };
    const sw = new Swapper({ rpc, kp, jitoUrls: ['https://jito.test/a', 'https://jito.test/b'], jupBase: 'x', portalBase: '', slippage: 25, priorityFee: 0 });
    setTimeout(() => (landed = true), 300);
    const r = await sw.send(unsignedTx(k.pub));
    assert.ok(r.sig);
    assert.ok(jito.length >= 2, 'both Jito relays got it');
    assert.equal(jito[0].body.method, 'sendTransaction');
    assert.ok(verifyTxSignature(Buffer.from(jito[0].body.params[0], 'base64'), k.pub));
    const firstRpc = rpcCalls.find((c) => c.m === 'sendTransaction').at;
    assert.ok(Math.abs(jito[0].at - firstRpc) < 50, 'sent in parallel, not one after the other');
    // and with no Jito, an RPC refusal is still an error
    const sw2 = new Swapper({ rpc, kp, jitoUrls: [], jupBase: 'x', portalBase: '', slippage: 25, priorityFee: 0 });
    await assert.rejects(sw2.send(unsignedTx(k.pub)), /rate limited/);
  } finally {
    globalThis.fetch = realFetch;
  }
});

const SCALE = { sizeMode: 'scale', scaleAt1: 0.5, maxBuySol: 1, scaleMaxAt: 1000, maxWalletPct: 20, maxPerCoinSol: 2, minBuySol: 0.01, copyAdds: true, quickTpX: 1.5, quickTpPercent: 35, quickTpHisMinSol: 1 };

test('sizing: scales with his buy (1 -> 0.5, 1000 -> 1), never more than 20% of the wallet or 2 SOL per coin', async () => {
  const h = harness({ cfg: SCALE, bal: 100 });
  await h.c.refreshBalance();
  const sz = (x) => h.c.sizeFor(x, 'NEW');
  assert.equal(sz(0.2), 0.1);
  assert.equal(sz(1), 0.5);
  assert.ok(Math.abs(sz(10) - 0.6666) < 0.001, String(sz(10)));
  assert.ok(Math.abs(sz(100) - 0.8333) < 0.001, String(sz(100)));
  assert.equal(sz(1000), 1);
  assert.equal(sz(50000), 1, 'never more than COPY_MAX_BUY_SOL');
  assert.equal(sz(0), 0.5, 'his size unknown -> as if 1 SOL');
  assert.equal(sz(0.005), null, 'too small to bother');
  // small wallet: 20% cap
  const g = harness({ cfg: SCALE, bal: 1 });
  await g.c.refreshBalance();
  assert.equal(g.c.sizeFor(1000, 'X'), 0.2);
  // per-coin cap: 1.9 SOL already in -> only 0.1 more
  h.c.positions.FULL = { tokens: 5, costSol: 1.9 };
  assert.equal(h.c.sizeFor(1000, 'FULL'), 0.1);
  h.c.positions.FULL.costSol = 2;
  assert.equal(h.c.sizeFor(1000, 'FULL'), null);
});

test('re-entries and adds are copied (scaled), quick bursts become one buy, the per-coin cap holds', async () => {
  const h = harness({ cfg: SCALE, bal: 100 });
  await h.c.refreshBalance();
  h.c.onSignal({ ev: h.ev('ADD1'), kind: 'ENTRY', pre: 0, post: 1, sol: 10 });
  await h.flush();
  assert.ok(Math.abs(h.trades[0].amount - 0.6666) < 0.001);
  // he adds 3 times quickly while we're busy -> one combined add
  h.world.delay = 50;
  h.c.onSignal({ ev: h.ev('ADD1'), kind: 'ADD', pre: 1, post: 2, sol: 1 });
  h.c.onSignal({ ev: h.ev('ADD1'), kind: 'ADD', pre: 2, post: 3, sol: 1 });
  h.c.onSignal({ ev: h.ev('ADD1'), kind: 'ADD', pre: 3, post: 4, sol: 1 });
  await h.flush();
  await sleep(120);
  await h.flush();
  const buys = h.trades.filter((t) => t.action === 'buy');
  assert.ok(buys.length <= 3, `bursts merged (${buys.length} buys)`);
  const p = h.c.positions.ADD1;
  assert.ok(p.costSol <= 2.0001, `per-coin cap ${p.costSol}`);
  assert.ok(p.buys >= 2);
  assert.match(h.sent.join('\n'), /COPY ADD/);
  // he sells out, then buys back in -> we buy again
  h.c.onSignal({ ev: h.ev('ADD1'), kind: 'EXIT', pre: 4, post: 0, sol: 3 });
  await h.flush();
  assert.equal(h.c.positions.ADD1, undefined);
  const before = h.trades.length;
  h.c.onSignal({ ev: h.ev('ADD1'), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await h.flush();
  assert.equal(h.trades.length, before + 1);
  assert.equal(h.trades.at(-1).amount, 0.5);
  assert.match(h.sent.at(-1), /COPY BUY/);
});

test("adds into his old bags (coins we never bought with him) are never copied", async () => {
  const h = harness({ cfg: SCALE, bal: 100 });
  await h.c.refreshBalance();
  h.c.onSignal({ ev: h.ev('OLD1'), kind: 'ADD', pre: 50, post: 80, sol: 20 });
  await h.flush();
  assert.equal(h.trades.length, 0, 'no buy into a coin he already held');
  assert.equal(h.c.positions.OLD1, undefined);
  // a coin we skipped (paused) stays skipped when he adds later
  h.c.setPaused(true);
  h.c.onSignal({ ev: h.ev('SKP1'), kind: 'ENTRY', pre: 0, post: 1, sol: 2 });
  h.c.setPaused(false);
  h.c.onSignal({ ev: h.ev('SKP1'), kind: 'ADD', pre: 1, post: 2, sol: 2 });
  await h.flush();
  assert.equal(h.trades.length, 0);
  // a new entry of his is still bought, and then his adds to it are too
  h.c.onSignal({ ev: h.ev('NEW1'), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await h.flush();
  h.c.onSignal({ ev: h.ev('NEW1'), kind: 'ADD', pre: 1, post: 2, sol: 1 });
  await h.flush();
  assert.equal(h.trades.filter((t) => t.action === 'buy').length, 2);
});

test('quick profit: big buys of his (> 1 SOL) sell 35% at 1.5x and keep the rest; small ones wait for 2x', async () => {
  const h = harness({ cfg: { ...SCALE, tpX: 2, tpPercent: 25 }, bal: 100 });
  await h.c.refreshBalance();
  h.c.onSignal({ ev: h.ev('BIG1'), kind: 'ENTRY', pre: 0, post: 1, sol: 5 }); // big
  h.c.onSignal({ ev: h.ev('SML1'), kind: 'ENTRY', pre: 0, post: 1, sol: 0.5 }); // small
  await h.flush();
  const costBig = h.c.positions.BIG1.costSol;
  const costSml = h.c.positions.SML1.costSol;
  // both at 1.6x (value for 1000 tokens with market_cap in SOL over a 1B supply)
  h.world.mc.BIG1 = (costBig * 1.6 * 1e9) / 1000;
  h.world.mc.SML1 = (costSml * 1.6 * 1e9) / 1000;
  await h.c.checkTakeProfit();
  await h.flush();
  const sells = () => h.trades.filter((t) => t.action === 'sell').map((t) => `${t.mint}:${t.amount}`);
  assert.deepEqual(sells(), ['BIG1:35%']);
  assert.ok(h.c.positions.BIG1.tokens > 0, 'kept the rest');
  assert.match(h.sent.at(-1), /QUICK PROFIT 1\.5x — SOLD 35%/);
  await h.c.checkTakeProfit();
  await h.flush();
  assert.deepEqual(sells(), ['BIG1:35%'], 'quick profit only once');
  // later 2x (measured on what the remaining tokens cost) -> normal take profit, still not a full sell
  h.world.mc.BIG1 = (costBig * 2.1 * 1e9) / 1000;
  h.world.mc.SML1 = (costSml * 2.1 * 1e9) / 1000;
  await h.c.checkTakeProfit();
  await h.flush();
  assert.deepEqual(sells().sort(), ['BIG1:25%', 'BIG1:35%', 'SML1:25%']);
  assert.ok(h.c.positions.BIG1.tokens > 0 && h.c.positions.SML1.tokens > 0, 'take-profit never sells out');
});

// ---------- the real bot process ----------
test('full bot: copies his entry with a real signed transaction, mirrors sells, takes profit, exits', { skip: !WS_LIB, timeout: 180000 }, async () => {
  const w = await startWorld(WS_LIB);
  const k = newKey();
  const A = 'CopyAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAApump';
  const B = 'CopyBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBpump';
  const C = 'CopyCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCpump';
  const portalReqs = [];
  const chain = { sol: 3, tokens: {}, txs: {}, badSigs: 0 };
  const pending = new Map(); // tx bytes key -> request
  try {
    for (const [m, n, s] of [[A, 'Big Booty Coin', 'BBC'], [B, 'Old News', 'OLD'], [C, 'Cum Processing Unit', 'CPU']]) {
      w.M.coins[m] = { mint: m, name: n, symbol: s, usd_market_cap: 50000, market_cap: 300, total_supply: 1e15, complete: false, program: 'pump', created_timestamp: Date.now() - 3600e3 };
    }
    w.M.ownerBalances = { [k.pub]: chain.tokens };
    const SOLM = 'So11111111111111111111111111111111111111112';
    const jupReqs = [];
    w.M.jup = async (path, q, body) => {
      if (path === '/quote') {
        jupReqs.push({ type: 'quote', ...q });
        if (q.inputMint === C || q.outputMint === C) return { status: 400, body: { error: 'COULD_NOT_FIND_ANY_ROUTE', errorCode: 'COULD_NOT_FIND_ANY_ROUTE' } };
        return { body: { inputMint: q.inputMint, outputMint: q.outputMint, inAmount: q.amount, outAmount: '123', slippageBps: +q.slippageBps } };
      }
      if (path === '/swap') {
        jupReqs.push({ type: 'swap', user: body.userPublicKey, fee: body.prioritizationFeeLamports });
        const qr = body.quoteResponse;
        const tx = unsignedTx(body.userPublicKey);
        const req = qr.inputMint === SOLM ? { action: 'buy', mint: qr.outputMint, sol: +qr.inAmount / 1e9 } : { action: 'sell', mint: qr.inputMint, raw: BigInt(qr.inAmount) };
        portalReqs.push({ via: 'jup', ...req, amount: req.action === 'buy' ? req.sol : String(req.raw) });
        pending.set(Buffer.from(tx.subarray(65)).toString('hex'), req);
        return { body: { swapTransaction: Buffer.from(tx).toString('base64'), lastValidBlockHeight: 1 } };
      }
      return { status: 404, body: {} };
    };
    w.M.portal = async (req) => {
      portalReqs.push({ via: 'portal', ...req });
      if (req.publicKey !== k.pub) return { status: 400, text: 'bad key' };
      const tx = unsignedTx(k.pub);
      pending.set(Buffer.from(tx.subarray(65)).toString('hex'), req.action === 'buy' ? { action: 'buy', mint: req.mint, sol: req.amount } : { action: 'sell', mint: req.mint, pct: parseFloat(req.amount) });
      return { bytes: tx };
    };
    w.M.rpcHook = (r) => {
      if (r.method === 'getBalance' && r.params[0] === k.pub) return { context: { slot: 1 }, value: Math.round(chain.sol * 1e9) };
      if (r.method === 'sendTransaction') {
        const bytes = Buffer.from(r.params[0], 'base64');
        if (!verifyTxSignature(bytes, k.pub)) {
          chain.badSigs++;
          return 'bad';
        }
        const sig = b58encode(bytes.subarray(1, 65));
        if (chain.txs[sig]) return sig; // rebroadcast
        const req = pending.get(Buffer.from(bytes.subarray(65)).toString('hex'));
        const preSol = chain.sol;
        const preTok = chain.tokens[req.mint] || 0;
        if (req.action === 'buy') {
          chain.sol -= req.sol + 0.001;
          chain.tokens[req.mint] = preTok + 1_000_000;
        } else {
          const sold = req.raw != null ? Number(req.raw) / 1e6 : preTok * (req.pct / 100);
          chain.tokens[req.mint] = preTok - sold;
          chain.sol += sold * 0.0000004;
        }
        const tb = (ui) => [{ accountIndex: 2, mint: req.mint, owner: k.pub, uiTokenAmount: { amount: String(Math.round(ui * 1e6)), uiAmountString: String(ui), decimals: 6 } }];
        chain.txs[sig] = {
          slot: 5,
          meta: { err: null, fee: 5000, preBalances: [Math.round(preSol * 1e9)], postBalances: [Math.round(chain.sol * 1e9)], preTokenBalances: preTok ? tb(preTok) : [], postTokenBalances: tb(chain.tokens[req.mint]) },
        };
        return sig;
      }
      if (r.method === 'getSignatureStatuses') return { value: r.params[0].map((s) => (chain.txs[s] ? { confirmationStatus: 'confirmed', err: null } : null)) };
      if (r.method === 'getTransaction' && chain.txs[r.params[0]]) return chain.txs[r.params[0]];
      return undefined;
    };
    w.startBot({ COPY_TRADE: 'on', COPY_PRIVATE_KEY: k.b58, COPY_BUY_SOL: '0.25', COPY_SIZE_MODE: 'fixed', COPY_ADDS: 'off', COPY_QUICK_TP_X: '0', COPY_TP_CHECK_SECONDS: '3', JUPITER_API_KEY: 'test-key' }); // key = no free-tier pacing
    await w.waitFor('copy live', () => /Copy trading LIVE with wallet/.test(w.out));
    await w.waitFor('feeds live', () => /trades feed live/.test(w.out));
    w.tgPush('/start');
    await w.waitFor('registered', () => w.sent(/You're set/).length);
    assert.match(w.sent(/You're set/)[0].text, /Copy trading is LIVE/);

    // 1) he enters BBC -> we buy 0.25 SOL with a transaction signed by our key
    w.addTrade({ tx: 'H1', isBuy: true, mint: A, baseAmount: 5_000_000, amountSol: 4, amountUsd: 400 });
    await w.waitFor('copy buy', () => w.sent(/COPY BUY<\/b> <b>\$BBC/).length);
    assert.deepEqual(portalReqs[0], { via: 'jup', action: 'buy', mint: A, sol: 0.25, amount: 0.25 });
    assert.equal(jupReqs[0].amount, '250000000');
    assert.equal(jupReqs[0].slippageBps, '2500');
    assert.equal(jupReqs[1].user, k.pub);
    assert.deepEqual(jupReqs[1].fee, { priorityLevelWithMaxLamports: { maxLamports: 2000000, priorityLevel: 'veryHigh' } });
    assert.equal(chain.badSigs, 0);
    assert.match(w.sent(/COPY BUY/)[0].text, /Spent <b>0\.251 SOL<\/b> → 1\.00M tokens/);
    await w.waitFor('entry alert too', () => w.sent(/NEW ENTRY.*\$BBC/).length);

    // 2) he sells 40% -> we sell 40%
    w.M.balances[A] = 3_000_000;
    w.addTrade({ tx: 'H2', isBuy: false, mint: A, baseAmount: 2_000_000, amountSol: 2, amountUsd: 200 });
    await w.waitFor('mirror sell', () => w.sent(/COPY SELL 40%/).length);
    assert.equal(portalReqs[1].amount, '400000000000', '40% of our 1M tokens in raw units');
    assert.equal(chain.tokens[A], 600_000);

    // 3) price runs: our 600K tokens at mc 900 SOL / 1B = 0.54 SOL vs 0.251 cost = 2.15x -> TP 25%
    w.M.coins[A].market_cap = 900;
    await w.waitFor('take profit', () => w.sent(/TAKE PROFIT 2x — SOLD 25%/).length, 15000);
    assert.equal(portalReqs[2].amount, '150000000000', '25% of 600K');

    // 4) /copy shows the open position
    w.tgPush('/copy');
    await w.waitFor('/copy', () => w.sent(/Copy trading: 🟢 LIVE/).length);
    assert.match(w.sent(/Copy trading: 🟢 LIVE/)[0].text, new RegExp(k.pub));
    assert.match(w.sent(/Copy trading: 🟢 LIVE/)[0].text, /\$BBC.*TP taken/s);

    // 5) he's fully out -> we sell everything
    w.M.balances[A] = 0;
    w.addTrade({ tx: 'H3', isBuy: false, mint: A, baseAmount: 3_000_000, amountSol: 3, amountUsd: 300 });
    await w.waitFor('exit', () => w.sent(/ALL OUT<\/b> <b>\$BBC/).length);
    assert.equal(portalReqs[3].amount, '450000000000', 'everything left');
    assert.equal(chain.tokens[A], 0);
    assert.match(w.sent(/ALL OUT/)[0].text, /Trip: in 0\.251/);

    // 6) an old buy of his (e.g. caught up after a restart) is not copied
    w.addTrade({ tx: 'H4', isBuy: true, mint: B, baseAmount: 1000, amountSol: 1, amountUsd: 100, timestamp: iso(Date.now() - 90000) });
    await w.waitFor('old entry alerted', () => w.sent(/NEW ENTRY.*\$OLD/).length);
    await sleep(1500);
    assert.equal(w.sent(/COPY BUY.*\$OLD/s).length, 0);

    // 7) /pause stops new buys, /resume starts again
    const D = 'CopyDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDpump';
    w.M.coins[D] = { ...w.M.coins[C], mint: D, name: 'Dunk Dunk', symbol: 'DDD' };
    w.tgPush('/pause');
    await w.waitFor('paused', () => w.sent(/Copy trading paused/).length);
    w.addTrade({ tx: 'H5', isBuy: true, mint: D, baseAmount: 1000, amountSol: 1, amountUsd: 100 });
    await w.waitFor('entry alert', () => w.sent(/NEW ENTRY.*\$DDD/).length);
    await sleep(1500);
    assert.equal(portalReqs.length, 4, 'no buy while paused');
    w.tgPush('/resume');
    await w.waitFor('resumed', () => w.sent(/live again/).length);

    // 7b) a coin Jupiter can't route yet -> built by PumpPortal instead
    w.addTrade({ tx: 'H6', isBuy: true, mint: C, baseAmount: 1000, amountSol: 1, amountUsd: 100, timestamp: iso(Date.now()) });
    await w.waitFor('portal fallback buy', () => w.sent(/COPY BUY<\/b> <b>\$CPU/).length, 15000);
    const fb = portalReqs.at(-1);
    assert.equal(fb.via, 'portal');
    assert.equal(fb.amount, 0.25);
    assert.equal(fb.denominatedInSol, 'true');
    w.M.balances[C] = 0;
    w.addTrade({ tx: 'H7', isBuy: false, mint: C, baseAmount: 1000, amountSol: 1, amountUsd: 100 });
    await w.waitFor('portal fallback sell', () => w.sent(/ALL OUT<\/b> <b>\$CPU/).length, 15000);
    assert.equal(portalReqs.at(-1).amount, '100%');

    // 8) manual /sell of something we don't hold
    w.tgPush(`/sell ${B}`);
    await w.waitFor('nothing to sell', () => w.sent(/doesn't hold that coin/).length);
    // 9) fast path: his pump.fun buy arrives on the live log stream -> we buy without waiting for the transaction
    const { b58encode: enc, b58decode: dec } = await import('../src/solana.js');
    const E = enc(crypto.randomBytes(32));
    w.M.coins[E] = { mint: E, name: 'Extra Thick Hoe', symbol: 'ETH', usd_market_cap: 9000, market_cap: 60, total_supply: 1e15, complete: false, program: 'pump', created_timestamp: Date.now() - 60e3 };
    w.M.balances[E] = 172_778_031.109208; // what his wallet shows right after the buy
    const evb = Buffer.alloc(401);
    Buffer.from([189, 219, 127, 211, 78, 230, 97, 238]).copy(evb, 0);
    Buffer.from(dec(E)).copy(evb, 8);
    evb.writeBigUInt64LE(2_500_000_000n, 40);
    evb.writeBigUInt64LE(172_778_031_109_208n, 48);
    evb[56] = 1;
    Buffer.from(dec(W)).copy(evb, 57);
    const fastSig = 'FastSig' + '1'.repeat(80);
    const n0 = portalReqs.length;
    const t0 = Date.now();
    w.notifyLogs(fastSig, 999, [
      'Program 6Vo3245eszAb5wuqEMw8mGdbfRUdKbHhDHP5LcaGuTAB invoke [1]',
      'Program 6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P invoke [2]',
      'Program log: Instruction: Buy',
      `Program data: ${evb.toString('base64')}`,
      'Program 6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P success',
      'Program 6Vo3245eszAb5wuqEMw8mGdbfRUdKbHhDHP5LcaGuTAB success',
    ]);
    await w.waitFor('fast copy buy', () => w.sent(/COPY BUY<\/b> <b>\$ETH/).length, 10000);
    const took = Date.now() - t0;
    assert.equal(portalReqs[n0].mint, E);
    assert.ok(!w.M.rpcCalls.some((r) => r.method === 'getTransaction' && r.params[0] === fastSig), 'no transaction download needed');
    assert.match(w.sent(/COPY BUY<\/b> <b>\$ETH/)[0].text, /Your buy was sent \d\.\d\ds after his buy was spotted/);
    await w.waitFor('fast entry alert', () => w.sent(/NEW ENTRY.*\$ETH/).length);
    assert.match(w.sent(/NEW ENTRY.*\$ETH/)[0].text, /Bought <b>2\.50 SOL/);
    assert.ok(took < 3000, `fast path took ${took}ms`);
    // ...and his sell arrives the same fast way -> we mirror it without downloading his transaction
    const evs = Buffer.from(evb);
    evs.writeBigUInt64LE(69_111_212_443_683n, 48); // 40% of his bag
    evs[56] = 0;
    const fastSellSig = 'FastSell' + '1'.repeat(79);
    const ns = portalReqs.length;
    const ts0 = Date.now();
    w.notifyLogs(fastSellSig, 1000, [
      'Program 6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P invoke [1]',
      'Program log: Instruction: Sell',
      `Program data: ${evs.toString('base64')}`,
      'Program 6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P success',
    ]);
    await w.waitFor('fast copy sell', () => w.sent(/COPY SELL 40%<\/b> <b>\$ETH/).length, 10000);
    assert.ok(Date.now() - ts0 < 3000, `fast sell took ${Date.now() - ts0}ms`);
    assert.equal(portalReqs[ns].action, 'sell');
    assert.ok(!w.M.rpcCalls.some((r) => r.method === 'getTransaction' && r.params[0] === fastSellSig));
    await w.waitFor('his sell alert', () => w.sent(/SOLD 40%.*\$ETH/).length);

    // the same buy showing up later on pump.fun's feed is not bought or alerted again
    w.addTrade({ tx: fastSig, isBuy: true, mint: E, baseAmount: 172778031, amountSol: 2.5, amountUsd: 400 });
    await sleep(2500);
    assert.equal(w.sent(/NEW ENTRY.*\$ETH/).length, 1);
    assert.equal(portalReqs.filter((r) => r.mint === E && r.action === 'buy').length, 1);

    // every trade was also sent to Jito's relay, with the same signed bytes
    assert.ok((w.M.jitoSends || []).length >= portalReqs.length - 1, `jito sends ${(w.M.jitoSends || []).length}`);
    assert.ok(w.M.jitoSends.every((x) => verifyTxSignature(Buffer.from(x.tx, 'base64'), k.pub)));

    assert.equal(chain.badSigs, 0);
    assert.doesNotMatch(w.out, new RegExp(k.b58), 'private key must never be logged');
  } finally {
    if (process.env.DEBUG_OUT) console.log('BOT OUTPUT >>>\n' + w.out.slice(-4000) + '\nSTEPS sent: ' + w.TG.sent.map((x) => x.text.split('\n')[0]).join(' | '));
    await w.close();
  }
});

test('Jupiter client: waits out the free-tier rate limit, reports a failed test run, falls back to PumpPortal', async () => {
  const { Swapper } = await import('../src/copytrade.js');
  const k = newKey();
  const kp = loadKeypair(k.b58);
  const realFetch = globalThis.fetch;
  const calls = [];
  let mode = 'ratelimit';
  globalThis.fetch = async (url, init = {}) => {
    calls.push({ url: String(url), t: Date.now() });
    const u = String(url);
    if (u.includes('/quote')) {
      if (mode === 'ratelimit' && calls.filter((c) => c.url.includes('/quote')).length === 1)
        return new Response('{"code":429}', { status: 429, headers: { 'x-ratelimit-reset': String(Math.ceil((Date.now() + 1200) / 1000)) } });
      if (mode === 'noroute') return new Response('{"error":"Could not find any route","errorCode":"COULD_NOT_FIND_ANY_ROUTE"}', { status: 400 });
      return new Response(JSON.stringify({ inAmount: '1', outAmount: '5' }), { status: 200 });
    }
    if (u.includes('/swap')) {
      const body = { swapTransaction: Buffer.from(unsignedTx(k.pub)).toString('base64') };
      if (mode === 'simfail') body.simulationError = { errorCode: 'TRANSACTION_ERROR', error: 'Attempt to debit an account but found no record of a prior credit.' };
      return new Response(JSON.stringify(body), { status: 200 });
    }
    if (u.includes('/trade-local')) return new Response(Buffer.from(unsignedTx(k.pub)), { status: 200 });
    throw new Error('unexpected ' + u);
  };
  try {
    const rpc = { getTokenBalance: async () => ({ ui: 10, raw: 10_000_000n }) };
    const sw = new Swapper({ rpc, kp, jupBase: 'https://jup.test', portalBase: 'https://portal.test', slippage: 25, priorityFee: 0.001 });
    const t0 = Date.now();
    const tx = await sw.build({ action: 'buy', mint: 'MintX', amount: 0.1 });
    assert.ok(tx.length > 100);
    assert.equal(sw.lastVenue, 'Jupiter');
    assert.ok(Date.now() - t0 >= 900, 'waited for the rate-limit window');
    assert.match(calls[1].url, /amount=100000000&slippageBps=2500/);

    mode = 'simfail';
    sw.portalBase = '';
    await assert.rejects(sw.build({ action: 'buy', mint: 'MintX', amount: 0.1 }), /not enough SOL/);

    mode = 'noroute';
    sw.portalBase = 'https://portal.test';
    calls.length = 0;
    await sw.build({ action: 'sell', mint: 'MintX', amount: '40%' });
    assert.equal(sw.lastVenue, 'PumpPortal');
    assert.match(calls[0].url, /amount=4000000&/, '40% of 10,000,000 raw');
    await assert.rejects(
      new Swapper({ rpc: { getTokenBalance: async () => ({ ui: 0, raw: 0n }) }, kp, jupBase: 'https://jup.test', portalBase: '', slippage: 25, priorityFee: 0 }).build({ action: 'sell', mint: 'M', amount: '100%' }),
      (e) => e.nothing === true,
    );
    // background checks never take the slots a trade needs
    const sw2 = new Swapper({ rpc: { getTokenBalance: async () => ({ ui: 1, raw: 1000000n }) }, kp, jupBase: 'https://jup.test', portalBase: '', slippage: 25, priorityFee: 0 });
    sw2.jupCalls = [Date.now(), Date.now()];
    await assert.rejects(sw2._jup('/quote?x=1', null, { background: true }), (e) => e.busy === true);
    assert.equal(await sw2.canSell('MintX'), 'busy');
    sw2.jupCalls = [];
    mode = 'ok';
    assert.equal(await sw2.canSell('MintX'), true);
  } finally {
    globalThis.fetch = realFetch;
  }
});

test('only his brand-new coins: a coin he traded before (per his token account history) is not bought', async () => {
  const h = harness({ cfg: { ...SCALE, onlyNewCoins: true, newCoinWindowMs: 600000 }, bal: 100 });
  await h.c.refreshBalance();
  const now = Math.floor(Date.now() / 1000);
  const history = {
    OLDC: [{ signature: 'cur' }, { signature: 'x', blockTime: now - 3 * 86400 }], // traded 3 days ago
    NEWC: [{ signature: 'cur', blockTime: now }, { signature: 'burst', blockTime: now - 20 }], // just a buy burst
  };
  let fail = 0;
  const base = h.c.rpc.call;
  h.c.rpc.call = async (m, p) => {
    if (m === 'getTokenAccountsByOwner') {
      if (p[1].mint === 'FLAK' && fail++ < 5) throw new Error('rpc down');
      return { value: [{ pubkey: 'acct-' + p[1].mint }] };
    }
    if (m === 'getSignaturesForAddress') return history[p[0].slice(5)] || [{ signature: 'cur' }];
    return base(m, p);
  };
  const ev = (mint) => ({ ...h.ev(mint), sig: 'cur', wallet: 'HIS' });
  for (const m of ['OLDC', 'NEWC', 'FLAK']) {
    h.c.onMaybeEntry(ev(m));
    h.c.onSignal({ ev: ev(m), kind: 'ENTRY', pre: 0, post: 1, sol: 2 });
  }
  await sleep(1500);
  await h.flush();
  const bought = h.trades.filter((t) => t.action === 'buy').map((t) => t.mint);
  assert.deepEqual(bought, ['NEWC']);
  assert.ok(h.c.stats.skipped >= 2);
  // a coin we bought with him: his later re-buy (after selling out) is copied without asking the chain
  h.c.onSignal({ ev: ev('NEWC'), kind: 'EXIT', pre: 1, post: 0, sol: 1 });
  await h.flush();
  history.NEWC = [{ signature: 'old', blockTime: now - 86400 }];
  h.c.onSignal({ ev: ev('NEWC'), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await h.flush();
  assert.equal(h.trades.filter((t) => t.action === 'buy').length, 2);
});

test('take profit works without pump.fun: one DexScreener price lookup for all open positions', async () => {
  const h = harness({ cfg: { tpX: 2, tpPercent: 25 }, bal: 100 });
  await h.c.refreshBalance();
  const asked = [];
  h.c.pump.getCoin = async () => {
    throw new Error('pump.fun is not used');
  };
  h.c.coins.pricesSol = async (mints) => {
    asked.push([...mints]);
    return { DXA: 0.0003, DXB: 0.00001 }; // our 1000 tokens: 0.3 SOL (3x on 0.1) and 0.01 SOL
  };
  h.c.onSignal({ ev: h.ev('DXA'), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  h.c.onSignal({ ev: h.ev('DXB'), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await h.flush();
  await h.c.checkTakeProfit();
  await h.flush();
  assert.equal(asked.length, 1, 'one batched lookup');
  assert.deepEqual(asked[0].sort(), ['DXA', 'DXB']);
  const sells = h.trades.filter((t) => t.action === 'sell');
  assert.deepEqual(sells.map((t) => [t.mint, t.amount]), [['DXA', '25%']]);
});
