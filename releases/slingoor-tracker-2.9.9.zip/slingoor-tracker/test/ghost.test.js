import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { GhostBook } from '../src/ghost.js';

const file = () => path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'gh-')), 'g.json');
const near = (a, b, e = 1e-6) => assert.ok(Math.abs(a - b) < e, `${a} vs ${b}`);

test('ghosts: side style sells all at +25%; main style rides; fees and our delay are counted', () => {
  let now = 1_000_000;
  const g = new GhostBook({ file: file(), now: () => now, fee: 0.0005, entryPenaltyPct: 5, rulesFor: () => ({}) });
  assert.equal(g.open('dilly', 'M1', 1e-7), true);
  assert.equal(g.open('dilly', 'M1', 1e-7), false, 'one buy per coin');
  const entry = 1.05e-7;
  now += 30000;
  g.price('M1', entry * 1.3); // +30% vs our (late) entry
  const side = g.d.closed.find((c) => c.style === 'side');
  near(side.pnl, 0.05 * 1.3 - 0.0005 - (0.05 + 0.0005));
  assert.equal(side.why, '+25%');
  assert.ok(Object.values(g.d.open).some((x) => x.style === 'main'), 'main still holding');
  // he sells everything: main sells at the last price
  g.hisSell('dilly', 'M1', 100, true);
  const main = g.d.closed.find((c) => c.style === 'main');
  near(main.pnl, 0.1 * 1.3 - 0.0005 - (0.1 + 0.0005));
  assert.equal(main.why, 'his exit');
  assert.equal(g.open('dilly', 'M1', 1e-7), false, 'no second buy after closing');
});

test('ghosts: stop loss -20% (two low prices in a row, after 60s), his partial sells, report ranks traders', () => {
  let now = 2_000_000;
  const g = new GhostBook({ file: file(), now: () => now, fee: 0, entryPenaltyPct: 0 });
  g.open('bot', 'L1', 1);
  now += 10000;
  g.price('L1', 0.7);
  g.price('L1', 0.7);
  assert.equal(g.d.closed.length, 0, 'not in the first 60s');
  now += 60000;
  g.price('L1', 0.7);
  assert.equal(g.d.closed.length, 0, 'first low check waits');
  g.price('L1', 0.7);
  assert.equal(g.d.closed.length, 2, 'both styles stopped out');
  assert.ok(g.d.closed.every((c) => c.why === 'stop loss'));
  // schoen: he sells half -> main sells half, side sells all
  g.open('schoen', 'W1', 1);
  now += 5000;
  g.price('W1', 1.2);
  g.hisSell('schoen', 'W1', 50, false);
  assert.ok(g.d.closed.some((c) => c.trader === 'schoen' && c.style === 'side' && c.why === 'he sold'));
  const m = Object.values(g.d.open).find((x) => x.trader === 'schoen');
  near(m.left, 0.5);
  g.hisSell('schoen', 'W1', 5, false); // tiny sells are ignored, like the real bot
  near(m.left, 0.5);
  g.price('W1', 2);
  g.hisSell('schoen', 'W1', 100, true);
  const r = g.report();
  assert.match(r, /🟢 <b>schoen<\/b>: main \+0\.060 \(1\/1\) · side \+0\.010 \(1\/1\) → best as main/);
  assert.match(r, /🔴 <b>bot<\/b>: main -0\.030 \(0\/1\) · side -0\.015 \(0\/1\)/);
  assert.ok(r.indexOf('schoen') < r.indexOf('bot'), 'best trader first');
  // survives a restart, reset clears
  g.save(true);
  assert.equal(new GhostBook({ file: g.file }).d.closed.length, 4);
  g.reset();
  assert.match(g.report(), /nothing yet/);
});
