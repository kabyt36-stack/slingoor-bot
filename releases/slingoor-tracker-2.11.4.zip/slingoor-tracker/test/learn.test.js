import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { Learner, Suggestions, simulate } from '../src/learn.js';

const tmp = (n) => path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'lrn-')), n);
const R0 = { miniFromX: 1.25, miniToX: 1.8, miniPullbackPct: 10, miniPct: 100, stopLossX: 0.8 };

test('simulate: replays the bot\'s sell rules on a price path', () => {
  const path1 = [[0, 1], [5, 1.3], [10, 1.6], [15, 1.43], [20, 2.4]];
  assert.equal(simulate(path1, R0), 1.43, '11% off the top after arming -> sold');
  assert.equal(simulate(path1, { ...R0, miniPullbackPct: 15 }), 2.4, 'wider dip -> rides to the top of the path');
  assert.equal(simulate([[0, 1], [5, 1.9]], R0), 1.9, 'sell-at x');
  assert.equal(simulate([[0, 1], [30, 0.85], [90, 0.7]], R0), 0.7, 'stop loss after 60s');
  assert.equal(simulate([[0, 1], [5, 1.3], [10, 1.1]], R0), 1.1, 'never sold: ends where the path ends');
  assert.equal(simulate([[0, 1], [5, 2], [10, 3]], { ...R0, miniToX: 2, miniPct: 50 }), 2.5, 'half at 2x, half rides');
});

test('learner: records the hold + 30 min after the sell, then finds better settings for that wallet', () => {
  let now = 1_000_000;
  const L = new Learner({ file: tmp('learn.json'), now: () => now, minTrades: 5 });
  // bot's coins: we sell at 1.8x, but they keep running to ~3x
  for (let i = 0; i < 6; i++) {
    const mint = `M${i}`;
    const p = { leader: 'bot', costSol: 0.1, openedAt: now, boughtTokens: 1000, tokens: 1000 };
    for (const x of [1, 1.2, 1.5, 1.8]) {
      L.sample(mint, p, x);
      now += 6000;
    }
    L.closed(mint, p);
    assert.deepEqual(L.watching(), [mint]);
    for (const x of [2.1, 2.5, 2.9, 3.1, 2.7]) {
      L.postPrice(mint, (x * 0.1) / 1000); // SOL per token
      now += 6000;
    }
    now += 31 * 60000;
    L.tick();
    assert.deepEqual(L.watching(), []);
  }
  assert.equal(L.trades('bot'), 6);
  assert.equal(L.d.done.bot[0].pts.length, 9);
  assert.equal(L.d.done.bot[0].exitIdx, 4);
  const s = L.best('bot', R0);
  assert.ok(s, 'has a suggestion');
  assert.ok(s.to.miniToX >= 2.9, `sells higher (${s.to.miniToX})`);
  assert.ok(s.gain > 0.05);
  assert.equal(s.early, 6, 'sold too early every time');
  assert.equal(L.best('nobody', R0), null, 'not enough trades');
  // saved and reloaded
  L.save(true);
  assert.equal(new Learner({ file: L.file, minTrades: 5 }).trades('bot'), 6);
});

test('no suggestion when your settings are already best', () => {
  const L = new Learner({ file: tmp('l.json'), minTrades: 3 });
  // coins pump to 1.8 then dump: the current 1.8x is right
  L.d.done.bot = Array.from({ length: 5 }, () => ({ cost: 0.1, pts: [[0, 1], [5, 1.4], [10, 1.8], [15, 1.0], [20, 0.5]], exitIdx: 3 }));
  assert.equal(L.best('bot', R0), null);
});

test('suggestions: sent at 6am / 12pm / 6pm / 12am, re-sent if you never answer, only /apply puts them to work', async () => {
  const at = (h, m = 0) => new Date(2026, 10, 12, h, m, 10).getTime();
  let now = at(5, 50);
  const L = new Learner({ file: tmp('l.json'), minTrades: 3 });
  L.d.done.bot = Array.from({ length: 5 }, () => ({ cost: 0.1, pts: [[0, 1], [5, 1.5], [10, 1.8], [15, 2.6], [20, 3]], exitIdx: 3 }));
  const sent = [];
  let applied = null;
  const cur = { bot: { ...R0 } };
  const S = new Suggestions({ file: tmp('s.json'), learner: L, rulesFor: (n) => cur[n] || R0, leaders: () => ['bot', 'schoen'], onApplied: (a) => (applied = a), send: async (h) => sent.push(h), now: () => now });
  assert.equal(await S.tick(), false, 'not a suggestion hour');
  now = at(6, 0);
  assert.equal(await S.tick(), true);
  assert.equal(await S.tick(), false, 'once per slot');
  assert.match(sent[0], /🧠 <b>Suggestions<\/b>/);
  assert.match(sent[0], /<b>bot<\/b>: sell at <b>2\.7x<\/b> \(now 1\.8x\), dip <b>10%<\/b> \(now 10%\)/);
  assert.match(sent[0], /\/apply_bot · \/skip_bot/);
  assert.match(sent[0], /<pre>Make these learned settings the defaults in my slingoor copy bot, test and publish:\n- bot: sell all at 2\.7x \(was 1\.8x\)/);
  assert.doesNotMatch(sent[0], /waiting since/);
  assert.equal(applied, null, 'nothing changes without an answer');
  // no answer -> at 12pm the same suggestion comes again
  now = at(12, 0);
  assert.equal(await S.tick(), true);
  assert.match(sent[1], /<b>bot<\/b> <i>\(waiting since 6:00 AM\)<\/i>/);
  // survives a restart
  const S2 = new Suggestions({ file: S.file, learner: L, rulesFor: (n) => cur[n] || R0, leaders: () => ['bot'], onApplied: (a) => (applied = a), send: async (h) => sent.push(h), now: () => now });
  assert.deepEqual(S2.apply('bot'), ['bot']);
  assert.deepEqual(applied, { bot: { miniToX: 2.7, miniPullbackPct: 10 } });
  assert.deepEqual(S2.apply(), [], 'nothing left');
  // with it applied, nothing new at 6pm
  cur.bot = { ...R0, ...applied.bot };
  now = at(18, 0);
  assert.equal(await S2.tick(), false);
  assert.match(S2.text(), /No suggestions right now/);
  S2.reset();
  assert.deepEqual(applied, {});
});

test('V2.8.1 coin learning: buckets every coin a wallet buys, finds what wins and what loses, suggests skipping the loser', async () => {
  const { featureKeys, keyLabel } = await import('../src/learn.js');
  assert.deepEqual(featureKeys({ tags: ['nsfw', 'animal'], twitter: false, mc: 8000, ageMin: 12, hisSol: 1.2, holders: 35, devCoins: 1 }), ['narr:nsfw', 'narr:animal', 'x:no', 'mc:<10k', 'age:5-30m', 'size:1-3', 'holders:20-50', 'dev:1st']);
  assert.deepEqual(featureKeys({}), ['narr:none'], 'unknown stays out');
  assert.equal(keyLabel('dev:6+'), 'devs with 6+ coins');
  let now = 5_000_000;
  const L = new Learner({ file: tmp('c.json'), now: () => now, minTrades: 10 });
  const run = (mint, f, xs) => {
    assert.equal(L.coinSeen(mint, 'bot', f), true);
    assert.equal(L.coinSeen(mint, 'bot', f), false, 'once per coin per wallet');
    assert.ok(L.watching().includes(mint));
    for (const x of xs) {
      L.postPrice(mint, x * 1e-6); // first price = 1x
      now += 6000;
    }
    now += 31 * 60000;
    L.tick();
  };
  // animal coins with an X run to 2x; NSFW coins with no X die
  for (let i = 0; i < 8; i++) run(`A${i}`, { tags: ['animal'], twitter: true }, [1, 1.4, 1.9, 2.0, 1.6]);
  for (let i = 0; i < 8; i++) run(`N${i}`, { tags: ['nsfw'], twitter: false }, [1, 0.9, 0.7, 0.5, 0.4]);
  assert.equal(L.coinsSeen('bot'), 16);
  const p = L.coinProfile('bot', R0);
  assert.equal(p.n, 16);
  assert.ok(p.best.some((b) => b.key === 'narr:animal'));
  assert.ok(p.worst.some((b) => b.key === 'narr:nsfw'));
  assert.ok(['narr:nsfw', 'x:no'].includes(p.skip.key), p.skip.key);
  assert.equal(p.skip.won, 0);
  // into suggestions
  let applied = null;
  const S = new Suggestions({ file: tmp('s.json'), learner: L, rulesFor: () => R0, leaders: () => ['bot'], onApplied: (a) => (applied = a), send: async () => {}, now: () => now });
  S.refresh();
  const t = S.text();
  assert.match(t, /<b>bot<\/b>: <b>skip (NSFW coins|coins with no X\/Twitter)<\/b> — won 0 of 8/);
  assert.match(t, /What makes a coin/);
  assert.match(t, /best: .*animal coins \+/);
  assert.match(t, /don't copy/);
  assert.deepEqual(S.apply('bot'), ['bot']);
  assert.deepEqual(applied.bot.skip, [p.skip.key]);
  S.refresh();
  assert.ok(!Object.values(S.d.pending).some((x) => x.type === 'skip' && x.key === p.skip.key), 'not suggested again once applied');
});

test('V2.8.2 learn file: thinned paths (top and sell point kept), written at most once a minute', async () => {
  const { compact } = await import('../src/learn.js');
  const pts = Array.from({ length: 1000 }, (_, i) => [i * 5, i === 537 ? 9.9 : 1 + i / 1000]);
  const c = compact(pts, 100);
  assert.ok(c.length <= 102, `${c.length}`);
  assert.ok(c.some((p) => p[1] === 9.9), 'highest point kept');
  assert.deepEqual(c.at(-1), pts.at(-1), 'last point kept');
  let now = 1_000_000;
  const file = tmp('t.json');
  const L = new Learner({ file, now: () => now, minTrades: 1 });
  L.coinSeen('A', 'bot', {});
  L.save();
  assert.ok(fs.existsSync(file), 'first save goes out');
  L.coinSeen('B', 'bot', {});
  L.save();
  assert.equal(Object.keys(JSON.parse(fs.readFileSync(file, 'utf8')).shadow).length, 1, 'not again within a minute');
  now += 61000;
  L.save();
  assert.equal(Object.keys(JSON.parse(fs.readFileSync(file, 'utf8')).shadow).length, 2);
  // a finished trade keeps its exact sell point
  const p = { leader: 'bot', costSol: 0.1, openedAt: now, boughtTokens: 1000 };
  for (let i = 0; i < 400; i++) {
    L.sample('T', p, 1 + i / 400);
    now += 5000;
  }
  L.closed('T', p);
  for (let i = 0; i < 300; i++) {
    L.postPrice('T', 2e-4);
    now += 6000;
  }
  now += 31 * 60000;
  L.tick();
  const t = L.d.done.bot[0];
  assert.ok(t.pts.length <= 244);
  assert.ok(Math.abs(t.pts[t.exitIdx - 1][1] - 1.998) < 0.01, `sell point ${t.pts[t.exitIdx - 1][1]}`);
});
