import path from 'node:path';
import fs from 'node:fs';
import os from 'node:os';
// Copy trading: key handling + signing (checked with Node's own ed25519 verify), the copy logic
// against fakes, and a full run of the real bot.js buying/selling against mock PumpPortal + RPC.
import test from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { b58encode, b58decode, loadKeypair, signTx, verifyTxSignature, parseTx } from '../src/solana.js';
import { CopyTrader, Swapper } from '../src/copytrade.js';
import { startWorld, W, sleep, iso } from './mock.js';

const WS_LIB = process.env.WS_LIB;

export function newKey() {
  const { privateKey, publicKey } = crypto.generateKeyPairSync('ed25519');
  const seed = privateKey.export({ format: 'der', type: 'pkcs8' }).subarray(-32);
  const pub = publicKey.export({ format: 'der', type: 'spki' }).subarray(-32);
  const secret = Buffer.concat([seed, pub]);
  return { b58: b58encode(secret), json: JSON.stringify([...secret]), pub: b58encode(pub) };
}

// A v0 transaction shaped like the ones PumpPortal returns: one signer (us), unsigned.
export function unsignedTx(payerB58, extraKeys = 3, versioned = true) {
  const parts = [Buffer.from([1]), Buffer.alloc(64)];
  if (versioned) parts.push(Buffer.from([0x80]));
  parts.push(Buffer.from([1, 0, 1]), Buffer.from([1 + extraKeys]), Buffer.from(b58decode(payerB58)));
  for (let i = 0; i < extraKeys; i++) parts.push(crypto.randomBytes(32));
  parts.push(crypto.randomBytes(32), Buffer.from([0])); // blockhash, no instructions
  if (versioned) parts.push(Buffer.from([0]));
  return new Uint8Array(Buffer.concat(parts));
}

test('wallet keys: Phantom base58 and solana-keygen JSON both load to the right address', () => {
  const k = newKey();
  assert.equal(loadKeypair(k.b58).publicKey, k.pub);
  assert.equal(loadKeypair(` "${k.b58}"\n`).publicKey, k.pub);
  assert.equal(loadKeypair(k.json).publicKey, k.pub);
  assert.throws(() => loadKeypair(k.b58.slice(0, 40)), /wrong length/);
  assert.throws(() => loadKeypair(k.b58.replace(/.$/, k.b58.endsWith('a') ? 'b' : 'a')), /damaged|wrong length/);
  assert.throws(() => loadKeypair('0OIl+/'), /not allowed/);
  assert.throws(() => loadKeypair(''), /no private key/);
  // base58 round trip incl. leading zeros
  for (const bytes of [new Uint8Array([0, 0, 1, 2, 255]), crypto.randomBytes(32), crypto.randomBytes(64)]) assert.deepEqual(b58decode(b58encode(bytes)), Uint8Array.from(bytes));
});

test('signing: signature lands in our slot and verifies; foreign transactions are refused', () => {
  const k = newKey();
  const kp = loadKeypair(k.b58);
  for (const versioned of [true, false]) {
    const tx = unsignedTx(k.pub, 5, versioned);
    const { bytes, sig } = signTx(tx, kp);
    assert.ok(verifyTxSignature(bytes, k.pub));
    assert.equal(b58encode(bytes.subarray(1, 65)), sig);
    assert.deepEqual(bytes.subarray(65), tx.subarray(65), 'message must not change');
    assert.equal(parseTx(bytes).versioned, versioned);
    // tampering breaks it
    const bad = Uint8Array.from(bytes);
    bad[bad.length - 3] ^= 1;
    assert.equal(verifyTxSignature(bad, k.pub), false);
  }
  const other = newKey();
  assert.throws(() => signTx(unsignedTx(other.pub), kp), /not for our wallet/);
});

// ---------- logic with fakes ----------
function harness({ cfg = {}, bal = 5 } = {}) {
  const k = newKey();
  const kp = loadKeypair(k.b58);
  const sent = [];
  const trades = [];
  const tokens = {}; // mint -> our balance
  const world = { solBal: bal, fail: null, delay: 0, mc: {} };
  const swapper = {
    async trade(req) {
      const { knownRaw, ...plainReq } = req;
      trades.push(plainReq);
      if (world.delay) await sleep(world.delay);
      if (world.fail) {
        const f = world.fail;
        world.fail = null;
        if (f.landed && req.action === 'buy') tokens[req.mint] = (tokens[req.mint] || 0) + 1000;
        throw Object.assign(new Error(f.msg), f);
      }
      if (req.action === 'buy') {
        tokens[req.mint] = (tokens[req.mint] || 0) + 1000;
        world.solBal -= req.amount;
        return { sig: 'S' + trades.length, solDelta: -req.amount - 0.001, tokenDelta: 1000 };
      }
      const pct = parseFloat(req.amount) / 100;
      const base = req.knownRaw != null ? Math.min(tokens[req.mint] || 0, Number(req.knownRaw) / 1e6) : tokens[req.mint] || 0;
      const sold = base * pct;
      tokens[req.mint] -= sold;
      const got = sold * 0.0003 * (world.sellMult ?? 1);
      return { sig: 'S' + trades.length, solDelta: got, tokenDelta: -sold };
    },
  };
  const rpc = {
    call: async (m) => (m === 'getBalance' ? { value: world.solBal * 1e9 } : null),
    getTokenBalance: async (_o, mint) => ({ ui: tokens[mint] || 0, raw: BigInt(Math.round((tokens[mint] || 0) * 1e6)) }),
  };
  const pump = { getCoin: async (m) => (world.mc[m] ? { market_cap: world.mc[m], total_supply: 1e15 } : null) };
  const coins = { get: async (m) => ({ symbol: m.slice(0, 3) }) };
  const c = new CopyTrader({
    cfg: { enabled: true, buySol: 0.1, slippage: 25, priorityFee: 0.001, mirrorSells: true, tpX: 2, tpPercent: 25, maxOpen: 10, dailyLimitSol: 0, minHisBuySol: 0, maxDelayMs: 30000, keepSol: 0.02, tpCheckMs: 1e9, ...cfg },
    rpc,
    kp,
    swapper,
    pump,
    coins,
    broadcast: async (html) => sent.push(html),
    getSolPrice: () => 100,
    file: `/tmp/copytest-${process.pid}-${Math.random()}.json`,
  });
  const ev = (mint, extra = {}) => ({ mint, time: Date.now(), wallet: W, ...extra });
  const flush = async () => {
    await sleep(5);
    await Promise.all([...c.locks.values()]);
  };
  return { c, sent, trades, tokens, world, ev, flush };
}

test('copy logic: buy on his entry, mirror his partial sell, sell all when he exits, trip PnL', async () => {
  const h = harness();
  h.c.onSignal({ ev: h.ev('AAA1'), kind: 'ENTRY', pre: 0, post: 500, sol: 3 });
  h.c.onSignal({ ev: h.ev('AAA1'), kind: 'ENTRY', pre: 0, post: 500, sol: 3 }); // same entry seen twice (chain + feed)
  h.c.onSignal({ ev: h.ev('AAA1'), kind: 'ADD', pre: 500, post: 900, sol: 2 }); // adds are not copied
  await h.flush();
  assert.equal(h.trades.length, 1);
  assert.deepEqual(h.trades[0], { action: 'buy', mint: 'AAA1', amount: 0.1, denominatedInSol: true });
  assert.match(h.sent[0], /COPY BUY.*AAA.*spent/s);
  assert.match(h.sent[0], /0\.101 SOL/);

  h.c.onSignal({ ev: h.ev('AAA1'), kind: 'PARTIAL', pre: 900, post: 540, sol: 1 }); // he sold 40%
  await h.flush();
  assert.deepEqual(h.trades[1], { action: 'sell', mint: 'AAA1', amount: '40%', denominatedInSol: false });
  assert.match(h.sent[1], /COPY SELL 40%/);
  assert.equal(h.tokens.AAA1, 600);

  h.c.onSignal({ ev: h.ev('AAA1'), kind: 'EXIT', pre: 540, post: 0, sol: 2 });
  await h.flush();
  assert.equal(h.trades[2].amount, '100%');
  assert.match(h.sent[2], /ALL OUT/);
  assert.match(h.sent[2], /Trip: in 0\.101/);
  assert.equal(h.c.positions.AAA1, undefined);
  // a later sell of his does nothing for us
  h.c.onSignal({ ev: h.ev('AAA1'), kind: 'EXIT', pre: 10, post: 0, sol: 0.1 });
  await h.flush();
  assert.equal(h.trades.length, 3);
});

test('cupsey mode: each coin follows the sells of the trader it was copied from; one buy per coin across both', async () => {
  const h = harness();
  const CUP = 'CupseyWa11et';
  h.c.traderOf = (w) => (w === CUP ? 'cupsey' : 'slingoor');
  // cupsey's new coin -> copied, alert says cupsey
  h.c.onSignal({ ev: h.ev('CUP1', { wallet: CUP }), kind: 'ENTRY', pre: 0, post: 500, sol: 2 });
  await h.flush();
  assert.equal(h.trades.length, 1);
  assert.equal(h.c.positions.CUP1.leader, 'cupsey');
  assert.match(h.sent[0], /COPY BUY<\/b> <b>[^<]+<\/b> — spent/);
  // sling buys the same coin -> no second buy
  h.c.onSignal({ ev: h.ev('CUP1'), kind: 'ENTRY', pre: 0, post: 100, sol: 1 });
  await h.flush();
  assert.equal(h.trades.length, 1, 'one buy per coin across traders');
  // sling sells that coin -> ignored (we copied it from cupsey)
  h.c.onSignal({ ev: h.ev('CUP1'), kind: 'EXIT', pre: 100, post: 0, sol: 1 });
  await h.flush();
  assert.equal(h.trades.length, 1, "another trader's sell is ignored");
  // cupsey sells 50% -> we sell 50%
  h.c.onSignal({ ev: h.ev('CUP1', { wallet: CUP }), kind: 'PARTIAL', pre: 500, post: 250, sol: 1 });
  await h.flush();
  assert.equal(h.trades[1].amount, '50%');
  assert.match(h.sent.at(-1), /👤 cupsey sold ~50%/);
  // sling's own coin still follows sling
  h.c.onSignal({ ev: h.ev('SLG1'), kind: 'ENTRY', pre: 0, post: 10, sol: 1 });
  await h.flush();
  assert.equal(h.c.positions.SLG1.leader, 'slingoor');
  h.c.onSignal({ ev: h.ev('SLG1', { wallet: CUP }), kind: 'EXIT', pre: 10, post: 0, sol: 1 });
  await h.flush();
  assert.ok(h.c.positions.SLG1, "cupsey selling sling's coin does nothing");
  h.c.onSignal({ ev: h.ev('SLG1'), kind: 'EXIT', pre: 10, post: 0, sol: 1 });
  await h.flush();
  assert.equal(h.c.positions.SLG1, undefined);
});

test('daily recap at 11:59pm: profit from closed coins, best/worst, buys/sells, wallet vs start of day; once a day', async () => {
  const h = harness({ cfg: { sizeMode: 'fixed', buySol: 0.1 }, bal: 100 });
  let now = new Date(2026, 10, 7, 9, 0).getTime();
  h.c.now = () => now;
  await h.c.refreshBalance();
  h.c.solBalance = async () => 100.05;
  // a winner and a loser closed today
  h.c.onSignal({ ev: h.ev('WIN1'), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  h.c.onSignal({ ev: h.ev('LOS1'), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await h.flush();
  h.world.sellMult = 1; // 0.3 SOL back on ~0.1 in
  h.c.onSignal({ ev: h.ev('WIN1'), kind: 'EXIT', pre: 1, post: 0, sol: 1 });
  await h.flush();
  h.world.sellMult = 0.1; // 0.03 back
  h.c.onSignal({ ev: h.ev('LOS1'), kind: 'EXIT', pre: 1, post: 0, sol: 1 });
  await h.flush();
  const sent = [];
  now = new Date(2026, 10, 7, 23, 58, 30).getTime();
  assert.equal(await h.c.checkDailyRecap(async (x) => sent.push(x)), false, 'not yet');
  now = new Date(2026, 10, 7, 23, 59, 10).getTime();
  assert.equal(await h.c.checkDailyRecap(async (x) => sent.push(x)), true);
  assert.equal(await h.c.checkDailyRecap(async (x) => sent.push(x)), false, 'once a day');
  const r = sent[0];
  assert.match(r, /Daily recap — Sat, Nov 7/);
  assert.match(r, /🟢 Total gains: <b>\+0\.199 SOL<\/b>/);
  assert.match(r, /🔴 Total losses: <b>-0\.071 SOL<\/b>/);
  assert.match(r, /💰 Total PnL: <b>\+0\.128 SOL<\/b>/);
  assert.match(r, /2 coins closed \(1 won, 1 lost\) · 2 buys · 2 sells/);
  assert.doesNotMatch(r, /WIN|LOS/, 'no coin names');
  assert.match(r, /👛 Wallet: <b>100\.0 SOL<\/b> \(started the day at 100\.0 SOL → \+0\.050 SOL\)/);
  // next day starts fresh
  now = new Date(2026, 10, 8, 10, 0).getTime();
  assert.match(await h.c.dailyRecapText(), /Total PnL: <b>\+0\.0+ SOL<\/b>/);
});

test('losing sells make no alert (COPY_LOSS_ALERTS=off) and show up in the daily recap; winning sells still alert', async () => {
  const h = harness({ cfg: { sizeMode: 'fixed', buySol: 0.1, lossAlerts: false }, bal: 100 });
  await h.c.refreshBalance();
  h.c.onSignal({ ev: h.ev('LOSE'), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  h.c.onSignal({ ev: h.ev('WINN'), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await h.flush();
  const before = h.sent.length;
  h.world.sellMult = 0.1; // 0.03 SOL back on ~0.1 in
  h.c.onSignal({ ev: h.ev('LOSE'), kind: 'PARTIAL', pre: 1, post: 0.5, sol: 1 });
  await h.flush();
  h.c.onSignal({ ev: h.ev('LOSE'), kind: 'EXIT', pre: 0.5, post: 0, sol: 1 });
  await h.flush();
  assert.equal(h.sent.length, before, 'no alerts for losing sells (partial or full)');
  h.world.sellMult = 1;
  h.c.onSignal({ ev: h.ev('WINN'), kind: 'EXIT', pre: 1, post: 0, sol: 1 });
  await h.flush();
  assert.equal(h.sent.length, before + 1);
  assert.match(h.sent.at(-1), /ALL OUT.*WIN/s);
  const r = await h.c.dailyRecapText();
  assert.match(r, /🔴 Total losses: <b>-0\.0\d+ SOL<\/b>/);
  assert.doesNotMatch(r, /LOS/);
});

test('daily recap: MPT (most profitable trader) = the trader whose copies made the most SOL', async () => {
  const h = harness({ cfg: { sizeMode: 'fixed', buySol: 0.1 }, bal: 100 });
  h.c.targetName = 'slingoor';
  h.c.traderOf = (w) => (w === 'CUP' ? 'cupsey' : 'slingoor');
  await h.c.refreshBalance();
  h.c.onSignal({ ev: h.ev('SL1'), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  h.c.onSignal({ ev: h.ev('CU1', { wallet: 'CUP' }), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await h.flush();
  h.world.sellMult = 0.1; // sling's coin loses
  h.c.onSignal({ ev: h.ev('SL1'), kind: 'EXIT', pre: 1, post: 0, sol: 1 });
  await h.flush();
  h.world.sellMult = 1; // cupsey's coin wins
  h.c.onSignal({ ev: h.ev('CU1', { wallet: 'CUP' }), kind: 'EXIT', pre: 1, post: 0, sol: 1 });
  await h.flush();
  const pl = h.c.pnlLines().join('\n');
  assert.match(pl, /PnL this hour: <b>\+0\.128 SOL<\/b> \(gains \+0\.199 · losses -0\.071\)/);
  assert.match(pl, /PnL today: <b>\+0\.128 SOL<\/b>/);
  const r = await h.c.dailyRecapText();
  assert.match(r, /🏆 <b>MPT<\/b> \(most profitable trader\): <b>cupsey<\/b> \+0\.199 SOL/);
  assert.match(r, /cupsey \+0\.199 · slingoor -0\.071/);
});

test('V2 short alerts: one line for a buy, a mini cook, a big cook, a plain sell', async () => {
  const h = await miniHarness(0.1, { shortAlerts: true });
  assert.match(h.sent[0], /^🟢 Bought <b>\$MC<\/b> — <b>0\.1\d* SOL<\/b>( · MC \$[\d.]+[KMB]?)?$/);
  assert.deepEqual(await h.at(1.9), []);
  assert.deepEqual(await h.at(1.7), ['50%']);
  assert.match(h.sent.at(-1), /^🍳 <b>[\d.]+x mini cook<\/b> on <b>\$MC<\/b> — got <b>[\d.]+ SOL<\/b> \(\+[\d.]+\)$/); // V2.11.22 the x it really sold at + the profit
  h.c.onSignal({ ev: h.ev('MC'), kind: 'EXIT', pre: 1, post: 0, sol: 1 });
  await h.flush();
  assert.match(h.sent.at(-1), /^🔥 <b>\d+\.\dx cook<\/b> on <b>\$MC<\/b> — got <b>[\d.]+ SOL<\/b> \(\+[\d.]+\)$/, 'trip closed at 2x+ -> big cook');
  for (const m of h.sent) assert.doesNotMatch(m, /\n/, 'every alert is one line');
});

test('V2 quick-profit wallet: sells 100% as soon as it is up 25%; follows the trader\'s partial sells with 100%', async () => {
  const qcfg = { sizeMode: 'fixed', buySol: 0.05, maxBuySol: 0.05, floorBuySol: 0, miniCook: false, tpLadder: [], tpX: 0, quickTpX: 0, quickFromX: 1.25, quickToX: 1.25, quickPullbackPct: 1, sellAllAlways: true };
  let h = await miniHarness(0.05, qcfg);
  h.c.quickMode = true;
  assert.deepEqual(await h.at(1.2), []);
  assert.deepEqual(await h.at(1.26), ['100%'], 'up 25% -> all out');
  h = await miniHarness(0.05, qcfg);
  h.c.quickMode = true;
  h.c.onSignal({ ev: h.ev('MC'), kind: 'PARTIAL', pre: 1, post: 0.6, sol: 1 });
  await h.flush();
  assert.deepEqual(h.trades.filter((t) => t.action === 'sell').map((t) => t.amount), ['100%'], 'his 40% sell -> quick wallet sells everything');
});

test('V2.4 dev coins: fixed buy size, bought even when the watcher fires minutes after launch, sold with the dev rules; held longer if a tracked trader is in', async () => {
  const devRules = { pat: { miniFromX: 1.25, miniToX: 1.4, miniPullbackPct: 5, miniPct: 100 } };
  const h = harness({ cfg: { sizeMode: 'scale', buySol: 0.5, devNames: ['pat'], devBuySol: 0.1, leaderRules: devRules, miniCook: true, miniMinSol: 0.1, protect: false, traderWallets: ['TRADER1'] }, bal: 100 });
  h.c.traderOf = (w) => (w === 'DEV' ? 'pat' : 'x');
  await h.c.refreshBalance();
  // a dip-dev buy decided 5 minutes after launch: no "his buy was too long ago" skip
  h.c.onSignal({ ev: h.ev('D1', { wallet: 'DEV', time: Date.now() - 5 * 60000 }), kind: 'ENTRY', pre: 0, post: 1, sol: 2, devReady: true });
  await h.flush();
  assert.equal(h.trades.length, 1);
  assert.ok(Math.abs(h.trades[0].amount - 0.1) < 1e-9, 'dev coins buy DEV_BUY_SOL, not scaled to the dev buy');
  const p = h.c.positions.D1;
  assert.equal(p.leader, 'pat');
  assert.equal(p.hisBuySol, null, 'dev buys never count as "weak small buys"');
  let px = 0;
  h.c.coins.pricesSol = async () => ({ D1: px });
  h.c.rpc.getTokenBalance = async () => null; // no tracked trader in it
  const at = async (x) => {
    px = (p.costSol / p.tokens) * x;
    await h.c.checkTakeProfit();
    await h.flush();
    return h.trades.filter((t) => t.action === 'sell').map((t) => t.amount);
  };
  assert.deepEqual(await at(1.3), []);
  assert.deepEqual(await at(1.35), []);
  assert.deepEqual(await at(1.27), ['100%'], 'instant dev: all out on a 5% dip after +25%');

  // same coin, but a tracked trader holds it -> normal rules: no quick sell at +30%
  const g = harness({ cfg: { sizeMode: 'scale', buySol: 0.5, devNames: ['pat'], devBuySol: 0.1, leaderRules: devRules, miniCook: true, miniMinSol: 0.1, miniFromX: 1.75, miniToX: 2.5, miniPullbackPct: 10, miniPct: 50, protect: false, traderWallets: ['TRADER1'] }, bal: 100 });
  g.c.traderOf = (w) => (w === 'DEV' ? 'pat' : 'x');
  await g.c.refreshBalance();
  g.c.onSignal({ ev: g.ev('D2', { wallet: 'DEV' }), kind: 'ENTRY', pre: 0, post: 1, sol: 2, devReady: true });
  await g.flush();
  const q = g.c.positions.D2;
  g.c.rpc.getTokenBalance = async (w) => (w === 'TRADER1' ? { ui: 5000 } : null);
  let px2 = 0;
  g.c.coins.pricesSol = async () => ({ D2: px2 });
  for (const x of [1.0, 1.3, 1.35, 1.27]) {
    px2 = (q.costSol / q.tokens) * x;
    await g.c.checkTakeProfit();
    await g.flush();
    await sleep(5);
  }
  assert.equal(q.tradersIn, true);
  assert.deepEqual(g.trades.filter((t) => t.action === 'sell'), [], 'a tracked trader is in: hold for more');
});

test('V2.4 watch-only wallets: one that buys in AFTER us makes the bot hold longer; one already in before us does not', async () => {
  const mk = async () => {
    const h = await miniHarness(0.1, { watchWallets: [{ name: 'kimchi', wallet: 'KIM' }, { name: 'henry', wallet: 'HEN' }] });
    return h;
  };
  let h = await mk();
  let inNow = new Set(['HEN']); // henry already holds it when we buy
  h.c.rpc.getTokenBalance = async (w) => (inNow.has(w) ? { ui: 100 } : null);
  const tick = async (x) => {
    if (h.c.positions.MC) h.c.positions.MC.smartCheckAt = h.c.positions.MC.smartCheckAt ? 1 : null; // a minute passed
    const r = await h.at(x);
    await sleep(5);
    return r;
  };
  await tick(1.0);
  assert.equal(h.c.positions.MC.tradersIn, undefined, 'henry was in before us');
  inNow.add('KIM'); // kimchi buys in after us
  await tick(1.0);
  assert.equal(h.c.positions.MC.tradersIn, true);
  assert.deepEqual(h.c.positions.MC.smartNames, ['kimchi']);
  // held longer: a 12% dip after 1.9x does NOT trigger the mini cook (needs 20% now)
  assert.deepEqual(await tick(1.9), []);
  assert.deepEqual(await tick(1.67), [], '12% off the top: keep riding');
});

test('V2.5 mini toaster: decu buying a coin we copied from bot holds it for the jump; decu selling sells 100%', async () => {
  const toast = { miniFromX: 1.2, miniToX: 1.4, miniPullbackPct: 5, miniPct: 100 };
  const h = harness({ cfg: { sizeMode: 'fixed', buySol: 0.1, leaderRules: { bot: toast }, miniCook: true, miniMinSol: 0.1, miniFromX: 1.75, miniToX: 2.5, miniPullbackPct: 10, miniPct: 50, protect: false, boosters: [['decu', 'bot']], traderBuySol: { decu: 0.05 } }, bal: 100 });
  h.c.traderOf = (w) => ({ BOTW: 'bot', DECU: 'decu' })[w] || 'x';
  await h.c.refreshBalance();
  h.c.onSignal({ ev: h.ev('T1', { wallet: 'BOTW' }), kind: 'ENTRY', pre: 0, post: 1, sol: 2 });
  await h.flush();
  const p = h.c.positions.T1;
  assert.equal(p.leader, 'bot');
  assert.equal(h.c.noteBooster({ ev: h.ev('T1', { wallet: 'DECU' }), kind: 'ENTRY' }), true);
  assert.equal(p.boostedBy, 'decu');
  let px = 0;
  h.c.coins.pricesSol = async () => ({ T1: px });
  const at = async (x) => {
    px = (p.costSol / p.tokens) * x;
    await h.c.checkTakeProfit();
    await h.flush();
    return h.trades.filter((t) => t.action === 'sell').map((t) => t.amount);
  };
  assert.deepEqual(await at(1.35), []);
  assert.deepEqual(await at(1.28), [], 'boosted: no quick toaster sell on a 5% dip');
  h.c.onSignal({ ev: h.ev('T1', { wallet: 'DECU' }), kind: 'PARTIAL', pre: 1, post: 0.5, sol: 1 });
  await h.flush();
  assert.deepEqual(h.trades.filter((t) => t.action === 'sell').map((t) => t.amount), ['100%'], 'decu sold -> all out');
});

test('V2.7.6 bot (mini toaster) holds longer: rides past 1.4x and a small dip, sells all on a 10% pullback or at 1.8x', async () => {
  const { loadConfig } = await import('../src/config.js');
  const f = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'cfg-')), 'settings.txt');
  fs.writeFileSync(f, 'TELEGRAM_BOT_TOKEN=1:x\n');
  const toast = loadConfig(f).copy.leaderRules.bot;
  assert.equal(toast.miniToX, 1.8);
  assert.equal(toast.miniPullbackPct, 10);
  const run = async (path) => {
    const h = harness({ cfg: { sizeMode: 'fixed', buySol: 0.1, leaderRules: { bot: toast }, miniCook: true, miniMinSol: 0.1, miniFromX: 1.75, miniToX: 2.5, miniPullbackPct: 10, miniPct: 50, protect: false }, bal: 100 });
    h.c.traderOf = (w) => (w === 'BOTW' ? 'bot' : 'x');
    await h.c.refreshBalance();
    h.c.onSignal({ ev: h.ev('T1', { wallet: 'BOTW' }), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
    await h.flush();
    const p = h.c.positions.T1;
    let px = 0;
    h.c.coins.pricesSol = async () => ({ T1: px });
    const out = [];
    for (const x of path) {
      px = (p.costSol / p.tokens) * x;
      await h.c.checkTakeProfit();
      await h.flush();
      out.push(h.trades.filter((t) => t.action === 'sell').length);
    }
    return out;
  };
  assert.deepEqual(await run([1.3, 1.45, 1.38, 1.6]), [0, 0, 0, 0], 'old rules sold at 1.4x / a 5% dip; now it keeps riding');
  assert.deepEqual(await run([1.3, 1.6, 1.42]), [0, 0, 1], '11% off the top: all out');
  assert.deepEqual(await run([1.3, 1.85]), [0, 1], '1.8x: all out');
});

test('V2.8 learning: the copier feeds the learner (hold + after the sell) and uses settings you applied', async () => {
  const { Learner } = await import('../src/learn.js');
  const toast = { miniFromX: 1.25, miniToX: 1.8, miniPullbackPct: 10, miniPct: 100 };
  const h = harness({ cfg: { sizeMode: 'fixed', buySol: 0.1, leaderRules: { bot: toast }, miniCook: true, miniMinSol: 0.1, miniFromX: 1.75, miniToX: 2.5, miniPullbackPct: 10, miniPct: 50, protect: false }, bal: 100 });
  h.c.traderOf = (w) => (w === 'BOTW' ? 'bot' : 'x');
  h.c.learner = new Learner({ file: path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'lr-')), 'l.json'), minTrades: 1 });
  h.c.learned = { bot: { miniToX: 2.5, miniPullbackPct: 20 } }; // you tapped /apply_bot
  await h.c.refreshBalance();
  h.c.onSignal({ ev: h.ev('T1', { wallet: 'BOTW' }), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await h.flush();
  const p = h.c.positions.T1;
  const per = p.costSol / p.tokens;
  let px = 0;
  h.c.coins.pricesSol = async () => ({ T1: px });
  const sells = () => h.trades.filter((t) => t.action === 'sell').length;
  const at = async (x) => {
    px = per * x;
    await h.c.checkTakeProfit();
    await h.flush();
    return sells();
  };
  assert.equal(await at(1.9), 0, 'applied: past the old 1.8x, still holding');
  assert.equal(await at(1.65), 0, '13% dip: inside the applied 20%');
  assert.ok(h.c.learner.d.live.T1, 'learning while we hold');
  assert.equal(await at(2.6), 1, 'sold at the applied 2.5x');
  assert.deepEqual(h.c.learner.watching(), ['T1'], 'keeps watching after the sell');
  h.c.learner.d.post.T1.pts.at(-1)[0] -= 10; // next sample is due
  px = per * 3.2;
  await h.c.learnPrices();
  assert.equal(h.c.learner.d.post.T1.pts.at(-1)[1], 3.2, 'price after the sell recorded');
});

test('V2.8.1 learned coin skips: a kind of coin you approved skipping is not bought; every buy of theirs is learned from', async () => {
  const { Learner } = await import('../src/learn.js');
  const h = harness({ cfg: { sizeMode: 'fixed', buySol: 0.1, protect: false }, bal: 100 });
  h.c.traderOf = (w) => (w === 'BOTW' ? 'bot' : 'x');
  h.c.coins.get = async (m) => (m === 'NS1' ? { name: 'Horny Milf', symbol: 'MILF', mc: 9000, twitter: '' } : { name: 'Brave Dog', symbol: 'DOG', mc: 40000, twitter: 'https://x.com/dog' });
  h.c.learner = new Learner({ file: path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'lr-')), 'l.json'), minTrades: 1 });
  h.c.learned = { bot: { skip: ['narr:nsfw'] } };
  await h.c.refreshBalance();
  h.c.onSignal({ ev: h.ev('NS1', { wallet: 'BOTW' }), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  h.c.onSignal({ ev: h.ev('DG1', { wallet: 'BOTW' }), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await h.flush();
  await sleep(20);
  await h.flush();
  assert.deepEqual(h.trades.filter((t) => t.action === 'buy').map((t) => t.mint), ['DG1'], 'NSFW coin skipped, dog coin bought');
  assert.match(h.c.skips.at(-1).why, /learned: bot's NSFW coins lose money/);
  const f = await h.c.coinFeatures('NS1', 1.5, { full: false });
  assert.deepEqual(f.tags.includes('nsfw'), true);
  assert.equal(f.twitter, false);
  h.c.learnSeen('DG1', 'bot', 2);
  await sleep(1700);
  assert.ok(Object.keys(h.c.learner.d.shadow).includes('bot|DG1'), 'following the coin he bought');
  assert.ok(h.c.learner.d.shadow['bot|DG1'].keys.includes('narr:animal'));
});

test('V2.8.2 a sell that fails on slippage (coin dumping) retries right away with more slippage: 10% -> 20% -> 35%', async () => {
  const h = harness({ cfg: { slippage: 10, maxSlippage: 50 } });
  h.c.onSignal({ ev: h.ev('DMP1'), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await h.flush();
  const real = h.c.swapper.trade.bind(h.c.swapper);
  let fails = 2;
  const slips = [];
  h.c.swapper.trade = async (req) => {
    if (req.action === 'sell') {
      slips.push(req.slippage ?? null);
      if (fails-- > 0) throw Object.assign(new Error('transaction failed on-chain: price moved more than your slippage'), { onChain: true });
    }
    return real(req);
  };
  const t0 = Date.now();
  h.c.onSignal({ ev: h.ev('DMP1'), kind: 'EXIT', pre: 1, post: 0, sol: 1 });
  await h.flush();
  assert.deepEqual(slips, [null, 20, 35]);
  assert.ok(Date.now() - t0 < 900, 'no waiting between slippage retries');
  assert.ok(!h.c.positions.DMP1, 'sold');
  assert.ok(!h.sent.some((m) => /SELL FAILED/.test(m)));
});

test('V2.8.2 Swapper: a raised slippage reaches the sell quote; the new coin account rent is not counted as cost', async () => {
  const k = newKey();
  const sw = new Swapper({ rpc: { getTokenBalance: async () => ({ raw: 5000n }) }, kp: loadKeypair(k.b58), jupBase: 'x', slippage: 10, priorityFee: 0.001 });
  const urls = [];
  sw._jup = async (u) => (urls.push(u), u.startsWith('/quote') ? { outAmount: '1' } : { swapTransaction: Buffer.from('tx').toString('base64') });
  await sw.build({ action: 'sell', mint: 'M', amount: '100%', knownRaw: '5000', slippage: 35 });
  assert.match(urls[0], /slippageBps=3500/);
  await sw.build({ action: 'sell', mint: 'M', amount: '100%', knownRaw: '5000' });
  assert.match(urls[2], /slippageBps=1000/);
  // buy that created our coin account (index 3): 0.1 SOL + 0.00203928 rent + fee
  const me = sw.kp.publicKey;
  sw.rpc.getTransaction = async () => ({ meta: { fee: 5000, preBalances: [1e9, 0, 0, 0], postBalances: [1e9 - 1e8 - 2039280 - 5000, 0, 0, 2039280], preTokenBalances: [], postTokenBalances: [{ accountIndex: 3, mint: 'M', owner: me, uiTokenAmount: { amount: '1000', uiAmountString: '1' } }] } });
  const r = await sw.result('SIG', 'M');
  assert.ok(Math.abs(r.rentSol - 0.00203928) < 1e-12);
  // an account we already had: no rent
  sw.rpc.getTransaction = async () => ({ meta: { fee: 5000, preBalances: [1e9, 0, 0, 2039280], postBalances: [1e9 - 1e8 - 5000, 0, 0, 2039280], preTokenBalances: [{ accountIndex: 3, mint: 'M', owner: me, uiTokenAmount: { amount: '0', uiAmountString: '0' } }], postTokenBalances: [{ accountIndex: 3, mint: 'M', owner: me, uiTokenAmount: { amount: '1000', uiAmountString: '1' } }] } });
  assert.equal((await sw.result('SIG', 'M')).rentSol, 0);
});

test('V2.8.2 the copier records cost without the coin account rent', async () => {
  const h = harness();
  const real = h.c.swapper.trade.bind(h.c.swapper);
  h.c.swapper.trade = async (req) => ({ ...(await real(req)), ...(req.action === 'buy' ? { solDelta: -0.05 - 0.0001 - 0.00203928, rentSol: 0.00203928 } : {}) });
  h.c.onSignal({ ev: h.ev('RNT1'), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await h.flush();
  assert.ok(Math.abs(h.c.positions.RNT1.costSol - 0.0501) < 1e-9, `cost ${h.c.positions.RNT1.costSol}`);
});

test('V2.8.2 quick-profit traders (decu buys 0.05): their own sell rules work even on buys under 0.1 SOL', async () => {
  const toast = { miniFromX: 1.25, miniToX: 1.8, miniPullbackPct: 10, miniPct: 100 };
  const h = harness({ cfg: { sizeMode: 'fixed', buySol: 0.05, leaderRules: { decu: toast }, miniCook: true, miniMinSol: 0.1, miniFromX: 1.75, miniToX: 2.5, miniPullbackPct: 10, miniPct: 50, protect: false } });
  h.c.traderOf = (w) => (w === 'DECU' ? 'decu' : 'x');
  h.c.onSignal({ ev: h.ev('DC1', { wallet: 'DECU' }), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await h.flush();
  const p = h.c.positions.DC1;
  assert.ok(p.costSol < 0.1);
  h.c.coins.pricesSol = async () => ({ DC1: (p.costSol / p.tokens) * 1.85 });
  await h.c.checkTakeProfit();
  await h.flush();
  assert.equal(h.trades.filter((t) => t.action === 'sell').length, 1, 'sold at 1.8x+');
  assert.match(h.sent.at(-1), /MINI COOK|mini cook/);
});

test('V2.8.2 holder count for TRADER_MIN_HOLDERS starts when his buy is seen, not right before ours', async () => {
  const h = harness({ cfg: { traderMinHolders: { bot: 20 } } });
  h.c.traderOf = (w) => (w === 'BOTW' ? 'bot' : 'x');
  let calls = 0;
  let startedAt = null;
  h.c.countHolders = async () => {
    calls++;
    startedAt ??= Date.now();
    await sleep(60);
    return 30;
  };
  const t0 = Date.now();
  h.c.onSignal({ ev: h.ev('HC1', { wallet: 'BOTW' }), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  assert.ok(startedAt != null && startedAt - t0 < 5, 'counting started at once');
  await h.flush();
  await sleep(80);
  await h.flush();
  assert.equal(calls, 1, 'counted once, reused by the buy');
  assert.deepEqual(h.trades.map((t) => t.mint), ['HC1']);
});

test('V2.8.2 learner coins are priced in their own pass (the price check of held coins never waits for them)', async () => {
  const { Learner } = await import('../src/learn.js');
  const h = harness({ cfg: { protect: false, miniCook: true } });
  h.c.learner = new Learner({ file: path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'lp-')), 'l.json'), minTrades: 1 });
  h.c.learner.coinSeen('SH1', 'bot', { tags: ['animal'] });
  h.c.onSignal({ ev: h.ev('OWN1'), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await h.flush();
  const asked = [];
  h.c.coins.pricesSol = async (m) => (asked.push([...m]), Object.fromEntries(m.map((x) => [x, 1e-6])));
  await h.c.checkTakeProfit();
  assert.deepEqual(asked, [['OWN1']], 'only our coins in the trade price check');
  await h.c.learnPrices();
  assert.deepEqual(asked[1], ['SH1']);
  assert.equal(h.c.learner.d.shadow['bot|SH1'].pts.length, 1);
});

test('V2.8.2 quick-profit traders: his buy back into a coin he sold out of earlier is copied (it was skipped as "not new")', async () => {
  const h = harness({ cfg: { onlyNewCoins: true, copyReentries: false, toasters: ['bot'], newCoinWindowMs: 600000 } });
  h.c.traderOf = (w) => (w === 'BOTW' ? 'bot' : 'x');
  // his token account has trades from 20 minutes ago (he traded it before)
  const old = Math.floor((Date.now() - 20 * 60000) / 1000);
  h.c.rpc.call = async (m) => (m === 'getTokenAccountsByOwner' ? { value: [{ pubkey: 'ACC' }] } : m === 'getSignaturesForAddress' ? [{ signature: 'OLD', blockTime: old }] : m === 'getBalance' ? { value: 5e9 } : null);
  h.c.onSignal({ ev: h.ev('RE1', { wallet: 'BOTW', preUi: 0 }), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await h.flush();
  assert.deepEqual(h.trades.map((t) => t.mint), ['RE1'], 'bot re-buy copied');
  // a normal trader's re-buy is still skipped
  h.c.onSignal({ ev: h.ev('RE2', { wallet: 'OTHER', preUi: 0 }), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await h.flush();
  await sleep(20);
  assert.deepEqual(h.trades.map((t) => t.mint), ['RE1']);
  assert.match(h.c.skips.at(-1).why, /not a new coin for him/);
});

test('V2.8.10 his tiny partial sells (under 10%) are not copied; bigger ones and his exit are', async () => {
  const h = harness({ cfg: { minMirrorPct: 10 } });
  h.c.onSignal({ ev: h.ev('TS1'), kind: 'ENTRY', pre: 0, post: 1000, sol: 1 });
  await h.flush();
  h.c.onSignal({ ev: h.ev('TS1'), kind: 'PARTIAL', pre: 1000, post: 990, sol: 0.01 }); // 1%
  h.c.onSignal({ ev: h.ev('TS1'), kind: 'PARTIAL', pre: 990, post: 940, sol: 0.05 }); // 5%
  await h.flush();
  assert.equal(h.trades.filter((t) => t.action === 'sell').length, 0, 'tiny sells ignored');
  h.c.onSignal({ ev: h.ev('TS1'), kind: 'PARTIAL', pre: 940, post: 470, sol: 0.5 }); // 50%
  await h.flush();
  assert.deepEqual(h.trades.filter((t) => t.action === 'sell').map((t) => t.amount), ['50%']);
  h.c.onSignal({ ev: h.ev('TS1'), kind: 'EXIT', pre: 470, post: 0, sol: 0.5 });
  await h.flush();
  assert.deepEqual(h.trades.filter((t) => t.action === 'sell').map((t) => t.amount), ['50%', '100%']);
});

test('V2.9.4 every copy buy needs 30+ holders (a trader with his own minimum keeps it; launch-buying devs are exempt)', async () => {
  const h = harness({ cfg: { minHoldersToBuy: 30, traderMinHolders: { bot: 20 }, launchBuyers: ['pattersin'] } });
  h.c.traderOf = (w) => ({ DILLY: 'dilly', BOTW: 'bot', PAT: 'pattersin' })[w] || 'x';
  const holders = { FEW: 12, MANY: 45, B25: 25, NEW: 1 };
  h.c.countHolders = async (m) => holders[m];
  h.c.onSignal({ ev: h.ev('FEW', { wallet: 'DILLY' }), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  h.c.onSignal({ ev: h.ev('MANY', { wallet: 'DILLY' }), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  h.c.onSignal({ ev: h.ev('B25', { wallet: 'BOTW' }), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  h.c.onSignal({ ev: h.ev('NEW', { wallet: 'PAT' }), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await h.flush();
  await sleep(30);
  await h.flush();
  assert.deepEqual(h.trades.filter((t) => t.action === 'buy').map((t) => t.mint).sort(), ['B25', 'MANY', 'NEW']);
  assert.ok(h.c.skips.some((x) => /only 12 holders \(under 30\)/.test(x.why)));
});

test('V2.9.6 don\'t chase the pump: a buy priced 15%+ above his fill is not sent (and not retried); devs and adds are exempt', async () => {
  const { chaseCheck } = await import('../src/copytrade.js');
  // his price 1e-7 SOL/token; we'd get 0.1 SOL -> 800k tokens = 1.25e-7 (25% above): blocked
  assert.throws(() => chaseCheck({ action: 'buy', maxPriceSol: 1.15e-7, chasePct: 15 }, { inAmount: 1e8, outAmount: 800000e6 }), /price already 25% above his buy/);
  // 950k tokens = 1.05e-7 (5% above): fine
  chaseCheck({ action: 'buy', maxPriceSol: 1.15e-7, chasePct: 15 }, { inAmount: 1e8, outAmount: 950000e6 });
  chaseCheck({ action: 'sell', maxPriceSol: 1 }, { inAmount: 1, outAmount: 1 }); // sells never checked
  const h = harness({ cfg: { maxChasePct: 15, devNames: ['pattersin'], sizeMode: 'fixed', buySol: 0.1, devBuySol: 0.1 } });
  h.c.traderOf = (w) => ({ DILLY: 'dilly', PAT: 'pattersin' })[w] || 'x';
  const real = h.c.swapper.trade.bind(h.c.swapper);
  const seen = [];
  h.c.swapper.trade = async (req, pre) => {
    seen.push(req.maxPriceSol ?? null);
    chaseCheck(req, { inAmount: 1e8, outAmount: 800000e6 }); // the price ran 25% past his buy
    return real(req, pre);
  };
  h.c.onSignal({ ev: h.ev('CH1', { wallet: 'DILLY', priceSol: 1e-7 }), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await h.flush();
  assert.equal(seen.length, 1, 'tried once, no retry');
  assert.ok(Math.abs(seen[0] - 1.15e-7) < 1e-15);
  assert.equal(h.trades.filter((t) => t.action === 'buy').length, 0, 'not bought');
  assert.match(h.c.skips.at(-1).why, /price already 25% above his buy — not chasing it/);
  h.c.onSignal({ ev: h.ev('DV1', { wallet: 'PAT', priceSol: 1e-7 }), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await h.flush();
  await sleep(30);
  await h.flush();
  assert.equal(seen.length, 2, 'the dev buy was tried');
  assert.equal(seen.at(-1), null, 'dev buys have no chase limit');
});

test('V2.9.6 stop loss -20% for every copied trader (main and side wallets): down to 0.8x twice, held 60s+ -> sell all', async () => {
  const h = harness({ cfg: { stopLossX: 0.8, protect: false } });
  h.c.onSignal({ ev: h.ev('SL1'), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await h.flush();
  const p = h.c.positions.SL1;
  p.openedAt = Date.now() - 120000;
  let x = 0.85;
  h.c.coins.pricesSol = async () => ({ SL1: (p.costSol / p.tokens) * x });
  await h.c.checkTakeProfit();
  await h.flush();
  assert.equal(h.trades.filter((t) => t.action === 'sell').length, 0, '0.85x: holds');
  x = 0.78;
  await h.c.checkTakeProfit();
  await h.flush();
  assert.equal(h.trades.filter((t) => t.action === 'sell').length, 0, 'first low check: waits one more (bad price feed guard)');
  await h.c.checkTakeProfit();
  await h.flush();
  assert.deepEqual(h.trades.filter((t) => t.action === 'sell').map((t) => t.amount), ['100%'], 'second low check: sold all');
});

test('V2.9.7 a coin with no price from the price sites is valued by a Jupiter sell quote, so the stop loss still sells it', async () => {
  const h = harness({ cfg: { stopLossX: 0.8, protect: true } });
  h.c.onSignal({ ev: h.ev('NP1'), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await h.flush();
  const p = h.c.positions.NP1;
  p.openedAt = Date.now() - 120000;
  h.c.coins.pricesSol = async () => ({}); // no price anywhere
  h.c.pump.getCoin = async () => null;
  let quotes = 0;
  h.c.swapper.quoteSellSol = async () => (quotes++, p.costSol * 0.5); // selling now would pay half
  await h.c.checkTakeProfit();
  await h.flush();
  assert.equal(quotes, 1);
  await h.c.checkTakeProfit(); // within 20s: reuses the last quote, no new Jupiter call
  await h.flush();
  assert.equal(quotes, 1);
  assert.deepEqual(h.trades.filter((t) => t.action === 'sell').map((t) => t.amount), ['100%'], 'stop loss sold the unpriced coin');
});

test('V2.9.8 /wins: biggest winning coins and the market cap we bought at; buy alert shows the MC', async () => {
  const h = harness({ cfg: { shortAlerts: true } });
  h.c.getSolPrice = () => 150;
  h.c.onSignal({ ev: h.ev('MC1'), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await h.flush();
  const p = h.c.positions.MC1;
  assert.ok(Math.abs(p.buyMc - (p.costSol / p.tokens) * 1e9 * 150) < 1e-6);
  assert.match(h.sent.find((m) => /Bought/.test(m)), /· MC \$/);
  const now = Date.now();
  h.c.tripLog = [
    { sym: '$A', pnl: 0.2, x: 3, leader: 'dilly', at: now - 3600000, buyMc: 8000 },
    { sym: '$B', pnl: 0.05, x: 1.5, leader: 'dilly', at: now, buyMc: 12000 },
    { sym: '$C', pnl: -0.04, x: 0.6, leader: 'dilly', at: now, buyMc: 40000 },
    { sym: '$D', pnl: 0.5, x: 6, leader: 'schoen', at: now, buyMc: 5000 },
  ];
  const t = h.c.winsText({ leader: 'dilly' });
  assert.match(t, /Biggest wins<\/b> from dilly \(2 of 3 coins won · total \+0\.21/);
  assert.ok(t.indexOf('$A') < t.indexOf('$B'), 'biggest first');
  assert.doesNotMatch(t, /\$D|\$C<\/b> \+/);
  assert.match(t, /winners \$12\.0K · losers \$40\.0K/i);
});

test('V2.10.1 cupsey (a farmer): only coins with 100+ holders and under $40k market cap', async () => {
  const h = harness({ cfg: { traderMinHolders: { cupsey: 100 }, traderMaxMc: { cupsey: 40000 } } });
  h.c.traderOf = (w) => (w === 'CUP' ? 'cupsey' : 'x');
  h.c.getSolPrice = () => 100;
  const holders = { A: 150, B: 40, C: 300 };
  h.c.countHolders = async (m) => holders[m];
  h.c.onSignal({ ev: h.ev('A', { wallet: 'CUP', priceSol: 2e-7 }), kind: 'ENTRY', pre: 0, post: 1, sol: 1 }); // $20k, 150 holders: yes
  h.c.onSignal({ ev: h.ev('B', { wallet: 'CUP', priceSol: 2e-7 }), kind: 'ENTRY', pre: 0, post: 1, sol: 1 }); // 40 holders: no
  h.c.onSignal({ ev: h.ev('C', { wallet: 'CUP', priceSol: 6e-7 }), kind: 'ENTRY', pre: 0, post: 1, sol: 1 }); // $60k: no
  await h.flush();
  await sleep(30);
  await h.flush();
  assert.deepEqual(h.trades.filter((t) => t.action === 'buy').map((t) => t.mint), ['A']);
  assert.ok(h.c.skips.some((x) => /only 40 holders \(under 100\)/.test(x.why)));
  assert.ok(h.c.skips.some((x) => /cupsey: market cap \$60k is over his \$40k limit/.test(x.why)));
});

test('V2.5 per-trader settings: decu buys a fixed small size; bot coins with too few holders are not bought; /quick for one trader', async () => {
  const h = harness({ cfg: { sizeMode: 'fixed', buySol: 0.1, traderBuySol: { decu: 0.05 }, traderMinHolders: { bot: 20 }, quickFromX: 1.25, quickToX: 1.75, quickPullbackPct: 7, protect: false }, bal: 100 });
  h.c.traderOf = (w) => ({ BOTW: 'bot', DECU: 'decu', DIL: 'dilly' })[w] || 'x';
  h.c.countHolders = async (m) => (m === 'LOW' ? 8 : 50);
  await h.c.refreshBalance();
  h.c.onSignal({ ev: h.ev('DC1', { wallet: 'DECU' }), kind: 'ENTRY', pre: 0, post: 1, sol: 10 });
  h.c.onSignal({ ev: h.ev('LOW', { wallet: 'BOTW' }), kind: 'ENTRY', pre: 0, post: 1, sol: 2 });
  h.c.onSignal({ ev: h.ev('OK1', { wallet: 'BOTW' }), kind: 'ENTRY', pre: 0, post: 1, sol: 2 });
  h.c.onSignal({ ev: h.ev('DL1', { wallet: 'DIL' }), kind: 'ENTRY', pre: 0, post: 1, sol: 2 });
  await h.flush();
  await sleep(20);
  await h.flush();
  const bought = Object.fromEntries(h.trades.filter((t) => t.action === 'buy').map((t) => [t.mint, t.amount]));
  assert.ok(Math.abs(bought.DC1 - 0.05) < 1e-9, 'decu: fixed 0.05 SOL');
  assert.equal(bought.LOW, undefined, 'bot coin with 8 holders: skipped');
  assert.ok(bought.OK1 > 0);
  // /quick dilly on: only dilly's coin sells at +25%
  h.c.quickFor.add('dilly');
  const pd = h.c.positions.DL1;
  const po = h.c.positions.OK1;
  h.c.coins.pricesSol = async () => ({ DL1: (pd.costSol / pd.tokens) * 1.3, OK1: (po.costSol / po.tokens) * 1.3 });
  await h.c.checkTakeProfit();
  await h.flush();
  h.c.coins.pricesSol = async () => ({ DL1: (pd.costSol / pd.tokens) * 1.2, OK1: (po.costSol / po.tokens) * 1.2 });
  await h.c.checkTakeProfit();
  await h.flush();
  const sold = h.trades.filter((t) => t.action === 'sell').map((t) => t.mint);
  assert.deepEqual(sold, ['DL1'], "quick profit only on dilly's coin");
});

test('V2.5 rug-dev experiment: sells fast (+10% then a 3% dip), never holds past its few minutes, own PnL line', async () => {
  const rugR = { miniFromX: 1.1, miniToX: 1.3, miniPullbackPct: 3, miniPct: 100, maxHoldMinutes: 5 };
  const mk = async () => {
    const h = harness({ cfg: { sizeMode: 'fixed', buySol: 0.1, devNames: ['rugdev'], rugNames: ['rugdev'], devBuySol: 0.1, leaderRules: { rugdev: rugR }, miniCook: true, miniMinSol: 0.1, protect: false }, bal: 100 });
    h.c.traderOf = (w) => (w === 'RUG' ? 'rugdev' : 'x');
    await h.c.refreshBalance();
    h.c.onSignal({ ev: h.ev('R1', { wallet: 'RUG' }), kind: 'ENTRY', pre: 0, post: 1, sol: 1, devReady: true });
    await h.flush();
    const p = h.c.positions.R1;
    let px = 0;
    h.c.coins.pricesSol = async () => ({ R1: px });
    h.at = async (x) => {
      px = (p.costSol / p.tokens) * x;
      await h.c.checkTakeProfit();
      await h.flush();
      return h.trades.filter((t) => t.action === 'sell').map((t) => t.amount);
    };
    return { h, p };
  };
  let { h } = await mk();
  assert.deepEqual(await h.at(1.15), []);
  assert.deepEqual(await h.at(1.11), ['100%'], '+15% then a 3.5% dip -> all out');
  assert.match(h.c.pnlLines().join('\n'), /🧪 Rug test: <b>\+[\d.]+ SOL<\/b> \(1 coin, 1 won\)/);
  let r = await mk();
  r.p.openedAt = Date.now() - 6 * 60000;
  assert.deepEqual(await r.h.at(1.02), ['100%'], 'held over 5 minutes -> sold, no holding');
});

test('V2.4 hourly PnL lines include a Devs line', async () => {
  const h = harness({ cfg: { sizeMode: 'fixed', buySol: 0.1, devNames: ['pat'] }, bal: 100 });
  h.c.traderOf = (w) => (w === 'DEV' ? 'pat' : 'x');
  await h.c.refreshBalance();
  h.c.onSignal({ ev: h.ev('DV', { wallet: 'DEV' }), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await h.flush();
  h.c.onSignal({ ev: h.ev('DV', { wallet: 'DEV' }), kind: 'EXIT', pre: 1, post: 0, sol: 1 });
  await h.flush();
  assert.match(h.c.pnlLines()[0], /^👨‍💻 Devs: <b>\+0\.\d+ SOL<\/b>$/);
});

test('copy logic: his quick exit waits for our buy to land, then sells', async () => {
  const h = harness();
  h.world.delay = 150;
  h.c.onSignal({ ev: h.ev('FAST'), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  h.c.onSignal({ ev: h.ev('FAST'), kind: 'EXIT', pre: 1, post: 0, sol: 1 });
  await h.flush();
  assert.deepEqual(h.trades.map((t) => t.action), ['buy', 'sell']);
  assert.equal(h.tokens.FAST, 0);
});

test('copy logic: skips — stale signal, paused, low SOL, position limit, daily limit, small buys', async () => {
  let h = harness();
  h.c.onSignal({ ev: h.ev('OLD1', { time: Date.now() - 120000 }), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  h.c.setPaused(true);
  h.c.onSignal({ ev: h.ev('PAUS'), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await h.flush();
  assert.equal(h.trades.length, 0);
  assert.match(h.c.lastSkip.why, /paused/);

  h = harness({ bal: 0.05 });
  await h.c.refreshBalance(); // the bot keeps this fresh in the background
  h.c.onSignal({ ev: h.ev('POOR'), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await h.flush();
  assert.equal(h.trades.length, 0);
  assert.match(h.sent[0], /SKIPPED.*not enough SOL/s);

  h = harness({ cfg: { maxOpen: 2 } });
  for (const m of ['M1', 'M2', 'M3']) h.c.onSignal({ ev: h.ev(m), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await h.flush();
  assert.equal(h.trades.length, 2);
  assert.ok(h.sent.some((x) => /SKIPPED.*COPY_MAX_OPEN_POSITIONS/s.test(x)));

  h = harness({ cfg: { dailyLimitSol: 0.15 } });
  for (const m of ['D1', 'D2', 'D3']) h.c.onSignal({ ev: h.ev(m), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await h.flush();
  assert.equal(h.trades.length, 1, '0.101 spent, the next 0.1 would pass 0.15');
  assert.ok(h.sent.some((x) => /SKIPPED.*daily limit/s.test(x)));

  h = harness({ cfg: { minHisBuySol: 0.5 } });
  h.c.onSignal({ ev: h.ev('TINY'), kind: 'ENTRY', pre: 0, post: 1, sol: 0.2 });
  await h.flush();
  assert.equal(h.trades.length, 0);
});

test('copy logic: take profit sells 25% once at 2x; mirror off still exits fully', async () => {
  const h = harness();
  h.c.onSignal({ ev: h.ev('TPC1'), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await h.flush();
  // 1000 tokens, cost 0.101 SOL. market cap in SOL with 1B supply: value = 1000 * mc / 1e9
  h.world.mc.TPC1 = 150000; // 0.15 SOL = 1.49x
  await h.c.checkTakeProfit();
  await h.flush();
  assert.equal(h.trades.length, 1);
  h.world.mc.TPC1 = 210000; // 0.21 SOL = 2.08x
  await h.c.checkTakeProfit();
  await h.flush();
  assert.deepEqual(h.trades[1], { action: 'sell', mint: 'TPC1', amount: '25%', denominatedInSol: false });
  assert.match(h.sent.at(-1), /TAKE PROFIT 2x/);
  h.world.mc.TPC1 = 400000;
  await h.c.checkTakeProfit();
  await h.flush();
  assert.equal(h.trades.length, 2, 'take profit happens once per coin');

  const g = harness({ cfg: { mirrorSells: false } });
  g.c.onSignal({ ev: g.ev('NOMI'), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  g.c.onSignal({ ev: g.ev('NOMI'), kind: 'PARTIAL', pre: 10, post: 5, sol: 1 });
  g.c.onSignal({ ev: g.ev('NOMI'), kind: 'MOVED', pre: 5, post: 2, sol: 0 });
  g.c.onSignal({ ev: g.ev('NOMI'), kind: 'MOVED', pre: 2, post: 0, sol: 0 });
  await g.flush();
  assert.deepEqual(g.trades.map((t) => t.amount), [0.1, '100%']);
});

test('copy logic: a buy that timed out but landed late is never bought twice; failed sells tell you', async () => {
  const h = harness();
  h.world.fail = { msg: 'not confirmed in 60s', expired: true, landed: true, sig: 'LATE' };
  h.c.onSignal({ ev: h.ev('LATE'), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await h.flush();
  await sleep(3200);
  await h.flush();
  assert.equal(h.trades.length, 1);
  assert.match(h.sent[0], /landed late/);
  assert.equal(h.c.positions.LATE.tokens, 1000);

  const g = harness();
  g.c.onSignal({ ev: g.ev('SFAI'), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await g.flush();
  const orig = g.c.swapper.trade;
  g.c.swapper.trade = async () => {
    throw new Error('PumpPortal 500: down');
  };
  g.c.onSignal({ ev: g.ev('SFAI'), kind: 'EXIT', pre: 1, post: 0, sol: 1 });
  await g.flush();
  g.c.swapper.trade = orig;
  assert.match(g.sent.at(-1), /COPY SELL FAILED.*\/sell SFAI 100/s);
  assert.ok(g.c.positions.SFAI, 'position kept so you can retry');
}, { timeout: 20000 });

test('copy logic: a coin Jupiter can buy but not sell -> warns right after the buy, retries the sell until it works', async () => {
  // without a Jupiter key the check is skipped (free requests are kept for trades)
  const k0 = harness({ cfg: { sellCheckDelayMs: 10 } });
  let checked = 0;
  k0.c.swapper.canSell = async () => (checked++, false);
  k0.c.onSignal({ ev: k0.ev('NOKEY'), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await k0.flush();
  await sleep(60);
  assert.equal(checked, 0);
  assert.ok(!k0.sent.some((x) => /HEADS UP/.test(x)));

  const h = harness({ cfg: { sellRetryMs: 60, sellRetryMax: 20, sellCheckDelayMs: 10, forceSellCheck: true } });
  let sellable = false;
  h.c.swapper.canSell = async () => sellable;
  h.c.onSignal({ ev: h.ev('V3C1'), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await h.flush();
  await sleep(80);
  assert.match(h.sent.at(-1), /HEADS UP.*can't sell this coin type/s);
  const orig = h.c.swapper.trade;
  let fails = 3;
  h.c.swapper.trade = async (req) => {
    if (req.action === 'sell' && fails-- > 0) throw Object.assign(new Error('Jupiter 400: No routes found'), { noRoute: true });
    return orig(req);
  };
  h.c.onSignal({ ev: h.ev('V3C1'), kind: 'EXIT', pre: 1, post: 0, sol: 1 });
  await h.flush();
  assert.match(h.sent.at(-1), /COPY SELL DELAYED.*Padre/s);
  for (let i = 0; i < 40 && h.c.positions.V3C1; i++) await sleep(25);
  await h.flush();
  assert.equal(h.c.positions.V3C1, undefined, 'sold once a route appeared');
  assert.match(h.sent.at(-1), /ALL OUT/);
  assert.equal(h.sent.filter((x) => /DELAYED/.test(x)).length, 1, 'only one delay message');
  assert.equal(h.sent.filter((x) => /FAILED/.test(x)).length, 0);

  // a newer sell signal replaces a pending retry (no double selling)
  const g = harness({ cfg: { sellRetryMs: 200, sellRetryMax: 5, sellCheckDelayMs: 1e6 } });
  g.c.onSignal({ ev: g.ev('V3C2'), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await g.flush();
  const o2 = g.c.swapper.trade;
  let f2 = 1;
  g.c.swapper.trade = async (req) => {
    if (req.action === 'sell' && f2-- > 0) throw Object.assign(new Error('No routes found'), { noRoute: true });
    return o2(req);
  };
  g.c.onSignal({ ev: g.ev('V3C2'), kind: 'PARTIAL', pre: 10, post: 6, sol: 1 }); // 40%, fails -> retry pending
  await g.flush();
  g.c.onSignal({ ev: g.ev('V3C2'), kind: 'EXIT', pre: 6, post: 0, sol: 1 }); // he's out before the retry
  await g.flush();
  await sleep(300);
  await g.flush();
  assert.deepEqual(g.trades.filter((t) => t.action === 'sell').map((t) => t.amount), ['100%'], 'the stale 40% retry never ran after he exited');
  assert.equal(g.c.positions.V3C2, undefined);
});

test('speed: the buy is built while his entry is being confirmed, sent with no extra wait; adds drop it', async () => {
  const h = harness();
  const builds = [];
  let usedPrebuilt = 0;
  h.c.swapper.build = async (req) => {
    builds.push(req.mint);
    await sleep(40); // Jupiter quote + swap
    return new Uint8Array([1, 2, 3]);
  };
  const origTrade = h.c.swapper.trade;
  h.c.swapper.trade = async (req, prebuilt) => {
    if (prebuilt) usedPrebuilt++;
    return origTrade(req);
  };
  // entry: maybe-entry fires first (build starts), then the check says ENTRY
  h.c.onMaybeEntry(h.ev('PRE1'));
  await sleep(10);
  h.c.onSignal({ ev: h.ev('PRE1'), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await h.flush();
  assert.equal(usedPrebuilt, 1, 'sent the transaction that was built in advance');
  assert.deepEqual(builds, ['PRE1']);
  // add: built in advance but never sent
  h.c.onMaybeEntry(h.ev('PRE2'));
  h.c.onSignal({ ev: h.ev('PRE2'), kind: 'ADD', pre: 5, post: 6, sol: 1 });
  await h.flush();
  await sleep(60);
  assert.equal(h.trades.filter((t) => t.mint === 'PRE2').length, 0);
  assert.equal(h.c.prebuilt.has('PRE2'), false);
  // paused: nothing is built
  h.c.setPaused(true);
  h.c.onMaybeEntry(h.ev('PRE3'));
  assert.equal(builds.includes('PRE3'), false);
});

test('sells use our saved token amount (no balance lookup); if it was out of date, the rest is swept', async () => {
  const h = harness();
  h.c.onSignal({ ev: h.ev('RAW1'), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await h.flush();
  h.c.positions.RAW1.raw = '500000000'; // we think we hold 500, really 1000 (e.g. tokens arrived from elsewhere)
  h.c.onSignal({ ev: h.ev('RAW1'), kind: 'EXIT', pre: 1, post: 0, sol: 1 });
  await h.flush(); // includes the sweep (waits 2.5s, looks again, sells the rest)
  assert.deepEqual(h.trades.filter((t) => t.action === 'sell').map((t) => t.amount), ['100%', '100%'], 'saved-amount sell, then the sweep');
  assert.equal(h.sent.filter((x) => /ALL OUT/.test(x)).length, 1, 'one "all out" message');
  assert.equal(h.tokens.RAW1, 0, 'the rest was swept');
  assert.equal(h.c.positions.RAW1, undefined);
  assert.match(h.sent.at(-1), /ALL OUT/);
}, { timeout: 15000 });

test('sending: goes to the RPC and Jito at once; if the RPC refuses, Jito alone is enough', async () => {
  const { Swapper } = await import('../src/copytrade.js');
  const k = newKey();
  const kp = loadKeypair(k.b58);
  const realFetch = globalThis.fetch;
  const jito = [];
  globalThis.fetch = async (url, init) => {
    jito.push({ url: String(url), body: JSON.parse(init.body), at: Date.now() });
    return new Response(JSON.stringify({ jsonrpc: '2.0', id: 1, result: 'ok' }), { status: 200 });
  };
  try {
    let landed = false;
    const rpcCalls = [];
    const rpc = {
      call: async (m, params) => {
        rpcCalls.push({ m, at: Date.now() });
        if (m === 'sendTransaction') throw Object.assign(new Error('rate limited'), { status: 429 });
        if (m === 'getSignatureStatuses') return { value: [landed ? { confirmationStatus: 'confirmed', err: null } : null] };
        return null;
      },
    };
    const sw = new Swapper({ rpc, kp, jitoUrls: ['https://jito.test/a', 'https://jito.test/b'], jupBase: 'x', portalBase: '', slippage: 25, priorityFee: 0 });
    setTimeout(() => (landed = true), 300);
    const r = await sw.send(unsignedTx(k.pub));
    assert.ok(r.sig);
    assert.ok(jito.length >= 2, 'both Jito relays got it');
    assert.equal(jito[0].body.method, 'sendTransaction');
    assert.ok(verifyTxSignature(Buffer.from(jito[0].body.params[0], 'base64'), k.pub));
    const firstRpc = rpcCalls.find((c) => c.m === 'sendTransaction').at;
    assert.ok(Math.abs(jito[0].at - firstRpc) < 50, 'sent in parallel, not one after the other');
    // and with no Jito, an RPC refusal is still an error
    const sw2 = new Swapper({ rpc, kp, jitoUrls: [], jupBase: 'x', portalBase: '', slippage: 25, priorityFee: 0 });
    await assert.rejects(sw2.send(unsignedTx(k.pub)), /rate limited/);
  } finally {
    globalThis.fetch = realFetch;
  }
});

const SCALE = { oneBuyPerCoin: false, sizeMode: 'scale', scaleAt1: 0.5, maxBuySol: 1, scaleMaxAt: 1000, maxWalletPct: 20, maxPerCoinSol: 2, minBuySol: 0.01, copyAdds: true, quickTpX: 1.5, quickTpPercent: 35, quickTpHisMinSol: 1 };

test('sizing: scales with his buy (1 -> 0.5, 1000 -> 1), never more than 20% of the wallet or 2 SOL per coin', async () => {
  const h = harness({ cfg: SCALE, bal: 100 });
  await h.c.refreshBalance();
  const sz = (x) => h.c.sizeFor(x, 'NEW');
  assert.equal(sz(0.2), 0.1);
  assert.equal(sz(1), 0.5);
  assert.ok(Math.abs(sz(10) - 0.6666) < 0.001, String(sz(10)));
  assert.ok(Math.abs(sz(100) - 0.8333) < 0.001, String(sz(100)));
  assert.equal(sz(1000), 1);
  assert.equal(sz(50000), 1, 'never more than COPY_MAX_BUY_SOL');
  assert.equal(sz(0), 0.5, 'his size unknown -> as if 1 SOL');
  assert.equal(sz(0.005), null, 'too small to bother');
  // small wallet: 20% cap
  const g = harness({ cfg: SCALE, bal: 1 });
  await g.c.refreshBalance();
  assert.equal(g.c.sizeFor(1000, 'X'), 0.2);
  // per-coin cap: 1.9 SOL already in -> only 0.1 more
  h.c.positions.FULL = { tokens: 5, costSol: 1.9 };
  assert.equal(h.c.sizeFor(1000, 'FULL'), 0.1);
  h.c.positions.FULL.costSol = 2;
  assert.equal(h.c.sizeFor(1000, 'FULL'), null);
});

test('re-entries and adds are copied (scaled), quick bursts become one buy, the per-coin cap holds', async () => {
  const h = harness({ cfg: SCALE, bal: 100 });
  await h.c.refreshBalance();
  h.c.onSignal({ ev: h.ev('ADD1'), kind: 'ENTRY', pre: 0, post: 1, sol: 10 });
  await h.flush();
  assert.ok(Math.abs(h.trades[0].amount - 0.6666) < 0.001);
  // he adds 3 times quickly while we're busy -> one combined add
  h.world.delay = 50;
  h.c.onSignal({ ev: h.ev('ADD1'), kind: 'ADD', pre: 1, post: 2, sol: 1 });
  h.c.onSignal({ ev: h.ev('ADD1'), kind: 'ADD', pre: 2, post: 3, sol: 1 });
  h.c.onSignal({ ev: h.ev('ADD1'), kind: 'ADD', pre: 3, post: 4, sol: 1 });
  await h.flush();
  await sleep(120);
  await h.flush();
  const buys = h.trades.filter((t) => t.action === 'buy');
  assert.ok(buys.length <= 3, `bursts merged (${buys.length} buys)`);
  const p = h.c.positions.ADD1;
  assert.ok(p.costSol <= 2.0001, `per-coin cap ${p.costSol}`);
  assert.ok(p.buys >= 2);
  assert.match(h.sent.join('\n'), /COPY ADD/);
  // he sells out, then buys back in -> we buy again
  h.c.onSignal({ ev: h.ev('ADD1'), kind: 'EXIT', pre: 4, post: 0, sol: 3 });
  await h.flush();
  assert.equal(h.c.positions.ADD1, undefined);
  const before = h.trades.length;
  h.c.onSignal({ ev: h.ev('ADD1'), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await h.flush();
  assert.equal(h.trades.length, before + 1);
  assert.equal(h.trades.at(-1).amount, 0.5);
  assert.match(h.sent.at(-1), /COPY BUY/);
});

test("adds into his old bags (coins we never bought with him) are never copied", async () => {
  const h = harness({ cfg: SCALE, bal: 100 });
  await h.c.refreshBalance();
  h.c.onSignal({ ev: h.ev('OLD1'), kind: 'ADD', pre: 50, post: 80, sol: 20 });
  await h.flush();
  assert.equal(h.trades.length, 0, 'no buy into a coin he already held');
  assert.equal(h.c.positions.OLD1, undefined);
  // a coin we skipped (paused) stays skipped when he adds later
  h.c.setPaused(true);
  h.c.onSignal({ ev: h.ev('SKP1'), kind: 'ENTRY', pre: 0, post: 1, sol: 2 });
  h.c.setPaused(false);
  h.c.onSignal({ ev: h.ev('SKP1'), kind: 'ADD', pre: 1, post: 2, sol: 2 });
  await h.flush();
  assert.equal(h.trades.length, 0);
  // a new entry of his is still bought, and then his adds to it are too
  h.c.onSignal({ ev: h.ev('NEW1'), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await h.flush();
  h.c.onSignal({ ev: h.ev('NEW1'), kind: 'ADD', pre: 1, post: 2, sol: 1 });
  await h.flush();
  assert.equal(h.trades.filter((t) => t.action === 'buy').length, 2);
});

test('quick profit: big buys of his (> 1 SOL) sell 35% at 1.5x and keep the rest; small ones wait for 2x', async () => {
  const h = harness({ cfg: { ...SCALE, tpX: 2, tpPercent: 25 }, bal: 100 });
  await h.c.refreshBalance();
  h.c.onSignal({ ev: h.ev('BIG1'), kind: 'ENTRY', pre: 0, post: 1, sol: 5 }); // big
  h.c.onSignal({ ev: h.ev('SML1'), kind: 'ENTRY', pre: 0, post: 1, sol: 0.5 }); // small
  await h.flush();
  const costBig = h.c.positions.BIG1.costSol;
  const costSml = h.c.positions.SML1.costSol;
  // both at 1.6x (value for 1000 tokens with market_cap in SOL over a 1B supply)
  h.world.mc.BIG1 = (costBig * 1.6 * 1e9) / 1000;
  h.world.mc.SML1 = (costSml * 1.6 * 1e9) / 1000;
  await h.c.checkTakeProfit();
  await h.flush();
  const sells = () => h.trades.filter((t) => t.action === 'sell').map((t) => `${t.mint}:${t.amount}`);
  assert.deepEqual(sells(), ['BIG1:35%']);
  assert.ok(h.c.positions.BIG1.tokens > 0, 'kept the rest');
  assert.match(h.sent.at(-1), /QUICK PROFIT 1\.5x — SOLD 35%/);
  await h.c.checkTakeProfit();
  await h.flush();
  assert.deepEqual(sells(), ['BIG1:35%'], 'quick profit only once');
  // later 2x (measured on what the remaining tokens cost) -> normal take profit, still not a full sell
  h.world.mc.BIG1 = (costBig * 2.1 * 1e9) / 1000;
  h.world.mc.SML1 = (costSml * 2.1 * 1e9) / 1000;
  await h.c.checkTakeProfit();
  await h.flush();
  assert.deepEqual(sells().sort(), ['BIG1:25%', 'BIG1:35%', 'SML1:25%']);
  assert.ok(h.c.positions.BIG1.tokens > 0 && h.c.positions.SML1.tokens > 0, 'take-profit never sells out');
});

// ---------- the real bot process ----------
test('full bot: copies his entry with a real signed transaction, mirrors sells, takes profit, exits', { skip: !WS_LIB, timeout: 180000 }, async () => {
  const w = await startWorld(WS_LIB);
  const k = newKey();
  const A = 'CopyAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAApump';
  const B = 'CopyBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBpump';
  const C = 'CopyCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCpump';
  const portalReqs = [];
  const chain = { sol: 3, tokens: {}, txs: {}, badSigs: 0 };
  const pending = new Map(); // tx bytes key -> request
  try {
    for (const [m, n, s] of [[A, 'Big Booty Coin', 'BBC'], [B, 'Old News', 'OLD'], [C, 'Cum Processing Unit', 'CPU']]) {
      w.M.coins[m] = { mint: m, name: n, symbol: s, usd_market_cap: 50000, market_cap: 300, total_supply: 1e15, complete: false, program: 'pump', created_timestamp: Date.now() - 3600e3 };
    }
    w.M.ownerBalances = { [k.pub]: chain.tokens };
    const SOLM = 'So11111111111111111111111111111111111111112';
    const jupReqs = [];
    w.M.jup = async (path, q, body) => {
      if (path === '/quote') {
        jupReqs.push({ type: 'quote', ...q });
        if (q.inputMint === C || q.outputMint === C) return { status: 400, body: { error: 'COULD_NOT_FIND_ANY_ROUTE', errorCode: 'COULD_NOT_FIND_ANY_ROUTE' } };
        // a sell quote (coin -> SOL) pays like the coin really is up (the take-profit double-check)
        return { body: { inputMint: q.inputMint, outputMint: q.outputMint, inAmount: q.amount, outAmount: q.outputMint === SOLM ? '1000000000' : '123', slippageBps: +q.slippageBps } };
      }
      if (path === '/swap') {
        jupReqs.push({ type: 'swap', user: body.userPublicKey, fee: body.prioritizationFeeLamports });
        const qr = body.quoteResponse;
        const tx = unsignedTx(body.userPublicKey);
        const req = qr.inputMint === SOLM ? { action: 'buy', mint: qr.outputMint, sol: +qr.inAmount / 1e9 } : { action: 'sell', mint: qr.inputMint, raw: BigInt(qr.inAmount) };
        portalReqs.push({ via: 'jup', ...req, amount: req.action === 'buy' ? req.sol : String(req.raw) });
        pending.set(Buffer.from(tx.subarray(65)).toString('hex'), req);
        return { body: { swapTransaction: Buffer.from(tx).toString('base64'), lastValidBlockHeight: 1 } };
      }
      return { status: 404, body: {} };
    };
    w.M.portal = async (req) => {
      portalReqs.push({ via: 'portal', ...req });
      if (req.publicKey !== k.pub) return { status: 400, text: 'bad key' };
      const tx = unsignedTx(k.pub);
      pending.set(Buffer.from(tx.subarray(65)).toString('hex'), req.action === 'buy' ? { action: 'buy', mint: req.mint, sol: req.amount } : { action: 'sell', mint: req.mint, pct: parseFloat(req.amount) });
      return { bytes: tx };
    };
    w.M.rpcHook = (r) => {
      if (r.method === 'getBalance' && r.params[0] === k.pub) return { context: { slot: 1 }, value: Math.round(chain.sol * 1e9) };
      if (r.method === 'sendTransaction') {
        const bytes = Buffer.from(r.params[0], 'base64');
        if (!verifyTxSignature(bytes, k.pub)) {
          chain.badSigs++;
          return 'bad';
        }
        const sig = b58encode(bytes.subarray(1, 65));
        if (chain.txs[sig]) return sig; // rebroadcast
        const req = pending.get(Buffer.from(bytes.subarray(65)).toString('hex'));
        const preSol = chain.sol;
        const preTok = chain.tokens[req.mint] || 0;
        if (req.action === 'buy') {
          chain.sol -= req.sol + 0.001;
          chain.tokens[req.mint] = preTok + 1_000_000;
        } else {
          const sold = req.raw != null ? Number(req.raw) / 1e6 : preTok * (req.pct / 100);
          chain.tokens[req.mint] = preTok - sold;
          chain.sol += sold * 0.0000004;
        }
        const tb = (ui) => [{ accountIndex: 2, mint: req.mint, owner: k.pub, uiTokenAmount: { amount: String(Math.round(ui * 1e6)), uiAmountString: String(ui), decimals: 6 } }];
        chain.txs[sig] = {
          slot: 5,
          meta: { err: null, fee: 5000, preBalances: [Math.round(preSol * 1e9)], postBalances: [Math.round(chain.sol * 1e9)], preTokenBalances: preTok ? tb(preTok) : [], postTokenBalances: tb(chain.tokens[req.mint]) },
        };
        return sig;
      }
      if (r.method === 'getSignatureStatuses') return { value: r.params[0].map((s) => (chain.txs[s] ? { confirmationStatus: 'confirmed', err: null } : null)) };
      if (r.method === 'getTransaction' && chain.txs[r.params[0]]) return chain.txs[r.params[0]];
      return undefined;
    };
    w.startBot({ COPY_TRADE: 'on', COPY_PRIVATE_KEY: k.b58, COPY_BUY_SOL: '0.25', COPY_SIZE_MODE: 'fixed', COPY_ADDS: 'off', COPY_QUICK_TP_X: '0', COPY_TP_CHECK_SECONDS: '3', COPY_TP_LADDER: 'off', COPY_MINI_COOK: 'off', JUPITER_API_KEY: 'test-key', JUPITER_RPS: '1000' }); // key = no free-tier pacing
    await w.waitFor('copy live', () => /Copy trading LIVE with wallet/.test(w.out));
    await w.waitFor('feeds live', () => /trades feed live/.test(w.out));
    w.tgPush('/start');
    await w.waitFor('registered', () => w.sent(/You're set/).length);
    assert.match(w.sent(/You're set/)[0].text, /Copy trading is LIVE/);

    // 1) he enters BBC -> we buy 0.25 SOL with a transaction signed by our key
    w.addTrade({ tx: 'H1', isBuy: true, mint: A, baseAmount: 5_000_000, amountSol: 4, amountUsd: 400 });
    await w.waitFor('copy buy', () => w.sent(/COPY BUY<\/b> <b>\$BBC/).length);
    assert.deepEqual(portalReqs[0], { via: 'jup', action: 'buy', mint: A, sol: 0.25, amount: 0.25 });
    assert.equal(jupReqs[0].amount, '250000000');
    assert.equal(jupReqs[0].slippageBps, '1000');
    assert.equal(jupReqs[1].user, k.pub);
    assert.deepEqual(jupReqs[1].fee, { priorityLevelWithMaxLamports: { maxLamports: 500000, priorityLevel: 'high' } }, 'low fee mode by default');
    assert.equal(chain.badSigs, 0);
    assert.match(w.sent(/COPY BUY/)[0].text, /^🤖 <b>COPY BUY<\/b> <b>\$BBC<\/b> — spent <b>0\.251 SOL<\/b>$/);
    assert.doesNotMatch(w.sent(/COPY BUY/)[0].text, /\n/, 'one line');
    await w.waitFor('entry alert too', () => w.sent(/NEW ENTRY.*\$BBC/).length);

    // 2) he sells 40% -> we sell 40%
    w.M.balances[A] = 3_000_000;
    w.addTrade({ tx: 'H2', isBuy: false, mint: A, baseAmount: 2_000_000, amountSol: 2, amountUsd: 200 });
    await w.waitFor('mirror sell', () => w.sent(/COPY SELL 40%/).length);
    assert.equal(portalReqs[1].amount, '400000000000', '40% of our 1M tokens in raw units');
    assert.equal(chain.tokens[A], 600_000);

    // 3) price runs: our 600K tokens at mc 900 SOL / 1B = 0.54 SOL vs 0.251 cost = 2.15x -> TP 25%
    w.M.coins[A].market_cap = 900;
    await w.waitFor('take profit', () => w.sent(/TAKE PROFIT 2x — SOLD 25%/).length, 15000);
    assert.match(w.sent(/TAKE PROFIT 2x — SOLD 25%/)[0].text, /^🏦 <b>MAIN WALLET COOK<\/b> · /, 'main wallet cooks say so');
    assert.equal(portalReqs[2].amount, '150000000000', '25% of 600K');

    // 4) /copy shows the open position
    w.tgPush('/copy');
    await w.waitFor('/copy', () => w.sent(/Copy trading: 🟢 LIVE/).length);
    assert.doesNotMatch(w.sent(/Copy trading: 🟢 LIVE/)[0].text, new RegExp(k.pub), 'no wallet address');
    assert.match(w.sent(/Copy trading: 🟢 LIVE/)[0].text, /\$BBC.*took out [\d.]+ \([\d.]+x\)/s);
    assert.match(w.sent(/Copy trading: 🟢 LIVE/)[0].text, /Last buy: <b>0\.25\d* SOL<\/b> on \$BBC/);

    // 5) he's fully out -> we sell everything
    w.M.balances[A] = 0;
    w.addTrade({ tx: 'H3', isBuy: false, mint: A, baseAmount: 3_000_000, amountSol: 3, amountUsd: 300 });
    await w.waitFor('exit', () => w.sent(/ALL OUT<\/b> <b>\$BBC/).length);
    assert.equal(portalReqs[3].amount, '450000000000', 'everything left');
    assert.equal(chain.tokens[A], 0);
    assert.match(w.sent(/ALL OUT/)[0].text, /Trip: in 0\.251/);

    // 6) an old buy of his (e.g. caught up after a restart) is not copied
    w.addTrade({ tx: 'H4', isBuy: true, mint: B, baseAmount: 1000, amountSol: 1, amountUsd: 100, timestamp: iso(Date.now() - 90000) });
    await w.waitFor('old entry alerted', () => w.sent(/NEW ENTRY.*\$OLD/).length);
    await sleep(1500);
    assert.equal(w.sent(/COPY BUY.*\$OLD/s).length, 0);

    // 7) /pause stops new buys, /resume starts again
    const D = 'CopyDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDpump';
    w.M.coins[D] = { ...w.M.coins[C], mint: D, name: 'Dunk Dunk', symbol: 'DDD' };
    w.tgPush('/pause');
    await w.waitFor('paused', () => w.sent(/Copy trading paused/).length);
    w.addTrade({ tx: 'H5', isBuy: true, mint: D, baseAmount: 1000, amountSol: 1, amountUsd: 100 });
    await w.waitFor('entry alert', () => w.sent(/NEW ENTRY.*\$DDD/).length);
    await sleep(1500);
    assert.equal(portalReqs.length, 4, 'no buy while paused');
    w.tgPush('/resume');
    await w.waitFor('resumed', () => w.sent(/live again/).length);

    // 7b) a coin Jupiter can't route yet -> built by PumpPortal instead
    w.addTrade({ tx: 'H6', isBuy: true, mint: C, baseAmount: 1000, amountSol: 1, amountUsd: 100, timestamp: iso(Date.now()) });
    await w.waitFor('portal fallback buy', () => w.sent(/COPY BUY<\/b> <b>\$CPU/).length, 15000);
    const fb = portalReqs.at(-1);
    assert.equal(fb.via, 'portal');
    assert.equal(fb.amount, 0.25);
    assert.equal(fb.denominatedInSol, 'true');
    w.M.balances[C] = 0;
    w.addTrade({ tx: 'H7', isBuy: false, mint: C, baseAmount: 1000, amountSol: 1, amountUsd: 100 });
    await w.waitFor('portal fallback sell', () => w.sent(/ALL OUT<\/b> <b>\$CPU/).length, 15000);
    assert.equal(portalReqs.at(-1).amount, '100%');

    // 8) manual /sell of something we don't hold
    w.tgPush(`/sell ${B}`);
    await w.waitFor('nothing to sell', () => w.sent(/doesn't hold that coin/).length);
    // 9) fast path: his pump.fun buy arrives on the live log stream -> we buy without waiting for the transaction
    const { b58encode: enc, b58decode: dec } = await import('../src/solana.js');
    const E = enc(crypto.randomBytes(32));
    w.M.coins[E] = { mint: E, name: 'Extra Thick Hoe', symbol: 'ETH', usd_market_cap: 9000, market_cap: 60, total_supply: 1e15, complete: false, program: 'pump', created_timestamp: Date.now() - 60e3 };
    w.M.balances[E] = 172_778_031.109208; // what his wallet shows right after the buy
    const evb = Buffer.alloc(401);
    Buffer.from([189, 219, 127, 211, 78, 230, 97, 238]).copy(evb, 0);
    Buffer.from(dec(E)).copy(evb, 8);
    evb.writeBigUInt64LE(2_500_000_000n, 40);
    evb.writeBigUInt64LE(172_778_031_109_208n, 48);
    evb[56] = 1;
    Buffer.from(dec(W)).copy(evb, 57);
    evb.writeBigUInt64LE(30_000_000_000n, 97); // curve reserves -> his price (for the ghost wallets)
    evb.writeBigUInt64LE(1_000_000_000_000_000n, 105);
    const fastSig = 'FastSig' + '1'.repeat(80);
    const n0 = portalReqs.length;
    const t0 = Date.now();
    w.notifyLogs(fastSig, 999, [
      'Program 6Vo3245eszAb5wuqEMw8mGdbfRUdKbHhDHP5LcaGuTAB invoke [1]',
      'Program 6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P invoke [2]',
      'Program log: Instruction: Buy',
      `Program data: ${evb.toString('base64')}`,
      'Program 6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P success',
      'Program 6Vo3245eszAb5wuqEMw8mGdbfRUdKbHhDHP5LcaGuTAB success',
    ]);
    await w.waitFor('fast copy buy', () => w.sent(/COPY BUY<\/b> <b>\$ETH/).length, 10000);
    const took = Date.now() - t0;
    assert.equal(portalReqs[n0].mint, E);
    assert.ok(!w.M.rpcCalls.some((r) => r.method === 'getTransaction' && r.params[0] === fastSig), 'no transaction download needed');
    assert.match(w.sent(/COPY BUY<\/b> <b>\$ETH/)[0].text, /— spent <b>[\d.]+ SOL<\/b>/);
    await w.waitFor('fast entry alert', () => w.sent(/NEW ENTRY.*\$ETH/).length);
    assert.match(w.sent(/NEW ENTRY.*\$ETH/)[0].text, /Bought <b>2\.50 SOL/);
    assert.ok(took < 3000, `fast path took ${took}ms`);
    // ...and his sell arrives the same fast way -> we mirror it without downloading his transaction
    const evs = Buffer.from(evb);
    evs.writeBigUInt64LE(69_111_212_443_683n, 48); // 40% of his bag
    evs[56] = 0;
    const fastSellSig = 'FastSell' + '1'.repeat(79);
    const ns = portalReqs.length;
    const ts0 = Date.now();
    w.notifyLogs(fastSellSig, 1000, [
      'Program 6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P invoke [1]',
      'Program log: Instruction: Sell',
      `Program data: ${evs.toString('base64')}`,
      'Program 6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P success',
    ]);
    await w.waitFor('fast copy sell', () => w.sent(/COPY SELL 40%<\/b> <b>\$ETH/).length, 10000);
    assert.ok(Date.now() - ts0 < 3000, `fast sell took ${Date.now() - ts0}ms`);
    assert.equal(portalReqs[ns].action, 'sell');
    assert.ok(!w.M.rpcCalls.some((r) => r.method === 'getTransaction' && r.params[0] === fastSellSig));
    await w.waitFor('his sell alert', () => w.sent(/SOLD 40%.*\$ETH/).length);
    // V2.9.9 his buy also opened his two ghost wallets
    w.tgPush('/ghosts');
    await w.waitFor('/ghosts', () => w.sent(/Ghost wallets/).length, 15000);
    assert.match(String(w.sent(/Ghost wallets/).at(-1).text), /<b>slingoor<\/b>: set [+-][\d.]+ · main [+-][\d.]+ \(\d+\/\d+\)( \+\d+ open [+-][\d.]+)? · 3 sides [+-][\d.]+ \(\d+\/\d+\)/);

    // the same buy showing up later on pump.fun's feed is not bought or alerted again
    w.addTrade({ tx: fastSig, isBuy: true, mint: E, baseAmount: 172778031, amountSol: 2.5, amountUsd: 400 });
    await sleep(2500);
    assert.equal(w.sent(/NEW ENTRY.*\$ETH/).length, 1);
    assert.equal(portalReqs.filter((r) => r.mint === E && r.action === 'buy').length, 1);

    // every trade was also sent to Jito's relay, with the same signed bytes
    assert.ok((w.M.jitoSends || []).length >= portalReqs.length - 1, `jito sends ${(w.M.jitoSends || []).length}`);
    assert.ok(w.M.jitoSends.every((x) => verifyTxSignature(Buffer.from(x.tx, 'base64'), k.pub)));

    assert.equal(chain.badSigs, 0);
    assert.doesNotMatch(w.out, new RegExp(k.b58), 'private key must never be logged');
  } finally {
    if (process.env.DEBUG_OUT) console.log('BOT OUTPUT >>>\n' + w.out.slice(-4000) + '\nSTEPS sent: ' + w.TG.sent.map((x) => x.text.split('\n')[0]).join(' | '));
    await w.close();
  }
});

test('Jupiter client: waits out the free-tier rate limit, reports a failed test run, falls back to PumpPortal', async () => {
  const { Swapper } = await import('../src/copytrade.js');
  const k = newKey();
  const kp = loadKeypair(k.b58);
  const realFetch = globalThis.fetch;
  const calls = [];
  let mode = 'ratelimit';
  globalThis.fetch = async (url, init = {}) => {
    calls.push({ url: String(url), t: Date.now() });
    const u = String(url);
    if (u.includes('/quote')) {
      if (mode === 'ratelimit' && calls.filter((c) => c.url.includes('/quote')).length === 1)
        return new Response('{"code":429}', { status: 429, headers: { 'x-ratelimit-reset': String(Math.ceil((Date.now() + 1200) / 1000)) } });
      if (mode === 'noroute') return new Response('{"error":"Could not find any route","errorCode":"COULD_NOT_FIND_ANY_ROUTE"}', { status: 400 });
      return new Response(JSON.stringify({ inAmount: '1', outAmount: '5' }), { status: 200 });
    }
    if (u.includes('/swap')) {
      const body = { swapTransaction: Buffer.from(unsignedTx(k.pub)).toString('base64') };
      if (mode === 'simfail') body.simulationError = { errorCode: 'TRANSACTION_ERROR', error: 'Attempt to debit an account but found no record of a prior credit.' };
      return new Response(JSON.stringify(body), { status: 200 });
    }
    if (u.includes('/trade-local')) return new Response(Buffer.from(unsignedTx(k.pub)), { status: 200 });
    throw new Error('unexpected ' + u);
  };
  try {
    const rpc = { getTokenBalance: async () => ({ ui: 10, raw: 10_000_000n }) };
    const sw = new Swapper({ rpc, kp, jupBase: 'https://jup.test', portalBase: 'https://portal.test', slippage: 25, priorityFee: 0.001 });
    const t0 = Date.now();
    const tx = await sw.build({ action: 'buy', mint: 'MintX', amount: 0.1 });
    assert.ok(tx.length > 100);
    assert.equal(sw.lastVenue, 'Jupiter');
    assert.ok(Date.now() - t0 >= 900, 'waited for the rate-limit window');
    assert.match(calls[1].url, /amount=100000000&slippageBps=2500/);

    mode = 'simfail';
    sw.portalBase = '';
    await assert.rejects(sw.build({ action: 'buy', mint: 'MintX', amount: 0.1 }), /not enough SOL/);

    mode = 'noroute';
    sw.portalBase = 'https://portal.test';
    calls.length = 0;
    await sw.build({ action: 'sell', mint: 'MintX', amount: '40%' });
    assert.equal(sw.lastVenue, 'PumpPortal');
    assert.match(calls[0].url, /amount=4000000&/, '40% of 10,000,000 raw');
    await assert.rejects(
      new Swapper({ rpc: { getTokenBalance: async () => ({ ui: 0, raw: 0n }) }, kp, jupBase: 'https://jup.test', portalBase: '', slippage: 25, priorityFee: 0 }).build({ action: 'sell', mint: 'M', amount: '100%' }),
      (e) => e.nothing === true,
    );
    // background checks never take the slots a trade needs
    const sw2 = new Swapper({ rpc: { getTokenBalance: async () => ({ ui: 1, raw: 1000000n }) }, kp, jupBase: 'https://jup.test', portalBase: '', slippage: 25, priorityFee: 0 });
    sw2.jupCalls = [Date.now(), Date.now()];
    await assert.rejects(sw2._jup('/quote?x=1', null, { background: true }), (e) => e.busy === true);
    assert.equal(await sw2.canSell('MintX'), 'busy');
    sw2.jupCalls = [];
    mode = 'ok';
    assert.equal(await sw2.canSell('MintX'), true);
  } finally {
    globalThis.fetch = realFetch;
  }
});

test('COPY_REENTRIES=on: buys when he held none before (first buy or buying back in days later), never adds to his bag', async () => {
  const h = harness({ cfg: { ...SCALE, onlyNewCoins: true, copyReentries: true }, bal: 100 });
  await h.c.refreshBalance();
  // his balance right after his buy (processed); his buy was 1000 tokens
  const his = { HELD: 51000, FRESH: 1000, BACKIN: 1000 };
  let fail = 0;
  h.c.rpc.getTokenBalance = async (owner, mint) => {
    if (owner !== 'HIS') return { ui: h.tokens[mint] || 0, raw: 0n };
    if (mint === 'FLAK' && fail++ < 5) throw new Error('rpc down');
    return { ui: his[mint] ?? 0, raw: 0n };
  };
  const ev = (mint, extra = {}) => ({ ...h.ev(mint), sig: 'cur', wallet: 'HIS', amountUi: 1000, ...extra });
  for (const m of ['HELD', 'FRESH', 'BACKIN', 'FLAK']) h.c.onSignal({ ev: ev(m), kind: 'ENTRY', pre: 0, post: 1, sol: 2 });
  await sleep(1200);
  await h.flush();
  const bought = h.trades.filter((t) => t.action === 'buy').map((t) => t.mint).sort();
  assert.deepEqual(bought, ['BACKIN', 'FRESH'], 'held a bag -> skip; RPC down -> skip; held none -> buy');
  assert.ok(h.c.stats.skipped >= 2);
  // when the balance before his buy is already known (from his transaction or the tracker), no extra lookup
  let asked = 0;
  h.c.rpc.getTokenBalance = async () => {
    asked++;
    return { ui: 0, raw: 0n };
  };
  h.c.onSignal({ ev: ev('TXKNOWN', { preUi: 0 }), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  h.c.onSignal({ ev: ev('CHECKED', { preChecked: true }), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await h.flush();
  assert.equal(asked, 0);
  assert.deepEqual(h.trades.filter((t) => t.action === 'buy').map((t) => t.mint).slice(-2).sort(), ['CHECKED', 'TXKNOWN']);
});

test('only his brand-new coins: a coin he traded before (per his token account history) is not bought', async () => {
  const h = harness({ cfg: { ...SCALE, onlyNewCoins: true, newCoinWindowMs: 600000 }, bal: 100 });
  await h.c.refreshBalance();
  const now = Math.floor(Date.now() / 1000);
  const history = {
    OLDC: [{ signature: 'cur' }, { signature: 'x', blockTime: now - 3 * 86400 }], // traded 3 days ago
    NEWC: [{ signature: 'cur', blockTime: now }, { signature: 'burst', blockTime: now - 20 }], // just a buy burst
  };
  let fail = 0;
  const base = h.c.rpc.call;
  h.c.rpc.call = async (m, p) => {
    if (m === 'getTokenAccountsByOwner') {
      if (p[1].mint === 'FLAK' && fail++ < 5) throw new Error('rpc down');
      return { value: [{ pubkey: 'acct-' + p[1].mint }] };
    }
    if (m === 'getSignaturesForAddress') return history[p[0].slice(5)] || [{ signature: 'cur' }];
    return base(m, p);
  };
  const ev = (mint) => ({ ...h.ev(mint), sig: 'cur', wallet: 'HIS' });
  for (const m of ['OLDC', 'NEWC', 'FLAK']) {
    h.c.onMaybeEntry(ev(m));
    h.c.onSignal({ ev: ev(m), kind: 'ENTRY', pre: 0, post: 1, sol: 2 });
  }
  await sleep(1500);
  await h.flush();
  const bought = h.trades.filter((t) => t.action === 'buy').map((t) => t.mint);
  assert.deepEqual(bought, ['NEWC']);
  assert.ok(h.c.stats.skipped >= 2);
  await sleep(50);
  assert.match(h.sent.join('\n'), /BOT SKIPPED<\/b> <b>\$OLD<\/b>\n❓ Why: not a new coin for him: he first traded it 3\.0d ago/);
  assert.match(h.sent.join('\n'), /BOT SKIPPED.*FLA.*\n❓ Why: couldn't confirm/s);
  // a coin we bought with him: his later re-buy (after selling out) is copied without asking the chain
  h.c.onSignal({ ev: ev('NEWC'), kind: 'EXIT', pre: 1, post: 0, sol: 1 });
  await h.flush();
  history.NEWC = [{ signature: 'old', blockTime: now - 86400 }];
  h.c.onSignal({ ev: ev('NEWC'), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await h.flush();
  assert.equal(h.trades.filter((t) => t.action === 'buy').length, 2);
});

test('take profit works without pump.fun: one DexScreener price lookup for all open positions', async () => {
  const h = harness({ cfg: { tpX: 2, tpPercent: 25 }, bal: 100 });
  await h.c.refreshBalance();
  const asked = [];
  h.c.pump.getCoin = async () => {
    throw new Error('pump.fun is not used');
  };
  h.c.coins.pricesSol = async (mints) => {
    asked.push([...mints]);
    return { DXA: 0.0003, DXB: 0.00001 }; // our 1000 tokens: 0.3 SOL (3x on 0.1) and 0.01 SOL
  };
  h.c.onSignal({ ev: h.ev('DXA'), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  h.c.onSignal({ ev: h.ev('DXB'), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await h.flush();
  await h.c.checkTakeProfit();
  await h.flush();
  assert.equal(asked.length, 1, 'one batched lookup');
  assert.deepEqual(asked[0].sort(), ['DXA', 'DXB']);
  const sells = h.trades.filter((t) => t.action === 'sell');
  assert.deepEqual(sells.map((t) => [t.mint, t.amount]), [['DXA', '25%']]);
});

test("chain-only: his big routed buy with cut-off logs (no pump.fun event, no balance notification) is still copied", { skip: !WS_LIB, timeout: 90000 }, async () => {
  const w = await startWorld(WS_LIB);
  const k = newKey();
  const SOLM = 'So11111111111111111111111111111111111111112';
  const E = b58encode(crypto.randomBytes(32));
  const chain = { sol: 1, tokens: {}, txs: {} };
  const pending = new Map();
  try {
    w.M.dexCoins = { [E]: { name: 'Routed Coin', symbol: 'RTD', mc: 20000 } };
    w.M.ownerBalances = { [k.pub]: chain.tokens };
    const lag = (ms) => new Promise((r) => setTimeout(r, ms)); // realistic network delays
    w.M.jup = async (p, q, body) => {
      await lag(150);
      if (p === '/quote') return { body: { inputMint: q.inputMint, outputMint: q.outputMint, inAmount: q.amount, outAmount: '123', slippageBps: +q.slippageBps } };
      if (p === '/swap') {
        const tx = unsignedTx(body.userPublicKey);
        pending.set(Buffer.from(tx.subarray(65)).toString('hex'), { mint: body.quoteResponse.outputMint, sol: +body.quoteResponse.inAmount / 1e9 });
        return { body: { swapTransaction: Buffer.from(tx).toString('base64'), lastValidBlockHeight: 1 } };
      }
      return { status: 404, body: {} };
    };
    const hisSig = 'Routed' + '1'.repeat(81);
    const now = Math.floor(Date.now() / 1000);
    w.M.rpcHook = async (r) => {
      if (r.method === 'getSignaturesForAddress' || (r.method === 'getTokenAccountsByOwner' && r.params[0] === W)) {
        await lag(150);
        return r.method === 'getSignaturesForAddress' ? [] : undefined;
      }
      if (r.method === 'getBalance' && r.params[0] === k.pub) return { context: { slot: 1 }, value: Math.round(chain.sol * 1e9) };
      if (r.method === 'getTransaction' && r.params[0] === hisSig) {
        return {
          slot: 777,
          blockTime: now,
          version: 1,
          transaction: { signatures: [hisSig], message: { header: { numRequiredSignatures: 1, numReadonlySignedAccounts: 0, numReadonlyUnsignedAccounts: 2 }, accountKeys: [W, 'HisAta1111111111111111111111111111111111111', SOLM], transactionConfig: {} } },
          meta: {
            err: null,
            fee: 5000,
            preBalances: [20e9, 0, 0],
            postBalances: [10e9 - 5000, 2039280, 0],
            preTokenBalances: [],
            postTokenBalances: [{ accountIndex: 1, mint: E, owner: W, programId: 'TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb', uiTokenAmount: { amount: '165757500000000', decimals: 6, uiAmount: 165757500, uiAmountString: '165757500' } }],
            logMessages: ['Program ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL invoke [1]', 'Program ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL success', 'Program 6Vo3245eszAb5wuqEMw8mGdbfRUdKbHhDHP5LcaGuTAB invoke [1]', 'Log truncated'],
          },
        };
      }
      if (r.method === 'sendTransaction') {
        const bytes = Buffer.from(r.params[0], 'base64');
        const sig = b58encode(bytes.subarray(1, 65));
        if (chain.txs[sig]) return sig;
        chain.sentAt ||= Date.now();
        const req = pending.get(Buffer.from(bytes.subarray(65)).toString('hex'));
        const pre = chain.sol;
        chain.sol -= req.sol + 0.001;
        chain.tokens[req.mint] = 1_000_000;
        chain.txs[sig] = { slot: 9, meta: { err: null, fee: 5000, preBalances: [Math.round(pre * 1e9)], postBalances: [Math.round(chain.sol * 1e9)], preTokenBalances: [], postTokenBalances: [{ accountIndex: 2, mint: req.mint, owner: k.pub, uiTokenAmount: { amount: '1000000000000', uiAmountString: '1000000', decimals: 6 } }] } };
        return sig;
      }
      if (r.method === 'getSignatureStatuses') return { value: r.params[0].map((s) => (chain.txs[s] ? { confirmationStatus: 'confirmed', err: null } : null)) };
      if (r.method === 'getTransaction' && chain.txs[r.params[0]]) return chain.txs[r.params[0]];
      return undefined;
    };
    w.startBot({ USE_PUMPFUN: 'off', COPY_TRADE: 'on', COPY_PRIVATE_KEY: k.b58, COPY_SIZE_MODE: 'fixed', COPY_BUY_SOL: '0.1', JUPITER_API_KEY: 'test-key', JUPITER_RPS: '1000', COPY_JITO: 'off' });
    await w.waitFor('copy live', () => /Copy trading LIVE with wallet/.test(w.out));
    await w.waitFor('chain subscribed', () => w.WS.subs.logsSubscribe);
    w.tgPush('/start');
    await w.waitFor('registered', () => w.sent(/You're set/).length);
    w.M.balances[E] = 165757500; // his balance right after the buy
    const t0 = Date.now();
    // only the log notification arrives: cut-off logs, no pump.fun event, and no balance notification
    w.notifyLogs(hisSig, 777, ['Program ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL invoke [1]', 'Program ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL success', 'Program 6Vo3245eszAb5wuqEMw8mGdbfRUdKbHhDHP5LcaGuTAB invoke [1]', 'Log truncated']);
    await w.waitFor('copy buy', () => w.sent(/COPY BUY<\/b> <b>\$RTD/).length, 15000);
    const took = Date.now() - t0;
    assert.ok(chain.sentAt - t0 < 500, `buy sent ${chain.sentAt - t0}ms after his trade (history check and build must overlap)`);
    assert.ok(took < 3000, `copied in ${took}ms`);
    await w.waitFor('entry alert', () => w.sent(/NEW ENTRY.*\$RTD/).length);
    assert.match(w.sent(/NEW ENTRY.*\$RTD/)[0].text, /Bought <b>10\.00 SOL/);
  } finally {
    await w.close();
  }
});

test("quiet mode: his trades go into the hourly summary; the bot entering a coin still pings right away", { skip: !WS_LIB, timeout: 90000 }, async () => {
  const w = await startWorld(WS_LIB);
  const k = newKey();
  const SOLM = 'So11111111111111111111111111111111111111112';
  const E = b58encode(crypto.randomBytes(32));
  const chain = { sol: 1, tokens: {}, txs: {} };
  const pending = new Map();
  try {
    w.M.dexCoins = { [E]: { name: 'Routed Coin', symbol: 'RTD', mc: 20000 } };
    w.M.ownerBalances = { [k.pub]: chain.tokens };
    const lag = (ms) => new Promise((r) => setTimeout(r, ms)); // realistic network delays
    w.M.jup = async (p, q, body) => {
      await lag(150);
      if (p === '/quote') return { body: { inputMint: q.inputMint, outputMint: q.outputMint, inAmount: q.amount, outAmount: '123', slippageBps: +q.slippageBps } };
      if (p === '/swap') {
        const tx = unsignedTx(body.userPublicKey);
        pending.set(Buffer.from(tx.subarray(65)).toString('hex'), { mint: body.quoteResponse.outputMint, sol: +body.quoteResponse.inAmount / 1e9 });
        return { body: { swapTransaction: Buffer.from(tx).toString('base64'), lastValidBlockHeight: 1 } };
      }
      return { status: 404, body: {} };
    };
    const hisSig = 'Routed' + '1'.repeat(81);
    const now = Math.floor(Date.now() / 1000);
    w.M.rpcHook = async (r) => {
      if (r.method === 'getSignaturesForAddress' || (r.method === 'getTokenAccountsByOwner' && r.params[0] === W)) {
        await lag(150);
        return r.method === 'getSignaturesForAddress' ? [] : undefined;
      }
      if (r.method === 'getBalance' && r.params[0] === k.pub) return { context: { slot: 1 }, value: Math.round(chain.sol * 1e9) };
      if (r.method === 'getTransaction' && r.params[0] === hisSig) {
        return {
          slot: 777,
          blockTime: now,
          version: 1,
          transaction: { signatures: [hisSig], message: { header: { numRequiredSignatures: 1, numReadonlySignedAccounts: 0, numReadonlyUnsignedAccounts: 2 }, accountKeys: [W, 'HisAta1111111111111111111111111111111111111', SOLM], transactionConfig: {} } },
          meta: {
            err: null,
            fee: 5000,
            preBalances: [20e9, 0, 0],
            postBalances: [10e9 - 5000, 2039280, 0],
            preTokenBalances: [],
            postTokenBalances: [{ accountIndex: 1, mint: E, owner: W, programId: 'TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb', uiTokenAmount: { amount: '165757500000000', decimals: 6, uiAmount: 165757500, uiAmountString: '165757500' } }],
            logMessages: ['Program ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL invoke [1]', 'Program ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL success', 'Program 6Vo3245eszAb5wuqEMw8mGdbfRUdKbHhDHP5LcaGuTAB invoke [1]', 'Log truncated'],
          },
        };
      }
      if (r.method === 'sendTransaction') {
        const bytes = Buffer.from(r.params[0], 'base64');
        const sig = b58encode(bytes.subarray(1, 65));
        if (chain.txs[sig]) return sig;
        chain.sentAt ||= Date.now();
        const req = pending.get(Buffer.from(bytes.subarray(65)).toString('hex'));
        const pre = chain.sol;
        chain.sol -= req.sol + 0.001;
        chain.tokens[req.mint] = 1_000_000;
        chain.txs[sig] = { slot: 9, meta: { err: null, fee: 5000, preBalances: [Math.round(pre * 1e9)], postBalances: [Math.round(chain.sol * 1e9)], preTokenBalances: [], postTokenBalances: [{ accountIndex: 2, mint: req.mint, owner: k.pub, uiTokenAmount: { amount: '1000000000000', uiAmountString: '1000000', decimals: 6 } }] } };
        return sig;
      }
      if (r.method === 'getSignatureStatuses') return { value: r.params[0].map((s) => (chain.txs[s] ? { confirmationStatus: 'confirmed', err: null } : null)) };
      if (r.method === 'getTransaction' && chain.txs[r.params[0]]) return chain.txs[r.params[0]];
      return undefined;
    };
    w.startBot({ QUIET_MODE: 'on', USE_PUMPFUN: 'off', COPY_TRADE: 'on', COPY_PRIVATE_KEY: k.b58, COPY_SIZE_MODE: 'fixed', COPY_BUY_SOL: '0.1', JUPITER_API_KEY: 'test-key', JUPITER_RPS: '1000', COPY_JITO: 'off' });
    await w.waitFor('copy live', () => /Copy trading LIVE with wallet/.test(w.out));
    await w.waitFor('chain subscribed', () => w.WS.subs.logsSubscribe);
    w.tgPush('/start');
    await w.waitFor('registered', () => w.sent(/You're set/).length);
    w.M.balances[E] = 165757500; // his balance right after the buy
    const t0 = Date.now();
    // only the log notification arrives: cut-off logs, no pump.fun event, and no balance notification
    w.notifyLogs(hisSig, 777, ['Program ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL invoke [1]', 'Program ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL success', 'Program 6Vo3245eszAb5wuqEMw8mGdbfRUdKbHhDHP5LcaGuTAB invoke [1]', 'Log truncated']);
    await w.waitFor('copy buy sent', () => chain.sentAt, 15000);
    const fs2 = await import('node:fs');
    const file = w.lastEnv.SUMMARY_FILE;
    await w.waitFor('in the summary', () => {
      try {
        const d = JSON.parse(fs2.readFileSync(file, 'utf8'));
        return Object.values(d.coins).some((c) => c.sym === '$RTD' && c.buySol > 9);
      } catch {
        return false;
      }
    }, 15000);
    await new Promise((r) => setTimeout(r, 1500));
    assert.equal(w.sent(/NEW ENTRY|Tracker online/).length, 0, 'his trade waits for the summary');
    await w.waitFor('bot entering a coin pings right away', () => w.sent(/COPY BUY<\/b> <b>\$RTD/).length);
  } finally {
    await w.close();
  }
});

test("V2.7 paper mode: the full bot copies the buy at a real quote into the paper wallet and sends NOTHING on chain", { skip: !WS_LIB, timeout: 90000 }, async () => {
  const w = await startWorld(WS_LIB);
  const k = newKey();
  const SOLM = 'So11111111111111111111111111111111111111112';
  const E = b58encode(crypto.randomBytes(32));
  const chain = { sol: 1, tokens: {}, txs: {} };
  const pending = new Map();
  try {
    w.M.dexCoins = { [E]: { name: 'Routed Coin', symbol: 'RTD', mc: 20000 } };
    w.M.ownerBalances = { [k.pub]: chain.tokens };
    const lag = (ms) => new Promise((r) => setTimeout(r, ms)); // realistic network delays
    w.M.jup = async (p, q, body) => {
      await lag(150);
      if (p === '/quote') return { body: { inputMint: q.inputMint, outputMint: q.outputMint, inAmount: q.amount, outAmount: '123', slippageBps: +q.slippageBps } };
      if (p === '/swap') {
        const tx = unsignedTx(body.userPublicKey);
        pending.set(Buffer.from(tx.subarray(65)).toString('hex'), { mint: body.quoteResponse.outputMint, sol: +body.quoteResponse.inAmount / 1e9 });
        return { body: { swapTransaction: Buffer.from(tx).toString('base64'), lastValidBlockHeight: 1 } };
      }
      return { status: 404, body: {} };
    };
    const hisSig = 'Routed' + '1'.repeat(81);
    const now = Math.floor(Date.now() / 1000);
    w.M.rpcHook = async (r) => {
      if (r.method === 'getSignaturesForAddress' || (r.method === 'getTokenAccountsByOwner' && r.params[0] === W)) {
        await lag(150);
        return r.method === 'getSignaturesForAddress' ? [] : undefined;
      }
      if (r.method === 'getBalance' && r.params[0] === k.pub) return { context: { slot: 1 }, value: Math.round(chain.sol * 1e9) };
      if (r.method === 'getTransaction' && r.params[0] === hisSig) {
        return {
          slot: 777,
          blockTime: now,
          version: 1,
          transaction: { signatures: [hisSig], message: { header: { numRequiredSignatures: 1, numReadonlySignedAccounts: 0, numReadonlyUnsignedAccounts: 2 }, accountKeys: [W, 'HisAta1111111111111111111111111111111111111', SOLM], transactionConfig: {} } },
          meta: {
            err: null,
            fee: 5000,
            preBalances: [20e9, 0, 0],
            postBalances: [10e9 - 5000, 2039280, 0],
            preTokenBalances: [],
            postTokenBalances: [{ accountIndex: 1, mint: E, owner: W, programId: 'TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb', uiTokenAmount: { amount: '165757500000000', decimals: 6, uiAmount: 165757500, uiAmountString: '165757500' } }],
            logMessages: ['Program ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL invoke [1]', 'Program ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL success', 'Program 6Vo3245eszAb5wuqEMw8mGdbfRUdKbHhDHP5LcaGuTAB invoke [1]', 'Log truncated'],
          },
        };
      }
      if (r.method === 'sendTransaction') {
        const bytes = Buffer.from(r.params[0], 'base64');
        const sig = b58encode(bytes.subarray(1, 65));
        if (chain.txs[sig]) return sig;
        chain.sentAt ||= Date.now();
        const req = pending.get(Buffer.from(bytes.subarray(65)).toString('hex'));
        const pre = chain.sol;
        chain.sol -= req.sol + 0.001;
        chain.tokens[req.mint] = 1_000_000;
        chain.txs[sig] = { slot: 9, meta: { err: null, fee: 5000, preBalances: [Math.round(pre * 1e9)], postBalances: [Math.round(chain.sol * 1e9)], preTokenBalances: [], postTokenBalances: [{ accountIndex: 2, mint: req.mint, owner: k.pub, uiTokenAmount: { amount: '1000000000000', uiAmountString: '1000000', decimals: 6 } }] } };
        return sig;
      }
      if (r.method === 'getSignatureStatuses') return { value: r.params[0].map((s) => (chain.txs[s] ? { confirmationStatus: 'confirmed', err: null } : null)) };
      if (r.method === 'getTransaction' && chain.txs[r.params[0]]) return chain.txs[r.params[0]];
      return undefined;
    };
    const fsP = await import('node:fs');
    fsP.writeFileSync(path.join(w.tmp, 'paper-mode.json'), JSON.stringify({ on: true, reset: true, layout298: true, layout2119: true, layout21110: true, layout21114: true, layout21115: true, layout21127: true, layout21128: true }));
    // an hourly summary is due right away: in paper mode it must be the PAPER summary
    const sumFile = path.join(w.tmp, 'summary-paper-test.json');
    fsP.writeFileSync(sumFile, JSON.stringify({ since: Date.now(), coins: {}, lines: [], launches: [], callouts: [], lastHour: 'earlier' }));
    w.startBot({ QUIET_MODE: 'on', SUMMARY_FILE: sumFile, PAPER_START_SOL: 'main:0.5', USE_PUMPFUN: 'off', COPY_TRADE: 'on', COPY_PRIVATE_KEY: k.b58, COPY_SIZE_MODE: 'fixed', COPY_BUY_SOL: '0.1', JUPITER_API_KEY: 'test-key', JUPITER_RPS: '1000', COPY_JITO: 'off' });
    await w.waitFor('copy live', () => /Copy trading LIVE with wallet/.test(w.out));
    await w.waitFor('chain subscribed', () => w.WS.subs.logsSubscribe);
    w.tgPush('/start');
    await w.waitFor('registered', () => w.sent(/You're set/).length);
    w.M.balances[E] = 165757500; // his balance right after the buy
    const t0 = Date.now();
    // only the log notification arrives: cut-off logs, no pump.fun event, and no balance notification
    w.notifyLogs(hisSig, 777, ['Program ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL invoke [1]', 'Program ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL success', 'Program 6Vo3245eszAb5wuqEMw8mGdbfRUdKbHhDHP5LcaGuTAB invoke [1]', 'Log truncated']);
    await w.waitFor('paper buy alert', () => w.sent(/COPY BUY<\/b> <b>\$RTD.*🧪 paper/s).length, 15000);
    assert.equal(chain.sentAt, undefined, 'paper: no transaction sent');
    const book = JSON.parse(fsP.readFileSync(path.join(w.tmp, 'paper-book.json'), 'utf8'));
    assert.ok(book.wallets.main.sol < 0.5 && book.wallets.main.sol > 0.3, 'paper SOL spent');
    assert.ok(Object.keys(book.wallets.main.tokens).length === 1, 'paper coin held');
    assert.match(w.out, /PAPER MODE: no real trades/);
    w.tgPush('/paperwallet');
    await w.waitFor('paper wallet view', () => w.sent(/Paper wallets[\s\S]*Total:/).length, 15000);
    assert.match(w.sent(/Paper wallets[\s\S]*Total:/)[0].text, /<b>main<\/b>: 0\.\d+ SOL \+ 1 coin\(s\).*Total: <b>[\d.]+ SOL<\/b> \(started 0\.500\) · PnL/s);
    // V2.8.3: the hourly summary in paper mode is the PAPER summary, never the real one
    await w.waitFor('paper summary', () => w.sent(/Paper trading summary/).length, 30000);
    const ps = String(w.sent(/Paper trading summary/)[0].text);
    assert.match(ps, /Paper PnL \(all wallets\)<\/b>: this hour/);
    assert.match(ps, /👛 Paper wallets: main <b>0\.\d+<\/b> \(-0\.\d+\) \+1 coin/);
    assert.doesNotMatch(ps, /Hourly summary|Bot wallet|My PnL/);
    assert.equal(w.sent(/Hourly summary/).length, 0);
  } finally {
    await w.close();
  }
});

test("V2.5 /wallet main off: side wallets only, the main wallet makes no buy", { skip: !WS_LIB, timeout: 90000 }, async () => {
  const w = await startWorld(WS_LIB);
  const k = newKey();
  const SOLM = 'So11111111111111111111111111111111111111112';
  const E = b58encode(crypto.randomBytes(32));
  const chain = { sol: 1, tokens: {}, txs: {} };
  const pending = new Map();
  try {
    w.M.dexCoins = { [E]: { name: 'Routed Coin', symbol: 'RTD', mc: 20000 } };
    w.M.ownerBalances = { [k.pub]: chain.tokens };
    const lag = (ms) => new Promise((r) => setTimeout(r, ms)); // realistic network delays
    w.M.jup = async (p, q, body) => {
      await lag(150);
      if (p === '/quote') return { body: { inputMint: q.inputMint, outputMint: q.outputMint, inAmount: q.amount, outAmount: '123', slippageBps: +q.slippageBps } };
      if (p === '/swap') {
        const tx = unsignedTx(body.userPublicKey);
        pending.set(Buffer.from(tx.subarray(65)).toString('hex'), { mint: body.quoteResponse.outputMint, sol: +body.quoteResponse.inAmount / 1e9 });
        return { body: { swapTransaction: Buffer.from(tx).toString('base64'), lastValidBlockHeight: 1 } };
      }
      return { status: 404, body: {} };
    };
    const hisSig = 'Routed' + '1'.repeat(81);
    const now = Math.floor(Date.now() / 1000);
    w.M.rpcHook = async (r) => {
      if (r.method === 'getSignaturesForAddress' || (r.method === 'getTokenAccountsByOwner' && r.params[0] === W)) {
        await lag(150);
        return r.method === 'getSignaturesForAddress' ? [] : undefined;
      }
      if (r.method === 'getBalance' && r.params[0] === k.pub) return { context: { slot: 1 }, value: Math.round(chain.sol * 1e9) };
      if (r.method === 'getTransaction' && r.params[0] === hisSig) {
        return {
          slot: 777,
          blockTime: now,
          version: 1,
          transaction: { signatures: [hisSig], message: { header: { numRequiredSignatures: 1, numReadonlySignedAccounts: 0, numReadonlyUnsignedAccounts: 2 }, accountKeys: [W, 'HisAta1111111111111111111111111111111111111', SOLM], transactionConfig: {} } },
          meta: {
            err: null,
            fee: 5000,
            preBalances: [20e9, 0, 0],
            postBalances: [10e9 - 5000, 2039280, 0],
            preTokenBalances: [],
            postTokenBalances: [{ accountIndex: 1, mint: E, owner: W, programId: 'TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb', uiTokenAmount: { amount: '165757500000000', decimals: 6, uiAmount: 165757500, uiAmountString: '165757500' } }],
            logMessages: ['Program ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL invoke [1]', 'Program ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL success', 'Program 6Vo3245eszAb5wuqEMw8mGdbfRUdKbHhDHP5LcaGuTAB invoke [1]', 'Log truncated'],
          },
        };
      }
      if (r.method === 'sendTransaction') {
        const bytes = Buffer.from(r.params[0], 'base64');
        const sig = b58encode(bytes.subarray(1, 65));
        if (chain.txs[sig]) return sig;
        chain.sentAt ||= Date.now();
        const req = pending.get(Buffer.from(bytes.subarray(65)).toString('hex'));
        const pre = chain.sol;
        chain.sol -= req.sol + 0.001;
        chain.tokens[req.mint] = 1_000_000;
        chain.txs[sig] = { slot: 9, meta: { err: null, fee: 5000, preBalances: [Math.round(pre * 1e9)], postBalances: [Math.round(chain.sol * 1e9)], preTokenBalances: [], postTokenBalances: [{ accountIndex: 2, mint: req.mint, owner: k.pub, uiTokenAmount: { amount: '1000000000000', uiAmountString: '1000000', decimals: 6 } }] } };
        return sig;
      }
      if (r.method === 'getSignatureStatuses') return { value: r.params[0].map((s) => (chain.txs[s] ? { confirmationStatus: 'confirmed', err: null } : null)) };
      if (r.method === 'getTransaction' && chain.txs[r.params[0]]) return chain.txs[r.params[0]];
      return undefined;
    };
    w.startBot({ QUIET_MODE: 'off', USE_PUMPFUN: 'off', COPY_TRADE: 'on', COPY_PRIVATE_KEY: k.b58, COPY_SIZE_MODE: 'fixed', COPY_BUY_SOL: '0.1', JUPITER_API_KEY: 'test-key', JUPITER_RPS: '1000', COPY_JITO: 'off' });
    await w.waitFor('copy live', () => /Copy trading LIVE with wallet/.test(w.out));
    await w.waitFor('chain subscribed', () => w.WS.subs.logsSubscribe);
    w.tgPush('/start');
    await w.waitFor('registered', () => w.sent(/You're set/).length);
    w.tgPush('/wallet main off');
    await w.waitFor('wallets reply', () => w.sent(/⏸ main/).length, 15000);
    w.M.balances[E] = 165757500; // his balance right after the buy
    const t0 = Date.now();
    // only the log notification arrives: cut-off logs, no pump.fun event, and no balance notification
    w.notifyLogs(hisSig, 777, ['Program ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL invoke [1]', 'Program ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL success', 'Program 6Vo3245eszAb5wuqEMw8mGdbfRUdKbHhDHP5LcaGuTAB invoke [1]', 'Log truncated']);
    await new Promise((r) => setTimeout(r, 5000));
    assert.equal(chain.sentAt, undefined, 'main wallet is off: no buy sent');
    assert.equal(w.sent(/COPY BUY/).length, 0);
  } finally {
    await w.close();
  }
});

test("V2.11.28 paper restarts with main 0.2 SOL + 3 side wallets 0.25 SOL each; /wins answers", { skip: !WS_LIB, timeout: 90000 }, async () => {
  const w = await startWorld(WS_LIB);
  const k = newKey();
  try {
    const fsP = await import('node:fs');
    fsP.writeFileSync(path.join(w.tmp, 'paper-mode.json'), JSON.stringify({ on: true, reset: false })); // paper already on, old amounts
    fsP.writeFileSync(path.join(w.tmp, 'paper-book.json'), JSON.stringify({ wallets: { main: { sol: 0.05, tokens: {} } }, startedAt: Date.now() - 3600000, start: { main: 0.5 } }));
    w.startBot({ QUIET_MODE: 'off', COPY_TRADE: 'on', COPY_PRIVATE_KEY: k.b58, JUPITER_API_KEY: 'test-key', COPY_JITO: 'off', USE_PUMPFUN: 'off' });
    await w.waitFor('bot up', () => w.out.includes('PAPER MODE'), 20000);
    assert.match(w.out, /Paper: main 0\.2 SOL \+ 3 side wallets 0\.25 SOL each — paper restarts now/);
    const line = /PAPER MODE: no real trades\. Balances: ([^\n]+)/.exec(w.out)?.[1] || '';
    const bal = Object.fromEntries([...line.matchAll(/(main|W\d+) ([\d.]+)/g)].map((x) => [x[1], +x[2]]));
    assert.equal(bal.main, 0.2);
    const sides = Object.keys(bal).filter((l) => l !== 'main');
    for (const l of sides) assert.equal(bal[l], 0.25);
    assert.deepEqual(sides, ['W2', 'W3', 'W4'], line);
    assert.ok(Math.abs(sides.reduce((t, l) => t + bal[l], 0) - 0.75) < 1e-9, `sides add up to 0.75: ${line}`);
    for (const l of sides) assert.ok(bal[l] >= 0.05, 'each side wallet at least 0.05');
    await w.waitFor('3 side wallets', () => (w.out.match(/Quick wallet W\d+ LIVE/g) || []).length === 3, 15000);
    await w.waitFor('chain subscribed', () => w.WS.subs.logsSubscribe);
    w.tgPush('/start');
    await w.waitFor('registered', () => w.sent(/You're set/).length);
    w.tgPush('/wins');
    await w.waitFor('/wins', () => w.sent(/No closed coins yet/).length, 15000);
    w.tgPush('/paper');
    await w.waitFor('/paper', () => w.sent(/Paper wallets[\s\S]*Total:/).length, 15000);
    assert.match(String(w.sent(/Paper wallets[\s\S]*Total:/)[0].text), /started 0\.950/);
    assert.doesNotMatch(w.out, /TypeError|ReferenceError|Unhandled/);
  } finally {
    await w.close();
  }
});

test("V2.7 hibernation: during the night window no new buys; /hibernate plans tonight 12:01am", { skip: !WS_LIB, timeout: 90000 }, async () => {
  const w = await startWorld(WS_LIB);
  const k = newKey();
  const SOLM = 'So11111111111111111111111111111111111111112';
  const E = b58encode(crypto.randomBytes(32));
  const chain = { sol: 1, tokens: {}, txs: {} };
  const pending = new Map();
  try {
    w.M.dexCoins = { [E]: { name: 'Routed Coin', symbol: 'RTD', mc: 20000 } };
    w.M.ownerBalances = { [k.pub]: chain.tokens };
    const lag = (ms) => new Promise((r) => setTimeout(r, ms)); // realistic network delays
    w.M.jup = async (p, q, body) => {
      await lag(150);
      if (p === '/quote') return { body: { inputMint: q.inputMint, outputMint: q.outputMint, inAmount: q.amount, outAmount: '123', slippageBps: +q.slippageBps } };
      if (p === '/swap') {
        const tx = unsignedTx(body.userPublicKey);
        pending.set(Buffer.from(tx.subarray(65)).toString('hex'), { mint: body.quoteResponse.outputMint, sol: +body.quoteResponse.inAmount / 1e9 });
        return { body: { swapTransaction: Buffer.from(tx).toString('base64'), lastValidBlockHeight: 1 } };
      }
      return { status: 404, body: {} };
    };
    const hisSig = 'Routed' + '1'.repeat(81);
    const now = Math.floor(Date.now() / 1000);
    w.M.rpcHook = async (r) => {
      if (r.method === 'getSignaturesForAddress' || (r.method === 'getTokenAccountsByOwner' && r.params[0] === W)) {
        await lag(150);
        return r.method === 'getSignaturesForAddress' ? [] : undefined;
      }
      if (r.method === 'getBalance' && r.params[0] === k.pub) return { context: { slot: 1 }, value: Math.round(chain.sol * 1e9) };
      if (r.method === 'getTransaction' && r.params[0] === hisSig) {
        return {
          slot: 777,
          blockTime: now,
          version: 1,
          transaction: { signatures: [hisSig], message: { header: { numRequiredSignatures: 1, numReadonlySignedAccounts: 0, numReadonlyUnsignedAccounts: 2 }, accountKeys: [W, 'HisAta1111111111111111111111111111111111111', SOLM], transactionConfig: {} } },
          meta: {
            err: null,
            fee: 5000,
            preBalances: [20e9, 0, 0],
            postBalances: [10e9 - 5000, 2039280, 0],
            preTokenBalances: [],
            postTokenBalances: [{ accountIndex: 1, mint: E, owner: W, programId: 'TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb', uiTokenAmount: { amount: '165757500000000', decimals: 6, uiAmount: 165757500, uiAmountString: '165757500' } }],
            logMessages: ['Program ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL invoke [1]', 'Program ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL success', 'Program 6Vo3245eszAb5wuqEMw8mGdbfRUdKbHhDHP5LcaGuTAB invoke [1]', 'Log truncated'],
          },
        };
      }
      if (r.method === 'sendTransaction') {
        const bytes = Buffer.from(r.params[0], 'base64');
        const sig = b58encode(bytes.subarray(1, 65));
        if (chain.txs[sig]) return sig;
        chain.sentAt ||= Date.now();
        const req = pending.get(Buffer.from(bytes.subarray(65)).toString('hex'));
        const pre = chain.sol;
        chain.sol -= req.sol + 0.001;
        chain.tokens[req.mint] = 1_000_000;
        chain.txs[sig] = { slot: 9, meta: { err: null, fee: 5000, preBalances: [Math.round(pre * 1e9)], postBalances: [Math.round(chain.sol * 1e9)], preTokenBalances: [], postTokenBalances: [{ accountIndex: 2, mint: req.mint, owner: k.pub, uiTokenAmount: { amount: '1000000000000', uiAmountString: '1000000', decimals: 6 } }] } };
        return sig;
      }
      if (r.method === 'getSignatureStatuses') return { value: r.params[0].map((s) => (chain.txs[s] ? { confirmationStatus: 'confirmed', err: null } : null)) };
      if (r.method === 'getTransaction' && chain.txs[r.params[0]]) return chain.txs[r.params[0]];
      return undefined;
    };
    const fsH = await import('node:fs');
    fsH.writeFileSync(path.join(w.tmp, 'hibernate.json'), JSON.stringify({ from: Date.now() - 1000, until: Date.now() + 120000, asleep: false }));
    // V2.8: 20 learned trades for the main trader whose coins kept running past where we sold
    fsH.writeFileSync(path.join(w.tmp, 'learn.json'), JSON.stringify({ live: {}, post: {}, done: { slingoor: Array.from({ length: 20 }, () => ({ cost: 0.1, pts: [[0, 1], [5, 1.5], [10, 1.9], [15, 2.6], [20, 3]], exitIdx: 3 })) } }));
    w.startBot({ QUIET_MODE: 'off', USE_PUMPFUN: 'off', COPY_TRADE: 'on', COPY_PRIVATE_KEY: k.b58, COPY_SIZE_MODE: 'fixed', COPY_BUY_SOL: '0.1', JUPITER_API_KEY: 'test-key', JUPITER_RPS: '1000', COPY_JITO: 'off' });
    await w.waitFor('copy live', () => /Copy trading LIVE with wallet/.test(w.out));
    await w.waitFor('chain subscribed', () => w.WS.subs.logsSubscribe);
    w.tgPush('/start');
    await w.waitFor('registered', () => w.sent(/You're set/).length);
    await w.waitFor('hibernating', () => w.sent(/Hibernating/).length, 15000);
    w.M.balances[E] = 165757500; // his balance right after the buy
    const t0 = Date.now();
    // only the log notification arrives: cut-off logs, no pump.fun event, and no balance notification
    w.notifyLogs(hisSig, 777, ['Program ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL invoke [1]', 'Program ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL success', 'Program 6Vo3245eszAb5wuqEMw8mGdbfRUdKbHhDHP5LcaGuTAB invoke [1]', 'Log truncated']);
    await new Promise((r) => setTimeout(r, 5000));
    assert.equal(chain.sentAt, undefined, 'hibernating: no buy sent');
    assert.equal(w.sent(/COPY BUY/).length, 0);
    w.tgPush('/skips');
    await w.waitFor('skips reply', () => w.sent(/Last skipped buys|No skipped buys/).length, 15000);
    w.tgPush('/skips W9');
    await w.waitFor('/skips usage', () => w.sent(/Usage: \/skips · \/skips W2/).length, 15000);
    w.tgPush('/hibernate off');
    await w.waitFor('cancel reply', () => w.sent(/Hibernation cancelled/).length, 15000);
    w.tgPush('/hibernate 9');
    await w.waitFor('hibernate reply', () => w.sent(/Hibernation set/).length, 15000);
    assert.match(w.sent(/Hibernation set/)[0].text, /12:01am and wakes at 9:00am/);
    // V2.9.9 ghost wallets
    w.tgPush('/ghosts');
    await w.waitFor('/ghosts', () => w.sent(/Ghost wallets/).length, 15000);
    w.tgPush('/ghosts today');
    await w.waitFor('/ghosts today', () => w.sent(/Ghost wallets — today/).length, 15000);
    // V2.9.12 sweet spot
    // V2.11.8 sweet spot is on from the start (Khalil); /sweetspot off|on still switch it
    w.tgPush('/sweetspot');
    await w.waitFor('/sweetspot', () => w.sent(/Sweet spot is <b>ON<\/b>: buys in a ⛔ range are skipped/).length, 15000);
    w.tgPush('/sweetspot off');
    await w.waitFor('/sweetspot off', () => w.sent(/Sweet spot is <b>OFF<\/b>/).length, 15000);
    w.tgPush('/sweetspot on');
    await w.waitFor('/sweetspot on', () => w.sent(/Sweet spot is <b>ON<\/b>: buys in a ⛔ range are skipped/).length >= 2, 15000);
    // V2.9.1 hourly goal
    w.tgPush('/goal');
    await w.waitFor('/goal', () => w.sent(/No hourly goal set/).length, 15000);
    w.tgPush('/goal 0.05');
    await w.waitFor('/goal 0.05', () => w.sent(/Hourly goal: 0\.050 SOL<\/b> \(all wallets, closed trades\)\nThis hour: \+0\.0+ SOL\nAn hour that hits it raises the next hour's goal \(never lower\); midnight goes back to 0\.050\.\n\/goal off/).length, 15000);
    w.tgPush('/goal off');
    await w.waitFor('/goal off', () => w.sent(/Hourly goal off/).length, 15000);
    w.tgPush('/suggestions');
    await w.waitFor('suggestions reply', () => w.sent(/🧠 <b>(Suggestions|No suggestions)/).length, 15000);
    const sg = w.sent(/🧠 <b>(Suggestions|No suggestions)/)[0].text;
    assert.match(sg, /<b>slingoor<\/b>: sell at <b>[\d.]+x<\/b>/, sg);
    assert.match(sg, /\/apply_slingoor/);
    assert.match(sg, /<pre>Make these learned settings/);
    w.tgPush('/apply_slingoor');
    await w.waitFor('apply reply', () => w.sent(/Applied/).length, 15000);
    assert.match(w.sent(/Applied/)[0].text, /slingoor → sell at [\d.]+x/);
    w.tgPush('/suggestions');
    await w.waitFor('in use', () => w.sent(/In use now: slingoor/).length, 15000);
    assert.doesNotMatch(w.out, /TypeError|ReferenceError|Unhandled/);
  } finally {
    await w.close();
  }
});

test("V2 quick wallets: a wallet-key-2 file starts a quick-profit wallet next to the main one; the main buy still goes out", { skip: !WS_LIB, timeout: 90000 }, async () => {
  const w = await startWorld(WS_LIB);
  const k = newKey();
  const k2 = newKey();
  const fs3 = await import('node:fs');
  const keyFile2 = path.join(w.tmp, 'wallet-key-2.txt');
  fs3.writeFileSync(keyFile2, k2.b58);
  const SOLM = 'So11111111111111111111111111111111111111112';
  const E = b58encode(crypto.randomBytes(32));
  const chain = { sol: 1, tokens: {}, txs: {} };
  const pending = new Map();
  try {
    w.M.dexCoins = { [E]: { name: 'Routed Coin', symbol: 'RTD', mc: 20000 } };
    w.M.ownerBalances = { [k.pub]: chain.tokens };
    const lag = (ms) => new Promise((r) => setTimeout(r, ms)); // realistic network delays
    w.M.jup = async (p, q, body) => {
      await lag(150);
      if (p === '/quote') return { body: { inputMint: q.inputMint, outputMint: q.outputMint, inAmount: q.amount, outAmount: '123', slippageBps: +q.slippageBps } };
      if (p === '/swap') {
        const tx = unsignedTx(body.userPublicKey);
        pending.set(Buffer.from(tx.subarray(65)).toString('hex'), { mint: body.quoteResponse.outputMint, sol: +body.quoteResponse.inAmount / 1e9 });
        return { body: { swapTransaction: Buffer.from(tx).toString('base64'), lastValidBlockHeight: 1 } };
      }
      return { status: 404, body: {} };
    };
    const hisSig = 'Routed' + '1'.repeat(81);
    const now = Math.floor(Date.now() / 1000);
    w.M.rpcHook = async (r) => {
      if (r.method === 'getSignaturesForAddress' || (r.method === 'getTokenAccountsByOwner' && r.params[0] === W)) {
        await lag(150);
        return r.method === 'getSignaturesForAddress' ? [] : undefined;
      }
      if (r.method === 'getBalance' && r.params[0] === k2.pub) return { context: { slot: 1 }, value: 1e9 };
      if (r.method === 'getBalance' && r.params[0] === k.pub) return { context: { slot: 1 }, value: Math.round(chain.sol * 1e9) };
      if (r.method === 'getTransaction' && r.params[0] === hisSig) {
        return {
          slot: 777,
          blockTime: now,
          version: 1,
          transaction: { signatures: [hisSig], message: { header: { numRequiredSignatures: 1, numReadonlySignedAccounts: 0, numReadonlyUnsignedAccounts: 2 }, accountKeys: [W, 'HisAta1111111111111111111111111111111111111', SOLM], transactionConfig: {} } },
          meta: {
            err: null,
            fee: 5000,
            preBalances: [20e9, 0, 0],
            postBalances: [10e9 - 5000, 2039280, 0],
            preTokenBalances: [],
            postTokenBalances: [{ accountIndex: 1, mint: E, owner: W, programId: 'TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb', uiTokenAmount: { amount: '165757500000000', decimals: 6, uiAmount: 165757500, uiAmountString: '165757500' } }],
            logMessages: ['Program ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL invoke [1]', 'Program ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL success', 'Program 6Vo3245eszAb5wuqEMw8mGdbfRUdKbHhDHP5LcaGuTAB invoke [1]', 'Log truncated'],
          },
        };
      }
      if (r.method === 'sendTransaction') {
        const bytes = Buffer.from(r.params[0], 'base64');
        const sig = b58encode(bytes.subarray(1, 65));
        if (chain.txs[sig]) return sig;
        chain.sentAt ||= Date.now();
        const req = pending.get(Buffer.from(bytes.subarray(65)).toString('hex'));
        const pre = chain.sol;
        chain.sol -= req.sol + 0.001;
        chain.tokens[req.mint] = 1_000_000;
        chain.txs[sig] = { slot: 9, meta: { err: null, fee: 5000, preBalances: [Math.round(pre * 1e9)], postBalances: [Math.round(chain.sol * 1e9)], preTokenBalances: [], postTokenBalances: [{ accountIndex: 2, mint: req.mint, owner: k.pub, uiTokenAmount: { amount: '1000000000000', uiAmountString: '1000000', decimals: 6 } }] } };
        return sig;
      }
      if (r.method === 'getSignatureStatuses') return { value: r.params[0].map((s) => (chain.txs[s] ? { confirmationStatus: 'confirmed', err: null } : null)) };
      if (r.method === 'getTransaction' && chain.txs[r.params[0]]) return chain.txs[r.params[0]];
      return undefined;
    };
    // a summary from an earlier hour is pending, so the first summary goes out right away
    const sumFile = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'sum-')), 'summary.json');
    fs.writeFileSync(sumFile, JSON.stringify({ since: Date.now(), coins: {}, lines: [], launches: [], callouts: [], lastHour: 'earlier' }));
    w.startBot({ WALLET_TRADERS: process.env.T_W2_ALL ? 'main:all' : 'main:all,W2:dilly', QUIET_MODE: 'on', SUMMARY_FILE: sumFile, QUICK_WALLETS: 'on', QUICK_WALLET_KEY_FILES: keyFile2, USE_PUMPFUN: 'off', COPY_TRADE: 'on', COPY_PRIVATE_KEY: k.b58, COPY_SIZE_MODE: 'fixed', COPY_BUY_SOL: '0.1', JUPITER_API_KEY: 'test-key', JUPITER_RPS: '1000', COPY_JITO: 'off' });
    await w.waitFor('copy live', () => /Copy trading LIVE with wallet/.test(w.out));
    await w.waitFor('chain subscribed', () => w.WS.subs.logsSubscribe);
    w.tgPush('/start');
    await w.waitFor('registered', () => w.sent(/You're set/).length);
    w.M.balances[E] = 165757500; // his balance right after the buy
    const t0 = Date.now();
    // only the log notification arrives: cut-off logs, no pump.fun event, and no balance notification
    w.notifyLogs(hisSig, 777, ['Program ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL invoke [1]', 'Program ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL success', 'Program 6Vo3245eszAb5wuqEMw8mGdbfRUdKbHhDHP5LcaGuTAB invoke [1]', 'Log truncated']);
    await w.waitFor('copy buy sent', () => chain.sentAt, 15000);
    await w.waitFor('quick wallet started', () => w.out.includes(`Quick wallet W2 LIVE (${k2.pub})`), 15000);
    await w.waitFor('main copy buy alert', () => w.sent(/COPY BUY<\/b> <b>\$RTD/).length, 15000);
    await w.waitFor('hourly summary with my PnL', () => w.sent(/Hourly summary/).length, 30000);
    const sum = w.sent(/Hourly summary/)[0];
    assert.match(String(sum.text ?? sum), /My PnL \(all wallets\)<\/b>: this hour <b>\+0\.0+ SOL<\/b> · today <b>\+0\.0+ SOL/);
    assert.match(String(sum.text ?? sum), /PnL this hour/);
    assert.match(String(sum.text ?? sum), /📲 <b>Side wallets<\/b>: this hour <b>[+-]0\.0+ SOL<\/b> · today <b>[+-]0\.0+ SOL<\/b> \(W2 [+-]0\.0+\)/);
    await new Promise((r) => setTimeout(r, 1500));
    // V2.9 W2 only copies dilly: it did not buy this trader's coin (only the main wallet's buy went out)
    assert.equal(Object.keys(chain.txs).length, process.env.T_W2_ALL ? 2 : 1, 'buys sent');
    w.tgPush('/wallettraders');
    await w.waitFor('/wallettraders', () => w.sent(/Who each wallet copies/).length, 15000);
    const wt = String(w.sent(/Who each wallet copies/)[0].text);
    assert.match(wt, /<b>main<\/b> copies: everyone/);
    if (!process.env.T_W2_ALL) assert.match(wt, /<b>W2<\/b> copies: dilly/);
    w.tgPush('/wallettraders W2 all');
    await w.waitFor('/wallettraders W2 all', () => w.sent(/<b>W2<\/b> copies: everyone/).length, 15000);
    const sideBuys = w.sent(/<i>W2<\/i>/).map((m) => String(m.text ?? m)).filter((t) => /Bought|COPY BUY|COPY ADD|SKIPPED|TAKING OVER/.test(t));
    assert.deepEqual(sideBuys, [], 'no buy alerts from side wallets');
    assert.doesNotMatch(w.out, /Unhandled|TypeError|ReferenceError/);
  } finally {
    await w.close();
  }
});

test("V2.9.3 wallet sets: a devs set (its own main + mini) buys the devs' coins; the dilly-only main wallet stays out", { skip: !WS_LIB, timeout: 90000 }, async () => {
  const w = await startWorld(WS_LIB);
  const k = newKey();
  const k2 = newKey();
  const fs3 = await import('node:fs');
  const k4 = newKey();
  fs3.writeFileSync(path.join(w.tmp, 'wallet-key-devs.txt'), k2.b58); // the devs set's main
  fs3.writeFileSync(path.join(w.tmp, 'wallet-key-devs-2.txt'), k4.b58); // its mini
  const payers = [];
  const SOLM = 'So11111111111111111111111111111111111111112';
  const E = b58encode(crypto.randomBytes(32));
  const chain = { sol: 1, tokens: {}, txs: {} };
  const pending = new Map();
  try {
    w.M.dexCoins = { [E]: { name: 'Routed Coin', symbol: 'RTD', mc: 20000 } };
    w.M.ownerBalances = { [k.pub]: chain.tokens };
    const lag = (ms) => new Promise((r) => setTimeout(r, ms)); // realistic network delays
    w.M.jup = async (p, q, body) => {
      await lag(150);
      if (p === '/quote') return { body: { inputMint: q.inputMint, outputMint: q.outputMint, inAmount: q.amount, outAmount: '123', slippageBps: +q.slippageBps } };
      if (p === '/swap') {
        const tx = unsignedTx(body.userPublicKey);
        pending.set(Buffer.from(tx.subarray(65)).toString('hex'), { mint: body.quoteResponse.outputMint, sol: +body.quoteResponse.inAmount / 1e9, payer: body.userPublicKey });
        return { body: { swapTransaction: Buffer.from(tx).toString('base64'), lastValidBlockHeight: 1 } };
      }
      return { status: 404, body: {} };
    };
    const hisSig = 'Routed' + '1'.repeat(81);
    const now = Math.floor(Date.now() / 1000);
    w.M.rpcHook = async (r) => {
      if (r.method === 'getSignaturesForAddress' || (r.method === 'getTokenAccountsByOwner' && r.params[0] === W)) {
        await lag(150);
        return r.method === 'getSignaturesForAddress' ? [] : undefined;
      }
      if (r.method === 'getBalance' && (r.params[0] === k2.pub || r.params[0] === k4.pub)) return { context: { slot: 1 }, value: 1e9 };
      if (r.method === 'getBalance' && r.params[0] === k.pub) return { context: { slot: 1 }, value: Math.round(chain.sol * 1e9) };
      if (r.method === 'getTransaction' && r.params[0] === hisSig) {
        return {
          slot: 777,
          blockTime: now,
          version: 1,
          transaction: { signatures: [hisSig], message: { header: { numRequiredSignatures: 1, numReadonlySignedAccounts: 0, numReadonlyUnsignedAccounts: 2 }, accountKeys: [W, 'HisAta1111111111111111111111111111111111111', SOLM], transactionConfig: {} } },
          meta: {
            err: null,
            fee: 5000,
            preBalances: [20e9, 0, 0],
            postBalances: [10e9 - 5000, 2039280, 0],
            preTokenBalances: [],
            postTokenBalances: [{ accountIndex: 1, mint: E, owner: W, programId: 'TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb', uiTokenAmount: { amount: '165757500000000', decimals: 6, uiAmount: 165757500, uiAmountString: '165757500' } }],
            logMessages: ['Program ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL invoke [1]', 'Program ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL success', 'Program 6Vo3245eszAb5wuqEMw8mGdbfRUdKbHhDHP5LcaGuTAB invoke [1]', 'Log truncated'],
          },
        };
      }
      if (r.method === 'sendTransaction') {
        const bytes = Buffer.from(r.params[0], 'base64');
        const sig = b58encode(bytes.subarray(1, 65));
        if (chain.txs[sig]) return sig;
        chain.sentAt ||= Date.now();
        const req = pending.get(Buffer.from(bytes.subarray(65)).toString('hex'));
        payers.push(req.payer);
        const pre = chain.sol;
        chain.sol -= req.sol + 0.001;
        chain.tokens[req.mint] = 1_000_000;
        chain.txs[sig] = { slot: 9, meta: { err: null, fee: 5000, preBalances: [Math.round(pre * 1e9)], postBalances: [Math.round(chain.sol * 1e9)], preTokenBalances: [], postTokenBalances: [{ accountIndex: 2, mint: req.mint, owner: k.pub, uiTokenAmount: { amount: '1000000000000', uiAmountString: '1000000', decimals: 6 } }] } };
        return sig;
      }
      if (r.method === 'getSignatureStatuses') return { value: r.params[0].map((s) => (chain.txs[s] ? { confirmationStatus: 'confirmed', err: null } : null)) };
      if (r.method === 'getTransaction' && chain.txs[r.params[0]]) return chain.txs[r.params[0]];
      return undefined;
    };
    // a summary from an earlier hour is pending, so the first summary goes out right away
    const sumFile = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'sum-')), 'summary.json');
    fs.writeFileSync(sumFile, JSON.stringify({ since: Date.now(), coins: {}, lines: [], launches: [], callouts: [], lastHour: 'earlier' }));
    w.startBot({ WALLET_SETS: 'devs:slingoor', WALLET_SET_DIR: w.tmp, WALLET_TRADERS: 'main:dilly', QUIET_MODE: 'off', QUICK_WALLETS: 'off', USE_PUMPFUN: 'off', COPY_TRADE: 'on', COPY_PRIVATE_KEY: k.b58, COPY_SIZE_MODE: 'fixed', COPY_BUY_SOL: '0.1', JUPITER_API_KEY: 'test-key', JUPITER_RPS: '1000', COPY_JITO: 'off' });
    await w.waitFor('copy live', () => /Copy trading LIVE with wallet/.test(w.out));
    await w.waitFor('chain subscribed', () => w.WS.subs.logsSubscribe);
    w.tgPush('/start');
    await w.waitFor('registered', () => w.sent(/You're set/).length);
    w.M.balances[E] = 165757500; // his balance right after the buy
    const t0 = Date.now();
    // only the log notification arrives: cut-off logs, no pump.fun event, and no balance notification
    w.notifyLogs(hisSig, 777, ['Program ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL invoke [1]', 'Program ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL success', 'Program 6Vo3245eszAb5wuqEMw8mGdbfRUdKbHhDHP5LcaGuTAB invoke [1]', 'Log truncated']);
    await w.waitFor('devs set started', () => w.out.includes(`Wallet set devs LIVE: main ${k2.pub}, 1 mini wallet(s), copies slingoor`), 15000);
    await w.waitFor('two buys (devs main + devs mini)', () => payers.length >= 2, 15000);
    await new Promise((r) => setTimeout(r, 1500));
    assert.deepEqual([...new Set(payers)].sort(), [k2.pub, k4.pub].sort(), 'only the devs set bought');
    assert.ok(!payers.includes(k.pub), 'the dilly-only main wallet did not buy');
    w.tgPush('/wallettraders');
    await w.waitFor('/wallettraders', () => w.sent(/Who each wallet copies/).length, 15000);
    const wt = String(w.sent(/Who each wallet copies/)[0].text);
    assert.match(wt, /<b>main<\/b> copies: dilly/);
    assert.match(wt, /<b>devs<\/b> copies: slingoor/);
    assert.match(wt, /<b>devs-W2<\/b> copies: slingoor/);
    w.tgPush('/wallets');
    await w.waitFor('/wallets', () => w.sent(/devs \(devs set main\)/).length, 15000);
    assert.match(String(w.sent(/devs \(devs set main\)/)[0].text), /devs-W2 \(devs set mini\)/);
    assert.doesNotMatch(w.out, /Unhandled|TypeError|ReferenceError/);
  } finally {
    await w.close();
  }
});

test("V2.9.12 sweet spot ON: a buy in a market-cap range where his pretend wallets lost money is skipped (OFF: bought)", { skip: !WS_LIB, timeout: 90000 }, async () => {
  const w = await startWorld(WS_LIB);
  const k = newKey();
  const k2 = newKey();
  const fs3 = await import('node:fs');
  const k4 = newKey();
  // his pretend wallets lost money in every market-cap range (9 coins each)
  const closed = [];
  for (const mc of [5000, 20000, 60000, 300000, 900000]) for (let i = 0; i < 9; i++) for (const style of ['main', 'W2']) closed.push({ key: `slingoor|${style}|X${mc}${i}`, trader: 'slingoor', style, pnl: -0.02, x: 0.8, why: 'stop loss', at: Date.now() - 60000, held: 1, mc });
  fs3.writeFileSync(path.join(w.tmp, 'ghosts.json'), JSON.stringify({ open: {}, closed, since: Date.now() - 3600000 }));
  fs3.writeFileSync(path.join(w.tmp, 'sweetspot.json'), JSON.stringify({ on: !process.env.T_SWEET_OFF, alwaysOn1112: true }));
  const payers = [];
  const SOLM = 'So11111111111111111111111111111111111111112';
  const E = b58encode(crypto.randomBytes(32));
  const chain = { sol: 1, tokens: {}, txs: {} };
  const pending = new Map();
  try {
    w.M.dexCoins = { [E]: { name: 'Routed Coin', symbol: 'RTD', mc: 20000 } };
    w.M.ownerBalances = { [k.pub]: chain.tokens };
    const lag = (ms) => new Promise((r) => setTimeout(r, ms)); // realistic network delays
    w.M.jup = async (p, q, body) => {
      await lag(150);
      if (p === '/quote') return { body: { inputMint: q.inputMint, outputMint: q.outputMint, inAmount: q.amount, outAmount: '123', slippageBps: +q.slippageBps } };
      if (p === '/swap') {
        const tx = unsignedTx(body.userPublicKey);
        pending.set(Buffer.from(tx.subarray(65)).toString('hex'), { mint: body.quoteResponse.outputMint, sol: +body.quoteResponse.inAmount / 1e9, payer: body.userPublicKey });
        return { body: { swapTransaction: Buffer.from(tx).toString('base64'), lastValidBlockHeight: 1 } };
      }
      return { status: 404, body: {} };
    };
    const hisSig = 'Routed' + '1'.repeat(81);
    const now = Math.floor(Date.now() / 1000);
    w.M.rpcHook = async (r) => {
      if (r.method === 'getSignaturesForAddress' || (r.method === 'getTokenAccountsByOwner' && r.params[0] === W)) {
        await lag(150);
        return r.method === 'getSignaturesForAddress' ? [] : undefined;
      }
      if (r.method === 'getBalance' && (r.params[0] === k2.pub || r.params[0] === k4.pub)) return { context: { slot: 1 }, value: 1e9 };
      if (r.method === 'getBalance' && r.params[0] === k.pub) return { context: { slot: 1 }, value: Math.round(chain.sol * 1e9) };
      if (r.method === 'getTransaction' && r.params[0] === hisSig) {
        return {
          slot: 777,
          blockTime: now,
          version: 1,
          transaction: { signatures: [hisSig], message: { header: { numRequiredSignatures: 1, numReadonlySignedAccounts: 0, numReadonlyUnsignedAccounts: 2 }, accountKeys: [W, 'HisAta1111111111111111111111111111111111111', SOLM], transactionConfig: {} } },
          meta: {
            err: null,
            fee: 5000,
            preBalances: [20e9, 0, 0],
            postBalances: [10e9 - 5000, 2039280, 0],
            preTokenBalances: [],
            postTokenBalances: [{ accountIndex: 1, mint: E, owner: W, programId: 'TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb', uiTokenAmount: { amount: '165757500000000', decimals: 6, uiAmount: 165757500, uiAmountString: '165757500' } }],
            logMessages: ['Program ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL invoke [1]', 'Program ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL success', 'Program 6Vo3245eszAb5wuqEMw8mGdbfRUdKbHhDHP5LcaGuTAB invoke [1]', 'Log truncated'],
          },
        };
      }
      if (r.method === 'sendTransaction') {
        const bytes = Buffer.from(r.params[0], 'base64');
        const sig = b58encode(bytes.subarray(1, 65));
        if (chain.txs[sig]) return sig;
        chain.sentAt ||= Date.now();
        const req = pending.get(Buffer.from(bytes.subarray(65)).toString('hex'));
        payers.push(req.payer);
        const pre = chain.sol;
        chain.sol -= req.sol + 0.001;
        chain.tokens[req.mint] = 1_000_000;
        chain.txs[sig] = { slot: 9, meta: { err: null, fee: 5000, preBalances: [Math.round(pre * 1e9)], postBalances: [Math.round(chain.sol * 1e9)], preTokenBalances: [], postTokenBalances: [{ accountIndex: 2, mint: req.mint, owner: k.pub, uiTokenAmount: { amount: '1000000000000', uiAmountString: '1000000', decimals: 6 } }] } };
        return sig;
      }
      if (r.method === 'getSignatureStatuses') return { value: r.params[0].map((s) => (chain.txs[s] ? { confirmationStatus: 'confirmed', err: null } : null)) };
      if (r.method === 'getTransaction' && chain.txs[r.params[0]]) return chain.txs[r.params[0]];
      return undefined;
    };
    // a summary from an earlier hour is pending, so the first summary goes out right away
    const sumFile = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'sum-')), 'summary.json');
    fs.writeFileSync(sumFile, JSON.stringify({ since: Date.now(), coins: {}, lines: [], launches: [], callouts: [], lastHour: 'earlier' }));
    w.startBot({ WALLET_TRADERS: 'main:all', QUIET_MODE: 'off', QUICK_WALLETS: 'off', USE_PUMPFUN: 'off', COPY_TRADE: 'on', COPY_PRIVATE_KEY: k.b58, COPY_SIZE_MODE: 'fixed', COPY_BUY_SOL: '0.1', JUPITER_API_KEY: 'test-key', JUPITER_RPS: '1000', COPY_JITO: 'off' });
    await w.waitFor('copy live', () => /Copy trading LIVE with wallet/.test(w.out));
    await w.waitFor('chain subscribed', () => w.WS.subs.logsSubscribe);
    w.tgPush('/start');
    await w.waitFor('registered', () => w.sent(/You're set/).length);
    w.M.balances[E] = 165757500; // his balance right after the buy
    const t0 = Date.now();
    // only the log notification arrives: cut-off logs, no pump.fun event, and no balance notification
    w.notifyLogs(hisSig, 777, ['Program ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL invoke [1]', 'Program ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL success', 'Program 6Vo3245eszAb5wuqEMw8mGdbfRUdKbHhDHP5LcaGuTAB invoke [1]', 'Log truncated']);
    await new Promise((r) => setTimeout(r, 6000));
    if (process.env.T_SWEET_OFF) {
      assert.ok(payers.includes(k.pub), 'sweet spot off: bought');
    } else {
      assert.deepEqual(payers, [], 'sweet spot on: not bought');
      assert.match(w.out, /outside slingoor's sweet spot \([<$\d.k-]+ market cap lost money in his pretend wallets\)/);
    }
    assert.doesNotMatch(w.out, /Unhandled|TypeError|ReferenceError/);
  } finally {
    await w.close();
  }
});

const smartRun = (mode) => async () => {
  const w = await startWorld(WS_LIB);
  const k = newKey();
  const k2 = newKey();
  const fs3 = await import('node:fs');
  const k4 = newKey();
  // his pretend wallets: 'hours' -> 9 losing coins bought this hour of the day; 'size' -> they were 2h ago,
  // and his usual buy is 1 SOL (this one is 10 SOL: his big bet)
  const closed = [];
  const at = Date.now() - (mode !== 'hours' ? 2 * 3600000 : 0);
  for (let i = 0; i < 9; i++) for (const style of ['main', 'W2']) closed.push({ key: `slingoor|${style}|H${i}`, trader: 'slingoor', style, pnl: -0.02, x: 0.8, why: 'stop loss', at, held: 1 });
  if (mode === 'confirm') {
    // V2.11.24 he usually sells within seconds (10 coins held ~5s): a fast trader
    closed.length = 0;
    for (let i = 0; i < 10; i++) closed.push({ key: `slingoor|main|Q${i}`, trader: 'slingoor', style: 'main', pnl: 0.001, x: 1.01, why: 'his exit', at: at - 1000, held: 5000, peak: 1.05 });
  }
  if (mode === 'runner') {
    // V2.11.16 his coins usually run (8 of 10 went 3x); 50 coins of others mostly didn't
    closed.length = 0;
    for (let i = 0; i < 10; i++) closed.push({ key: `slingoor|main|R${i}`, trader: 'slingoor', style: 'main', pnl: 0.05, x: 1.5, why: 'his exit', at: at - 1000, held: 600000, peak: i < 8 ? 3 : 1.2 });
    for (let i = 0; i < 50; i++) closed.push({ key: `zed|main|Z${i}`, trader: 'zed', style: 'main', pnl: -0.01, x: 0.9, why: 'his exit', at: at - 1000, held: 1, peak: i < 3 ? 2.2 : 1.1 });
  }
  fs3.writeFileSync(path.join(w.tmp, 'ghosts.json'), JSON.stringify({ open: {}, closed, since: Date.now() - 3600000, ...(mode === 'runner' ? {} : { sizes: { slingoor: Array(10).fill(1) } }) }));
  fs3.writeFileSync(path.join(w.tmp, 'sweetspot.json'), JSON.stringify({ on: false, alwaysOn1112: true }));
  if (mode === 'neutral') fs3.writeFileSync(path.join(w.tmp, 'rotate.json'), JSON.stringify({ on: true, copying: ['slingoor'], tiers: { slingoor: 'neutral' }, firstSeen: { slingoor: 1 }, log: [] }));
  const payers = [];
  const SOLM = 'So11111111111111111111111111111111111111112';
  const E = b58encode(crypto.randomBytes(32));
  const chain = { sol: 1, tokens: {}, txs: {} };
  const pending = new Map();
  try {
    w.M.dexCoins = { [E]: { name: 'Routed Coin', symbol: 'RTD', mc: 20000 } };
    w.M.ownerBalances = { [k.pub]: chain.tokens };
    const lag = (ms) => new Promise((r) => setTimeout(r, ms)); // realistic network delays
    w.M.jup = async (p, q, body) => {
      await lag(150);
      if (p === '/quote') return { body: { inputMint: q.inputMint, outputMint: q.outputMint, inAmount: q.amount, outAmount: '123', slippageBps: +q.slippageBps } };
      if (p === '/swap') {
        const tx = unsignedTx(body.userPublicKey);
        pending.set(Buffer.from(tx.subarray(65)).toString('hex'), { mint: body.quoteResponse.outputMint, sol: +body.quoteResponse.inAmount / 1e9, payer: body.userPublicKey });
        return { body: { swapTransaction: Buffer.from(tx).toString('base64'), lastValidBlockHeight: 1 } };
      }
      return { status: 404, body: {} };
    };
    const hisSig = 'Routed' + '1'.repeat(81);
    const now = Math.floor(Date.now() / 1000);
    w.M.rpcHook = async (r) => {
      if (r.method === 'getSignaturesForAddress' || (r.method === 'getTokenAccountsByOwner' && r.params[0] === W)) {
        await lag(150);
        return r.method === 'getSignaturesForAddress' ? [] : undefined;
      }
      if (r.method === 'getBalance' && (r.params[0] === k2.pub || r.params[0] === k4.pub)) return { context: { slot: 1 }, value: 1e9 };
      if (r.method === 'getBalance' && r.params[0] === k.pub) return { context: { slot: 1 }, value: Math.round(chain.sol * 1e9) };
      if (r.method === 'getTransaction' && r.params[0] === hisSig) {
        return {
          slot: 777,
          blockTime: now,
          version: 1,
          transaction: { signatures: [hisSig], message: { header: { numRequiredSignatures: 1, numReadonlySignedAccounts: 0, numReadonlyUnsignedAccounts: 2 }, accountKeys: [W, 'HisAta1111111111111111111111111111111111111', SOLM], transactionConfig: {} } },
          meta: {
            err: null,
            fee: 5000,
            preBalances: [20e9, 0, 0],
            postBalances: [10e9 - 5000, 2039280, 0],
            preTokenBalances: [],
            postTokenBalances: [{ accountIndex: 1, mint: E, owner: W, programId: 'TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb', uiTokenAmount: { amount: '165757500000000', decimals: 6, uiAmount: 165757500, uiAmountString: '165757500' } }],
            logMessages: ['Program ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL invoke [1]', 'Program ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL success', 'Program 6Vo3245eszAb5wuqEMw8mGdbfRUdKbHhDHP5LcaGuTAB invoke [1]', 'Log truncated'],
          },
        };
      }
      if (r.method === 'sendTransaction') {
        const bytes = Buffer.from(r.params[0], 'base64');
        const sig = b58encode(bytes.subarray(1, 65));
        if (chain.txs[sig]) return sig;
        chain.sentAt ||= Date.now();
        const req = pending.get(Buffer.from(bytes.subarray(65)).toString('hex'));
        payers.push(req.payer);
        const pre = chain.sol;
        chain.sol -= req.sol + 0.001;
        chain.tokens[req.mint] = 1_000_000;
        chain.txs[sig] = { slot: 9, meta: { err: null, fee: 5000, preBalances: [Math.round(pre * 1e9)], postBalances: [Math.round(chain.sol * 1e9)], preTokenBalances: [], postTokenBalances: [{ accountIndex: 2, mint: req.mint, owner: k.pub, uiTokenAmount: { amount: '1000000000000', uiAmountString: '1000000', decimals: 6 } }] } };
        return sig;
      }
      if (r.method === 'getSignatureStatuses') return { value: r.params[0].map((s) => (chain.txs[s] ? { confirmationStatus: 'confirmed', err: null } : null)) };
      if (r.method === 'getTransaction' && chain.txs[r.params[0]]) return chain.txs[r.params[0]];
      return undefined;
    };
    // a summary from an earlier hour is pending, so the first summary goes out right away
    const sumFile = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'sum-')), 'summary.json');
    fs.writeFileSync(sumFile, JSON.stringify({ since: Date.now(), coins: {}, lines: [], launches: [], callouts: [], lastHour: 'earlier' }));
    w.startBot({ ...(mode === 'neutral' ? { AUTO_ROTATE: 'on' } : {}), ...(mode === 'size' ? { DEV_CHECK: 'on' } : {}), ...(mode === 'confirm' ? { COPY_CONFIRM_SECONDS: '2', COPY_MIN_HOLD_SECONDS: '120' } : {}), COPY_BEST_HOURS: 'on', COPY_SMART_SIZE: 'on', COPY_MAX_WALLET_PERCENT: '50', WALLET_TRADERS: 'main:all', QUIET_MODE: 'off', QUICK_WALLETS: 'off', USE_PUMPFUN: 'off', COPY_TRADE: 'on', COPY_PRIVATE_KEY: k.b58, COPY_SIZE_MODE: 'fixed', COPY_BUY_SOL: '0.1', JUPITER_API_KEY: 'test-key', JUPITER_RPS: '1000', COPY_JITO: 'off' });
    await w.waitFor('copy live', () => /Copy trading LIVE with wallet/.test(w.out));
    await w.waitFor('chain subscribed', () => w.WS.subs.logsSubscribe);
    w.tgPush('/start');
    await w.waitFor('registered', () => w.sent(/You're set/).length);
    w.M.balances[E] = 165757500; // his balance right after the buy
    const t0 = Date.now();
    // only the log notification arrives: cut-off logs, no pump.fun event, and no balance notification
    w.notifyLogs(hisSig, 777, ['Program ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL invoke [1]', 'Program ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL success', 'Program 6Vo3245eszAb5wuqEMw8mGdbfRUdKbHhDHP5LcaGuTAB invoke [1]', 'Log truncated']);
    await new Promise((r) => setTimeout(r, 6000));
    if (mode === 'confirm') {
      assert.match(w.out, /slingoor still holds \w+ after 2s — copying/);
      assert.ok(payers.includes(k.pub), 'his buy he was still holding: copied');
      const conf = w.out.indexOf('still holds');
      const bought = w.out.search(/Copy: bought/);
      assert.ok(bought > conf, 'bought only after the wait');
    } else if (mode === 'runner') {
      assert.ok(payers.includes(k.pub), 'bought');
      assert.match(w.out, /bought \$?RTD for 0\.15\d* SOL/, 'his coins usually run: 1.5x the 0.1 SOL buy');
      assert.ok(w.sent(/🏃 \d+% runner chance · holding \(1\.5x size\)/).length, 'the buy alert says why');
    } else if (mode === 'neutral') {
      assert.ok(payers.includes(k.pub), 'neutral: still bought');
      assert.match(w.out, /bought \$?RTD for 0\.07[56]\d* SOL/, 'neutral 0.5x and his big bet 1.5x: 0.075 SOL');
      assert.ok(w.sent(/🟡 neutral trader · 💪 his big bet \(0\.75x size\)/).length, 'the buy alert says why');
    } else if (mode === 'size') {
      assert.ok(payers.includes(k.pub), 'other hour: bought');
      assert.match(w.out, /bought \$?RTD for 0\.15\d* SOL/, 'his big bet: 1.5x the 0.1 SOL buy');
      assert.ok(w.sent(/💪 his big bet \(1\.5x size\)/).length, 'the buy alert says why');
    } else {
      assert.deepEqual(payers, [], 'his losing hour: not bought');
      assert.match(w.out, /slingoor loses money at \d+(am|pm) \(his pretend wallets\)/);
    }
    assert.doesNotMatch(w.out, /Unhandled|TypeError|ReferenceError/);
  } finally {
    await w.close();
  }
};
test('V2.11 best hours: a trader is not copied in an hour of the day his pretend wallets lost money in', { skip: !WS_LIB, timeout: 90000 }, smartRun('hours'));
test('V2.11 his big bet (10x his usual buy) is copied 1.5x bigger, and the alert says so', { skip: !WS_LIB, timeout: 90000 }, smartRun('size'));
test('V2.11.2 a neutral trader (auto-rotate) is copied at half size; the alert says so', { skip: !WS_LIB, timeout: 90000 }, smartRun('neutral'));
test('V2.11.16 a wallet whose coins usually run gets a bigger buy (runner chance); the alert says so', { skip: !WS_LIB, timeout: 90000 }, smartRun('runner'));
test('V2.11.24 a fast trader (usually out in seconds): his buy is copied only once he still holds it 30s (here 2s) later', { skip: !WS_LIB, timeout: 90000 }, smartRun('confirm'));

test("cupsey mode: cupsey's brand-new coin is copied by the full bot and the alerts say it was cupsey", { skip: !WS_LIB, timeout: 90000 }, async () => {
  const w = await startWorld(WS_LIB);
  const k = newKey();
  const SOLM = 'So11111111111111111111111111111111111111112';
  const E = b58encode(crypto.randomBytes(32));
  const chain = { sol: 1, tokens: {}, txs: {} };
  const pending = new Map();
  try {
    w.M.dexCoins = { [E]: { name: 'Routed Coin', symbol: 'RTD', mc: 20000 } };
    w.M.ownerBalances = { [k.pub]: chain.tokens };
    const lag = (ms) => new Promise((r) => setTimeout(r, ms)); // realistic network delays
    w.M.jup = async (p, q, body) => {
      await lag(150);
      if (p === '/quote') return { body: { inputMint: q.inputMint, outputMint: q.outputMint, inAmount: q.amount, outAmount: '123', slippageBps: +q.slippageBps } };
      if (p === '/swap') {
        const tx = unsignedTx(body.userPublicKey);
        pending.set(Buffer.from(tx.subarray(65)).toString('hex'), { mint: body.quoteResponse.outputMint, sol: +body.quoteResponse.inAmount / 1e9 });
        return { body: { swapTransaction: Buffer.from(tx).toString('base64'), lastValidBlockHeight: 1 } };
      }
      return { status: 404, body: {} };
    };
    const hisSig = 'Routed' + '1'.repeat(81);
    const now = Math.floor(Date.now() / 1000);
    w.M.rpcHook = async (r) => {
      if (r.method === 'getSignaturesForAddress' || (r.method === 'getTokenAccountsByOwner' && r.params[0] === W)) {
        await lag(150);
        return r.method === 'getSignaturesForAddress' ? [] : undefined;
      }
      if (r.method === 'getBalance' && r.params[0] === k.pub) return { context: { slot: 1 }, value: Math.round(chain.sol * 1e9) };
      if (r.method === 'getTransaction' && r.params[0] === hisSig) {
        return {
          slot: 777,
          blockTime: now,
          version: 1,
          transaction: { signatures: [hisSig], message: { header: { numRequiredSignatures: 1, numReadonlySignedAccounts: 0, numReadonlyUnsignedAccounts: 2 }, accountKeys: [W, 'HisAta1111111111111111111111111111111111111', SOLM], transactionConfig: {} } },
          meta: {
            err: null,
            fee: 5000,
            preBalances: [20e9, 0, 0],
            postBalances: [10e9 - 5000, 2039280, 0],
            preTokenBalances: [],
            postTokenBalances: [{ accountIndex: 1, mint: E, owner: W, programId: 'TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb', uiTokenAmount: { amount: '165757500000000', decimals: 6, uiAmount: 165757500, uiAmountString: '165757500' } }],
            logMessages: ['Program ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL invoke [1]', 'Program ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL success', 'Program 6Vo3245eszAb5wuqEMw8mGdbfRUdKbHhDHP5LcaGuTAB invoke [1]', 'Log truncated'],
          },
        };
      }
      if (r.method === 'sendTransaction') {
        const bytes = Buffer.from(r.params[0], 'base64');
        const sig = b58encode(bytes.subarray(1, 65));
        if (chain.txs[sig]) return sig;
        chain.sentAt ||= Date.now();
        const req = pending.get(Buffer.from(bytes.subarray(65)).toString('hex'));
        const pre = chain.sol;
        chain.sol -= req.sol + 0.001;
        chain.tokens[req.mint] = 1_000_000;
        chain.txs[sig] = { slot: 9, meta: { err: null, fee: 5000, preBalances: [Math.round(pre * 1e9)], postBalances: [Math.round(chain.sol * 1e9)], preTokenBalances: [], postTokenBalances: [{ accountIndex: 2, mint: req.mint, owner: k.pub, uiTokenAmount: { amount: '1000000000000', uiAmountString: '1000000', decimals: 6 } }] } };
        return sig;
      }
      if (r.method === 'getSignatureStatuses') return { value: r.params[0].map((s) => (chain.txs[s] ? { confirmationStatus: 'confirmed', err: null } : null)) };
      if (r.method === 'getTransaction' && chain.txs[r.params[0]]) return chain.txs[r.params[0]];
      return undefined;
    };
    w.startBot({ QUIET_MODE: 'off', TARGET_WALLETS: 'So11111111111111111111111111111111111111112', CUPSEY_MODE: 'on', CUPSEY_WALLETS: W, USE_PUMPFUN: 'off', COPY_TRADE: 'on', COPY_PRIVATE_KEY: k.b58, COPY_SIZE_MODE: 'fixed', COPY_BUY_SOL: '0.1', JUPITER_API_KEY: 'test-key', JUPITER_RPS: '1000', COPY_JITO: 'off' });
    await w.waitFor('copy live', () => /Copy trading LIVE with wallet/.test(w.out));
    await w.waitFor('chain subscribed', () => w.WS.subs.logsSubscribe);
    w.tgPush('/start');
    await w.waitFor('registered', () => w.sent(/You're set/).length);
    w.M.balances[E] = 165757500; // his balance right after the buy
    const t0 = Date.now();
    // only the log notification arrives: cut-off logs, no pump.fun event, and no balance notification
    w.notifyLogs(hisSig, 777, ['Program ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL invoke [1]', 'Program ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL success', 'Program 6Vo3245eszAb5wuqEMw8mGdbfRUdKbHhDHP5LcaGuTAB invoke [1]', 'Log truncated']);
    await w.waitFor('copy buy sent', () => chain.sentAt, 15000);
    await w.waitFor('copy buy alert', () => w.sent(/COPY BUY<\/b> <b>\$RTD/).length, 15000);
    assert.match(w.sent(/COPY BUY<\/b> <b>\$RTD/)[0].text, /— spent <b>/);
    await w.waitFor('his entry alert', () => w.sent(/NEW ENTRY/i).length, 15000);
    assert.match(w.sent(/NEW ENTRY/i)[0].text, /cupsey/i);
    assert.doesNotMatch(w.sent(/NEW ENTRY/i)[0].text, /slingoor/i);
  } finally {
    await w.close();
  }
});

test("paid Helius: his whole transaction arrives on the stream -> copied with no download at all", { skip: !WS_LIB, timeout: 90000 }, async () => {
  const w = await startWorld(WS_LIB);
  const k = newKey();
  const SOLM = 'So11111111111111111111111111111111111111112';
  const E = b58encode(crypto.randomBytes(32));
  const chain = { sol: 1, tokens: {}, txs: {} };
  const pending = new Map();
  try {
    w.M.dexCoins = { [E]: { name: 'Routed Coin', symbol: 'RTD', mc: 20000 } };
    w.M.ownerBalances = { [k.pub]: chain.tokens };
    const lag = (ms) => new Promise((r) => setTimeout(r, ms)); // realistic network delays
    w.M.jup = async (p, q, body) => {
      await lag(150);
      if (p === '/quote') return { body: { inputMint: q.inputMint, outputMint: q.outputMint, inAmount: q.amount, outAmount: '123', slippageBps: +q.slippageBps } };
      if (p === '/swap') {
        const tx = unsignedTx(body.userPublicKey);
        pending.set(Buffer.from(tx.subarray(65)).toString('hex'), { mint: body.quoteResponse.outputMint, sol: +body.quoteResponse.inAmount / 1e9 });
        return { body: { swapTransaction: Buffer.from(tx).toString('base64'), lastValidBlockHeight: 1 } };
      }
      return { status: 404, body: {} };
    };
    const hisSig = 'Routed' + '1'.repeat(81);
    const now = Math.floor(Date.now() / 1000);
    w.M.rpcHook = async (r) => {
      if (r.method === 'getSignaturesForAddress' || (r.method === 'getTokenAccountsByOwner' && r.params[0] === W)) {
        await lag(150);
        return r.method === 'getSignaturesForAddress' ? [] : undefined;
      }
      if (r.method === 'getBalance' && r.params[0] === k.pub) return { context: { slot: 1 }, value: Math.round(chain.sol * 1e9) };
      if (r.method === 'getTransaction' && r.params[0] === hisSig) {
        return {
          slot: 777,
          blockTime: now,
          version: 1,
          transaction: { signatures: [hisSig], message: { header: { numRequiredSignatures: 1, numReadonlySignedAccounts: 0, numReadonlyUnsignedAccounts: 2 }, accountKeys: [W, 'HisAta1111111111111111111111111111111111111', SOLM], transactionConfig: {} } },
          meta: {
            err: null,
            fee: 5000,
            preBalances: [20e9, 0, 0],
            postBalances: [10e9 - 5000, 2039280, 0],
            preTokenBalances: [],
            postTokenBalances: [{ accountIndex: 1, mint: E, owner: W, programId: 'TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb', uiTokenAmount: { amount: '165757500000000', decimals: 6, uiAmount: 165757500, uiAmountString: '165757500' } }],
            logMessages: ['Program ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL invoke [1]', 'Program ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL success', 'Program 6Vo3245eszAb5wuqEMw8mGdbfRUdKbHhDHP5LcaGuTAB invoke [1]', 'Log truncated'],
          },
        };
      }
      if (r.method === 'sendTransaction') {
        const bytes = Buffer.from(r.params[0], 'base64');
        const sig = b58encode(bytes.subarray(1, 65));
        if (chain.txs[sig]) return sig;
        chain.sentAt ||= Date.now();
        const req = pending.get(Buffer.from(bytes.subarray(65)).toString('hex'));
        const pre = chain.sol;
        chain.sol -= req.sol + 0.001;
        chain.tokens[req.mint] = 1_000_000;
        chain.txs[sig] = { slot: 9, meta: { err: null, fee: 5000, preBalances: [Math.round(pre * 1e9)], postBalances: [Math.round(chain.sol * 1e9)], preTokenBalances: [], postTokenBalances: [{ accountIndex: 2, mint: req.mint, owner: k.pub, uiTokenAmount: { amount: '1000000000000', uiAmountString: '1000000', decimals: 6 } }] } };
        return sig;
      }
      if (r.method === 'getSignatureStatuses') return { value: r.params[0].map((s) => (chain.txs[s] ? { confirmationStatus: 'confirmed', err: null } : null)) };
      if (r.method === 'getTransaction' && chain.txs[r.params[0]]) return chain.txs[r.params[0]];
      return undefined;
    };
    w.startBot({ WS_URL: w.wsUrl + '?helius=1', USE_PUMPFUN: 'off', COPY_TRADE: 'on', COPY_PRIVATE_KEY: k.b58, COPY_SIZE_MODE: 'fixed', COPY_BUY_SOL: '0.1', JUPITER_API_KEY: 'test-key', JUPITER_RPS: '1000', COPY_JITO: 'off' });
    await w.waitFor('copy live', () => /Copy trading LIVE with wallet/.test(w.out));
    await w.waitFor('full-tx stream subscribed', () => w.WS.subs.transactionSubscribe && /Full-transaction stream on/.test(w.out));
    w.tgPush('/start');
    await w.waitFor('registered', () => w.sent(/You're set/).length);
    w.M.balances[E] = 165757500; // his balance right after the buy
    const t0 = Date.now();
    // only the full-transaction notification arrives (no logs, no balance notification)
    const full = await w.M.rpcHook({ method: 'getTransaction', params: [hisSig] });
    w.notifyTx(hisSig, 777, full);
    await w.waitFor('copy buy', () => w.sent(/COPY BUY<\/b> <b>\$RTD/).length, 15000);
    const took = Date.now() - t0;
    assert.ok(chain.sentAt - t0 < 500, `buy sent ${chain.sentAt - t0}ms after his trade (history check and build must overlap)`);
    assert.ok(took < 3000, `copied in ${took}ms`);
    await w.waitFor('entry alert', () => w.sent(/NEW ENTRY.*\$RTD/).length);
    assert.match(w.sent(/NEW ENTRY.*\$RTD/)[0].text, /Bought <b>10\.00 SOL/);
    assert.ok(!w.M.rpcCalls.some((r) => r.method === 'getTransaction' && r.params[0] === hisSig), 'no download needed');
  } finally {
    await w.close();
  }
});

test('one buy per coin (default): his burst of buys = one buy of ours; no adds; no rebuy after we sold; skips say why', async () => {
  const h = harness({ cfg: { sizeMode: 'fixed', buySol: 0.2, copyAdds: true }, bal: 100 });
  await h.c.refreshBalance();
  h.world.delay = 60; // our buy takes a moment, like on the real network
  h.c.onSignal({ ev: h.ev('ONE1'), kind: 'ENTRY', pre: 0, post: 1, sol: 10 });
  h.c.onSignal({ ev: h.ev('ONE1'), kind: 'ENTRY', pre: 0, post: 1, sol: 10 }); // same moment (2 txs of his)
  h.c.onSignal({ ev: h.ev('ONE1'), kind: 'ADD', pre: 1, post: 2, sol: 5 });
  await sleep(150);
  await h.flush();
  assert.equal(h.trades.filter((t) => t.action === 'buy').length, 1, 'exactly one buy');
  // he adds later while we hold -> no add
  h.c.onSignal({ ev: h.ev('ONE1'), kind: 'ADD', pre: 2, post: 3, sol: 5 });
  await h.flush();
  assert.equal(h.trades.filter((t) => t.action === 'buy').length, 1);
  // he sells out -> we sell; he buys back in -> no rebuy
  h.c.onSignal({ ev: h.ev('ONE1'), kind: 'EXIT', pre: 3, post: 0, sol: 20 });
  await sleep(100);
  await h.flush();
  assert.equal(h.trades.filter((t) => t.action === 'sell').length, 1);
  h.c.onSignal({ ev: h.ev('ONE1'), kind: 'ENTRY', pre: 0, post: 1, sol: 10 });
  await sleep(100);
  await h.flush();
  assert.equal(h.trades.filter((t) => t.action === 'buy').length, 1, 'no rebuy after selling');
  await sleep(20);
  assert.match(h.sent.join('\n'), /BOT SKIPPED.*\n❓ Why: already holding it — one buy per coin, no adds/s);
});

test('take-profit ladder: 50% at 2x (initial back), then 25% of the rest at 4x, 6x, 8x; never sells out on profit', async () => {
  const h = harness({ cfg: { sizeMode: 'fixed', buySol: 0.1, tpLadder: [{ x: 2, pct: 50 }, { x: 4, pct: 25 }, { x: 6, pct: 25 }, { x: 8, pct: 25 }], quickTpX: 1.5, quickTpPercent: 35, tpX: 2, tpPercent: 25 }, bal: 100 });
  await h.c.refreshBalance();
  let px = 0;
  h.c.coins.pricesSol = async () => ({ LAD: px });
  h.c.onSignal({ ev: h.ev('LAD'), kind: 'ENTRY', pre: 0, post: 1, sol: 5 });
  await h.flush();
  const cost = h.c.positions.LAD.costSol; // ~0.101 SOL for 1000 tokens
  const at = async (x) => {
    px = (cost / 1000) * x;
    await h.c.checkTakeProfit();
    await h.flush();
    return h.trades.filter((t) => t.action === 'sell').map((t) => t.amount);
  };
  assert.deepEqual(await at(1.6), [], 'quick profit is replaced by the ladder');
  assert.deepEqual(await at(2.05), ['50%']);
  assert.ok(Math.abs(h.c.positions.LAD.tokens - 500) < 1e-6);
  assert.deepEqual(await at(3), ['50%'], 'nothing between rungs');
  assert.deepEqual(await at(4.2), ['50%', '25%']);
  assert.deepEqual(await at(9), ['50%', '25%', '25%'], 'one rung per check');
  assert.deepEqual(await at(9), ['50%', '25%', '25%', '25%']);
  assert.deepEqual(await at(20), ['50%', '25%', '25%', '25%'], 'done after the last rung');
  assert.ok(h.c.positions.LAD.tokens > 0, 'still holding the rest');
  assert.match(h.sent.join('\n'), /TAKE PROFIT 2x — SOLD 50%.*initial taken out/s);
  assert.match(h.sent.join('\n'), /TAKE PROFIT 8x — SOLD 25%/);
});


const MINI = { miniCook: true, miniFromX: 1.75, miniToX: 2.5, miniPullbackPct: 10, miniPct: 50, miniMinSol: 0.1 };
const LADDER = [{ x: 2, pct: 50 }, { x: 4, pct: 25 }, { x: 6, pct: 25 }, { x: 8, pct: 25 }];
async function miniHarness(buySol, extra = {}) {
  const h = harness({ cfg: { sizeMode: 'fixed', buySol, tpLadder: LADDER, ...MINI, ...extra }, bal: 100 });
  await h.c.refreshBalance();
  let px = 0;
  h.c.coins.pricesSol = async () => ({ MC: px });
  h.c.onSignal({ ev: h.ev('MC'), kind: 'ENTRY', pre: 0, post: 1, sol: 5 });
  await h.flush();
  const cost = h.c.positions.MC.costSol;
  const tokens = h.c.positions.MC.tokens;
  h.at = async (x) => {
    px = (cost / tokens) * x;
    await h.c.checkTakeProfit();
    await h.flush();
    return h.trades.filter((t) => t.action === 'sell').map((t) => t.amount);
  };
  return h;
}

test('mini cook: on 0.1 SOL+ buys, arms at 1.75x and sells 50% once it pulls back 10% from its top; ladder 2x is covered, 4x+ still runs', async () => {
  const h = await miniHarness(0.1);
  assert.deepEqual(await h.at(1.5), [], 'not up 75% yet');
  assert.deepEqual(await h.at(1.8), [], 'armed, still climbing');
  assert.deepEqual(await h.at(2.2), [], 'still climbing: the 2x rung waits for the mini cook');
  assert.deepEqual(await h.at(1.95), ['50%'], 'pulled back >10% from 2.2x -> mini cook');
  const msg = h.sent.join('\n');
  assert.match(msg, /MINI COOK 1\.95x — SOLD 50%/);
  assert.match(msg, /Safety net: up 95%/);
  assert.ok(h.c.positions.MC.tokens > 0, 'still holding the rest');
  assert.deepEqual(await h.at(2.3), ['50%'], 'no second 50% at the 2x rung');
  assert.deepEqual(await h.at(4.1), ['50%', '25%'], 'ladder carries on at 4x');
});

test('mini cook: a fast run straight past 2.5x sells at once', async () => {
  const h = await miniHarness(0.1);
  assert.deepEqual(await h.at(2.7), ['50%']);
  assert.match(h.sent.join('\n'), /MINI COOK 2\.70x/);
});

const CUP_RULES = { leaderRules: { cupsey: { miniPct: 100, stopLossX: 0.7, crashDropPct: 20, trailArmX: 1.3, trailDropPct: 25, floorX: 1.05 } }, protect: true };
async function cupHarness() {
  const h = await miniHarness(0.1, CUP_RULES);
  h.c.positions.MC.leader = 'cupsey';
  return h;
}

test('cupsey coins: up 75%+ -> sells EVERYTHING on the first pullback (no holding)', async () => {
  const h = await cupHarness();
  assert.deepEqual(await h.at(1.9), []);
  assert.deepEqual(await h.at(1.7), ['100%'], '10% off the top -> all out');
  assert.match(h.sent.join('\n'), /MINI COOK 1\.70x — SOLD 100%/);
  assert.match(h.sent.join('\n'), /took the whole win \(cupsey new pair/);
  assert.equal(h.c.positions.MC, undefined);
});

test('profit sells are double-checked with a real quote: price feed says 1.6x+ but selling really pays 0.85x -> no "mini cook" sale', async () => {
  const h = await cupHarness();
  const cost = h.c.positions.MC.costSol;
  h.c.swapper.quoteSellSol = async () => cost * 0.85;
  h.c.positions.MC.raw = '1000000000';
  assert.deepEqual(await h.at(1.9), []);
  assert.deepEqual(await h.at(1.61), [], 'feed pulled back -> mini fires, but the real quote is 0.85x -> no sale');
  await h.flush();
  assert.equal(h.c.positions.MC.miniDone, false, 'mini cook undone');
  assert.ok(Math.abs(h.c.positions.MC.quoteX - 0.85) < 1e-9, 'next checks use the real price for 30s');
  // next check judges it on the real price: under the buy -> sold, labelled honestly
  assert.deepEqual(await h.at(1.61), ['100%']);
  const all = h.sent.join('\n');
  assert.doesNotMatch(all, /MINI COOK|PROFIT LOCK/);
  assert.match(all, /LOSING — SOLD ALL|DUMPING — SOLD ALL/);
});

test('profit sells: when the real quote confirms the profit, it sells and the alert shows the REAL multiple', async () => {
  const h = await cupHarness();
  const cost = h.c.positions.MC.costSol;
  h.c.swapper.quoteSellSol = async () => cost * 1.8;
  h.c.positions.MC.raw = '1000000000';
  assert.deepEqual(await h.at(2.0), []);
  assert.deepEqual(await h.at(1.75), ['100%']);
  assert.match(h.sent.join('\n'), /MINI COOK 1\.80x — SOLD 100%/);
});

test('cupsey coins: stop loss at 0.7x (two checks in a row, not in the first minute)', async () => {
  const h = await cupHarness();
  assert.deepEqual(await h.at(0.65), [], 'first minute: a late price feed must not sell');
  h.c.positions.MC.openedAt = Date.now() - 120000;
  h.c.positions.MC.hist = [];
  assert.deepEqual(await h.at(0.68), [], 'needs two low checks in a row');
  assert.deepEqual(await h.at(0.66), ['100%']);
  assert.match(h.sent.join('\n'), /STOP LOSS — SOLD ALL/);
});

test('cupsey coins: falling 20% fast sells all; sling coins need 35%', async () => {
  let h = await cupHarness();
  h.c.positions.MC.openedAt = Date.now() - 120000;
  assert.deepEqual(await h.at(1.2), []);
  assert.deepEqual(await h.at(0.95), ['100%'], '-21% from its 5-min high');
  h = await miniHarness(0.1, CUP_RULES); // sling's coin (no leader rules)
  assert.deepEqual(await h.at(1.2), []);
  assert.deepEqual(await h.at(0.95), [], 'normal rules: -21% is not a crash');
});

test('cupsey coins: after a 1.3x run, giving back 25% sells all; never back under 1.05x', async () => {
  let h = await cupHarness();
  h.c.positions.MC.openedAt = Date.now() - 120000;
  assert.deepEqual(await h.at(1.5), []);
  h.c.positions.MC.hist = []; // past the 5-min crash window
  assert.deepEqual(await h.at(1.12), ['100%'], '1.5 -> 1.12 is -25%');
  assert.match(h.sent.join('\n'), /PROFIT LOCK/);
  h = await cupHarness();
  h.c.positions.MC.openedAt = Date.now() - 120000;
  assert.deepEqual(await h.at(1.32), []);
  h.c.positions.MC.hist = [];
  assert.deepEqual(await h.at(1.04), ['100%'], 'ran past 1.3x, back to 1.04x -> out before it goes red');
});

test('dead coin: losing, quiet (few trades/low volume) and more sellers than buyers -> sell all after two checks', async () => {
  const h = await miniHarness(0.1, { deadCoin: true, deadMinMs: 1200000, deadMaxTrades5m: 10, deadMaxVol5m: 300 });
  const act = new Map();
  h.c.coins.activity = act;
  const dead = { at: Date.now(), buysM5: 1, sellsM5: 3, buysH1: 20, sellsH1: 45, volM5: 80, volH1: 4000 };
  act.set('MC', dead);
  assert.deepEqual(await h.at(0.8), [], 'too soon after buying (20 min)');
  h.c.positions.MC.openedAt = Date.now() - 30 * 60000;
  act.set('MC', { ...dead, at: Date.now() });
  assert.deepEqual(await h.at(0.8), [], 'first dead check');
  act.set('MC', { ...dead, at: Date.now(), buysM5: 30, sellsM5: 20, volM5: 5000 });
  assert.deepEqual(await h.at(0.8), [], 'trading picked up -> count resets');
  act.set('MC', { ...dead, at: Date.now() });
  assert.deepEqual(await h.at(0.8), []);
  act.set('MC', { ...dead, at: Date.now(), buysH1: 60 });
  assert.deepEqual(await h.at(0.8), [], 'more buyers than sellers -> not dead');
  act.set('MC', { ...dead, at: Date.now() });
  await h.at(0.8);
  assert.deepEqual(await h.at(0.8), ['100%']);
  assert.match(h.sent.join('\n'), /DEAD COIN — SOLD ALL/);
  assert.match(h.sent.join('\n'), /4 trades, \$80 volume in 5 min; 45 sells vs 20 buys/);
});

test("sling's coins: under 80 holders, losing and not gaining holders (after 10 min, two counts in a row) -> sell all; a gaining coin is kept; cupsey's coins not affected", async () => {
  const h = await miniHarness(0.1, { minHolders: 80, minHoldersAfterMs: 600000 });
  h.c.targetName = 'slingoor';
  let holders = 50;
  let calls = 0;
  h.c.countHolders = async () => (calls++, holders);
  // each tick: a fresh holder count lands in the background first (like a minute passing), then the check runs
  const tick = async (x) => {
    if (Date.now() - h.c.positions.MC.openedAt >= 600000) {
      if (h.c.holderCache) for (const [k, v] of h.c.holderCache) h.c.holderCache.set(k, { ...v, at: v.at - 61000 });
      h.c._holders('MC');
      await sleep(5);
    }
    return h.at(x);
  };
  assert.deepEqual(await tick(0.8), [], 'first 10 minutes: new coins start with few holders');
  assert.equal(calls, 0);
  h.c.positions.MC.openedAt = Date.now() - 11 * 60000;
  assert.deepEqual(await tick(1.3), [], 'few holders but in profit -> keep');
  assert.deepEqual(await tick(1.3), [], 'still in profit -> keep');
  holders = 60;
  assert.deepEqual(await tick(0.9), [], 'holders went up 50 -> 60: gaining -> keep');
  assert.deepEqual(await tick(0.9), [], 'losing, 60 holders, not growing: first low count');
  assert.deepEqual(await tick(0.9), ['100%'], 'second low count -> sell all');
  assert.match(h.sent.join('\n'), /TOO FEW HOLDERS — SOLD ALL/);
  assert.match(h.sent.join('\n'), /Only 60 holders \(under 80\), not growing/);

  const c = await miniHarness(0.1, { minHolders: 80, minHoldersAfterMs: 0 });
  c.c.targetName = 'slingoor';
  c.c.positions.MC.leader = 'cupsey';
  c.c.countHolders = async () => 5;
  for (let i = 0; i < 4; i++) assert.deepEqual(await c.at(0.9), [], "cupsey's coin keeps his own rules");
});

test('V2 weak buy: trader bought under 3 SOL and the chart is fading -> sell all (two checks, after 3 min); big buys or busy charts are kept', async () => {
  const h = await miniHarness(0.1, { weakBuySol: 3, weakMinMs: 180000, weakMaxX: 1.1 });
  const act = new Map();
  h.c.coins.activity = act;
  const fade = () => act.set('MC', { at: Date.now(), buysM5: 3, sellsM5: 4, buysH1: 50, sellsH1: 50, volM5: 100, volH1: 6000 });
  h.c.positions.MC.hisBuySol = 1.2;
  fade();
  assert.deepEqual(await h.at(1.0), [], 'first 3 minutes: give it a chance');
  h.c.positions.MC.openedAt = Date.now() - 4 * 60000;
  fade();
  assert.deepEqual(await h.at(1.0), [], 'first fading check');
  act.set('MC', { at: Date.now(), buysM5: 40, sellsM5: 10, buysH1: 60, sellsH1: 40, volM5: 3000, volH1: 6000 });
  assert.deepEqual(await h.at(1.0), [], 'volume picked up -> reset');
  fade();
  await h.at(1.0);
  fade();
  assert.deepEqual(await h.at(1.0), ['100%']);
  assert.match(h.sent.join('\n'), /WEAK COIN — SOLD ALL/);

  // more people getting in -> keep it (missed runners)
  const r = await miniHarness(0.1, { weakBuySol: 3, weakMinMs: 0 });
  r.c.coins.activity = act;
  r.c.positions.MC.hisBuySol = 1;
  let holders = 40;
  r.c.countHolders = async () => holders;
  for (let i = 0; i < 4; i++) {
    holders += 10;
    if (r.c.holderCache) for (const [k, v] of r.c.holderCache) r.c.holderCache.set(k, { ...v, at: v.at - 61000 });
    r.c._holders('MC');
    await sleep(5);
    fade();
    assert.deepEqual(await r.at(1.0), [], 'holders going up: keep');
  }
  act.set('MC', { at: Date.now(), buysM5: 9, sellsM5: 2, buysH1: 50, sellsH1: 50, volM5: 100, volH1: 6000 });
  assert.deepEqual(await r.at(1.0), [], 'more buyers than sellers: keep');

  const big = await miniHarness(0.1, { weakBuySol: 3, weakMinMs: 0 });
  big.c.coins.activity = act;
  big.c.positions.MC.hisBuySol = 5;
  for (let i = 0; i < 3; i++) {
    fade();
    assert.deepEqual(await big.at(1.0), [], 'he bought 5 SOL: not a weak buy');
  }
});

test('dead coin: never sells a coin that is in profit', async () => {
  const h = await miniHarness(0.1, { deadCoin: true, deadMinMs: 60000 });
  h.c.coins.activity = new Map([['MC', { at: Date.now(), buysM5: 0, sellsM5: 1, buysH1: 1, sellsH1: 9, volM5: 5, volH1: 50 }]]);
  h.c.positions.MC.openedAt = Date.now() - 30 * 60000;
  h.c.coins.activity.get('MC').at = Date.now();
  assert.deepEqual(await h.at(1.1), []);
  h.c.coins.activity.get('MC').at = Date.now();
  assert.deepEqual(await h.at(1.1), [], 'up 10%: quiet but not losing -> keep');
});

test('quick profit mode: every coin (any size) sells 100% once up 25%, on a 7% dip or at +75%', async () => {
  const q = { quickFromX: 1.25, quickToX: 1.75, quickPullbackPct: 7 };
  let h = await miniHarness(0.05, { floorBuySol: 0, ...q });
  h.c.quickMode = true;
  assert.deepEqual(await h.at(1.2), []);
  assert.deepEqual(await h.at(1.4), [], 'up 40%, still climbing');
  assert.deepEqual(await h.at(1.29), ['100%'], '8% off the top -> all out');
  assert.match(h.sent.join('\n'), /QUICK PROFIT 1\.29x — SOLD ALL/);
  assert.equal(h.c.positions.MC, undefined);
  h = await miniHarness(0.1, q);
  h.c.quickMode = true;
  assert.deepEqual(await h.at(1.8), ['100%'], 'straight past +75% -> all out');
  h = await miniHarness(0.1, q);
  assert.deepEqual(await h.at(1.4), [], 'mode off: normal rules');
});

test('mini cook: buys under 0.1 SOL keep the normal ladder', async () => {
  const h = await miniHarness(0.05, { floorBuySol: 0 });
  assert.deepEqual(await h.at(1.9), []);
  assert.deepEqual(await h.at(2.05), ['50%'], 'normal 2x rung');
  assert.doesNotMatch(h.sent.join('\n'), /MINI COOK/);
});

test('/copy status: wallet SOL + last buy size, no wallet address, no settings line, no last skip', async () => {
  const h = harness({ cfg: { sizeMode: 'fixed', buySol: 0.1 }, bal: 100 });
  await h.c.refreshBalance();
  h.c.solBalance = async () => 0.665;
  h.c.coins.pricesSol = async () => ({});
  let t = await h.c.statusText();
  assert.match(t, /👛 Wallet: <b>0\.665 SOL<\/b>/);
  assert.match(t, /Last buy: none yet/);
  h.c.onSignal({ ev: h.ev('ST'), kind: 'ENTRY', pre: 0, post: 1, sol: 5 });
  await h.flush();
  h.c._skip('OLD1', 'old coin');
  t = await h.c.statusText();
  assert.match(t, /💰 Last buy: <b>0\.1\d* SOL<\/b> on .+ ago\)/);
  assert.doesNotMatch(t, new RegExp(h.c.kp.publicKey), 'no wallet address');
  assert.doesNotMatch(t, /Buys scaled|slippage|mirrors his sells|⚙️/, 'no settings line');
  assert.doesNotMatch(t, /Last skip/);
  assert.match(t, /<code>ST<\/code>/, 'coin address stays (for /sell and /hold)');
});

test('brand-new pool with no route yet: the buy keeps retrying until Jupiter finds it; stops if he sells out', async () => {
  const h = harness({ cfg: { sizeMode: 'fixed', buySol: 0.1, routeWaitMs: 8000 }, bal: 100 });
  await h.c.refreshBalance();
  let noRouteLeft = 2;
  const real = h.c.swapper.trade.bind(h.c.swapper);
  h.c.swapper.trade = async (req, pre) => {
    if (req.action === 'buy' && noRouteLeft > 0) {
      noRouteLeft--;
      throw Object.assign(new Error('Jupiter 400: No routes found · PumpPortal 400: Bad Request'), { noRoute: true });
    }
    return real(req, pre);
  };
  h.c.onSignal({ ev: h.ev('NEWPOOL'), kind: 'ENTRY', pre: 0, post: 1, sol: 45 });
  await sleep(4000);
  await h.flush();
  assert.equal(h.trades.filter((t) => t.action === 'buy').length, 1, 'bought once the route appeared');
  assert.match(h.sent.join('\n'), /COPY BUY WAITING/);
  assert.match(h.sent.join('\n'), /COPY BUY<\/b>/);
  // never routable, and he sells out meanwhile -> gives up instead of buying his exit
  noRouteLeft = 1e9;
  h.c.onSignal({ ev: h.ev('DUD'), kind: 'ENTRY', pre: 0, post: 1, sol: 28 });
  await sleep(500);
  h.c.onSignal({ ev: h.ev('DUD'), kind: 'EXIT', pre: 1, post: 0, sol: 86 });
  await sleep(2500);
  await h.flush();
  assert.match(h.sent.join('\n'), /COPY BUY FAILED<\/b> <b>\$DUD/);
  assert.equal(h.trades.filter((t) => t.action === 'buy').length, 1);
});

test('a coin found in our wallet that he holds (bought by hand / landed late) is taken over with its real cost', async () => {
  const h = harness({ cfg: { sizeMode: 'fixed', buySol: 0.1 }, bal: 100 });
  const me = h.c.kp.publicKey;
  h.c.targets = ['HIS'];
  const tok = (mint, ui) => ({ pubkey: 'acct-' + mint, account: { data: { parsed: { info: { mint, tokenAmount: { uiAmount: ui } } } } } });
  h.c.rpc.call = async (m, p) => {
    if (m === 'getTokenAccountsByOwner') return { value: p[1].programId.startsWith('Tokenz') ? [tok('MANUAL', 47388), tok('SPAM', 5)] : [] };
    if (m === 'getSignaturesForAddress') return p[0] === 'acct-MANUAL' ? [{ signature: 'b1' }, { signature: 'b2' }, { signature: 'f1', err: {} }] : [];
    if (m === 'getBalance') return { value: 100e9 };
    return null;
  };
  h.c.rpc.getTokenBalance = async (owner, mint) => ({ ui: owner === 'HIS' && mint === 'MANUAL' ? 1e6 : 0 });
  const bal = (amt) => [{ owner: me, mint: 'MANUAL', uiTokenAmount: { uiAmountString: String(amt) } }];
  h.c.rpc.getTransaction = async (sig) => ({
    b1: { transaction: { message: { accountKeys: [me] } }, meta: { preBalances: [1e9], postBalances: [1e9 - 12.6e6], preTokenBalances: [], postTokenBalances: bal(4267) } },
    b2: { transaction: { message: { accountKeys: [me] } }, meta: { preBalances: [1e9], postBalances: [1e9 - 101.1e6], preTokenBalances: bal(4267), postTokenBalances: bal(47388) } },
  })[sig];
  await h.c.adoptStrays();
  const p = h.c.positions.MANUAL;
  assert.ok(p, 'taken over');
  assert.equal(p.tokens, 47388);
  assert.ok(Math.abs(p.costSol - 0.1137) < 1e-6, String(p.costSol));
  assert.equal(h.c.positions.SPAM, undefined, "a coin he doesn't hold is ignored");
  assert.match(h.sent.join('\n'), /TAKING OVER/);
  // and it now follows his sells
  h.tokens.MANUAL = 47388;
  h.c.onSignal({ ev: h.ev('MANUAL'), kind: 'EXIT', pre: 1, post: 0, sol: 5 });
  await sleep(50);
  await h.flush();
  assert.equal(h.trades.filter((t) => t.action === 'sell' && t.mint === 'MANUAL').length, 1);
});

test('small buys of his: buy at least 0.1 SOL (COPY_FLOOR_BUY_SOL), caps still apply', async () => {
  const h = harness({ cfg: { ...SCALE, floorBuySol: 0.1 }, bal: 100 });
  await h.c.refreshBalance();
  assert.equal(h.c.sizeFor(0.005, 'A'), 0.1, 'tiny buy -> 0.1');
  assert.equal(h.c.sizeFor(0.1, 'A'), 0.1, '0.1 SOL of his -> 0.05 scaled -> 0.1');
  assert.equal(h.c.sizeFor(1, 'A'), 0.5, 'bigger buys unchanged');
  const small = harness({ cfg: { ...SCALE, floorBuySol: 0.1 }, bal: 0.3 });
  await small.c.refreshBalance();
  assert.equal(small.c.sizeFor(0.01, 'A'), 0.06, 'never more than 20% of the wallet');
});

test("PumpPortal fallback is simulated first: a coin priced in another token (UnsupportedQuoteMint) isn't sent, it waits for a route", async () => {
  const kp = loadKeypair(newKey().b58);
  let simErr = { InstructionError: [2, { Custom: 6063 }] };
  const rpc = { call: async (m) => (m === 'simulateTransaction' ? { value: { err: simErr, logs: ['Program log: AnchorError caused by account: bonding_curve. Error Code: UnsupportedQuoteMint. Error Number: 6063. Error Message: Unsupported quote mint.'] } } : null) };
  const s = new Swapper({ rpc, kp, jupBase: 'http://x', portalBase: 'http://y', slippage: 25, priorityFee: 0.0005 });
  s._jupBuild = async () => {
    throw Object.assign(new Error('Jupiter 400: No routes found'), { noRoute: true });
  };
  s._portalBuild = async () => new Uint8Array(10);
  await assert.rejects(s.build({ action: 'buy', mint: 'M', amount: 0.1 }), (e) => e.noRoute === true && /UnsupportedQuoteMint|Unsupported quote mint/.test(e.message));
  simErr = null; // a normal coin: PumpPortal's transaction is used
  assert.equal((await s.build({ action: 'buy', mint: 'M', amount: 0.1 })).length, 10);
});

test('after COPY_MAX_HOLD_HOURS (8h) the rest is sold; a good trip gets a COOKED alert', async () => {
  const h = harness({ cfg: { sizeMode: 'fixed', buySol: 0.1, maxHoldHours: 8, tpLadder: [{ x: 2, pct: 50 }] }, bal: 100 });
  await h.c.refreshBalance();
  let px = 0;
  h.c.coins.pricesSol = async () => ({ HOLD: px });
  h.c.onSignal({ ev: h.ev('HOLD'), kind: 'ENTRY', pre: 0, post: 1, sol: 5 });
  await h.flush();
  const p = h.c.positions.HOLD;
  px = (p.costSol / 1000) * 1.5;
  await h.c.checkTakeProfit();
  await h.flush();
  assert.equal(h.trades.filter((t) => t.action === 'sell').length, 0, 'not yet 8h');
  p.openedAt = Date.now() - 8.1 * 3600000;
  p.proceedsSol = p.costSol * 3; // say the ladder already banked 3x along the way
  await h.c.checkTakeProfit();
  await h.flush();
  await h.c.checkTakeProfit(); // never sold twice
  await h.flush();
  const sells = h.trades.filter((t) => t.action === 'sell');
  assert.deepEqual(sells.map((t) => t.amount), ['100%']);
  assert.equal(h.c.positions.HOLD, undefined, 'position closed');
  const msg = h.sent.join('\n');
  assert.match(msg, /8H UP — SOLD ALL/);
  assert.doesNotMatch(msg, /COPY_MAX_HOLD_HOURS|closing the position/, 'no settings name / extra line');
  assert.doesNotMatch(msg, /· held /, '8h is implied, no held time');
  assert.doesNotMatch(h.sent.find((m) => /8H UP/.test(m)), /<code>HOLD<\/code>/, 'no address at the bottom');
  assert.match(msg, /COOKED \d+\.\dx<\/b> on <b>\$HOL/);
});

test('8h auto-sell: warns 30 min before with a /hold command; /hold keeps the coin, /unhold brings it back', async () => {
  const h = harness({ cfg: { sizeMode: 'fixed', buySol: 0.1, maxHoldHours: 8, tpLadder: [] }, bal: 100 });
  await h.c.refreshBalance();
  let prices = {};
  h.c.coins.pricesSol = async () => prices;
  h.c.onSignal({ ev: h.ev('KEEP'), kind: 'ENTRY', pre: 0, post: 1, sol: 5 });
  await h.flush();
  const p = h.c.positions.KEEP;
  p.openedAt = Date.now() - 7.7 * 3600000;
  prices = { KEEP: (p.costSol / p.tokens) * 1.4 }; // the bag is worth 1.4x what it cost (under any take-profit)
  await h.c.checkTakeProfit();
  await sleep(20);
  const warn = h.sent.join('\n');
  assert.match(warn, /gets sold in ~\d+ min \(8h limit\).*\/hold KEEP/s);
  assert.match(warn, /you'd get <b>~[\d.]+ SOL<\/b>/, 'shows the SOL the sale would bring');
  assert.match(warn, /<b>\+[\d.]+ SOL<\/b> profit \(1\.40x\)/, 'shows the trip profit');
  await h.flush();
  assert.equal(h.c.setKeep('KEEP', true), true);
  p.openedAt = Date.now() - 9 * 3600000;
  p.hist = [{ t: Date.now(), x: 5 }]; // even a dump doesn't sell a held coin
  await h.c.checkTakeProfit();
  await h.flush();
  assert.equal(h.trades.filter((t) => t.action === 'sell').length, 0, 'kept');
  h.c.setKeep('KEEP', false);
  await h.c.checkTakeProfit();
  await h.flush();
  assert.equal(h.trades.filter((t) => t.action === 'sell').length, 1, 'sold after /unhold');
  assert.equal(h.c.setKeep('NOPE', true), false);
});

test('8h warning on a losing bag shows the loss as negative: -SOL loss (-x)', async () => {
  const h = harness({ cfg: { sizeMode: 'fixed', buySol: 0.1, maxHoldHours: 8, tpLadder: [], protect: false }, bal: 100 });
  await h.c.refreshBalance();
  let prices = {};
  h.c.coins.pricesSol = async () => prices;
  h.c.onSignal({ ev: h.ev('LOSE'), kind: 'ENTRY', pre: 0, post: 1, sol: 5 });
  await h.flush();
  const p = h.c.positions.LOSE;
  p.openedAt = Date.now() - 7.7 * 3600000;
  prices = { LOSE: (p.costSol / p.tokens) * 0.6 };
  await h.c.checkTakeProfit();
  await sleep(20);
  assert.match(h.sent.join('\n'), /🔴 <b>-[\d.]+ SOL<\/b> loss \(-0\.40x\)/);
});

test('dying coin: fast dump from its recent high, giving back 40% from the top, or sliding back to entry -> sell everything', async () => {
  const mk = async () => {
    const h = harness({ cfg: { sizeMode: 'fixed', buySol: 0.1, tpLadder: [{ x: 2, pct: 50 }] }, bal: 100 });
    await h.c.refreshBalance();
    let px = 0;
    h.c.coins.pricesSol = async () => ({ DIE: px });
    h.c.onSignal({ ev: h.ev('DIE'), kind: 'ENTRY', pre: 0, post: 1, sol: 5 });
    await h.flush();
    const cost = h.c.positions.DIE.costSol;
    h.at = async (x) => {
      px = (cost / 1000) * x;
      await h.c.checkTakeProfit();
      await h.flush();
      return h.trades.filter((t) => t.action === 'sell').map((t) => t.amount);
    };
    return h;
  };
  // 1) the $1.3M -> $500K case: 2.6x then 1.0x within minutes -> sell all (after the 2x rung took half)
  let h = await mk();
  assert.deepEqual(await h.at(1.4), []);
  assert.deepEqual(await h.at(2.6), ['50%']);
  assert.deepEqual(await h.at(1.0), ['50%', '100%']);
  assert.match(h.sent.join('\n'), /DUMPING — SOLD ALL/);
  // 2) slow bleed after a run: 1.8x top, slowly back to 1.15x -> profit lock
  h = await mk();
  await h.at(1.8);
  const p = h.c.positions.DIE;
  p.hist = []; // the top was long ago (no "fast dump")
  assert.deepEqual(await h.at(1.6), []);
  p.hist = [];
  assert.deepEqual(await h.at(1.1), ['100%']);
  assert.match(h.sent.join('\n'), /PROFIT LOCK — SOLD ALL/);
  // 3) normal wiggles don't sell
  h = await mk();
  for (const x of [1.2, 1.1, 1.3, 1.05, 1.25]) assert.deepEqual(await h.at(x), []);
});

test('coins launched long ago (e.g. a month) are never copied, even as his brand-new entry', async () => {
  const h = harness({ cfg: { sizeMode: 'fixed', buySol: 0.1, onlyNewCoins: true, maxCoinAgeMs: 3 * 3600000 }, bal: 100 });
  await h.c.refreshBalance();
  h.c.coins.ageMs = async (m) => (m === 'OLDLAUNCH' ? 30 * 86400000 : m === 'FRESHLAUNCH' ? 5 * 60000 : 0);
  h.c.rpc.call = async (m) => (m === 'getTokenAccountsByOwner' ? { value: [] } : m === 'getBalance' ? { value: 100e9 } : null); // his first buy of both
  h.c.onSignal({ ev: { ...h.ev('OLDLAUNCH'), wallet: 'HIS' }, kind: 'ENTRY', pre: 0, post: 1, sol: 5 });
  h.c.onSignal({ ev: { ...h.ev('FRESHLAUNCH'), wallet: 'HIS' }, kind: 'ENTRY', pre: 0, post: 1, sol: 5 });
  await sleep(300);
  await h.flush();
  assert.deepEqual(h.trades.filter((t) => t.action === 'buy').map((t) => t.mint), ['FRESHLAUNCH']);
  assert.match(h.sent.join('\n'), /BOT SKIPPED.*launched 30\.0d ago — only new coins/s);
});

test('a buy that fails on-chain on slippage (launch pumping) is retried at double slippage', async () => {
  const h = harness({ cfg: { sizeMode: 'fixed', buySol: 0.1, slippage: 25, maxSlippage: 50 }, bal: 100 });
  await h.c.refreshBalance();
  let fails = 1;
  const real = h.c.swapper.trade.bind(h.c.swapper);
  const seen = [];
  h.c.swapper.trade = async (req, pre) => {
    seen.push(req.slippage ?? null);
    if (req.action === 'buy' && fails-- > 0) throw Object.assign(new Error('transaction failed on-chain: price moved more than your slippage'), { onChain: true, sig: 'x' });
    return real(req, pre);
  };
  h.c.onSignal({ ev: h.ev('PUMPING'), kind: 'ENTRY', pre: 0, post: 1, sol: 30 });
  await sleep(100);
  await h.flush();
  assert.deepEqual(seen, [null, 50]);
  assert.ok(h.c.positions.PUMPING, 'bought on the retry');
});

test('V2.11 smart size: x1.5 / x2 / x0.5 of the normal buy, still capped by COPY_MAX_WALLET_PERCENT; the buy alert says why', async () => {
  const h = harness({ cfg: { sizeMode: 'fixed', buySol: 0.1, maxBuySol: 0.1, maxWalletPct: 20, shortAlerts: true, protect: false }, bal: 1 });
  await h.c.refreshBalance();
  assert.equal(h.c.scaled(0.1, 1.5, 'X'), 0.15);
  assert.equal(h.c.scaled(0.1, 2, 'X'), 0.2);
  assert.equal(h.c.scaled(0.15, 2, 'X'), 0.2, '20% of 1 SOL');
  assert.equal(h.c.scaled(0.1, 0.5, 'X'), 0.05);
  assert.equal(h.c.scaled(0.006, 0.5, 'X'), 0.005, 'never under the smallest buy');
  assert.equal(h.c.scaled(0.1, undefined, 'X'), 0.1);
  h.c.onSignal({ ev: h.ev('BIG1', { sizeX: 1.5, sizeWhy: '👥 2 traders in (1.5x size)' }), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await h.flush();
  await sleep(20);
  assert.equal(h.trades.find((t) => t.action === 'buy' && t.mint === 'BIG1').amount, 0.15);
  assert.ok(h.sent.some((m) => /Bought <b>\$BIG<\/b>.*👥 2 traders in \(1\.5x size\)/.test(m)), h.sent.join('\n'));
});

test('V2.11 best exit per trader: the exit picked from the pretend wallets is used for his coins (settings you approved still win)', async () => {
  const h = harness({ cfg: { sizeMode: 'fixed', buySol: 0.1, miniCook: false, protect: false, tpX: 0, tpPercent: 0, quickTpX: 0 }, bal: 100 });
  h.c.traderOf = (w) => ({ DW: 'dilly' })[w] || 'x';
  h.c.exitPick = { dilly: { miniFromX: 1.5, miniToX: 1.5, miniPullbackPct: 1, miniPct: 100, exitStyle: 't15' } };
  await h.c.refreshBalance();
  h.c.onSignal({ ev: h.ev('E1', { wallet: 'DW' }), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  h.c.onSignal({ ev: h.ev('E2', { wallet: 'OTHER' }), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await h.flush();
  await sleep(20);
  const px = {};
  h.c.coins.pricesSol = async () => px;
  const at = async (x) => {
    for (const m of ['E1', 'E2']) px[m] = (h.c.positions[m].costSol / h.c.positions[m].tokens) * x;
    await h.c.checkTakeProfit();
    await h.flush();
    return h.trades.filter((t) => t.action === 'sell').map((t) => t.mint);
  };
  assert.deepEqual(await at(1.3), []);
  assert.deepEqual(await at(1.55), ['E1'], "dilly's coin sold at 1.5x, the other trader's coin keeps its normal rules");
});

test('V2.11.2 neutral traders: only buy while the last COPY_HOT_RESERVE open slots are free; hot traders can use them', async () => {
  const h = harness({ cfg: { sizeMode: 'fixed', buySol: 0.1, maxOpen: 4, hotReserve: 2, protect: false }, bal: 100 });
  await h.c.refreshBalance();
  const buys = () => h.trades.filter((t) => t.action === 'buy').map((t) => t.mint);
  for (const m of ['N1', 'N2', 'N3']) {
    h.c.onSignal({ ev: h.ev(m, { tier: 'neutral' }), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
    await h.flush();
    await sleep(20);
  }
  assert.deepEqual(buys(), ['N1', 'N2'], 'third neutral buy: the last 2 of 4 slots are kept for hot traders');
  for (const m of ['H1', 'H2', 'H3']) {
    h.c.onSignal({ ev: h.ev(m, { tier: 'hot' }), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
    await h.flush();
    await sleep(20);
  }
  assert.deepEqual(buys(), ['N1', 'N2', 'H1', 'H2'], 'hot traders fill the kept slots (then the normal 4-position limit)');
});

test('V2.11.5 a trader removed for being cold a week is not followed at all after a restart (the main trader never is)', { skip: !WS_LIB, timeout: 60000 }, async () => {
  const w = await startWorld(WS_LIB);
  try {
    fs.writeFileSync(path.join(w.tmp, 'retired.json'), JSON.stringify({ dilly: { wallets: ['G9gmk9msvd6wT4hDJFm64vKra5z82YvD9je9WqjBvnuk'], at: 1 }, slingoor: { wallets: [], at: 1 } }));
    w.startBot({ TRADERS: 'dilly:G9gmk9msvd6wT4hDJFm64vKra5z82YvD9je9WqjBvnuk,schoen:5hAgYC8TJCcEZV7LTXAzkTrm7YL29YXyQQJPCNrG84zM', USE_PUMPFUN: 'off' });
    await w.waitFor('started', () => /Starting tracker for/.test(w.out));
    const line = w.out.split('\n').find((l) => /Starting tracker for/.test(l));
    assert.match(line, /5hAg…/, 'schoen still followed');
    assert.doesNotMatch(line, /G9gm…/, 'dilly removed');
    await w.waitFor('chain subscribed', () => w.WS.subs.logsSubscribe);
    assert.doesNotMatch(w.out, /Unhandled|TypeError|ReferenceError/);
  } finally {
    await w.close();
  }
});

test('V2.11.5/6 cold for a week: removed with a message and his wallet; one that made you 1+ SOL is kept', { skip: !WS_LIB, timeout: 60000 }, async () => {
  const w = await startWorld(WS_LIB);
  try {
    const DIL = 'G9gmk9msvd6wT4hDJFm64vKra5z82YvD9je9WqjBvnuk';
    const SCH = '5hAgYC8TJCcEZV7LTXAzkTrm7YL29YXyQQJPCNrG84zM';
    const closed = [];
    for (const t of ['dilly', 'schoen']) for (let i = 0; i < 12; i++) closed.push({ key: `${t}|main|C${t}${i}`, trader: t, style: 'main', pnl: -0.02, x: 0.8, why: 'stop loss', at: Date.now() - 60000, held: 1 });
    fs.writeFileSync(path.join(w.tmp, 'ghosts.json'), JSON.stringify({ open: {}, closed, since: Date.now() - 9 * 86400000, life: { schoen: 2.5, dilly: -0.24 } }));
    const week = Date.now() - 8 * 86400000;
    fs.writeFileSync(path.join(w.tmp, 'rotate.json'), JSON.stringify({ on: true, copying: [], tiers: {}, firstSeen: { dilly: 1, schoen: 1 }, coldSince: { dilly: week, schoen: week }, log: [] }));
    const k = newKey();
    w.startBot({ AUTO_ROTATE: 'on', ROTATE_FIRST_MS: '5000', TRADERS: `dilly:${DIL},schoen:${SCH}`, USE_PUMPFUN: 'off', QUICK_WALLETS: 'off', COPY_TRADE: 'on', COPY_PRIVATE_KEY: k.b58, JUPITER_API_KEY: 'test-key', COPY_JITO: 'off' });
    await w.waitFor('started', () => /Starting tracker for/.test(w.out));
    w.tgPush('/start');
    await w.waitFor('registered', () => w.sent(/You're set/).length);
    await w.waitFor('removed', () => w.sent(/🗑 Removed <b>dilly<\/b>/).length, 20000);
    const m = String(w.sent(/🗑 Removed/)[0].text);
    assert.match(m, /cold for 8 days/);
    assert.match(m, new RegExp(DIL));
    assert.doesNotMatch(m, /schoen/, 'schoen made +2.5 SOL: kept');
    assert.match(w.out, /schoen is cold for a week but made \+2\.5\d* SOL — kept/);
    // V2.11.14 /ghosts is a short trader list when auto-rotate is on
    w.tgPush('/ghosts');
    await w.waitFor('/ghosts short', () => w.sent(/👻 <b>Traders<\/b> \(last 30 pretend trades\)/).length, 15000);
    const g = String(w.sent(/👻 <b>Traders<\/b>/)[0].text);
    assert.match(g, /🧊 <b>schoen<\/b> -0\.24 \(12\)/);
    assert.ok(g.split('\n').length < 12, 'short');
    w.tgPush('/ghosts full');
    await w.waitFor('/ghosts full', () => w.sent(/Ghost wallets/).length, 15000);
    const ret = JSON.parse(fs.readFileSync(path.join(w.tmp, 'retired.json'), 'utf8'));
    assert.deepEqual(Object.keys(ret), ['dilly']);
    assert.doesNotMatch(w.out, /Unhandled|TypeError|ReferenceError/);
  } finally {
    await w.close();
  }
});

test('V2.11.10 paper bank: a side wallet above its starting SOL sends the extra to main (like a real transfer); main never buys', { skip: !WS_LIB, timeout: 60000 }, async () => {
  const w = await startWorld(WS_LIB);
  const k = newKey();
  try {
    fs.writeFileSync(path.join(w.tmp, 'paper-mode.json'), JSON.stringify({ on: true, reset: false, layout298: true, layout2119: true, layout21110: true, layout21114: true, layout21115: true, layout21127: true, layout21128: true, mainBank: true, random: { total: 1, main: 0, sides: 10 } }));
    const start = { main: 0, W2: 0.1, W3: 0.1 };
    fs.writeFileSync(path.join(w.tmp, 'paper-book.json'), JSON.stringify({ startedAt: Date.now() - 3600000, start, wallets: { main: { sol: 0, tokens: {} }, W2: { sol: 0.25, tokens: {} }, W3: { sol: 0.105, tokens: {} } } }));
    w.startBot({ PAPER_BANK_MS: '1000', QUICK_WALLETS: 'on', COPY_TRADE: 'on', COPY_PRIVATE_KEY: k.b58, JUPITER_API_KEY: 'test-key', COPY_JITO: 'off', USE_PUMPFUN: 'off' });
    await w.waitFor('bank', () => /Paper bank: W2 sent 0\.1[45]\d* SOL to main/.test(w.out), 20000);
    assert.doesNotMatch(w.out, /W3 sent/, 'W3 made under 0.01: stays');
    const book = JSON.parse(fs.readFileSync(path.join(w.tmp, 'paper-book.json'), 'utf8'));
    assert.ok(Math.abs(book.wallets.main.sol - 0.149995) < 1e-6, `main ${book.wallets.main.sol}`);
    assert.ok(Math.abs(book.wallets.W2.sol - 0.1) < 1e-6, 'W2 keeps its starting 0.1 to trade with');
    assert.doesNotMatch(w.out, /Unhandled|TypeError|ReferenceError/);
  } finally {
    await w.close();
  }
});

test('V2.11.12 /daygoal: shows and sets the daily goal from Telegram', { skip: !WS_LIB, timeout: 60000 }, async () => {
  const w = await startWorld(WS_LIB);
  const k = newKey();
  try {
    w.startBot({ DAILY_GOAL_SOL: '1', COPY_TRADE: 'on', COPY_PRIVATE_KEY: k.b58, JUPITER_API_KEY: 'test-key', COPY_JITO: 'off', USE_PUMPFUN: 'off' });
    await w.waitFor('copy live', () => /Copy trading LIVE/.test(w.out));
    w.tgPush('/start');
    await w.waitFor('registered', () => w.sent(/You're set/).length);
    w.tgPush('/daygoal');
    await w.waitFor('/daygoal', () => w.sent(/🏁 Daily goal 1 SOL: today \+0\.000 \(0%\) · tomorrow 1\.5/).length, 15000);
    w.tgPush('/daygoal 2');
    await w.waitFor('/daygoal 2', () => w.sent(/🏁 Daily goal 2 SOL/).length, 15000);
    w.tgPush('/daygoal off');
    await w.waitFor('/daygoal off', () => w.sent(/No daily goal/).length, 15000);
    assert.doesNotMatch(w.out, /Unhandled|TypeError|ReferenceError/);
  } finally {
    await w.close();
  }
});

test('V2.11.14 /paper random 1 0 10: all 10 side wallet slots trade again', { skip: !WS_LIB, timeout: 60000 }, async () => {
  const w = await startWorld(WS_LIB);
  const k = newKey();
  try {
    fs.writeFileSync(path.join(w.tmp, 'paper-mode.json'), JSON.stringify({ on: false, layout298: true, layout2119: true, layout21110: true, layout21114: true, layout21115: true, layout21127: true, layout21128: true, mainBank: true, random: { total: 1, main: 0, sides: 3 } }));
    w.startBot({ COPY_TRADE: 'on', COPY_PRIVATE_KEY: k.b58, JUPITER_API_KEY: 'test-key', COPY_JITO: 'off', USE_PUMPFUN: 'off' });
    await w.waitFor('copy live', () => /Copy trading LIVE/.test(w.out));
    w.tgPush('/start');
    await w.waitFor('registered', () => w.sent(/You're set/).length);
    w.tgPush('/paper random 1 0 10');
    await w.waitFor('random', () => w.sent(/Paper starts: main 0 SOL, 10 side wallets random, 1 SOL in total/).length, 15000);
    const pm = JSON.parse(fs.readFileSync(path.join(w.tmp, 'paper-mode.json'), 'utf8'));
    assert.deepEqual(pm.random, { total: 1, main: 0, sides: 10 });
    assert.doesNotMatch(w.out, /Unhandled|TypeError|ReferenceError/);
  } finally {
    await w.close();
  }
});

test('V2.11.18 hold trader (kimchi): the main wallet holds his coin — 25% off at 2x, no 8h limit, only a -75% stop loss', async () => {
  const hold = { miniFromX: 2, miniToX: 2, miniPullbackPct: 1, miniPct: 25, stopLossX: 0.25 };
  const h = harness({ cfg: { sizeMode: 'fixed', buySol: 0.05, holdRules: { kimchi: hold }, quickFromX: 1.25, quickToX: 1.25, quickPullbackPct: 1, tpX: 0, quickTpX: 0, maxHoldHours: 8, protect: true, deadCoin: true }, bal: 100 });
  h.c.traderOf = (w) => ({ KIM: 'kimchi' })[w] || 'x';
  h.c.quickFor = new Set(['x']); // the other trader's coins: quick profit
  await h.c.refreshBalance();
  h.c.onSignal({ ev: h.ev('K1', { wallet: 'KIM' }), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  h.c.onSignal({ ev: h.ev('O1', { wallet: 'OTHER' }), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await h.flush();
  await sleep(20);
  const px = {};
  h.c.coins.pricesSol = async () => px;
  const at = async (m, x) => {
    const p = h.c.positions[m];
    px[m] = (p.costSol / (p.boughtTokens || p.tokens)) * x; // x of what the coins still held cost
    await h.c.checkTakeProfit();
    await h.flush();
    return h.trades.filter((t) => t.action === 'sell').map((t) => `${t.mint} ${t.amount}`);
  };
  assert.deepEqual(await at('O1', 1.3), ['O1 100%'], 'another trader\'s coin: quick profit');
  assert.deepEqual(await at('K1', 1.3), ['O1 100%'], "kimchi's coin: held");
  assert.deepEqual(await at('K1', 2.05), ['O1 100%', 'K1 25%'], '25% off at 2x');
  assert.deepEqual(await at('K1', 2.5), ['O1 100%', 'K1 25%'], 'the rest rides');
  h.c.positions.K1.openedAt = Date.now() - 20 * 3600000; // way past 8h: no time limit for him
  assert.deepEqual(await at('K1', 0.5), ['O1 100%', 'K1 25%'], 'down 50%: no stop loss yet, no 8h sell');
  await at('K1', 0.2);
  assert.deepEqual(await at('K1', 0.2), ['O1 100%', 'K1 25%', 'K1 100%'], '-80%: the -75% stop loss');
});

test('V2.11.19/20 likely runner (any trader): the main wallet holds it (25% off at 1.5x, the rest rides); side wallets keep their quick +25%', async () => {
  const h = harness({ cfg: { sizeMode: 'fixed', buySol: 0.05, runnerHoldRule: { miniFromX: 1.5, miniToX: 1.5, miniPullbackPct: 1, miniPct: 25, stopLossX: 0.8 }, quickFromX: 1.25, quickToX: 1.25, quickPullbackPct: 1, tpX: 0, quickTpX: 0, maxHoldHours: 8, protect: true }, bal: 100 });
  await h.c.refreshBalance();
  h.c.onSignal({ ev: h.ev('R1', { runnerHold: true }), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await h.flush();
  await sleep(20);
  assert.equal(h.c.positions.R1.runnerHold, true);
  const px = {};
  h.c.coins.pricesSol = async () => px;
  const at = async (x) => {
    const p = h.c.positions.R1;
    px.R1 = (p.costSol / (p.boughtTokens || p.tokens)) * x;
    await h.c.checkTakeProfit();
    await h.flush();
    return h.trades.filter((t) => t.action === 'sell').map((t) => t.amount);
  };
  assert.deepEqual(await at(1.3), [], 'main wallet: no early sell');
  assert.deepEqual(await at(1.55), ['25%'], '25% off at 1.5x');
  assert.deepEqual(await at(3), ['25%'], 'the rest rides');
  // a side wallet (quick mode) on the same kind of coin: still sells 100% at +25%
  const s = harness({ cfg: { sizeMode: 'fixed', buySol: 0.05, runnerHoldRule: { miniFromX: 1.5, miniToX: 1.5, miniPullbackPct: 1, miniPct: 25, stopLossX: 0.8 }, holdRules: { x: { miniFromX: 2, miniToX: 2, miniPullbackPct: 1, miniPct: 25, stopLossX: 0.25 } }, quickFromX: 1.25, quickToX: 1.25, quickPullbackPct: 1, tpX: 0, quickTpX: 0, protect: false }, bal: 100 });
  s.c.quickMode = true;
  await s.c.refreshBalance();
  s.c.onSignal({ ev: s.ev('R2', { runnerHold: true }), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await s.flush();
  await sleep(20);
  const p2 = s.c.positions.R2;
  s.c.coins.pricesSol = async () => ({ R2: (p2.costSol / p2.tokens) * 1.3 });
  await s.c.checkTakeProfit();
  await s.flush();
  assert.deepEqual(s.trades.filter((t) => t.action === 'sell').map((t) => t.amount), ['100%'], 'side wallet: quick +25% as always');
});

test('V2.11.21 side wallets start with the +50%..+100% sell range', { skip: !WS_LIB, timeout: 60000 }, async () => {
  const w = await startWorld(WS_LIB);
  const k = newKey();
  try {
    fs.writeFileSync(path.join(w.tmp, 'paper-mode.json'), JSON.stringify({ on: true, reset: true, layout298: true, layout2119: true, layout21110: true, layout21114: true, layout21115: true, layout21127: true, layout21128: true, start: { main: 0.1, W2: 0.3, W3: 0.3, W4: 0.3 } }));
    w.startBot({ SIDE_TAKE_FROM_X: '1.5', SIDE_TAKE_TO_X: '2', SIDE_TAKE_PULLBACK_PERCENT: '10', COPY_TRADE: 'on', COPY_PRIVATE_KEY: k.b58, JUPITER_API_KEY: 'test-key', COPY_JITO: 'off', USE_PUMPFUN: 'off' });
    await w.waitFor('sides', () => (w.out.match(/Quick wallet W\d LIVE \([^)]+\): 0\.050 SOL per buy, sells 100% between 1\.5x and 2x \(10% pullback\)/g) || []).length === 3, 20000);
    assert.doesNotMatch(w.out, /Unhandled|TypeError|ReferenceError/);
  } finally {
    await w.close();
  }
});

test('V2.11.22 cook alert only when that coin made money; a big cook also shows your total PnL today', async () => {
  const h = harness({ cfg: { sizeMode: 'fixed', buySol: 0.1, shortAlerts: true, lossAlerts: false, cookShowTotalSol: 0.02, protect: false }, bal: 100 });
  h.c.totalPnl = () => 12.5;
  await h.c.refreshBalance();
  h.c.onSignal({ ev: h.ev('C1'), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  h.c.onSignal({ ev: h.ev('C2'), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await h.flush();
  await sleep(20);
  // C1: sold at a profit (mock pays 0.0003 SOL per token: 1000 tokens -> 0.3 SOL for a 0.101 SOL cost)
  await h.c._sell('C1', 100, 'mini');
  assert.ok(h.sent.some((m) => /cook<\/b> on <b>\$C1<\/b> — got <b>0\.300 SOL<\/b> \(\+0\.199\)\n💰 Your PnL today: <b>\+12\.50 SOL<\/b>/.test(m)), h.sent.join('\n'));
  // C2: the same kind of sell, but at a loss -> no cook (no alert at all with loss alerts off)
  h.world.sellMult = 0.2;
  const before = h.sent.length;
  await h.c._sell('C2', 100, 'mini');
  assert.equal(h.sent.slice(before).filter((m) => /cook/.test(m)).length, 0);
  // V2.11.23 a coin in profit while your day is red: no cook either (a plain sell, summary only)
  h.c.onSignal({ ev: h.ev('C3'), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await h.flush();
  await sleep(20);
  h.world.sellMult = 1;
  h.c.totalPnl = () => -0.05;
  const b2 = h.sent.length;
  await h.c._sell('C3', 100, 'mini');
  assert.ok(h.sent.slice(b2).every((m) => !/cook/.test(m)), h.sent.slice(b2).join('\n'));
});

test('V2.11.23 fresh dev: the main wallet skips the coin; a side wallet buys it and gets out fast (+10%..+25%)', async () => {
  const dr = { known: () => ({ kind: 'fresh' }), check: async () => ({ kind: 'fresh' }), risky: (k) => k === 'fresh' };
  const m = harness({ cfg: { sizeMode: 'fixed', buySol: 0.1 }, bal: 100 });
  m.c.devRisk = dr;
  await m.c.refreshBalance();
  m.c.onSignal({ ev: m.ev('F1'), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await m.flush();
  await sleep(20);
  assert.equal(m.trades.filter((t) => t.action === 'buy').length, 0, 'main: skipped');
  const s = harness({ cfg: { sizeMode: 'fixed', buySol: 0.05, quickFromX: 1.5, quickToX: 2, quickPullbackPct: 10, freshFromX: 1.1, freshToX: 1.25, freshPullbackPct: 5, tpX: 0, quickTpX: 0, protect: false }, bal: 100 });
  s.c.quickMode = true;
  s.c.devRisk = dr;
  await s.c.refreshBalance();
  s.c.onSignal({ ev: s.ev('F1'), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await s.flush();
  await sleep(20);
  assert.equal(s.c.positions.F1.freshDev, true, 'side wallet: bought, marked');
  const p = s.c.positions.F1;
  const at = async (x) => {
    s.c.coins.pricesSol = async () => ({ F1: (p.costSol / p.tokens) * x });
    await s.c.checkTakeProfit();
    await s.flush();
    return s.trades.filter((t) => t.action === 'sell').map((t) => t.amount);
  };
  assert.deepEqual(await at(1.05), []);
  assert.deepEqual(await at(1.2), [], 'armed at +10%');
  assert.deepEqual(await at(1.13), ['100%'], 'pulled back 5% from the top: all out (not waiting for +50%)');
});

test('V2.11.27 main wallet with 0.1 SOL still buys under growth sizing (what is left after fees); side wallets do not', async () => {
  const cfgG = { sizeMode: 'fixed', buySol: 0.05, growthSize: true, growthMinSol: 0.08, growthPct: 25, growthMaxPct: 50, protect: false, keepSol: 0.02, priorityFee: 0.002 };
  let h = harness({ cfg: cfgG, bal: 0.1 });
  await h.c.refreshBalance();
  h.c.onSignal({ ev: h.ev('MAIN1'), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await h.flush();
  await sleep(20);
  const b = h.trades.find((t) => t.action === 'buy');
  assert.ok(b, 'main bought');
  assert.equal(b.amount, 0.075, '0.1 minus reserve 0.02, fee 0.002, 0.003');
  h = harness({ cfg: cfgG, bal: 0.03 });
  await h.c.refreshBalance();
  h.c.onSignal({ ev: h.ev('MAIN2'), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await h.flush();
  assert.equal(h.trades.length, 0, 'under 0.02 left: skipped');
  h = harness({ cfg: { ...cfgG, quickMode: true }, bal: 0.1 });
  await h.c.refreshBalance();
  h.c.onSignal({ ev: h.ev('SIDE1'), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await h.flush();
  assert.equal(h.trades.filter((t) => t.action === 'buy').length, 0, 'side wallet keeps the 0.08 minimum');
});

test('V2.11.28 every buy at least 0.1 SOL (side wallets and main)', async () => {
  const { loadConfig } = await import('../src/config.js');
  const f = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'cfg-')), 'settings.txt');
  fs.writeFileSync(f, 'TELEGRAM_BOT_TOKEN=1:x\n');
  const c = loadConfig(f).copy;
  assert.equal(c.sideMinBuySol, 0.1);
  assert.equal(c.growthMinSol, 0.1);
  const h = harness({ cfg: { sizeMode: 'fixed', buySol: 0.05, growthSize: true, growthMinSol: c.sideMinBuySol, growthPct: 25, growthMaxPct: 50, protect: false, quickMode: true }, bal: 0.25 });
  await h.c.refreshBalance();
  assert.equal(h.c.growthAmount(), 0.1, '0.25 side wallet: 0.1 buys');
  assert.equal(h.c.scaled(0.1, 0.5, 'X'), 0.1, 'never under 0.1');
});

test('V2.11.25 growth sizing: every buy at least 0.08 SOL or 25% of the wallet; multipliers never under 0.08 or over 50%', async () => {
  const h = harness({ cfg: { sizeMode: 'fixed', buySol: 0.05, growthSize: true, growthMinSol: 0.08, growthPct: 25, growthMaxPct: 50, protect: false }, bal: 0.3 });
  await h.c.refreshBalance();
  assert.equal(h.c.growthAmount(), 0.08, '0.3 SOL wallet: 25% = 0.075 -> the 0.08 minimum');
  assert.equal(h.c.scaled(0.08, 0.5, 'X'), 0.08, 'neutral half size: still 0.08');
  assert.equal(h.c.scaled(0.08, 1.5, 'X'), 0.12);
  h.world.solBal = 1;
  await h.c.refreshBalance();
  assert.equal(h.c.growthAmount(), 0.25, '1 SOL: 0.25');
  assert.equal(h.c.scaled(0.25, 2, 'X'), 0.5, 'capped at 50% of the wallet');
  h.world.solBal = 4;
  await h.c.refreshBalance();
  assert.equal(h.c.growthAmount(), 1, '4 SOL: 1 SOL buys');
  h.c.onSignal({ ev: h.ev('G1'), kind: 'ENTRY', pre: 0, post: 1, sol: 0.2 });
  await h.flush();
  await sleep(20);
  assert.equal(h.trades.find((t) => t.action === 'buy').amount, 1, 'the real buy uses it (his size does not matter)');
});

test('V2.11.30 paper auto-restart: paper lost its profit -> alert straight away, restart paper; no trader benched', { skip: !WS_LIB, timeout: 60000 }, async () => {
  const w = await startWorld(WS_LIB);
  const k = newKey();
  try {
    fs.writeFileSync(path.join(w.tmp, 'paper-mode.json'), JSON.stringify({ on: true, reset: false, layout298: true, layout2119: true, layout21110: true, layout21114: true, layout21115: true, layout21127: true, layout21128: true, start: { main: 0.2, W2: 0.25 } }));
    const startedAt = Date.now() - 3600000;
    fs.writeFileSync(path.join(w.tmp, 'paper-book.json'), JSON.stringify({ startedAt, start: { main: 0.2, W2: 0.25 }, wallets: { main: { sol: 0.06, tokens: {} }, W2: { sol: 0.04, tokens: {} } } }));
    w.startBot({ PAPER_AUTO_RESTART_AT: '0.6', PAPER_WATCH_MS: '4000', PAPER_MIN_AGE_MS: '0', COPY_TRADE: 'on', COPY_PRIVATE_KEY: k.b58, JUPITER_API_KEY: 'test-key', COPY_JITO: 'off', USE_PUMPFUN: 'off' });
    w.tgPush('/start');
    await w.waitFor('registered', () => w.sent(/You're set/).length);
    await w.waitFor('restart', () => w.sent(/Paper restarted/).length, 20000);
    const msg = String(w.sent(/Paper restarted/)[0].text);
    assert.match(msg, /^🚨🧪 <b>Paper restarted: it lost its profit<\/b>\n<b>Paper fell to 0\.100 SOL<\/b> \(started 0\.450\)/);
    assert.doesNotMatch(msg, /not copied|benched/, 'no trader is benched for it');
    // the alert goes out first, the reset is saved right after it
    await w.waitFor('paper reset saved', () => JSON.parse(fs.readFileSync(path.join(w.tmp, 'paper-mode.json'), 'utf8')).reset === true, 10000);
    assert.doesNotMatch(w.out, /Unhandled|TypeError|ReferenceError/);
  } finally {
    await w.close();
  }
});

test('V2.11.30 market adapt: a coin of a kind losing across the market is skipped; other coins and always-copied traders are bought', async () => {
  const h = harness({ cfg: { sizeMode: 'fixed', buySol: 0.1, protect: false, alwaysCopy: ['kimchi'] }, bal: 5 });
  h.c.coins.get = async (m) => ({ name: m, symbol: m.slice(0, 3), mc: m.startsWith('BIG') ? 150000 : 20000 });
  h.c.traderOf = (w) => (w === 'KIMW' ? 'kimchi' : w === 'DILW' ? 'dilly' : null);
  h.c.marketSkip = new Set(['mc:100k+']);
  await h.c.refreshBalance();
  h.c.onSignal({ ev: h.ev('BIG1', { wallet: 'DILW' }), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  h.c.onSignal({ ev: h.ev('SMALL1', { wallet: 'DILW' }), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  h.c.onSignal({ ev: h.ev('BIG2', { wallet: 'KIMW' }), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await h.flush();
  await sleep(50);
  const bought = h.trades.filter((t) => t.action === 'buy').map((t) => t.mint).sort();
  assert.deepEqual(bought, ['BIG2', 'SMALL1']);
  assert.match(h.c.lastSkip.why, /^market: coins at \$100k\+ market cap are losing right now$/);
});

test('V2.11.30 /market: the bot reads the market from what every wallet bought and shows what it skips', { skip: !WS_LIB, timeout: 60000 }, async () => {
  const w = await startWorld(WS_LIB);
  const k = newKey();
  try {
    const now = Date.now();
    const rug = [[0, 1], [30, 0.6], [600, 0.2]];
    const pump = [[0, 1], [30, 1.3], [60, 1.6], [90, 1.75], [120, 1.5], [600, 1.2]];
    const coins = [];
    for (let i = 0; i < 12; i++) coins.push({ at: now - 3600000, keys: ['mc:100k+', 'narr:none'], pts: rug });
    for (let i = 0; i < 30; i++) coins.push({ at: now - 3600000, keys: ['mc:10-30k', 'narr:animal'], pts: pump });
    // V2.11.36 slingoor's coins dip right after his buy, then climb: the bot learns to buy him later
    const dip = [[0, 1], [5, 0.9], [10, 0.82], [15, 0.8], [20, 0.8], [30, 0.9], [45, 1], [60, 1.05], [120, 0.95], [300, 0.7]];
    const sc = Array.from({ length: 20 }, () => ({ at: now - 3600000, keys: [], pts: dip }));
    fs.writeFileSync(path.join(w.tmp, 'learn.json'), JSON.stringify({ live: {}, post: {}, done: {}, shadow: {}, coins: { dilly: coins, slingoor: sc } }));
    w.startBot({ CAUTIOUS_HOURS: 'on', MARKET_ADAPT: 'on', MARKET_MS: '1000', QUICK_WALLETS: 'on', COPY_TRADE: 'on', COPY_PRIVATE_KEY: k.b58, JUPITER_API_KEY: 'test-key', COPY_JITO: 'off', USE_PUMPFUN: 'off' });
    await w.waitFor('market read', () => /Market adapt \(\d+ coins, 6h\): skipping /.test(w.out), 20000);
    await w.waitFor('buy time', () => /Market adapt: slingoor bought (10|15|20)s after him \(20 coins, \+[\d.]+ SOL better\)/.test(w.out), 20000);
    w.tgPush('/start');
    await w.waitFor('registered', () => w.sent(/You're set/).length);
    w.tgPush('/market');
    await w.waitFor('/market', () => w.sent(/📈 <b>Market<\/b>/).length, 15000);
    const msg = String(w.sent(/📈 <b>Market<\/b>/)[0].text);
    assert.match(msg, /last 6h, 62 coins/);
    assert.match(msg, /⏱ Buy time: slingoor \+(10|15|20)s \(others right away\)/);
    assert.match(msg, /⛔ Skipping: .*coins at \$100k\+ market cap \(0\/12\)/);
    assert.match(msg, /✅ Working: .*animal coins \(30\/30\)/);
    assert.match(msg, /🏃 Held runners: 25% off at [\d.]+x, the rest rides/);
    assert.match(msg, /🌙 Now \(\d+(am|pm)\): (normal|night — cautious|a losing hour — cautious)/);
    assert.doesNotMatch(w.out, /Unhandled|TypeError|ReferenceError/);
  } finally {
    await w.close();
  }
});

test('V2.11.32 SUGGESTIONS=off (default): no suggestions; settings approved from them before are not used', { skip: !WS_LIB, timeout: 60000 }, async () => {
  const { loadConfig } = await import('../src/config.js');
  const f = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'cfg-')), 'settings.txt');
  fs.writeFileSync(f, 'TELEGRAM_BOT_TOKEN=1:x\n');
  assert.equal(loadConfig(f).learn.suggest, false, 'off by default');
  const w = await startWorld(WS_LIB);
  const k = newKey();
  try {
    fs.writeFileSync(path.join(w.tmp, 'suggestions.json'), JSON.stringify({ pending: {}, applied: { dilly: { skip: ['mc:100k+'], miniToX: 3 } }, lastSlot: null }));
    w.startBot({ SUGGESTIONS: 'off', SUGGEST_FILE: path.join(w.tmp, 'suggestions.json'), COPY_TRADE: 'on', COPY_PRIVATE_KEY: k.b58, JUPITER_API_KEY: 'test-key', COPY_JITO: 'off', USE_PUMPFUN: 'off' });
    w.tgPush('/start');
    await w.waitFor('registered', () => w.sent(/You're set/).length);
    w.tgPush('/suggestions');
    await w.waitFor('/suggestions', () => w.sent(/Suggestions are off — the bot adapts to the market by itself/).length, 15000);
    w.tgPush('/apply');
    await w.waitFor('/apply', () => w.sent(/Suggestions are off/).length >= 2, 15000);
    assert.doesNotMatch(w.out, /Unhandled|TypeError|ReferenceError/);
  } finally {
    await w.close();
  }
});

test('V2.11.35 side wallets sell all between +10% and +25% (old SIDE_SELL_* ignored); paper refills a side wallet too low to buy', { skip: !WS_LIB, timeout: 60000 }, async () => {
  const { loadConfig } = await import('../src/config.js');
  const f = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'cfg-')), 'settings.txt');
  fs.writeFileSync(f, 'TELEGRAM_BOT_TOKEN=1:x\nSIDE_SELL_FROM_X=1.5\nSIDE_SELL_TO_X=2\n');
  const c = loadConfig(f).copy;
  assert.deepEqual([c.sideFromX, c.sideToX, c.sidePullbackPct, c.paperRefillSides], [1.15, 1.25, 5, true]);
  assert.equal(c.sidePriorityFee, 0.0005, 'side wallets tip at most 0.0005 SOL');
  assert.deepEqual([c.topUpSides, c.topUpToSol, c.topUpMainMinSol], [true, 0.25, 1], 'V2.11.38 real top-up on, to 0.25, only while main has over 1 SOL');
  const w = await startWorld(WS_LIB);
  const k = newKey();
  try {
    fs.writeFileSync(path.join(w.tmp, 'paper-mode.json'), JSON.stringify({ on: true, reset: false, layout298: true, layout2119: true, layout21110: true, layout21114: true, layout21115: true, layout21127: true, layout21128: true, bank: true, start: { main: 0.2, W2: 0.25, W3: 0.25 } }));
    fs.writeFileSync(path.join(w.tmp, 'paper-book.json'), JSON.stringify({ startedAt: Date.now() - 3600000, start: { main: 0.2, W2: 0.25, W3: 0.25 }, wallets: { main: { sol: 0.8, tokens: {} }, W2: { sol: 0.1, tokens: {} }, W3: { sol: 0.25, tokens: {} } } }));
    w.startBot({ COPY_FEE_MODE: 'fast', COPY_PRIORITY_FEE: '0.002', SIDE_PRIORITY_FEE: '0.0005', PAPER_REFILL_SIDES: 'on', SIDE_TAKE_FROM_X: '1.1', SIDE_TAKE_TO_X: '1.25', SIDE_TAKE_PULLBACK_PERCENT: '5', GROWTH_SIZE: 'on', PAPER_BANK_MS: '1000', QUICK_WALLETS: 'on', COPY_TRADE: 'on', COPY_PRIVATE_KEY: k.b58, JUPITER_API_KEY: 'test-key', COPY_JITO: 'off', USE_PUMPFUN: 'off' });
    await w.waitFor('sides', () => /Quick wallet W2 LIVE \([^)]+\): [\d.]+ SOL per buy, sells 100% between 1\.1x and 1\.25x \(5% pullback\) · tip up to 0\.0005 SOL/.test(w.out), 20000);
    await w.waitFor('refill', () => /Paper refill: main sent W2 0\.15\d* SOL/.test(w.out), 20000);
    assert.doesNotMatch(w.out, /main sent W3/, 'W3 can still buy: not topped up');
    const book = JSON.parse(fs.readFileSync(path.join(w.tmp, 'paper-book.json'), 'utf8'));
    assert.ok(Math.abs(book.wallets.W2.sol - 0.25) < 1e-6, `W2 ${book.wallets.W2.sol}`);
    assert.doesNotMatch(w.out, /Unhandled|TypeError|ReferenceError/);
  } finally {
    await w.close();
  }
});

test('V2.11.37/44 copy his style (henry): every wallet sells his coins his way — all out at his take, -10% stop, out after his hold time; main still holds a likely runner', async () => {
  const styleRules = { henry: { miniFromX: 1.05, miniToX: 1.08, miniPullbackPct: 3, miniPct: 100, stopLossX: 0.9, maxHoldMinutes: 3 } };
  const base = { sizeMode: 'fixed', buySol: 0.05, styleRules, runnerHoldRule: { miniFromX: 1.5, miniToX: 1.5, miniPullbackPct: 1, miniPct: 25, stopLossX: 0.8 }, quickFromX: 1.15, quickToX: 1.25, quickPullbackPct: 5, tpX: 0, quickTpX: 0, protect: false };
  for (const quickMode of [false, true]) {
    const h = harness({ cfg: { ...base, quickMode }, bal: 100 });
    h.c.traderOf = (w) => ({ HEN: 'henry' })[w] || 'x';
    await h.c.refreshBalance();
    h.c.onSignal({ ev: h.ev('H1', { wallet: 'HEN', runnerHold: true }), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
    h.c.onSignal({ ev: h.ev('H2', { wallet: 'HEN' }), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
    h.c.onSignal({ ev: h.ev('H3', { wallet: 'HEN' }), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
    await h.flush();
    await sleep(20);
    const px = {};
    h.c.coins.pricesSol = async () => px;
    const at = async (m, x) => {
      const p = h.c.positions[m];
      px[m] = (p.costSol / (p.boughtTokens || p.tokens)) * x;
      await h.c.checkTakeProfit();
      await h.flush();
      return h.trades.filter((t) => t.action === 'sell').map((t) => `${t.mint} ${t.amount}`);
    };
    const who = quickMode ? 'side wallet' : 'main';
    const h1 = quickMode ? ['H1 100%'] : [];
    assert.deepEqual(await at('H1', 1.09), h1, quickMode ? 'side wallet: all out at +8%' : 'main: a likely runner is held (V2.11.44), not sold his way');
    h.c.positions.H2.openedAt = Date.now() - 120000;
    await at('H2', 0.85);
    assert.deepEqual(await at('H2', 0.85), [...h1, 'H2 100%'], `${who}: -10% stop`);
    h.c.positions.H3.openedAt = Date.now() - 4 * 60000;
    assert.deepEqual(await at('H3', 1.01), [...h1, 'H2 100%', 'H3 100%'], `${who}: out after his 3 min`);
  }
});

test('V2.11.38 real trading: main tops up a side wallet that is too low to buy, any time (not just 11:55pm)', { skip: !WS_LIB, timeout: 60000 }, async () => {
  const w = await startWorld(WS_LIB);
  const k = newKey();
  const k2 = newKey();
  fs.writeFileSync(path.join(w.tmp, 'wallet-key-2.txt'), k2.b58);
  const sends = [];
  let mainSol = 0.9; // under 1 SOL: no top-up
  try {
    w.M.rpcHook = async (r) => {
      if (r.method === 'getBalance' && r.params[0] === k2.pub) return { context: { slot: 1 }, value: 0.02e9 };
      if (r.method === 'getBalance' && r.params[0] === k.pub) return { context: { slot: 1 }, value: mainSol * 1e9 };
      if (r.method === 'getLatestBlockhash') return { context: { slot: 1 }, value: { blockhash: b58encode(crypto.randomBytes(32)), lastValidBlockHeight: 99 } };
      if (r.method === 'sendTransaction') sends.push(r);
      return undefined;
    };
    w.startBot({ QUICK_WALLETS: 'on', QUICK_WALLET_KEY_FILES: path.join(w.tmp, 'wallet-key-2.txt'), TOP_UP_SIDES: 'on', TOP_UP_MS: '1000', AUTO_FUND: 'on', AUTO_FUND_REFILL: 'on', GROWTH_SIZE: 'on', COPY_TRADE: 'on', COPY_PRIVATE_KEY: k.b58, JUPITER_API_KEY: 'test-key', COPY_JITO: 'off', USE_PUMPFUN: 'off' });
    await w.waitFor('side wallet', () => /Quick wallet W2 LIVE/.test(w.out), 20000);
    await sleep(4000);
    assert.equal(sends.length, 0, 'main under 1 SOL: nothing sent');
    mainSol = 1.5;
    await w.waitFor('top-up sent', () => sends.length > 0, 20000); // the transfer from main to W2 went out
    assert.doesNotMatch(w.out, /Unhandled|TypeError|ReferenceError/);
  } finally {
    await w.close();
  }
});

test('V2.11.40 paper auto-restart: a held coin with no price counts at what it cost (not 0), and it takes 2 low checks in a row', { skip: !WS_LIB, timeout: 60000 }, async () => {
  const w = await startWorld(WS_LIB);
  const k = newKey();
  try {
    fs.writeFileSync(path.join(w.tmp, 'paper-mode.json'), JSON.stringify({ on: true, reset: false, layout298: true, layout2119: true, layout21110: true, layout21114: true, layout21115: true, layout21127: true, layout21128: true, start: { main: 0.2, W2: 0.25 } }));
    const startedAt = Date.now() - 3600000;
    const M = b58encode(crypto.randomBytes(32));
    fs.writeFileSync(path.join(w.tmp, 'paper-book.json'), JSON.stringify({ startedAt, start: { main: 0.2, W2: 0.25 }, wallets: { main: { sol: 0.06, tokens: {} }, W2: { sol: 0.04, tokens: { [M]: { ui: 1000, raw: '1000000000' } } } } }));
    fs.writeFileSync(path.join(w.tmp, 'copytrade-paper-W2.json'), JSON.stringify({ positions: { [M]: { tokens: 1000, costSol: 0.3, boughtTokens: 1000, openedAt: startedAt, leader: 'x' } } }));
    w.startBot({ PAPER_AUTO_RESTART_AT: '0.6', PAPER_WATCH_MS: '1000', PAPER_MIN_AGE_MS: '0', QUICK_WALLETS: 'on', COPY_TRADE: 'on', COPY_PRIVATE_KEY: k.b58, JUPITER_API_KEY: 'test-key', COPY_JITO: 'off', USE_PUMPFUN: 'off' });
    await w.waitFor('side wallet', () => /Quick wallet W2 LIVE/.test(w.out), 20000);
    await sleep(8000);
    assert.doesNotMatch(w.out, /Paper auto-restart/, '0.06 + 0.04 + a 0.3 SOL coin with no price = 0.4 of 0.45: no restart');
    assert.doesNotMatch(w.out, /Unhandled|TypeError|ReferenceError/);
  } finally {
    await w.close();
  }
});

test('V2.11.41 cautious hour: no wallet buys a fresh dev\'s coin (side wallets too); a normal coin is still bought', async () => {
  const dr = { known: (m) => ({ kind: m.startsWith('F') ? 'fresh' : 'ok' }), check: async (m) => ({ kind: m.startsWith('F') ? 'fresh' : 'ok' }), risky: (k) => k === 'fresh' };
  const s = harness({ cfg: { sizeMode: 'fixed', buySol: 0.05, protect: false }, bal: 100 });
  s.c.quickMode = true;
  s.c.devRisk = dr;
  await s.c.refreshBalance();
  s.c.onSignal({ ev: s.ev('F1', { cautious: true }), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  s.c.onSignal({ ev: s.ev('OK1', { cautious: true }), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await s.flush();
  await sleep(20);
  assert.deepEqual(s.trades.filter((t) => t.action === 'buy').map((t) => t.mint), ['OK1']);
  assert.match(s.c.lastSkip?.why || '', /cautious hour, no wallet buys it/);
});

test('V2.11.43 a paper restart keeps what each trader\'s copies did (for the losing-trader check)', { skip: !WS_LIB, timeout: 60000 }, async () => {
  const w = await startWorld(WS_LIB);
  const k = newKey();
  try {
    fs.writeFileSync(path.join(w.tmp, 'paper-mode.json'), JSON.stringify({ on: true, reset: true, layout298: true, layout2119: true, layout21110: true, layout21114: true, layout21115: true, layout21127: true, layout21128: true, start: { main: 0.2 } }));
    const at = Date.now() - 3600000;
    const trips = Array.from({ length: 6 }, (_, i) => ({ sym: `L${i}`, leader: 't4', pnl: -0.02, x: 0.8, at: at + i }));
    fs.writeFileSync(path.join(w.tmp, 'copytrade-paper.json'), JSON.stringify({ positions: {}, tripLog: trips }));
    fs.writeFileSync(path.join(w.tmp, 'copytrade-paper-W2.json'), JSON.stringify({ positions: {}, tripLog: [{ sym: 'W', leader: 't4', pnl: -0.01, x: 0.9, at }] }));
    w.startBot({ COPY_TRADE: 'on', COPY_PRIVATE_KEY: k.b58, JUPITER_API_KEY: 'test-key', COPY_JITO: 'off', USE_PUMPFUN: 'off' });
    await w.waitFor('paper up', () => /PAPER MODE/.test(w.out), 20000);
    const h = JSON.parse(fs.readFileSync(path.join(w.tmp, 'copy-history.json'), 'utf8'));
    assert.equal(h.trips.filter((t) => t.leader === 't4').length, 7, 'all 7 of t4\'s copies kept');
    assert.ok(!fs.existsSync(path.join(w.tmp, 'copytrade-paper.json')) || !JSON.parse(fs.readFileSync(path.join(w.tmp, 'copytrade-paper.json'), 'utf8')).tripLog?.length, 'paper itself starts fresh');
    assert.doesNotMatch(w.out, /Unhandled|TypeError|ReferenceError/);
  } finally {
    await w.close();
  }
});

test('V2.11.43 a trader whose copies won 1 in 5 or less over his last 6+ (24h, across paper restarts) is not copied', { skip: !WS_LIB, timeout: 60000 }, async () => {
  const w = await startWorld(WS_LIB);
  const k = newKey();
  try {
    const at = Date.now() - 3600000;
    const trips = Array.from({ length: 6 }, (_, i) => ({ sym: `L${i}`, mint: `M${i}`, leader: 'slingoor', pnl: -0.02, x: 0.8, at: at + i }));
    fs.writeFileSync(path.join(w.tmp, 'copy-history.json'), JSON.stringify({ trips }));
    // his pretend wallets look great (so the rotation alone would copy him)
    const closed = Array.from({ length: 25 }, (_, i) => ({ key: `slingoor|main|G${i}`, trader: 'slingoor', style: 'main', pnl: 0.05, x: 1.5, why: 'he sold', at: at + i, held: 600000 }));
    fs.writeFileSync(path.join(w.tmp, 'ghosts.json'), JSON.stringify({ open: {}, closed }));
    w.startBot({ AUTO_ROTATE: 'on', ROTATE_FIRST_MS: '500', COPY_REAL_VETO_COINS: '10', COPY_TRADE: 'on', COPY_PRIVATE_KEY: k.b58, JUPITER_API_KEY: 'test-key', COPY_JITO: 'off', USE_PUMPFUN: 'off' });
    w.tgPush('/start');
    await w.waitFor('registered', () => w.sent(/You're set/).length);
    await sleep(1500);
    w.tgPush('/ghosts');
    await w.waitFor('/ghosts', () => w.sent(/🧊 <b>slingoor<\/b> .*your copies won 0 of 6/).length, 15000);
    assert.doesNotMatch(w.out, /Unhandled|TypeError|ReferenceError/);
  } finally {
    await w.close();
  }
});

test('V2.11.44 every trader his style: main holds when another tracked trader is in the coin; a side wallet keeps its quick band for a big-exit trader', async () => {
  const styleRules = { big: { miniFromX: 2.25, miniToX: 2.5, miniPullbackPct: 10, miniPct: 100, maxHoldMinutes: 30 } };
  const base = { sizeMode: 'fixed', buySol: 0.05, styleRules, quickFromX: 1.15, quickToX: 1.25, quickPullbackPct: 5, tpX: 0, quickTpX: 0, protect: false };
  // side wallet: his style says 2.5x, but a side wallet sells inside its +15..+25% band
  const s = harness({ cfg: { ...base, quickMode: true }, bal: 100 });
  s.c.traderOf = () => 'big';
  await s.c.refreshBalance();
  s.c.onSignal({ ev: s.ev('B1'), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await s.flush();
  await sleep(20);
  const px = {};
  s.c.coins.pricesSol = async () => px;
  const p = s.c.positions.B1;
  px.B1 = (p.costSol / (p.boughtTokens || p.tokens)) * 1.26;
  await s.c.checkTakeProfit();
  await s.flush();
  assert.deepEqual(s.trades.filter((t) => t.action === 'sell').map((t) => t.amount), ['100%'], 'side wallet: out at +25%, not waiting for 2.5x');
  // main: his way = all out at 2.5x; but with another tracked trader in the coin it is not sold his way at 2.5x
  const m = harness({ cfg: base, bal: 100 });
  m.c.traderOf = () => 'big';
  await m.c.refreshBalance();
  m.c.onSignal({ ev: m.ev('B2'), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  m.c.onSignal({ ev: m.ev('B3'), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await m.flush();
  await sleep(20);
  m.c.positions.B3.tradersIn = ['other'];
  const mpx = {};
  m.c.coins.pricesSol = async () => mpx;
  for (const k of ['B2', 'B3']) mpx[k] = (m.c.positions[k].costSol / (m.c.positions[k].boughtTokens || m.c.positions[k].tokens)) * 2.6;
  await m.c.checkTakeProfit();
  await m.flush();
  assert.deepEqual(m.trades.filter((t) => t.action === 'sell').map((t) => `${t.mint} ${t.amount}`), ['B2 100%'], 'main: his coin out at his 2.5x; the coin another trader is in is held');
});

test('V2.11.44 the bot learns a trader\'s style from his pretend wallets (no setup needed)', { skip: !WS_LIB, timeout: 60000 }, async () => {
  const w = await startWorld(WS_LIB);
  const k = newKey();
  try {
    const at = Date.now() - 3600000;
    const closed = Array.from({ length: 12 }, (_, i) => ({ key: `slingoor|main|G${i}`, trader: 'slingoor', style: 'main', pnl: 0.05, x: 1.5, why: 'he sold', at: at + i, held: 240000 }));
    fs.writeFileSync(path.join(w.tmp, 'ghosts.json'), JSON.stringify({ open: {}, closed, exits: { slingoor: Array(10).fill(1.6) } }));
    w.startBot({ COPY_STYLE_ALL: 'on', STYLE_FIT: 'on', COPY_TRADE: 'on', COPY_PRIVATE_KEY: k.b58, JUPITER_API_KEY: 'test-key', COPY_JITO: 'off', USE_PUMPFUN: 'off' });
    await w.waitFor('style', () => /Copy style slingoor: all out at 1\.52x \(or a 10% dip\), out after 8 min/.test(w.out), 20000);
    assert.doesNotMatch(w.out, /Unhandled|TypeError|ReferenceError/);
  } finally {
    await w.close();
  }
});

test('V2.11.53 coin book: a copycat with no website is skipped by the wallet; a held coin passed by a newer same-name coin is sold', async () => {
  const { CoinBook } = await import('../src/versions.js');
  const h = harness({ cfg: { sizeMode: 'fixed', buySol: 0.1, protect: false }, bal: 100 });
  h.c.traderOf = (w) => (w === 'BOTW' ? 'bot' : 'x');
  const info = {
    OG1: { name: 'Same Coin', symbol: 'SAME', createdAt: Date.now() - 3600000 },
    CP1: { name: 'Same Coin', symbol: 'SAME', createdAt: Date.now() - 120000 },
    NW1: { name: 'same coin', symbol: 'SAME', createdAt: Date.now() - 60000, website: 'https://news.example/story' },
  };
  h.c.coins.get = async (m) => info[m] || { name: m, symbol: m };
  h.c.book = new CoinBook({ coins: h.c.coins, getSolPrice: () => 100, cfg: { lateChaseX: 10, versionCheck: true } });
  await h.c.refreshBalance();
  const pxAt = (mc) => mc / 100 / 1e9;
  h.c.book.note('OG1', 'bot', pxAt(50000));
  h.c.onSignal({ ev: h.ev('OG1', { wallet: 'BOTW', priceSol: pxAt(50000) }), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await h.flush();
  await sleep(20);
  await h.flush();
  h.c.book.note('CP1', 'bot', pxAt(6000));
  h.c.onSignal({ ev: h.ev('CP1', { wallet: 'BOTW', priceSol: pxAt(6000) }), kind: 'ENTRY', pre: 0, post: 1, sol: 1 });
  await h.flush();
  await sleep(20);
  await h.flush();
  assert.deepEqual(h.trades.filter((t) => t.action === 'buy').map((t) => t.mint), ['OG1'], 'original bought, copycat skipped');
  assert.match(h.c.skips.at(-1).why, /copycat/);
  assert.deepEqual(h.c.sellOutdated(), [], 'a smaller copy never sells the original');
  // the version with the real source runs past the original: the original is sold, once
  h.c.book.note('NW1', 'bot', pxAt(120000));
  await h.c.book.info('NW1');
  assert.deepEqual(h.c.sellOutdated(), ['OG1']);
  await h.flush();
  assert.equal(h.trades.filter((t) => t.action === 'sell' && t.mint === 'OG1').length, 1);
  assert.deepEqual(h.c.sellOutdated(), []);
});

test('V2.11.55 side wallets copy their own picks: a trader cold for main but making money the side-wallet way', { skip: !WS_LIB, timeout: 60000 }, async () => {
  const w = await startWorld(WS_LIB);
  try {
    const DIL = 'G9gmk9msvd6wT4hDJFm64vKra5z82YvD9je9WqjBvnuk';
    const SCH = '5hAgYC8TJCcEZV7LTXAzkTrm7YL29YXyQQJPCNrG84zM';
    const closed = [];
    const at = Date.now() - 3600000;
    // schoen: his 20 coins lost held the main way, but made money sold quick (W2-W4); dilly lost both ways
    for (let i = 0; i < 20; i++) {
      closed.push({ key: `schoen|main|S${i}`, trader: 'schoen', style: 'main', pnl: -0.02, x: 0.8, why: 'stop loss', at: at + i, held: 600000 });
      for (const st of ['W2', 'W3', 'W4']) closed.push({ key: `schoen|${st}|S${i}`, trader: 'schoen', style: st, pnl: 0.01, x: 1.2, why: 'took profit', at: at + i, held: 600000 });
      closed.push({ key: `dilly|main|D${i}`, trader: 'dilly', style: 'main', pnl: -0.02, x: 0.8, why: 'stop loss', at: at + i, held: 600000 });
      for (const st of ['W2', 'W3', 'W4']) closed.push({ key: `dilly|${st}|D${i}`, trader: 'dilly', style: st, pnl: -0.01, x: 0.9, why: 'stop loss', at: at + i, held: 600000 });
    }
    fs.writeFileSync(path.join(w.tmp, 'ghosts.json'), JSON.stringify({ open: {}, closed }));
    fs.writeFileSync(path.join(w.tmp, 'rotate.json'), JSON.stringify({ on: true, copying: [], tiers: {}, firstSeen: { dilly: 1, schoen: 1 }, log: [] }));
    fs.writeFileSync(path.join(w.tmp, 'paper-mode.json'), JSON.stringify({ on: true, reset: true, layout298: true, layout2119: true, layout21110: true, layout21114: true, layout21115: true, layout21127: true, layout21128: true }));
    const k = newKey();
    w.startBot({ SIDE_OWN_PICKS: 'on', STYLE_FIT: 'on', AUTO_ROTATE: 'on', PAPER_START_SOL: 'main:0.2,W2:0.25', TRADERS: `dilly:${DIL},schoen:${SCH}`, USE_PUMPFUN: 'off', COPY_TRADE: 'on', COPY_PRIVATE_KEY: k.b58, JUPITER_API_KEY: 'test-key', COPY_JITO: 'off' });
    await w.waitFor('copy live', () => /Copy trading LIVE with wallet|PAPER MODE/.test(w.out), 20000);
    w.tgPush('/start');
    await w.waitFor('registered', () => w.sent(/You're set/).length);
    w.tgPush('/wallettraders');
    await w.waitFor('/wallettraders', () => w.sent(/Who each wallet copies/).length, 15000);
    const t = String(w.sent(/Who each wallet copies/)[0].text);
    assert.match(t, /🧩 <b>W2<\/b> also copy their own picks: schoen/);
    assert.doesNotMatch(t.split('🧩')[1].split('\n')[0], /dilly/, 'dilly lost the side-wallet way too: not picked');
    assert.doesNotMatch(w.out, /Unhandled|TypeError|ReferenceError/);
  } finally {
    await w.close();
  }
});
