import { fileURLToPath } from 'node:url';
import fs from 'node:fs';
import path from 'node:path';
import { isAddress } from './util.js';

export const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

const DEFAULTS = {
  TELEGRAM_BOT_TOKEN: '',
  TELEGRAM_CHAT_ID: '',
  TARGET_NAME: 'slingoor',
  SELF_KEYWORDS: 'sling',
  TARGET_WALLETS: '5YRgrP3mjGzrzirYYN5HAQH19cTYREYwGxW6XRJQUzij',
  HELIUS_API_KEY: '',
  USE_PUMPFUN: 'off',
  CHAIN_COMMITMENT: 'auto',
  RPC_URL: 'https://api.mainnet-beta.solana.com',
  WS_URL: 'wss://api.mainnet-beta.solana.com',
  PUMP_TRADES_POLL_SECONDS: '2',
  CALLOUT_POLL_SECONDS: '5',
  CALLOUT_LIST_SECONDS: '20',
  LAUNCH_POLL_SECONDS: '60',
  MERGE_WINDOW_SECONDS: '20',
  MIN_ALERT_SOL: '0',
  ALERT_NEW_ENTRIES: 'on',
  ALERT_ADDS: 'on',
  ALERT_PARTIAL_SELLS: 'on',
  ALERT_FULL_EXITS: 'on',
  ALERT_TRANSFERS: 'on',
  ALERT_CALLOUTS: 'on',
  ALERT_CALLOUT_UPDATES: 'on',
  ALERT_LAUNCHES: 'on',
  META_ONLY_ENTRIES: 'off',
  // Copy trading
  COPY_TRADE: 'off',
  COPY_PRIVATE_KEY: '',
  COPY_KEY_FILE: 'wallet-key.txt',
  COPY_BUY_SOL: '0.1',
  COPY_SIZE_MODE: 'scale',
  COPY_SCALE_AT_1_SOL: '0.5',
  COPY_MAX_BUY_SOL: '1',
  COPY_SCALE_MAX_AT_SOL: '1000',
  COPY_MAX_WALLET_PERCENT: '20',
  COPY_MAX_PER_COIN_SOL: '2',
  COPY_MIN_BUY_SOL: '0.01',
  COPY_ADDS: 'on',
  COPY_ONLY_NEW_COINS: 'on',
  COPY_RECLAIM_RENT: 'on',
  COPY_NEW_COIN_MINUTES: '10',
  COPY_QUICK_TP_X: '1.5',
  COPY_QUICK_TP_PERCENT: '35',
  COPY_QUICK_TP_HIS_MIN_SOL: '1',
  COPY_SLIPPAGE: '25',
  COPY_PRIORITY_FEE: '0.002',
  COPY_MIRROR_SELLS: 'on',
  COPY_TAKE_PROFIT_X: '2',
  COPY_TAKE_PROFIT_SELL_PERCENT: '25',
  COPY_MAX_OPEN_POSITIONS: '10',
  COPY_DAILY_LIMIT_SOL: '0',
  COPY_MIN_HIS_BUY_SOL: '0',
  COPY_MAX_DELAY_SECONDS: '30',
  COPY_KEEP_SOL: '0.02',
  COPY_TP_CHECK_SECONDS: '10',
  COPY_SELL_RETRY_SECONDS: '15',
  COPY_SELL_RETRY_MINUTES: '10',
  COPY_SELL_CHECK_DELAY_SECONDS: '3',
  PUMPPORTAL_API_BASE: 'https://pumpportal.fun/api',
  JUPITER_API_BASE: 'https://lite-api.jup.ag/swap/v1',
  JUPITER_API_KEY: '',
  COPY_JITO: 'on',
  JITO_URLS: 'https://mainnet.block-engine.jito.wtf/api/v1/transactions,https://ny.mainnet.block-engine.jito.wtf/api/v1/transactions',
  COPY_FILE: 'data/copytrade.json',
  // Advanced / testing overrides
  PUMP_API_BASE: 'https://frontend-api-v3.pump.fun',
  PROFILE_API_BASE: 'https://profile-api.pump.fun',
  TELEGRAM_API_BASE: 'https://api.telegram.org',
  DEX_API_BASE: 'https://api.dexscreener.com',
  STATE_FILE: 'data/state.json',
  LOG_FILE: 'logs/bot.log',
};

function parseFile(file) {
  const out = {};
  if (!fs.existsSync(file)) return out;
  for (const raw of fs.readFileSync(file, 'utf8').replace(/^\uFEFF/, '').split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith('#')) continue;
    const i = line.indexOf('=');
    if (i < 1) continue;
    const k = line.slice(0, i).trim();
    let v = line.slice(i + 1).trim();
    // strip inline comment " # ..." and surrounding quotes
    const hash = v.search(/\s+#/);
    if (hash >= 0) v = v.slice(0, hash).trim();
    v = v.replace(/^["'“”‘’]+|["'“”‘’]+$/g, ''); // TextEdit may turn quotes into “smart quotes”
    out[k] = v;
  }
  return out;
}

const on = (v) => /^(on|true|yes|1)$/i.test(String(v).trim());
const num = (v, d) => (Number.isFinite(+v) && String(v).trim() !== '' ? +v : d);

export function cleanHeliusKey(v) {
  let k = String(v || '').trim().replace(/^["'“”‘’<]+|["'“”‘’>]+$/g, '');
  const m = k.match(/api[-_]key=([^&\s"'<>]+)/i);
  if (m) k = m[1];
  const uuid = k.match(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i);
  if (uuid) k = uuid[0];
  return k.replace(/[^\w-]/g, '');
}

export function loadConfig(settingsFile = process.env.SETTINGS_FILE || path.join(ROOT, 'settings.txt')) {
  const fileVals = parseFile(settingsFile);
  const raw = { ...DEFAULTS, ...fileVals };
  // Environment variables win (used by tests and power users)
  for (const k of Object.keys(DEFAULTS)) if (process.env[k] != null && process.env[k] !== '') raw[k] = process.env[k];

  let rpcUrl = raw.RPC_URL;
  let wsUrl = raw.WS_URL;
  // People paste the whole Helius URL (https://mainnet.helius-rpc.com/?api-key=...) instead of the key.
  raw.HELIUS_API_KEY = cleanHeliusKey(raw.HELIUS_API_KEY);
  // ...or put the Helius link in RPC_URL / WS_URL: use its key for both, so the live stream
  // never ends up on the public Solana server (which blocks many home connections).
  if (!raw.HELIUS_API_KEY) {
    for (const u of [raw.RPC_URL, raw.WS_URL]) if (/helius/i.test(u || '') && /api[-_]key=/i.test(u)) raw.HELIUS_API_KEY ||= cleanHeliusKey(u);
  }
  if (raw.HELIUS_API_KEY) {
    rpcUrl = `https://mainnet.helius-rpc.com/?api-key=${raw.HELIUS_API_KEY}`;
    wsUrl = `wss://mainnet.helius-rpc.com/?api-key=${raw.HELIUS_API_KEY}`;
  }
  // a custom RPC_URL without its own WS_URL: use the same server for the live stream
  if (!raw.HELIUS_API_KEY && rpcUrl !== DEFAULTS.RPC_URL && wsUrl === DEFAULTS.WS_URL) wsUrl = rpcUrl.replace(/^http/i, 'ws');
  const isPublicRpc = /api\.mainnet-beta\.solana\.com/.test(rpcUrl);

  const wallets = raw.TARGET_WALLETS.split(/[\s,]+/).filter(Boolean);
  const bad = wallets.filter((w) => !isAddress(w));
  if (bad.length) throw new Error(`TARGET_WALLETS has invalid address(es): ${bad.join(', ')}`);
  if (!wallets.length) throw new Error('TARGET_WALLETS is empty');

  const resolve = (p) => (path.isAbsolute(p) ? p : path.join(ROOT, p));

  return {
    settingsFile,
    telegramToken: raw.TELEGRAM_BOT_TOKEN,
    chatIds: raw.TELEGRAM_CHAT_ID.split(/[\s,]+/).filter(Boolean),
    targetName: raw.TARGET_NAME || 'target',
    selfWords: raw.SELF_KEYWORDS.split(/[\s,]+/).filter(Boolean),
    wallets,
    rpcUrl,
    wsUrl,
    isPublicRpc,
    tradesPollMs: Math.max(1, num(raw.PUMP_TRADES_POLL_SECONDS, 2)) * 1000,
    calloutPollMs: Math.max(2, num(raw.CALLOUT_POLL_SECONDS, 5)) * 1000,
    calloutListMs: Math.max(2, num(raw.CALLOUT_LIST_SECONDS, 20)) * 1000,
    launchPollMs: Math.max(5, num(raw.LAUNCH_POLL_SECONDS, 60)) * 1000,
    mergeWindowMs: Math.max(0, num(raw.MERGE_WINDOW_SECONDS, 20)) * 1000,
    minAlertSol: num(raw.MIN_ALERT_SOL, 0),
    alerts: {
      entry: on(raw.ALERT_NEW_ENTRIES),
      add: on(raw.ALERT_ADDS),
      partial: on(raw.ALERT_PARTIAL_SELLS),
      exit: on(raw.ALERT_FULL_EXITS),
      transfer: on(raw.ALERT_TRANSFERS),
      callout: on(raw.ALERT_CALLOUTS),
      calloutUpdate: on(raw.ALERT_CALLOUT_UPDATES),
      launch: on(raw.ALERT_LAUNCHES),
    },
    metaOnlyEntries: on(raw.META_ONLY_ENTRIES),
    // processed = sees his trades ~0.3s sooner; the public Solana server is slower at it, so only on others
    usePumpfun: on(raw.USE_PUMPFUN),
    chainCommitment: /^(processed|confirmed)$/i.test(raw.CHAIN_COMMITMENT) ? raw.CHAIN_COMMITMENT.toLowerCase() : isPublicRpc ? 'confirmed' : 'processed',
    copy: copyConfig(raw, resolve),
    pumpApi: raw.PUMP_API_BASE.replace(/\/$/, ''),
    profileApi: raw.PROFILE_API_BASE.replace(/\/$/, ''),
    telegramApi: raw.TELEGRAM_API_BASE.replace(/\/$/, ''),
    dexApi: raw.DEX_API_BASE.replace(/\/$/, ''),
    stateFile: resolve(raw.STATE_FILE),
    logFile: resolve(raw.LOG_FILE),
  };
}

function copyConfig(raw, resolve) {
  let key = raw.COPY_PRIVATE_KEY;
  const keyFile = resolve(raw.COPY_KEY_FILE);
  if (!key && fs.existsSync(keyFile)) key = fs.readFileSync(keyFile, 'utf8').replace(/^\uFEFF/, '').trim();
  const c = {
    enabled: on(raw.COPY_TRADE),
    privateKey: key || '',
    keyFile,
    buySol: num(raw.COPY_BUY_SOL, 0.1),
    sizeMode: /^fixed$/i.test(raw.COPY_SIZE_MODE) ? 'fixed' : 'scale',
    scaleAt1: Math.max(0, num(raw.COPY_SCALE_AT_1_SOL, 0.5)),
    maxBuySol: Math.max(0, num(raw.COPY_MAX_BUY_SOL, 1)),
    scaleMaxAt: Math.max(10, num(raw.COPY_SCALE_MAX_AT_SOL, 1000)),
    maxWalletPct: Math.min(100, Math.max(0, num(raw.COPY_MAX_WALLET_PERCENT, 20))),
    maxPerCoinSol: Math.max(0, num(raw.COPY_MAX_PER_COIN_SOL, 2)),
    minBuySol: Math.max(0.001, num(raw.COPY_MIN_BUY_SOL, 0.01)),
    copyAdds: on(raw.COPY_ADDS),
    onlyNewCoins: on(raw.COPY_ONLY_NEW_COINS),
    reclaimRent: on(raw.COPY_RECLAIM_RENT),
    newCoinWindowMs: Math.max(1, num(raw.COPY_NEW_COIN_MINUTES, 10)) * 60000,
    quickTpX: Math.max(0, num(raw.COPY_QUICK_TP_X, 1.5)),
    quickTpPercent: Math.min(90, Math.max(0, num(raw.COPY_QUICK_TP_PERCENT, 35))), // never sells out on profit
    quickTpHisMinSol: Math.max(0, num(raw.COPY_QUICK_TP_HIS_MIN_SOL, 1)),
    slippage: num(raw.COPY_SLIPPAGE, 25),
    priorityFee: num(raw.COPY_PRIORITY_FEE, 0.002),
    mirrorSells: on(raw.COPY_MIRROR_SELLS),
    tpX: num(raw.COPY_TAKE_PROFIT_X, 2),
    tpPercent: Math.min(90, Math.max(0, num(raw.COPY_TAKE_PROFIT_SELL_PERCENT, 25))), // take-profit never sells out
    maxOpen: Math.max(1, num(raw.COPY_MAX_OPEN_POSITIONS, 10)),
    dailyLimitSol: num(raw.COPY_DAILY_LIMIT_SOL, 0),
    minHisBuySol: num(raw.COPY_MIN_HIS_BUY_SOL, 0),
    maxDelayMs: Math.max(3, num(raw.COPY_MAX_DELAY_SECONDS, 30)) * 1000,
    keepSol: Math.max(0, num(raw.COPY_KEEP_SOL, 0.02)),
    tpCheckMs: Math.max(3, num(raw.COPY_TP_CHECK_SECONDS, 10)) * 1000,
    sellRetryMs: Math.max(0.05, num(raw.COPY_SELL_RETRY_SECONDS, 15)) * 1000,
    sellRetryMax: Math.max(0, Math.round(num(raw.COPY_SELL_RETRY_MINUTES, 10) * 60 / Math.max(0.05, num(raw.COPY_SELL_RETRY_SECONDS, 15)))),
    sellCheckDelayMs: Math.max(0, num(raw.COPY_SELL_CHECK_DELAY_SECONDS, 3)) * 1000,
    portalBase: raw.PUMPPORTAL_API_BASE.replace(/\/$/, ''),
    jupKey: raw.JUPITER_API_KEY,
    jitoUrls: on(raw.COPY_JITO) ? raw.JITO_URLS.split(/[\s,]+/).filter(Boolean) : [],
    // with a key, use the main Jupiter API (higher limits)
    jupBase: (raw.JUPITER_API_KEY && raw.JUPITER_API_BASE === DEFAULTS.JUPITER_API_BASE ? 'https://api.jup.ag/swap/v1' : raw.JUPITER_API_BASE).replace(/\/$/, ''),
    file: resolve(raw.COPY_FILE),
  };
  if (c.enabled) {
    if (!(c.buySol > 0)) throw new Error('COPY_BUY_SOL must be more than 0');
    if (c.buySol > 50) throw new Error('COPY_BUY_SOL is over 50 SOL — that looks like a typo');
    if (c.maxBuySol > 50) throw new Error('COPY_MAX_BUY_SOL is over 50 SOL — that looks like a typo');
    if (!(c.slippage > 0 && c.slippage <= 100)) throw new Error('COPY_SLIPPAGE must be between 1 and 100');
    if (c.priorityFee < 0 || c.priorityFee > 0.1) throw new Error('COPY_PRIORITY_FEE must be between 0 and 0.1 SOL');
  }
  return c;
}
