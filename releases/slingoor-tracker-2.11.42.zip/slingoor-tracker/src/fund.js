// V2.6 auto-funding: every time the main wallet reaches a new whole AUTO_FUND_EVERY_SOL step (1 SOL, 2 SOL…),
// it sends AUTO_FUND_SOL (default 0.1) to each side (quick-profit) wallet. Plain SOL transfers between
// your own wallets, signed here; never below AUTO_FUND_KEEP_SOL in the main wallet.
import fs from 'node:fs';
import path from 'node:path';
import { b58decode } from './solana.js';
import { log } from './log.js';

const SYSTEM = '11111111111111111111111111111111';

function shortVec(n) {
  const out = [];
  for (;;) {
    let b = n & 0x7f;
    n >>= 7;
    if (n) b |= 0x80;
    out.push(b);
    if (!n) return out;
  }
}

function u64le(n) {
  const b = Buffer.alloc(8);
  b.writeBigUInt64LE(BigInt(n));
  return [...b];
}

// legacy transaction: `from` pays and signs; one System transfer per destination
export function buildTransferTx(from, dests, blockhash) {
  if (!dests.length) throw new Error('no destinations');
  const keys = [from, ...dests.map((d) => d.to), SYSTEM];
  if (new Set(keys).size !== keys.length) throw new Error('duplicate accounts');
  const msg = [1, 0, 1, ...shortVec(keys.length)];
  for (const k of keys) msg.push(...b58decode(k));
  const bh = b58decode(blockhash);
  if (bh.length !== 32) throw new Error('bad blockhash');
  msg.push(...bh, ...shortVec(dests.length));
  dests.forEach((d, i) => {
    msg.push(keys.length - 1, ...shortVec(2), 0, i + 1, ...shortVec(12), 2, 0, 0, 0, ...u64le(d.lamports));
  });
  return Uint8Array.from([...shortVec(1), ...new Uint8Array(64), ...msg]);
}

export class AutoFunder {
  constructor({ rpc, swapper, owner, sideWallets, everySol = 1, sendSol = 0.1, keepSol = 0.3, mainSharePct = 70, file, notify, balance }) {
    Object.assign(this, { rpc, swapper, owner, sideWallets, everySol, sendSol, keepSol, mainSharePct, file, notify, balance });
    this.state = { step: null };
    try {
      this.state = { ...this.state, ...JSON.parse(fs.readFileSync(file, 'utf8')) };
    } catch {}
    this.running = false;
  }

  save() {
    try {
      fs.mkdirSync(path.dirname(this.file), { recursive: true });
      fs.writeFileSync(this.file, JSON.stringify(this.state));
    } catch {}
  }

  // V2.8.4 end of the day (once a day, at refillAt): every side wallet too low to make a buy (under
  // minSol) gets refillSol from the main wallet, lowest first. The main wallet still keeps
  // AUTO_FUND_KEEP_SOL and its 70% share.
  async refill({ minSol, refillSol, at = { h: 23, m: 55 }, mainMinSol = 0.1, now = Date.now() } = {}) {
    if (this.running || !this.sideWallets().length) return 0;
    const d = new Date(now);
    const day = `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;
    if (this.state.refillDay === day || d.getHours() * 60 + d.getMinutes() < at.h * 60 + at.m) return 0;
    this.running = true;
    try {
      this.state.refillDay = day;
      this.save();
      const bal = await this.balance();
      if (!(bal >= 0)) return 0;
      const all = this.sideWallets();
      const sideBals = await Promise.all(all.map((w) => this.rpc.call('getBalance', [w.pub, { commitment: 'confirmed' }]).then((r) => (r?.value ?? 0) / 1e9).catch(() => null)));
      // V2.8.4b: the refill runs whenever the main wallet has at least AUTO_FUND_REFILL_MAIN_MIN_SOL (0.1)
      // left after sending (the 70% share and the 0.3 keep only apply to the new-high top-ups)
      const allowed = bal - mainMinSol;
      const n = Math.max(0, Math.floor((allowed + 1e-9) / refillSol));
      const drained = all.map((w, i) => ({ ...w, bal: sideBals[i] })).filter((w) => w.bal != null && w.bal < minSol).sort((a, b) => a.bal - b.bal);
      if (!drained.length) return 0;
      const ws = drained.slice(0, n);
      if (!ws.length) {
        log.info(`End-of-day refill: ${drained.map((w) => w.label).join(', ')} need SOL, but the main wallet must keep ${mainMinSol} SOL`);
        await this.notify?.(`🪫 ${drained.map((w) => w.label).join(', ')} ${drained.length > 1 ? 'are' : 'is'} out of SOL, but the main wallet is too low to refill (it needs ${mainMinSol} SOL left after sending).`);
        return 0;
      }
      const bh = await this.rpc.call('getLatestBlockhash', [{ commitment: 'confirmed' }]);
      const tx = buildTransferTx(this.owner, ws.map((w) => ({ to: w.pub, lamports: Math.round(refillSol * 1e9) })), bh.value.blockhash);
      const r = await this.swapper.send(tx);
      log.info(`End-of-day refill: sent ${refillSol} SOL to ${ws.map((w) => w.label).join(', ')} (${r.sig})`);
      await this.notify?.(`🔋 End-of-day refill: <b>${refillSol} SOL</b> to ${ws.map((w) => w.label).join(', ')} (${ws.length > 1 ? 'were' : 'was'} too low to buy)`);
      return refillSol * ws.length;
    } catch (err) {
      log.warn(`End-of-day refill failed: ${err.message}`);
      return 0;
    } finally {
      this.running = false;
    }
  }

  // V2.11.38 (Khalil, Nov 13 10:03pm: "the main needs to top side when it runs low on real too"): any time, a side
  // wallet under `below` (too low for one buy) is topped back up to `to` from the main wallet, lowest first, as long
  // as main keeps `keep`. Each wallet at most once per `cooldownMs`. Plain SOL transfers between your own wallets.
  // Returns the SOL sent.
  async topUp({ below, to, keep, cooldownMs = 10 * 60000, now = Date.now() } = {}) {
    if (this.running || !this.sideWallets().length || !(to > below)) return 0;
    this.running = true;
    try {
      const bal = await this.balance();
      if (!(bal >= 0)) return 0;
      const all = this.sideWallets();
      const sideBals = await Promise.all(all.map((w) => this.rpc.call('getBalance', [w.pub, { commitment: 'confirmed' }]).then((r) => (r?.value ?? 0) / 1e9).catch(() => null)));
      const last = (this.state.topUpAt ||= {});
      const low = all.map((w, i) => ({ ...w, bal: sideBals[i] })).filter((w) => w.bal != null && w.bal < below && now - (last[w.label] || 0) >= cooldownMs).sort((a, b) => a.bal - b.bal);
      if (!low.length) return 0;
      let spare = bal - keep - 0.00001 * low.length;
      const sends = [];
      for (const w of low) {
        const amt = Math.floor(Math.min(to - w.bal, spare) * 1e4) / 1e4;
        if (!(w.bal + amt >= below)) break; // not enough left to make it able to buy
        sends.push({ ...w, amt });
        spare -= amt;
      }
      if (!sends.length) {
        // (main under its keep amount is expected while it's small: no message then)
        if (bal > keep && now - (this.state.lowNoteAt || 0) >= 3600000) {
          this.state.lowNoteAt = now;
          this.save();
          await this.notify?.(`🪫 ${low.map((w) => w.label).join(', ')} ${low.length > 1 ? 'are' : 'is'} too low to buy, and the main wallet can't top ${low.length > 1 ? 'them' : 'it'} up (it keeps ${keep} SOL for its own buys).`);
        }
        return 0;
      }
      for (const w of sends) last[w.label] = now;
      this.save();
      const bh = await this.rpc.call('getLatestBlockhash', [{ commitment: 'confirmed' }]);
      const tx = buildTransferTx(this.owner, sends.map((w) => ({ to: w.pub, lamports: Math.round(w.amt * 1e9) })), bh.value.blockhash);
      const r = await this.swapper.send(tx);
      const total = Math.round(sends.reduce((a, w) => a + w.amt, 0) * 1e4) / 1e4;
      log.info(`Top-up: sent ${sends.map((w) => `${w.label} ${w.amt}`).join(', ')} SOL from main (${r.sig})`);
      await this.notify?.(`🔋 Top-up: ${sends.map((w) => `${w.label} <b>${w.amt} SOL</b>`).join(' · ')} from main (${sends.length > 1 ? 'they were' : 'it was'} too low to buy)`);
      return total;
    } catch (err) {
      log.warn(`Top-up failed: ${err.message}`);
      return 0;
    } finally {
      this.running = false;
    }
  }

  // one check: returns the SOL sent (0 if nothing to do)
  async run() {
    if (this.running || !this.sideWallets().length) return 0;
    this.running = true;
    try {
      const bal = await this.balance();
      if (!(bal >= 0)) return 0;
      const step = Math.floor(bal / this.everySol);
      // first run: remember where we are, send nothing
      if (this.state.step == null) {
        this.state.step = step;
        this.save();
        return 0;
      }
      // V2.8.2: only a NEW high counts. Sending the SOL drops the main wallet back under the number
      // it just reached (2.01 -> 1.71), and climbing back to 2 again must not send a second time.
      this.state.high = Math.max(this.state.high ?? this.state.step, this.state.step);
      if (step <= this.state.high || step < 1) {
        if (step !== this.state.step) {
          this.state.step = step;
          this.save();
        }
        return 0;
      }
      // the main wallet always keeps at least AUTO_FUND_MAIN_SHARE_PERCENT (70%) of ALL your SOL:
      // only as many side wallets get topped up (lowest first) as that allows
      const all = this.sideWallets();
      const sideBals = await Promise.all(all.map((w) => this.rpc.call('getBalance', [w.pub, { commitment: 'confirmed' }]).then((r) => (r?.value ?? 0) / 1e9).catch(() => 0)));
      const grand = bal + sideBals.reduce((a, b) => a + b, 0);
      const allowed = Math.min(bal - this.keepSol, bal - (this.mainSharePct / 100) * grand);
      const n = Math.max(0, Math.min(all.length, Math.floor((allowed + 1e-9) / this.sendSol)));
      const ws = all.map((w, i) => ({ ...w, bal: sideBals[i] })).sort((a, b) => a.bal - b.bal).slice(0, n);
      if (!ws.length) {
        this.state.step = step; // nothing allowed at this step; wait for the next one
        this.state.high = step;
        this.save();
        return 0;
      }
      const total = this.sendSol * ws.length;
      const bh = await this.rpc.call('getLatestBlockhash', [{ commitment: 'confirmed' }]);
      const tx = buildTransferTx(this.owner, ws.map((w) => ({ to: w.pub, lamports: Math.round(this.sendSol * 1e9) })), bh.value.blockhash);
      const r = await this.swapper.send(tx);
      this.state.step = step;
      this.state.high = step;
      this.save();
      log.info(`Auto-fund: sent ${this.sendSol} SOL to ${ws.map((w) => w.label).join(', ')} (${r.sig})`);
      await this.notify?.(`💸 Main wallet hit ${step * this.everySol} SOL: sent <b>${this.sendSol} SOL</b> each to ${ws.map((w) => w.label).join(', ')}`);
      return total;
    } catch (err) {
      log.warn(`Auto-fund failed: ${err.message}`);
      return 0;
    } finally {
      this.running = false;
    }
  }
}
