import test from 'node:test';
import assert from 'node:assert/strict';
import os from 'node:os';
import fs from 'node:fs';
import path from 'node:path';
import { AutoFunder, buildTransferTx } from '../src/fund.js';
import { b58encode, parseTx } from '../src/solana.js';
import crypto from 'node:crypto';

const addr = () => b58encode(crypto.randomBytes(32));

test('transfer tx: one System transfer per side wallet, main pays', () => {
  const from = addr();
  const a = addr();
  const b = addr();
  const tx = buildTransferTx(from, [{ to: a, lamports: 100000000 }, { to: b, lamports: 100000000 }], addr());
  const p = parseTx(tx);
  assert.equal(p.keys[0], from);
  assert.deepEqual(p.keys.slice(1, 3), [a, b]);
  assert.equal(p.keys.at(-1), '11111111111111111111111111111111');
});

test('auto-fund: sends 0.1 SOL to each side wallet each time the main wallet reaches a NEW whole-SOL high', async () => {
  let bal = 0.7;
  const sent = [];
  const f = new AutoFunder({
    rpc: { call: async (m) => (m === 'getBalance' ? { value: 0 } : { value: { blockhash: addr() } }) },
    swapper: { send: async (tx) => (sent.push(tx), { sig: 'S' + sent.length }) },
    owner: addr(),
    sideWallets: () => [{ label: 'W2', pub: addr() }, { label: 'W3', pub: addr() }],
    file: path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'fund-')), 'f.json'),
    balance: async () => bal,
  });
  assert.equal(await f.run(), 0, 'first run only remembers 0 SOL');
  bal = 0.95;
  assert.equal(await f.run(), 0);
  bal = 1.05;
  assert.ok(Math.abs((await f.run()) - 0.2) < 1e-9, 'hit 1 SOL -> 0.1 to each of 2 wallets');
  bal = 0.85; // after sending
  assert.equal(await f.run(), 0, 'dropped under 1 again: nothing');
  bal = 1.1;
  assert.equal(await f.run(), 0, 'back over 1 SOL (the transfer itself dropped it): not a new high, nothing sent');
  bal = 1.6;
  assert.equal(await f.run(), 0, 'same step');
  bal = 2.05;
  assert.ok(Math.abs((await f.run()) - 0.2) < 1e-9, 'new high: 2 SOL -> sends');
  bal = 1.8;
  await f.run();
  bal = 2.2;
  assert.equal(await f.run(), 0, 'dipped and came back to 2: still nothing');
  assert.equal(sent.length, 2);
  // survives a restart
  const f2 = new AutoFunder({ ...f, rpc: f.rpc, swapper: f.swapper, owner: f.owner, sideWallets: f.sideWallets, file: f.file, balance: async () => 2.3 });
  assert.equal(await f2.run(), 0, 'restart remembers the high');
});

test('auto-fund: the main wallet always keeps 70% of ALL your SOL (main + side wallets)', async () => {
  let bal = 0.9;
  const sent = [];
  const sides = { A: 0.3, B: 0.05, C: 0.05 }; // side wallets already hold SOL
  const pubs = { A: addr(), B: addr(), C: addr() };
  const f = new AutoFunder({
    rpc: { call: async (m, p) => (m === 'getBalance' ? { value: Math.round(sides[Object.keys(pubs).find((k) => pubs[k] === p[0])] * 1e9) } : { value: { blockhash: addr() } }) },
    swapper: { send: async (tx) => (sent.push(tx), { sig: 'S' }) },
    owner: addr(),
    sideWallets: () => Object.keys(pubs).map((k) => ({ label: k, pub: pubs[k] })),
    file: path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'fund-')), 'f.json'),
    balance: async () => bal,
  });
  await f.run();
  bal = 1.3; // all = 1.3 + 0.4 = 1.7; main must keep 1.19 -> only 0.11 can go out -> one 0.1 transfer, to the lowest wallet
  const out = await f.run();
  assert.ok(Math.abs(out - 0.1) < 1e-9, `sent ${out}`);
  assert.equal(sent.length, 1);
});

test('V2.8.4 end-of-day refill: a drained side wallet gets 0.05 SOL from main, once a day, after 11:55pm', async () => {
  const sides = { W2: 0.01, W3: 0.3, W4: 0.02 };
  const pubs = { W2: addr(), W3: addr(), W4: addr() };
  const sent = [];
  const notes = [];
  let bal = 2;
  const f = new AutoFunder({
    rpc: { call: async (m, p) => (m === 'getBalance' ? { value: Math.round(sides[Object.keys(pubs).find((k) => pubs[k] === p[0])] * 1e9) } : { value: { blockhash: addr() } }) },
    swapper: { send: async (tx) => (sent.push(tx), { sig: 'S' }) },
    owner: addr(),
    sideWallets: () => Object.keys(pubs).map((k) => ({ label: k, pub: pubs[k] })),
    file: path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'fund-')), 'f.json'),
    balance: async () => bal,
    notify: async (h) => notes.push(h),
  });
  const at = (h, m) => new Date(2026, 10, 12, h, m).getTime();
  const opt = { minSol: 0.06, refillSol: 0.05, at: { h: 23, m: 55 } };
  assert.equal(await f.refill({ ...opt, now: at(18, 0) }), 0, 'not yet');
  assert.ok(Math.abs((await f.refill({ ...opt, now: at(23, 56) })) - 0.1) < 1e-9, 'W2 + W4 refilled');
  assert.equal(sent.length, 1);
  assert.match(notes[0], /End-of-day refill: <b>0\.05 SOL<\/b> to W2, W4/);
  assert.equal(await f.refill({ ...opt, now: at(23, 58) }), 0, 'once a day');
  // next night: main at 0.16 -> it can send 0.05 to ONE wallet and still keep 0.1 (lowest gets it)
  bal = 0.16;
  assert.ok(Math.abs((await f.refill({ ...opt, now: at(23, 55) + 86400000 })) - 0.05) < 1e-9, 'one refill, main keeps 0.1+');
  assert.match(notes.at(-1), /to W2\b/);
  // night after: main 0.12 -> sending would leave it under 0.1: no refill, you're told
  bal = 0.12;
  assert.equal(await f.refill({ ...opt, now: at(23, 55) + 2 * 86400000 }), 0);
  assert.match(notes.at(-1), /too low to refill/);
  assert.equal(sent.length, 2);
});

test('V2.11.38 real top-up any time: a side wallet too low to buy is topped back up to 0.25 from main; main keeps enough for its own buy; 10 min cooldown', async () => {
  const sides = { W2: 0.05, W3: 0.3, W4: 0.1 };
  const pubs = { W2: addr(), W3: addr(), W4: addr() };
  const sent = [];
  const notes = [];
  let bal = 0.5;
  const f = new AutoFunder({
    rpc: { call: async (m, p) => (m === 'getBalance' ? { value: Math.round(sides[Object.keys(pubs).find((k) => pubs[k] === p[0])] * 1e9) } : { value: { blockhash: addr() } }) },
    swapper: { send: async (tx) => (sent.push(tx), { sig: 'S' }) },
    owner: addr(),
    sideWallets: () => Object.keys(pubs).map((k) => ({ label: k, pub: pubs[k] })),
    file: path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'fund-')), 'f.json'),
    balance: async () => bal,
    notify: async (h) => notes.push(h),
  });
  const t0 = Date.now();
  const opt = { below: 0.125, to: 0.25, keep: 0.125 };
  const out = await f.topUp({ ...opt, now: t0 });
  assert.ok(Math.abs(out - 0.35) < 1e-9, `W2 +0.2, W4 +0.15: ${out}`);
  assert.equal(sent.length, 1, 'one transaction');
  assert.match(notes[0], /🔋 Top-up: W2 <b>0\.2 SOL<\/b> · W4 <b>0\.15 SOL<\/b> from main/);
  assert.equal(await f.topUp({ ...opt, now: t0 + 60000 }), 0, 'cooldown: not again within 10 min');
  // main nearly empty: nothing goes out, one note an hour
  bal = 0.15;
  sides.W2 = 0.01;
  assert.equal(await f.topUp({ ...opt, now: t0 + 11 * 60000 }), 0);
  assert.match(notes.at(-1), /too low to buy, and the main wallet can't top/);
  const n = notes.length;
  await f.topUp({ ...opt, now: t0 + 22 * 60000 });
  assert.equal(notes.length, n, 'no repeat note within the hour');
});
