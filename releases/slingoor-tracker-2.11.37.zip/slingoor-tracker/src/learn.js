// V2.8 learning: the bot watches how every wallet's coins move after we copy them (while we hold AND
// for 30 minutes after we sell), then replays those real price paths against other sell settings to
// find what would have made the most for that wallet. Nothing changes until you approve it:
// suggestions go out at 6am, 12pm, 6pm and 12am (and on /suggestions). Unanswered ones are sent again
// next time; only /apply puts them to work.
import fs from 'node:fs';
import path from 'node:path';
import { log } from './log.js';

const SAMPLE_MS = 5000; // one price point every 5s
const POST_MS = 30 * 60000; // keep watching 30 min after we sold
const MAX_POINTS = 800;
const KEEP_TRIPS = 60; // per wallet
const r3 = (n) => Math.round(n * 1000) / 1000;
const SAVE_EVERY_MS = 60000; // the learn file can be big: written at most once a minute (and on exit)
const KEEP_POINTS = 240; // a finished path is thinned to this many points (top and last always kept)

// thin a long price path, keeping its shape: every k-th point + the highest + the last
export function compact(pts, max = KEEP_POINTS) {
  if (pts.length <= max) return pts;
  const k = Math.ceil(pts.length / max);
  let top = 0;
  for (let i = 1; i < pts.length; i++) if (pts[i][1] > pts[top][1]) top = i;
  return pts.filter((_, i) => i % k === 0 || i === top || i === pts.length - 1);
}
const KEEP_COINS = 150; // per wallet: coins it bought, followed 30 min from its buy
const MAX_SHADOW = 40; // coins followed at once

// V2.8.1 what a coin looked like when the wallet bought it -> buckets the learner can compare
const band = (v, cuts, names) => {
  if (v == null || !Number.isFinite(v)) return null;
  for (let i = 0; i < cuts.length; i++) if (v < cuts[i]) return names[i];
  return names[cuts.length];
};
export function featureKeys(f = {}) {
  const k = [];
  for (const t of f.tags?.length ? f.tags : ['none']) k.push(`narr:${t}`);
  if (f.twitter != null) k.push(`x:${f.twitter ? 'yes' : 'no'}`);
  const mc = band(f.mc, [10000, 30000, 100000], ['<10k', '10-30k', '30-100k', '100k+']);
  if (mc) k.push(`mc:${mc}`);
  const age = band(f.ageMin, [5, 30, 180], ['<5m', '5-30m', '30m-3h', '3h+']);
  if (age) k.push(`age:${age}`);
  const size = band(f.hisSol, [1, 3, 10], ['<1', '1-3', '3-10', '10+']);
  if (size) k.push(`size:${size}`);
  const h = band(f.holders, [20, 50, 150], ['<20', '20-50', '50-150', '150+']);
  if (h) k.push(`holders:${h}`);
  const dev = band(f.devCoins, [2, 6], ['1st', '2-5', '6+']);
  if (dev) k.push(`dev:${dev}`);
  // V2.11.30 volume over the last hour (USD) and the dev check's answer (fresh = no trades before this coin)
  const vol = band(f.volH1, [5000, 25000, 100000], ['<5k', '5-25k', '25-100k', '100k+']);
  if (vol) k.push(`vol:${vol}`);
  if (f.devKind) k.push(`devk:${f.devKind}`);
  return k;
}
const NARR = { none: 'no clear narrative', titty: 'Big Titty', nsfw: 'NSFW', backronym: 'backronym', ticker: 'real-ticker vamp', kol: 'KOL', self: 'about the trader', animal: 'animal', ai: 'AI', celeb: 'celeb / politics', cryptoculture: 'crypto culture', finance: 'finance', tech: 'tech', anime: 'anime', slang: 'slang', seasonal: 'seasonal', tweet: 'tweet' };
// V2.11.26: labels like "<10k" broke Telegram's HTML (the fallback then cut text out); show "under 10k" instead
export function keyLabel(key) {
  return rawLabel(key).replace(/\$</g, 'under $').replace(/</g, 'under ').replace(/>/g, 'over ').replace(/&/g, 'and');
}

function rawLabel(key) {
  const [a, b] = String(key).split(':');
  if (a === 'narr') return `${NARR[b] || b} coins`;
  if (a === 'x') return b === 'yes' ? 'coins with an X/Twitter' : 'coins with no X/Twitter';
  if (a === 'mc') return `coins at ${b === '100k+' ? '$100k+' : `$${b}`} market cap`;
  if (a === 'age') return `coins ${b} old`;
  if (a === 'size') return `his ${b} SOL buys`;
  if (a === 'holders') return `coins with ${b} holders`;
  if (a === 'vol') return `coins with $${b} volume (1h)`;
  if (a === 'devk') return b === 'fresh' ? "fresh devs' coins" : 'coins from devs with history';
  if (a === 'dev') return b === '1st' ? "dev's first coin" : `devs with ${b} coins`;
  return key;
}

function readJson(file, d) {
  try {
    return { ...d, ...JSON.parse(fs.readFileSync(file, 'utf8')) };
  } catch {
    return d;
  }
}
function writeJson(file, v) {
  try {
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.writeFileSync(file + '.tmp', JSON.stringify(v));
    fs.renameSync(file + '.tmp', file);
  } catch (err) {
    log.warn('learn save failed', err.message);
  }
}

// Replay one price path with these sell settings -> the x we would have sold at (on average).
// Same mini-cook logic the bot uses: armed at fromX, sells pct% at toX or on a pull back from the top.
export function simulate(points, R) {
  const fromX = R.miniFromX ?? 1.25;
  const toX = R.miniToX ?? 1.8;
  const pull = (R.miniPullbackPct ?? 10) / 100;
  const pct = Math.min(1, (R.miniPct ?? 100) / 100);
  const sl = R.stopLossX > 0 ? R.stopLossX : 0;
  let armed = false;
  let peak = 0;
  for (const [t, x] of points) {
    if (sl && x <= sl && t > 60) return x; // stop loss sells everything
    if (x >= fromX) armed = true;
    if (!armed) continue;
    peak = Math.max(peak, x);
    if (x >= toX || (x <= peak * (1 - pull) && x > 1.05)) {
      if (pct >= 1) return x;
      const end = points.at(-1)[1];
      return pct * x + (1 - pct) * end;
    }
  }
  return points.length ? points.at(-1)[1] : 1;
}

const GRID_TO = Array.from({ length: 28 }, (_, i) => r3(1.3 + i * 0.1)); // 1.3x .. 4.0x
const GRID_PULL = Array.from({ length: 13 }, (_, i) => 5 + i * 2.5); // 5% .. 35%

export class Learner {
  constructor({ file, now = () => Date.now(), minTrades = 15 }) {
    this.file = file;
    this.now = now;
    this.minTrades = minTrades;
    this.d = readJson(file, { live: {}, post: {}, done: {}, shadow: {}, coins: {} });
    this.d.shadow ||= {};
    this.d.coins ||= {};
    this._dirty = false;
  }

  save(force) {
    if (!this._dirty && !force) return;
    if (!force && this._savedAt && this.now() - this._savedAt < SAVE_EVERY_MS) return;
    this._savedAt = this.now();
    this._dirty = false;
    writeJson(this.file, this.d);
  }

  // while we hold: one point every 5s (x = what our coins are worth vs what they cost)
  sample(mint, p, x) {
    if (!(x > 0) || !p.leader) return;
    const l = (this.d.live[mint] ||= { leader: p.leader, cost: p.costSol, start: p.openedAt || this.now(), pts: [] });
    const t = Math.round((this.now() - l.start) / 1000);
    const last = l.pts.at(-1);
    if (last && t - last[0] < SAMPLE_MS / 1000) return;
    if (l.pts.length < MAX_POINTS) l.pts.push([t, r3(x)]);
    this._dirty = true;
  }

  // we sold out: keep following its price for 30 more minutes (did we leave money on the table?)
  closed(mint, p) {
    const l = this.d.live[mint];
    delete this.d.live[mint];
    if (!l || !l.pts.length) return;
    const perToken = p.costSol / (p.boughtTokens || p.tokens || 1);
    if (!(perToken > 0)) return;
    this.d.post[mint] = { ...l, perToken, exitIdx: l.pts.length, until: this.now() + POST_MS };
    this._dirty = true;
  }

  // V2.8.1 a tracked wallet bought a coin (copied or not): follow it 30 min from his buy
  coinSeen(mint, leader, f) {
    const key = `${leader}|${mint}`;
    if (this.d.shadow[key] || Object.keys(this.d.shadow).length >= MAX_SHADOW) return false;
    this.d.shadow[key] = { mint, leader, f, keys: featureKeys(f), start: this.now(), until: this.now() + POST_MS, perToken: null, pts: [] };
    this._dirty = true;
    return true;
  }

  watching() {
    return [...new Set([...Object.keys(this.d.post), ...Object.values(this.d.shadow).map((w) => w.mint)])];
  }

  // price (SOL per token) of a coin we already sold
  postPrice(mint, pxSol) {
    for (const s of Object.values(this.d.shadow)) {
      if (s.mint !== mint || !(pxSol > 0)) continue;
      s.perToken ??= pxSol; // the first price after his buy is 1x
      const t = Math.round((this.now() - s.start) / 1000);
      const last = s.pts.at(-1);
      if ((!last || t - last[0] >= SAMPLE_MS / 1000) && s.pts.length < MAX_POINTS) s.pts.push([t, r3(pxSol / s.perToken)]);
      this._dirty = true;
    }
    const w = this.d.post[mint];
    if (!w) return;
    if (pxSol > 0) {
      const t = Math.round((this.now() - w.start) / 1000);
      const last = w.pts.at(-1);
      if ((!last || t - last[0] >= SAMPLE_MS / 1000) && w.pts.length < MAX_POINTS) w.pts.push([t, r3(pxSol / w.perToken)]);
      this._dirty = true;
    }
    if (this.now() >= w.until) this._finish(mint);
  }

  tick() {
    for (const [mint, w] of Object.entries(this.d.post)) if (this.now() >= w.until) this._finish(mint);
    for (const [key, s] of Object.entries(this.d.shadow)) {
      if (this.now() < s.until) continue;
      delete this.d.shadow[key];
      this._dirty = true;
      if (s.pts.length < 3) continue; // never got a price
      const list = (this.d.coins[s.leader] ||= []);
      list.push({ at: this.now(), keys: s.keys, pts: compact(s.pts) });
      if (list.length > KEEP_COINS) list.splice(0, list.length - KEEP_COINS);
    }
    // a position that vanished without a sell (sold by hand outside the bot): drop after 12h
    for (const [mint, l] of Object.entries(this.d.live)) if (this.now() - l.start > 12 * 3600000) delete this.d.live[mint];
    this.save();
  }

  _finish(mint) {
    const w = this.d.post[mint];
    delete this.d.post[mint];
    const list = (this.d.done[w.leader] ||= []);
    // thin the hold and the after-sell parts separately, so the sell point stays exact
    const hold = compact(w.pts.slice(0, w.exitIdx), KEEP_POINTS / 2);
    const after = compact(w.pts.slice(w.exitIdx), KEEP_POINTS / 2);
    list.push({ at: this.now(), cost: w.cost, pts: [...hold, ...after], exitIdx: hold.length });
    if (list.length > KEEP_TRIPS) list.splice(0, list.length - KEEP_TRIPS);
    this._dirty = true;
  }

  trades(leader) {
    return (this.d.done[leader] || []).length;
  }

  coinsSeen(leader) {
    return (this.d.coins[leader] || []).length;
  }

  // What makes a coin for this wallet: every kind of coin it buys, replayed with its sell settings
  // (0.1 SOL per coin). best/worst kinds, and a "skip these" rule when one clearly loses.
  coinProfile(leader, R, { minEach = 6 } = {}) {
    const list = this.d.coins[leader] || [];
    if (list.length < this.minTrades) return null;
    const by = {};
    let total = 0;
    for (const c of list) {
      const pnl = (simulate(c.pts, R) - 1) * 0.1;
      total += pnl;
      for (const k of c.keys) {
        const b = (by[k] ||= { key: k, n: 0, won: 0, pnl: 0 });
        b.n++;
        b.pnl += pnl;
        if (pnl > 0) b.won++;
      }
    }
    const rows = Object.values(by).filter((b) => b.n >= minEach).map((b) => ({ ...b, pnl: r3(b.pnl), rate: b.won / b.n }));
    rows.sort((a, b) => b.pnl / b.n - a.pnl / a.n);
    const best = rows.filter((b) => b.pnl > 0).slice(0, 3);
    const worst = rows.filter((b) => b.pnl < 0).slice(-3).reverse();
    // skip suggestion: a kind that loses money, wins under 40%, and skipping it adds +0.02 SOL or more
    const skip = rows.filter((b) => b.pnl <= -0.02 && b.rate < 0.4 && b.n < list.length).sort((a, b) => a.pnl - b.pnl)[0] || null;
    return { leader, n: list.length, total: r3(total), best, worst, skip };
  }

  // V2.11.30 market read (Khalil, Nov 13 4:27-4:29pm: "adapt to market cap, volume, holders, narrative and the dev",
  // "it's a moving market, what works today might not work tomorrow"): every coin ANY tracked wallet bought in the
  // last few hours, replayed with the side wallets' sell rule. Kinds of coins losing right now -> skipped by every
  // wallet until they work again (it's a rolling window, so they come back by themselves).
  marketCoins(hours) {
    const since = this.now() - hours * 3600000;
    return Object.values(this.d.coins).flat().filter((c) => (c.at || 0) >= since);
  }

  marketRead(R, { hours = 6, minEach = 8, minCoins = 40, maxSkip = 3 } = {}) {
    const list = this.marketCoins(hours);
    const by = {};
    let total = 0;
    for (const c of list) {
      const pnl = (simulate(c.pts, R) - 1) * 0.1;
      total += pnl;
      for (const k of new Set(c.keys)) {
        if (k.startsWith('size:')) continue; // his buy size is about him, not the market
        const b = (by[k] ||= { key: k, n: 0, won: 0, pnl: 0 });
        b.n++;
        b.pnl += pnl;
        if (pnl > 0) b.won++;
      }
    }
    const rows = Object.values(by).map((b) => ({ ...b, pnl: r3(b.pnl), rate: b.won / b.n }));
    // a losing kind: 8+ coins, lost 0.05+ SOL, won under 35%, and not most of the market (never stops all trading)
    const bad = list.length >= minCoins ? rows.filter((b) => b.n >= minEach && b.pnl <= -0.05 && b.rate < 0.35 && b.n <= list.length * 0.5).sort((a, b) => a.pnl - b.pnl).slice(0, maxSkip) : [];
    const good = rows.filter((b) => b.n >= minEach && b.pnl > 0).sort((a, b) => b.pnl - a.pnl).slice(0, 3);
    return { n: list.length, total: r3(total), bad, good, hours };
  }

  // the side wallets' sell point that works best right now (inside Khalil's +50%..+100% band), or null
  // V2.11.36 adaptive buy time (Khalil, Nov 13 7:23pm: "some traders the price drops more after buy, sometimes it goes
  // straight up — make the bot's buy time adaptable"): his last coins replayed as if we bought d seconds after him.
  // Returns the delay that made the most (needs 15+ coins and a clear edge over buying right away), or 0.
  buyDelay(leader, R, { hours = 24, delays = [0, 5, 10, 15, 20, 30, 45, 60], minCoins = 15 } = {}) {
    const since = this.now() - hours * 3600000;
    const max = Math.max(...delays);
    const list = (this.d.coins[leader] || []).filter((c) => (c.at || 0) >= since && c.pts?.length && c.pts.at(-1)[0] >= max + 60);
    if (list.length < minCoins) return { delay: 0, n: list.length, gain: 0 };
    const at = (pts, d) => {
      const i = pts.findIndex((p) => p[0] >= d);
      if (i < 0 || pts[i][0] > d + 10) return null; // no price close to that moment
      const x0 = pts[i][1];
      return x0 > 0 ? pts.slice(i).map(([t, x]) => [t - d, r3(x / x0)]) : null;
    };
    const total = (d) => list.reduce((a, c) => {
      const p = at(c.pts, d);
      return a + (p ? (simulate(p, R) - 1) * 0.1 : 0);
    }, 0);
    const base = total(0);
    let top = { delay: 0, gain: 0 };
    for (const d of delays) {
      if (!d) continue;
      const g = total(d) - base;
      if (g > top.gain + 1e-9) top = { delay: d, gain: g };
    }
    // a clear edge only: 0.02 SOL and 3% of what was spent (0.1 per coin)
    if (top.gain < Math.max(0.02, list.length * 0.1 * 0.03)) return { delay: 0, n: list.length, gain: 0 };
    return { delay: top.delay, n: list.length, gain: r3(top.gain) };
  }

  // fromIsTo: the rule sells its part right at toX (held coins: 25% at the take point, the rest rides)
  marketSell(R, { hours = 6, minCoins = 40, toGrid = [1.5, 1.6, 1.7, 1.8, 1.9, 2], pullGrid = [5, 7.5, 10, 12.5, 15, 20], fromIsTo = false } = {}) {
    const list = this.marketCoins(hours);
    if (list.length < minCoins) return null;
    const sum = (Q) => list.reduce((a, c) => a + (simulate(c.pts, Q) - 1) * 0.1, 0);
    const base = sum(R);
    let top = { gain: 0, toX: R.miniToX, pull: R.miniPullbackPct };
    for (const toX of toGrid)
      for (const pull of pullGrid) {
        if (!fromIsTo && toX < (R.miniFromX || 1)) continue;
        const g = sum({ ...R, miniToX: toX, miniPullbackPct: pull, ...(fromIsTo ? { miniFromX: toX } : {}) }) - base;
        if (g > top.gain + 1e-9) top = { gain: g, toX, pull };
      }
    // only move for a clear win (0.02 SOL over these coins), so noise doesn't flip it back and forth
    return top.gain >= 0.02 ? { toX: top.toX, pull: top.pull, gain: r3(top.gain), n: list.length } : { toX: R.miniToX, pull: R.miniPullbackPct, gain: 0, n: list.length };
  }

  // Best sell-x and pull-back for one wallet, vs its current settings. null = not enough trades or
  // no clear win (needs +0.02 SOL and +3% of what was spent, so random noise doesn't move your settings).
  best(leader, cur) {
    const trips = this.d.done[leader] || [];
    if (trips.length < this.minTrades) return null;
    const total = (R) => trips.reduce((a, t) => a + (simulate(t.pts, R) - 1) * (t.cost || 0.1), 0);
    const base = total(cur);
    // among equally good settings, the one closest to what you have now (smallest change)
    const dist = (toX, pull) => Math.abs(toX - cur.miniToX) / cur.miniToX + Math.abs(pull - cur.miniPullbackPct) / 100;
    let top = { gain: 0, toX: cur.miniToX, pull: cur.miniPullbackPct, d: 0 };
    for (const toX of GRID_TO)
      for (const pull of GRID_PULL) {
        const g = total({ ...cur, miniToX: toX, miniPullbackPct: pull }) - base;
        const d = dist(toX, pull);
        if (g > top.gain + 1e-9 || (g > 1e-9 && Math.abs(g - top.gain) <= 1e-9 && d < top.d)) top = { gain: g, toX, pull, d };
      }
    const spent = trips.reduce((a, t) => a + (t.cost || 0.1), 0);
    if (top.gain < Math.max(0.02, spent * 0.03)) return null;
    if (top.toX === cur.miniToX && top.pull === cur.miniPullbackPct) return null;
    // how often we sold before the coin went higher (shown with the suggestion)
    const early = trips.filter((t) => {
      const ex = t.pts[Math.max(0, (t.exitIdx || t.pts.length) - 1)]?.[1] ?? 1;
      return t.pts.slice(t.exitIdx || t.pts.length).some((p) => p[1] > ex * 1.2);
    }).length;
    return { leader, n: trips.length, gain: r3(top.gain), from: { miniToX: cur.miniToX, miniPullbackPct: cur.miniPullbackPct }, to: { miniToX: top.toX, miniPullbackPct: top.pull }, early };
  }
}

// Suggestions: sent at set hours, wait for /apply. Approved settings are saved here and used by the bot.
export class Suggestions {
  constructor({ file, learner, rulesFor, leaders, onApplied = () => {}, send, hours = [0, 6, 12, 18], now = () => Date.now() }) {
    this.file = file;
    this.learner = learner;
    this.rulesFor = rulesFor; // leader -> current sell settings (with anything already applied)
    this.leaders = leaders; // () => wallet names
    this.onApplied = onApplied;
    this.send = send;
    this.hours = hours;
    this.now = now;
    this.d = readJson(file, { pending: {}, applied: {}, lastSlot: null });
  }

  save() {
    writeJson(this.file, this.d);
  }

  applied() {
    return this.d.applied;
  }

  // recompute: a newer, better answer replaces that wallet's old one; old unanswered ones stay
  refresh() {
    const keep = (key, s) => {
      const old = this.d.pending[key];
      this.d.pending[key] = { ...s, firstAt: old?.firstAt ?? this.now(), sent: old?.sent ?? 0 };
    };
    this.profiles = {};
    for (const leader of this.leaders()) {
      const R = this.rulesFor(leader);
      const s = this.learner.best(leader, R);
      if (s) keep(leader, { ...s, type: 'sell' });
      // V2.8.1 what kind of coin works for this wallet -> maybe "skip these coins"
      const prof = this.learner.coinProfile?.(leader, R);
      if (!prof) continue;
      this.profiles[leader] = prof;
      const already = this.d.applied[leader]?.skip || [];
      if (prof.skip && !already.includes(prof.skip.key)) keep(`${leader}~coin`, { type: 'skip', leader, key: prof.skip.key, n: prof.skip.n, won: prof.skip.won, gain: r3(-prof.skip.pnl), of: prof.n });
    }
    this.save();
    return Object.values(this.d.pending);
  }

  _profileLines() {
    const out = [];
    for (const p of Object.values(this.profiles || {})) {
      const row = (b) => `${keyLabel(b.key)} ${b.pnl >= 0 ? '+' : ''}${b.pnl.toFixed(2)} (${b.won}/${b.n})`;
      out.push(`• <b>${p.leader}</b> (${p.n} coins): ${p.best.length ? `best: ${p.best.map(row).join(', ')}` : 'no winning kind yet'}${p.worst.length ? ` · worst: ${p.worst.map(row).join(', ')}` : ''}`);
    }
    return out.length ? ['', '🔬 <b>What makes a coin</b> (each coin they bought, 0.1 SOL each, your sell settings):', ...out] : [];
  }

  text() {
    const list = Object.values(this.d.pending);
    if (!list.length) {
      const counts = this.leaders().map((l) => `${l} ${this.learner.trades(l)}/${this.learner.coinsSeen?.(l) ?? 0}`).join(' · ');
      return [`🧠 <b>No suggestions right now</b> — your settings already beat everything it tested, or it's still learning (needs ${this.learner.minTrades} per wallet).`, `Learned (our trades / their coins): ${counts || 'none yet'}`, ...this._profileLines()].join('\n');
    }
    const pct = (p) => `${Math.round(p)}%`;
    const when = (t) => new Date(t).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
    const lines = [this.paper ? '🧪🧠 <b>Paper suggestions</b> (learned from paper trades at real prices)' : '🧠 <b>Suggestions</b> (learned from real trades)'];
    const script = [];
    const shown = new Set();
    for (const s of list) {
      const waiting = s.sent > 0 ? ` <i>(waiting since ${when(s.firstAt)})</i>` : '';
      lines.push('');
      if (s.type === 'skip') {
        lines.push(`<b>${s.leader}</b>${waiting}: <b>skip ${keyLabel(s.key)}</b> — won ${s.won} of ${s.n}, +${s.gain.toFixed(3)} SOL better without them (of ${s.of} coins)`);
        script.push(`- ${s.leader}: don't copy ${keyLabel(s.key)} (${s.key}) — won ${s.won} of ${s.n}, +${s.gain.toFixed(3)} SOL better without them`);
      } else {
        lines.push(`<b>${s.leader}</b>${waiting}: sell at <b>${s.to.miniToX}x</b> (now ${s.from.miniToX}x), dip <b>${pct(s.to.miniPullbackPct)}</b> (now ${pct(s.from.miniPullbackPct)})`, `+${s.gain.toFixed(3)} SOL better over ${s.n} trades · sold too early ${s.early}×`);
        script.push(`- ${s.leader}: sell all at ${s.to.miniToX}x (was ${s.from.miniToX}x), sell on a ${s.to.miniPullbackPct}% dip from the top (was ${s.from.miniPullbackPct}%) — ${s.n} trades, +${s.gain.toFixed(3)} SOL better`);
      }
      if (!shown.has(s.leader) && list.filter((x) => x.leader === s.leader).at(-1) === s) {
        shown.add(s.leader);
        lines.push(`/apply_${s.leader} · /skip_${s.leader}`);
      }
    }
    lines.push(...this._profileLines());
    lines.push('', '/apply — apply all · /skip — skip all', '', '📋 <b>Or paste this to Claude:</b>');
    lines.push(`<pre>Make these learned settings the defaults in my slingoor copy bot, test and publish:\n${script.join('\n')}</pre>`);
    return lines.join('\n');
  }

  _keys(leader) {
    return Object.keys(this.d.pending).filter((k) => !leader || this.d.pending[k].leader === leader);
  }

  apply(leader) {
    const done = new Set();
    for (const k of this._keys(leader)) {
      const s = this.d.pending[k];
      const a = (this.d.applied[s.leader] ||= {});
      if (s.type === 'skip') a.skip = [...new Set([...(a.skip || []), s.key])];
      else Object.assign(a, s.to);
      delete this.d.pending[k];
      done.add(s.leader);
    }
    this.save();
    if (done.size) this.onApplied(this.d.applied);
    return [...done];
  }

  skip(leader) {
    const names = new Set();
    for (const k of this._keys(leader)) {
      names.add(this.d.pending[k].leader);
      delete this.d.pending[k];
    }
    this.save();
    return [...names];
  }

  reset() {
    this.d.applied = {};
    this.d.pending = {};
    this.save();
    this.onApplied({});
  }

  _slot(t) {
    const d = new Date(t);
    return this.hours.includes(d.getHours()) ? `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}-${d.getHours()}` : null;
  }

  // at 12am, 6am, 12pm, 6pm: send new + still-unanswered suggestions (nothing if there are none)
  async tick() {
    const slot = this._slot(this.now());
    if (!slot || slot === this.d.lastSlot) return false;
    this.d.lastSlot = slot;
    const list = this.refresh();
    if (!list.length) return false;
    const html = this.text();
    for (const s of list) s.sent = (s.sent || 0) + 1;
    this.save();
    await this.send(html).catch(() => {});
    return true;
  }
}
