// V2.9.9 ghost wallets: every tracked trader is copied by two pretend wallets of its own, without any SOL
// or any trade ever being sent:
//   main-style  (0.1 SOL per coin): follows his sells (10%+), his exit, the -20% stop loss, the safety-net
//               mini cook of his sell rules, and the 8h limit — like your main wallet
//   side-style  (0.05 SOL per coin): sells 100% at +25%, at -20%, or when he's out — like your side wallets
// Fills are estimated: his price + COPY delay (we land ~1.5s after him) + the real fee cap on each trade.
// Prices come from the same price site the bot already uses, in a background pass that never touches
// Jupiter, so real and paper trading are never slowed down.
import fs from 'node:fs';
import path from 'node:path';
import { log } from './log.js';

// V2.9.10 four pretend wallets per trader, like your real set: a main + 3 sides (sides buy a moment after
// the main, like the real ones: +2% more on their price)
const STYLES = {
  main: { sol: 0.1 },
  W2: { sol: 0.05, tpX: 1.25, side: true, late: 1.02 },
  W3: { sol: 0.05, tpX: 1.25, side: true, late: 1.02 },
  W4: { sol: 0.05, tpX: 1.25, side: true, late: 1.02 },
};
const SIDES = Object.keys(STYLES).filter((k) => STYLES[k].side);

export class GhostBook {
  constructor({ file, now = () => Date.now(), fee = 0.000505, entryPenaltyPct = 5, stopLossX = 0.8, maxHoldMs = 8 * 3600000, rulesFor = () => ({}), maxOpen = 120 }) {
    this.file = file;
    this.now = now;
    this.fee = fee; // per trade (real priority-fee cap + base fee)
    this.entryPenalty = 1 + entryPenaltyPct / 100; // we buy after him: a bit higher than his fill
    this.stopLossX = stopLossX;
    this.maxHoldMs = maxHoldMs;
    this.rulesFor = rulesFor; // trader -> his sell rules (mini cook settings)
    this.maxOpen = maxOpen;
    this.d = { open: {}, closed: [], since: this.now() };
    try {
      this.d = { ...this.d, ...JSON.parse(fs.readFileSync(file, 'utf8')) };
    } catch {}
    this._dirty = false;
  }

  save(force) {
    if (!this._dirty && !force) return;
    if (!force && this._savedAt && this.now() - this._savedAt < 60000) return;
    this._savedAt = this.now();
    this._dirty = false;
    try {
      fs.mkdirSync(path.dirname(this.file), { recursive: true });
      fs.writeFileSync(this.file + '.tmp', JSON.stringify(this.d));
      fs.renameSync(this.file + '.tmp', this.file);
    } catch (err) {
      log.warn('ghost save failed', err.message);
    }
  }

  reset() {
    this.d = { open: {}, closed: [], since: this.now() };
    this._dirty = true;
    this.save(true);
  }

  // he bought (ENTRY): both ghost wallets of his buy at his price + the delay penalty
  // priceSol unknown: the ghosts buy at the first price the bot sees for the coin (a bit later than him)
  open(trader, mint, priceSol, sym = null) {
    if (!trader || !mint) return false;
    if (!(priceSol > 0)) priceSol = null;
    if (Object.keys(this.d.open).length >= this.maxOpen * 4) return false;
    let opened = false;
    for (const style of Object.keys(STYLES)) {
      const key = `${trader}|${style}|${mint}`;
      if (this.d.open[key]) continue;
      if (this.d.closed.some((c) => c.key === key)) continue; // one buy per coin, like the real bot
      const entry = priceSol ? priceSol * this.entryPenalty * (STYLES[style].late || 1) : null;
      this.d.open[key] = { key, trader, style, mint, sym, entry, left: 1, got: 0, cost: STYLES[style].sol + this.fee, at: this.now(), peak: 1, low: 0 };
      opened = true;
    }
    if (opened) this._dirty = true;
    return opened;
  }

  // he sold part (pct of his bag) or all
  hisSell(trader, mint, pct, out) {
    for (const g of Object.values(this.d.open)) {
      if (g.trader !== trader || g.mint !== mint) continue;
      const px = g.lastPx;
      if (!(px > 0)) {
        if (out) g.hisOut = true; // sell at the next price we get
        continue;
      }
      if (out || STYLES[g.style]?.side) {
        if (out || pct >= 10) this._sell(g, 1, px, out ? 'his exit' : 'he sold');
      } else if (pct >= 10) this._sell(g, Math.min(1, pct / 100), px, 'he sold');
    }
  }

  watching() {
    return [...new Set(Object.values(this.d.open).map((g) => g.mint))];
  }

  // a price (SOL per token) for a coin some ghosts hold: run the sell rules
  price(mint, px) {
    if (!(px > 0)) return;
    for (const g of Object.values(this.d.open)) {
      if (g.mint !== mint) continue;
      if (!(g.entry > 0)) {
        g.entry = px * (STYLES[g.style]?.late || 1); // first price we got = its buy (already later than his)
        g.at = this.now();
      }
      g.lastPx = px;
      const x = px / g.entry;
      g.peak = Math.max(g.peak, x);
      if (g.hisOut) {
        this._sell(g, 1, px, 'his exit');
        continue;
      }
      // stop loss: twice in a row, after 60s (same guard as the real bot)
      if (x <= this.stopLossX && this.now() - g.at > 60000) {
        if ((g.low || 0) >= 1) {
          this._sell(g, 1, px, 'stop loss');
          continue;
        }
        g.low = (g.low || 0) + 1;
      } else g.low = 0;
      if (STYLES[g.style]?.side && x >= STYLES[g.style].tpX) {
        this._sell(g, 1, px, '+25%');
        continue;
      }
      if (g.style === 'main') {
        const R = this.rulesFor(g.trader) || {};
        if (R.miniToX > 0 && !g.miniDone) {
          const from = R.miniFromX ?? 1.5;
          const pull = (R.miniPullbackPct ?? 12) / 100;
          if (g.peak >= from && (x >= R.miniToX || x <= g.peak * (1 - pull))) {
            g.miniDone = true;
            this._sell(g, Math.min(1, (R.miniPct ?? 100) / 100), px, 'safety net');
            continue;
          }
        }
      }
      if (this.now() - g.at > this.maxHoldMs) this._sell(g, 1, px, '8h limit');
    }
  }

  _sell(g, part, px, why) {
    const share = Math.min(g.left, g.left * part);
    if (!(share > 0)) return;
    const solIn = (STYLES[g.style] || STYLES.W2).sol;
    g.got += solIn * share * (px / g.entry) - this.fee;
    g.left -= share;
    this._dirty = true;
    if (g.left > 1e-6) return;
    delete this.d.open[g.key];
    this.d.closed.push({ key: g.key, trader: g.trader, style: g.style, sym: g.sym, pnl: +(g.got - g.cost).toFixed(6), x: +(g.got / g.cost).toFixed(3), why, at: this.now(), held: this.now() - g.at });
    if (this.d.closed.length > 4000) this.d.closed.splice(0, this.d.closed.length - 4000);
  }

  // per trader and style: closed coins, wins, PnL (+ open ghosts valued at their last price)
  stats(sinceMs = null) {
    const from = sinceMs ? this.now() - sinceMs : 0;
    const by = {};
    const grp = (s) => (s === 'main' ? 'main' : 'side'); // W2 + W3 + W4 (and older 'side' ghosts) together
    const row = (t, s) => ((by[t] ||= { main: null, side: null })[grp(s)] ||= { n: 0, won: 0, pnl: 0, open: 0, openPnl: 0 });
    for (const c of this.d.closed) {
      if (c.at < from) continue;
      const r = row(c.trader, c.style);
      r.n++;
      if (c.pnl > 0) r.won++;
      r.pnl += c.pnl;
    }
    for (const g of Object.values(this.d.open)) {
      const r = row(g.trader, g.style);
      r.open++;
      if (g.lastPx > 0) r.openPnl += (STYLES[g.style] || STYLES.W2).sol * g.left * (g.lastPx / g.entry) + g.got - g.cost;
    }
    return by;
  }

  report({ sinceMs = null, title = '👻 <b>Ghost wallets</b>' } = {}) {
    const by = this.stats(sinceMs);
    const names = Object.keys(by);
    if (!names.length) return `${title}: nothing yet — every trader's buys are simulated from now on.`;
    const sg = (n) => `${n >= 0 ? '+' : '-'}${Math.abs(n).toFixed(3)}`;
    const tot = (b) => (b.main?.pnl || 0) + (b.side?.pnl || 0);
    names.sort((a, b) => tot(by[b]) - tot(by[a]));
    const cell = (r, label) => (r ? `${label} ${sg(r.pnl)} (${r.won}/${r.n})${r.open ? ` +${r.open} open ${sg(r.openPnl)}` : ''}` : `${label} —`);
    const lines = [`${title} (4 pretend wallets per trader, like yours: main 0.1 SOL/coin + ${SIDES.length} sides 0.05 SOL/coin)`];
    for (const n of names) {
      const b = by[n];
      const best = (b.main?.pnl || 0) >= (b.side?.pnl || 0) ? 'main' : 'sides';
      const t = tot(b);
      lines.push(`${t > 0 ? '🟢' : '🔴'} <b>${n}</b>: set ${sg(t)} · ${cell(b.main, 'main')} · ${cell(b.side, `${SIDES.length} sides`)}${t > 0 ? ` → best: ${best}` : ''}`);
    }
    const hrs = Math.max(0.1, (this.now() - (this.d.since || this.now())) / 3600000);
    lines.push(`<i>Since ${hrs < 24 ? `${hrs.toFixed(1)}h` : `${(hrs / 24).toFixed(1)} days`} ago · estimates: his price +${Math.round((this.entryPenalty - 1) * 100)}% for our delay, real fees · /ghosts reset to start over</i>`);
    return lines.join('\n');
  }
}
