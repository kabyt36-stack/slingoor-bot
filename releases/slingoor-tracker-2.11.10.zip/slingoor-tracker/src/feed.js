// Traders sent by the wallet leaderboard bot (a separate bot on this Mac). It writes its best wallets to a
// feed file; this bot reads that file (it never writes to it) and adds those wallets as traders.
// A trader added this way is treated like any other tracked trader: pretend wallets follow him first, and
// auto-rotate only copies him once his pretend results are good (🔥 hot / 🟡 neutral). Cold ones are never
// copied, and are removed after ROTATE_RETIRE_COLD_DAYS like everyone else.
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const B58 = /^[1-9A-HJ-NP-Za-km-z]{32,44}$/;
export const expandHome = (p) => String(p || '').replace(/^~(?=\/|$)/, os.homedir());

// the traders already taken in (data/feed-traders.json)
export function loadFeedTraders(storeFile) {
  try {
    const j = JSON.parse(fs.readFileSync(storeFile, 'utf8'));
    return (Array.isArray(j?.traders) ? j.traders : []).filter((t) => t && typeof t.name === 'string' && /^[\w-]{2,24}$/.test(t.name) && B58.test(t.wallet || ''));
  } catch {
    return [];
  }
}

function saveStore(storeFile, traders, extra = {}) {
  fs.mkdirSync(path.dirname(storeFile), { recursive: true });
  fs.writeFileSync(storeFile + '.tmp', JSON.stringify({ traders, ...extra }, null, 1));
  fs.renameSync(storeFile + '.tmp', storeFile);
}

// lb_ + the start of the wallet (longer if that name is taken)
export function feedName(wallet, taken) {
  for (let n = 4; n <= 12; n++) {
    const name = `lb_${wallet.slice(0, n)}`;
    if (!taken.has(name)) return name;
  }
  return `lb_${wallet.slice(0, 16)}`;
}

// Reads the feed and takes in picks it doesn't have yet.
//   knownWallets: wallets this bot already follows in any way (traders, devs, watch-only) — never added twice
//   takenNames:   trader names already in use
//   retired:      names removed for being cold (they don't count toward the limit, and are not re-added)
// -> { added: [...], reason } ; reason says why nothing was read (no file, stale, ...)
export function syncFeed({ feedFile, storeFile, knownWallets = new Set(), takenNames = new Set(), retired = new Set(), max = 10, maxAgeMs = 60 * 60000, now = Date.now() }) {
  let feed;
  try {
    feed = JSON.parse(fs.readFileSync(feedFile, 'utf8'));
  } catch (e) {
    return { added: [], reason: e.code === 'ENOENT' ? 'no feed file' : 'feed file unreadable' };
  }
  if (feed?.bot !== 'wallet-leaderboard-bot' || !Array.isArray(feed.picks)) return { added: [], reason: 'not a leaderboard feed' };
  if (!(now - feed.updatedAt <= maxAgeMs)) return { added: [], reason: 'feed is old (leaderboard bot not running?)' };
  const store = loadFeedTraders(storeFile);
  const have = new Set(store.map((t) => t.wallet));
  const names = new Set([...takenNames, ...store.map((t) => t.name)]);
  let live = store.filter((t) => !retired.has(t.name)).length;
  const added = [];
  for (const p of feed.picks) {
    if (live >= max) break;
    if (!p || !B58.test(p.wallet || '') || have.has(p.wallet) || knownWallets.has(p.wallet)) continue;
    const t = { name: feedName(p.wallet, names), wallet: p.wallet, addedAt: now, greenStreak: +p.greenStreak || 0, pnl7dSol: +p.pnl7dSol || 0, winRate: +p.winRate || 0 };
    names.add(t.name);
    have.add(t.wallet);
    store.push(t);
    added.push(t);
    live++;
  }
  if (added.length) saveStore(storeFile, store, { updatedAt: now });
  return { added, reason: null };
}
