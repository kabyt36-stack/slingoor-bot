// V2.10 auto-rotate (Khalil, Nov 12): the bot follows every trader with pretend wallets and decides on its own
// who your wallets copy, judged on his LAST 30 TRADES (a trader can get hot at any time of day).
// V2.11.2 three tiers (Khalil, Nov 12 9:11pm: "a neutral section the bot can trade but it will prioritize the
// hot trades. And if the neutral trade keeps getting profit it will just move to hot"):
//   🔥 hot     : his last 30 clearly made money (20+ trades, winners 2x+ the losers, e.g. +31 vs -3)
//                -> copied at full size, first in line
//   🟡 neutral : not hot, but not losing (10+ trades, break-even or up) -> copied at a smaller size, and only
//                while there's room left for the hot traders. Keeps winning -> becomes hot by itself.
//   🧊 cold    : lost more than he won over his last 30 (10+ trades) -> not copied
//   ⚪ not enough trades yet -> not copied (one you were already copying keeps his tier until he has 10)
//   🆕 new wallet (tracked under the wait) -> not copied yet
import fs from 'node:fs';
import path from 'node:path';

const DAY = 24 * 3600000;
const EMPTY = { coins: 0, pnl: 0, gains: 0, losses: 0, last10: 0 };

export class Rotator {
  constructor({ file, now = () => Date.now(), recent, traders, minCoins = 20, neutralMinCoins = 10, window = 30, hotRatio = 2, newMs = 2 * DAY, noWaitUntil = 0, start = [], retireMs = 0 }) {
    this.retireMs = retireMs; // V2.11.5 cold this long without a break -> removed (0 = never)
    this.file = file;
    this.now = now;
    this.recent = recent; // (trader, n) -> { coins, pnl, gains, losses, last10 } of his last n pretend trades
    this.window = window;
    this.hotRatio = hotRatio;
    this.traders = traders; // () => names that can be copied
    this.minCoins = minCoins;
    this.neutralMinCoins = Math.min(neutralMinCoins, minCoins);
    this.newMs = newMs;
    this.noWaitUntil = noWaitUntil; // wallets first seen before this skip the wait
    this.d = { on: true, copying: [...start], tiers: {}, firstSeen: {}, log: [] };
    try {
      this.d = { ...this.d, ...JSON.parse(fs.readFileSync(file, 'utf8')) };
    } catch {}
    this.d.tiers ||= {};
    this.d.coldSince ||= {};
    // before tiers existed everyone copied counted as hot
    for (const n of this.d.copying) this.d.tiers[n] ||= 'hot';
  }

  save() {
    try {
      fs.mkdirSync(path.dirname(this.file), { recursive: true });
      fs.writeFileSync(this.file + '.tmp', JSON.stringify(this.d));
      fs.renameSync(this.file + '.tmp', this.file);
    } catch {}
  }

  get on() {
    return this.d.on;
  }

  set on(v) {
    this.d.on = !!v;
    this.save();
  }

  // everyone your wallets copy (hot + neutral)
  get copying() {
    return [...this.d.copying];
  }

  // 'hot' | 'neutral' | null (not copied)
  tier(trader) {
    if (!this.d.copying.includes(trader)) return null;
    return this.d.tiers[trader] === 'neutral' ? 'neutral' : 'hot';
  }

  // a trader the ghosts just saw buying (starts his wait)
  seen(trader) {
    if (!trader || this.d.firstSeen[trader]) return;
    this.d.firstSeen[trader] = this.now();
    this.save();
  }

  ageMs(trader) {
    const f = this.d.firstSeen[trader];
    if (f && f < this.noWaitUntil) return Infinity;
    return f ? this.now() - f : 0;
  }

  isHot(r) {
    return r.coins >= this.minCoins && r.pnl > 0 && r.gains >= this.hotRatio * r.losses;
  }

  // where he stands now: 'hot' | 'neutral' | 'cold' | 'few' (not enough trades) | 'new'
  judge(n, r, was) {
    if (!was && this.ageMs(n) < this.newMs) return 'new';
    if (this.isHot(r)) return 'hot';
    if (r.coins >= this.neutralMinCoins) return r.pnl >= 0 ? 'neutral' : 'cold';
    return was ? (was === 'neutral' ? 'neutral' : 'hot') : 'few'; // too few trades to judge: as before
  }

  // one decision round: { added (now hot), neutral (now neutral), dropped (now cold) } with their last-30 numbers
  run() {
    const out = { added: [], neutral: [], dropped: [], retire: [] };
    if (!this.d.on) return out;
    const names = this.traders();
    const copying = [];
    const tiers = {};
    for (const n of names) {
      const r = this.recent(n, this.window) || EMPTY;
      const was = this.d.copying.includes(n) ? this.d.tiers[n] || 'hot' : null;
      const now = this.judge(n, r, was);
      // V2.11.5 how long he's been cold without a break (anything else resets it)
      if (now === 'cold') this.d.coldSince[n] ||= this.now();
      else delete this.d.coldSince[n];
      if (now === 'cold' && this.retireMs > 0 && this.now() - this.d.coldSince[n] >= this.retireMs) out.retire.push({ name: n, ...r, coldMs: this.now() - this.d.coldSince[n] });
      if (now === 'hot' || now === 'neutral') {
        copying.push(n);
        tiers[n] = now;
      }
      if (now === 'hot' && was !== 'hot') out.added.push({ name: n, ...r });
      else if (now === 'neutral' && was !== 'neutral') out.neutral.push({ name: n, ...r, from: was });
      else if (was && now !== 'hot' && now !== 'neutral') out.dropped.push({ name: n, ...r });
    }
    this.d.copying = copying;
    this.d.tiers = tiers;
    const at = this.now();
    for (const x of out.added) this.d.log.push({ at, name: x.name, what: 'hot', pnl: x.pnl });
    for (const x of out.neutral) this.d.log.push({ at, name: x.name, what: 'neutral', pnl: x.pnl });
    for (const x of out.dropped) this.d.log.push({ at, name: x.name, what: 'dropped', pnl: x.pnl });
    if (this.d.log.length > 200) this.d.log.splice(0, this.d.log.length - 200);
    this.d.lastRun = at;
    this.save();
    return out;
  }

  statusText() {
    const names = this.traders();
    const sg = (n) => `${n >= 0 ? '+' : '-'}${Math.abs(n).toFixed(3)}`;
    const hot = this.d.copying.filter((n) => this.tier(n) === 'hot');
    const neu = this.d.copying.filter((n) => this.tier(n) === 'neutral');
    const lines = [`🔄 <b>Copying now</b> (picked automatically): 🔥 <b>${hot.join(', ') || 'nobody hot yet'}</b>${neu.length ? ` · 🟡 ${neu.join(', ')}` : ''}`];
    for (const n of names) {
      const r = this.recent(n, this.window) || EMPTY;
      const age = this.ageMs(n);
      const t = this.tier(n);
      let state;
      if (t === 'hot') state = '🔥 hot — copied';
      else if (t === 'neutral') state = '🟡 neutral — copied smaller, when there\'s room';
      else if (age < this.newMs) state = `🆕 new — usable in ${Math.ceil((this.newMs - age) / 3600000)}h`;
      else if (r.coins < this.neutralMinCoins) state = `⚪ not enough trades yet (${r.coins}/${this.neutralMinCoins})`;
      else state = this.judge(n, r, null) === 'cold' ? '🧊 cold' : '⏳ copied from the next check';
      lines.push(`• <b>${n}</b>: ${state} · last ${r.coins}: ${sg(r.pnl)} (won ${sg(r.gains)}, lost -${r.losses.toFixed(3)})`);
    }
    lines.push(
      `<i>🔥 hot = his last ${this.window} clearly made money (${this.minCoins}+ trades, winners ${this.hotRatio}x+ the losers): full size, first in line. 🟡 neutral = break-even or up (${this.neutralMinCoins}+ trades): smaller buys, only with room left for hot ones. 🧊 cold = lost more than he won: not copied.${this.newMs > 0 ? ` New wallets wait ${Math.round(this.newMs / 3600000)}h.` : ''}</i>`,
    );
    return lines.join('\n');
  }
}
