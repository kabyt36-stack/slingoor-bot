// End-to-end: runs the real bot.js as a child process against local mock servers that
// imitate pump.fun's API, a Solana RPC + websocket, and the Telegram Bot API.
// Requires the `ws` package for the mock websocket server: set WS_LIB to its path.
import { fileURLToPath } from 'node:url';
import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { realTxs, buildTx } from './helpers.js';
import { checkTelegramHtml, checkButtons } from './tg-html.js';

const WS_LIB = process.env.WS_LIB;
const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const fx = realTxs();
const W = fx.wallet;
const SSD = '5zNrC96R7vwWD6bfbTeUBseFztQY4Pr1iSgwoj7mpump';
const BTC = 'C5xph2yL6gMdxmuLGxJBkGpmuDFfyi5fqkBNhvL6pump';
const ABTC = 'ERs7y4nMGLFVmHcXyDxiS7iDKpp4jWHz2VUuE2gxpump';
const PLUMBER = '6y9aDagFD9RXVpJidYqmDozC3Qn2uRdtwPeoxT8pump';
const NEWC = 'NewLaunchMintAAAAAAAAAAAAAAAAAAAAAAAAAApump';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const iso = (t) => new Date(t).toISOString();

test('full bot run against mock pump.fun / Solana / Telegram', { skip: !WS_LIB, timeout: 120000 }, async () => {
  const { WebSocketServer } = await import(WS_LIB);
  const now = Date.now();

  // ---------------- mock data ----------------
  const M = {
    user: { address: W, userId: 'U1', username: 'slingoor', followers: 205538 },
    callouts: [{ calloutId: 'c-old', userId: W, coinMint: ABTC, marketCap: 30000, createdAt: now - 3600e3, thesis: 'old call', updateCount: 0, updates: [], multiple: 1.2, maxMultiplier: 2 }],
    replies: {},
    trades: [{ tx: 'oldTx', isBuy: true, timestamp: iso(now - 60e3), amountUsd: 50, baseAmount: 1000, priceUsd: 0.05, mint: BTC, walletAddress: W, amountSol: 0.5, kind: 'trade' }],
    tradeCoins: [{ mint: BTC, name: 'Big Titty Coin', symbol: 'BTC' }],
    positions: {
      [ABTC]: [{ coinMint: ABTC, isExited: false, amountHeld: 112000000, costBasisUsd: 16458, pnlUsd: 43579, pnlPercentage: 264.8 }],
      [SSD]: [{ coinMint: SSD, isExited: true, amountHeld: 0, pnlUsd: 455, pnlPercentage: 242.7, updatedAt: iso(now) }],
    },
    coins: {
      [SSD]: { mint: SSD, name: 'Sperm Storage Department', symbol: 'SSD', usd_market_cap: 35411, complete: false, program: 'pump', created_timestamp: now - 3600e3 },
      [BTC]: { mint: BTC, name: 'Big Titty Coin', symbol: 'BTC', usd_market_cap: 9_800_000, complete: true, program: 'pump', created_timestamp: now - 30 * 86400e3 },
      [ABTC]: { mint: ABTC, name: 'Anime Bitcoin', symbol: 'ABTC', usd_market_cap: 535308, complete: true, program: 'pump', created_timestamp: now - 86400e3 },
      [PLUMBER]: { mint: PLUMBER, name: 'Plumber', symbol: 'PLUMBER', usd_market_cap: 120000, complete: true, program: 'pump', created_timestamp: now - 86400e3 },
      [NEWC]: { mint: NEWC, name: 'Massive Sweaty Titties Rising', symbol: 'MSTR', usd_market_cap: 4200, complete: false, program: 'pump', created_timestamp: now },
    },
    created: [{ mint: 'OldLaunchMintAAAAAAAAAAAAAAAAAAAAAAAAAApump', name: 'its too', symbol: 'DAMN', created_timestamp: now - 86400e3 }],
    holdings: [
      { token_mint: BTC, token_name: 'Big Titty Coin', token_symbol: 'BTC', balance: 613615719, value: 9811068 },
      { token_mint: ABTC, token_name: 'Anime Bitcoin', token_symbol: 'ABTC', balance: 112000000, value: 60000 },
    ],
    balances: {},
    txs: {},
    rpcCalls: [],
  };
  for (const [name, t] of Object.entries(fx.txs)) M.txs[t.sig] = buildTx(t.c, W, t.sig);

  // ---------------- Telegram mock ----------------
  const TG = { sent: [], edits: [], updates: [], nextId: 1, updateId: 1 };
  const tgPush = (text, chatId = 111) => TG.updates.push({ update_id: TG.updateId++, message: { message_id: 1, date: Math.floor(Date.now() / 1000), chat: { id: chatId, type: 'private' }, text } });

  const server = http.createServer(async (req, res) => {
    const url = new URL(req.url, 'http://x');
    let body = '';
    for await (const chunk of req) body += chunk;
    const json = (o, status = 200) => {
      res.writeHead(status, { 'content-type': 'application/json' });
      res.end(JSON.stringify(o));
    };
    const p = url.pathname;
    // --- telegram
    if (p.startsWith('/tg/bot')) {
      const method = p.split('/').pop();
      const params = body ? JSON.parse(body) : {};
      if (method === 'getMe') return json({ ok: true, result: { id: 1, username: 'test_tracker_bot' } });
      if (method === 'sendMessage') {
        const id = TG.nextId++;
        TG.sent.push({ ...params, message_id: id });
        return json({ ok: true, result: { message_id: id } });
      }
      if (method === 'editMessageText') {
        TG.edits.push(params);
        return json({ ok: true, result: true });
      }
      if (method === 'getUpdates') {
        for (let i = 0; i < 10 && !TG.updates.length; i++) await sleep(100);
        const u = TG.updates.splice(0);
        return json({ ok: true, result: u });
      }
      return json({ ok: false, description: 'unknown' }, 404);
    }
    // --- pump.fun
    if (p === `/pump/users/${W}`) return json(M.user);
    if (p === `/pump/callout/list/U1` && M.calloutListDown) return json({ message: 'Service Unavailable' }, 503);
    if (p === `/pump/callout/list/U1`) return json({ callouts: [...M.callouts].sort((a, b) => b.createdAt - a.createdAt), nextPageToken: '' });
    let m;
    if ((m = /^\/pump\/callout\/([^/]+)\/replies$/.exec(p))) return json({ replies: M.replies[m[1]] || [] });
    if (p === `/pump/user-trades/U1`) return json({ trades: [...M.trades].sort((a, b) => Date.parse(b.timestamp) - Date.parse(a.timestamp)), coins: M.tradeCoins, traders: [], nextCursor: null });
    if (p === `/pump/user-positions/${W}`) {
      const mints = (url.searchParams.get('mints') || '').split(',');
      // like pump.fun: each position carries his latest callout on that coin
      const withCallout = (pos) => {
        const c = [...M.callouts].filter((x) => x.coinMint === pos.coinMint).sort((a, b) => b.createdAt - a.createdAt)[0];
        if (!c || pos.callout) return pos;
        return { ...pos, callout: { calloutId: c.calloutId, calledOutAtMcap: c.marketCap, calloutTimestamp: iso(c.createdAt), thesis: c.thesis, updateCount: c.updateCount, updates: [], multiple: c.multiple, maxMultiplier: c.maxMultiplier } };
      };
      return json({ positions: mints.flatMap((x) => M.positions[x] || []).map(withCallout) });
    }
    if (p === `/pump/coins-v2/user-created-coins/${W}`) return json({ count: M.created.length, coins: M.created.slice(+url.searchParams.get('offset') || 0) });
    if ((m = /^\/pump\/coins-v2\/(\w+)$/.exec(p))) return M.coins[m[1]] ? json(M.coins[m[1]]) : json({ statusCode: 404 }, 404);
    if (p === '/pump/sol-price') return json({ solPrice: 96.1 });
    if (p === `/profile/balance/tokens/${W}`) return json({ success: true, data: { tokens: M.holdings }, pagination: { page: 1, totalPages: 1 } });
    if (p.startsWith('/dex/')) return json({ pairs: [] });
    // --- RPC
    if (p === '/rpc') {
      const r = JSON.parse(body);
      M.rpcCalls.push(r);
      if (r.method === 'getTransaction') return json({ jsonrpc: '2.0', id: r.id, result: M.txs[r.params[0]] || null });
      if (r.method === 'getTokenAccountsByOwner') {
        const mint = r.params[1].mint;
        const ui = M.balances[mint];
        const value = ui == null ? [] : [{ account: { data: { parsed: { info: { tokenAmount: { amount: String(Math.round(ui * 1e6)), decimals: 6, uiAmountString: String(ui) } } } } } }];
        return json({ jsonrpc: '2.0', id: r.id, result: { value } });
      }
      return json({ jsonrpc: '2.0', id: r.id, result: null });
    }
    json({ error: 'not found', path: p }, 404);
  });

  // ---------------- Solana websocket mock ----------------
  const wss = new WebSocketServer({ server, path: '/ws' });
  const WS = { sock: null, subs: {}, subscribeCount: 0 };
  wss.on('connection', (sock) => {
    WS.sock = sock;
    sock.on('message', (raw) => {
      const r = JSON.parse(String(raw));
      if (r.method === 'accountSubscribe' || r.method === 'logsSubscribe') {
        WS.subscribeCount++;
        const id = (r.method === 'accountSubscribe' ? 100 : 200) + WS.subscribeCount;
        WS.subs[r.method] = id;
        sock.send(JSON.stringify({ jsonrpc: '2.0', id: r.id, result: id }));
      } else sock.send(JSON.stringify({ jsonrpc: '2.0', id: r.id, error: { code: -32602, message: 'Invalid subscription id' } }));
    });
  });
  const notifyLogs = (sig, slot, logs) =>
    WS.sock.send(JSON.stringify({ jsonrpc: '2.0', method: 'logsNotification', params: { subscription: WS.subs.logsSubscribe, result: { context: { slot }, value: { signature: sig, err: null, logs } } } }));
  const notifyAccount = (slot) =>
    WS.sock.send(JSON.stringify({ jsonrpc: '2.0', method: 'accountNotification', params: { subscription: WS.subs.accountSubscribe, result: { context: { slot }, value: { lamports: 1, data: ['', 'base64'] } } } }));
  const tradeLogs = ['Program ComputeBudget111111111111111111111111111111 invoke [1]', 'Program 6Vo3245eszAb5wuqEMw8mGdbfRUdKbHhDHP5LcaGuTAB invoke [1]', 'Program log: Instruction: Buy'];

  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  const port = server.address().port;
  const base = `http://127.0.0.1:${port}`;

  // ---------------- run the bot ----------------
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'tracker-'));
  fs.writeFileSync(path.join(tmp, 'settings.txt'), 'TELEGRAM_BOT_TOKEN=123:abc\nTARGET_NAME=slingoor\n');
  const env = {
    ...process.env,
    SETTINGS_FILE: path.join(tmp, 'settings.txt'),
    PUMP_API_BASE: `${base}/pump`,
    PROFILE_API_BASE: `${base}/profile`,
    TELEGRAM_API_BASE: `${base}/tg`,
    DEX_API_BASE: `${base}/dex`,
    RPC_URL: `${base}/rpc`,
    WS_URL: `ws://127.0.0.1:${port}/ws`,
    STATE_FILE: path.join(tmp, 'state.json'),
    LOG_FILE: path.join(tmp, 'bot.log'),
    PUMP_TRADES_POLL_SECONDS: '1',
    CALLOUT_POLL_SECONDS: '2',
    CALLOUT_LIST_SECONDS: '4',
    LAUNCH_POLL_SECONDS: '5',
    MERGE_WINDOW_SECONDS: '6',
    LOCK_FILE: path.join(tmp, 'bot.lock'),
    SUMMARY_FILE: path.join(tmp, 'summary.json'),
    TRADERS_OFF_FILE: path.join(tmp, 'traders-off.json'),
    COPY_TRADERS_OFF: 'none',
    TRADERS: 'none',
    DEVS: 'none',
    WATCH_WALLETS: 'none',
    SHORT_ALERTS: 'off',
    PAPER_LAND_MS: '0',
    WALLET_TRADERS: 'main:all',
    WALLET_SETS: 'none',
    COPY_MIN_HOLDERS_TO_BUY: '0',
    COPY_MAX_CHASE_PERCENT: '0',
    AUTO_ROTATE: 'off',
    TARGET_ONLY_ALERTS: 'off',
    COPY_SMART_SIZE: 'off',
    COPY_BEST_HOURS: 'off',
    COPY_EXIT_PICK: 'off',
    ROTATE_FILE: path.join(tmp, 'rotate.json'),
    ROTATE_DEVS_FILE: path.join(tmp, 'rotate-devs.json'),
    RETIRED_FILE: path.join(tmp, 'retired.json'),
    WALLET_TRADERS_FILE: path.join(tmp, 'wallet-traders.json'),
    QUIET_MODE: 'off', // this test checks every per-trade alert
    CUPSEY_MODE: 'off',
    USE_PUMPFUN: 'on', // this test covers the pump.fun feeds
  };
  const bot = spawn(process.execPath, ['bot.js'], { cwd: ROOT, env });
  let out = '';
  bot.stdout.on('data', (d) => (out += d));
  bot.stderr.on('data', (d) => (out += d));

  const waitFor = async (what, fn, ms = 15000) => {
    const t0 = Date.now();
    while (Date.now() - t0 < ms) {
      const v = fn();
      if (v) return v;
      await sleep(100);
    }
    throw new Error(`Timed out waiting for: ${what}\n--- bot output ---\n${out.slice(-3000)}`);
  };
  const sentMatching = (re) => TG.sent.filter((s) => re.test(s.text));

  try {
    await waitFor('websocket subscriptions', () => WS.subs.logsSubscribe && WS.subs.accountSubscribe);
    await waitFor('pollers seeded', () => /Callout feed live/.test(out) && /trades feed live/.test(out) && /Launch feed live/.test(out));

    // /start registers the chat
    tgPush('/start');
    await waitFor('/start reply', () => sentMatching(/You're set/).length);
    await waitFor('status reply', () => sentMatching(/Tracker status/).length);
    assert.equal(sentMatching(/oldTx|old call/).length, 0, 'history must not be alerted');
    await waitFor('meta learned', () => /Meta learned from/.test(out));

    // 1) NEW ENTRY from the chain stream (logs first, then his account changes in the same slot)
    const buy = fx.txs.ssdBuy;
    notifyLogs(buy.sig, buy.c.slot, tradeLogs);
    await sleep(150);
    notifyAccount(buy.c.slot);
    const entry = await waitFor('NEW ENTRY alert', () => sentMatching(/NEW ENTRY/)[0]);
    assert.match(entry.text, /\$SSD/);
    assert.match(entry.text, /Sperm Storage Department/);
    assert.match(entry.text, /Bought <b>1\.00 SOL<\/b>/);
    assert.match(entry.text, /BIG TITTY COIN FORMULA/);
    assert.match(entry.text, /via on-chain stream/);
    assert.match(entry.text, new RegExp(SSD));
    assert.ok(entry.reply_markup.inline_keyboard.flat().some((b) => b.url === `https://pump.fun/coin/${SSD}`));

    // 2) Other people's trades that mention him (his account NOT written that slot) are never fetched
    const before = M.rpcCalls.filter((r) => r.method === 'getTransaction').length;
    notifyLogs('TailTradeSig111', 999001, tradeLogs);
    notifyLogs('SpamTransferSig111', 999002, ['Program TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA invoke [1]', 'Program log: Instruction: TransferChecked']);
    notifyAccount(999003); // e.g. someone sent him dust SOL; no candidate tx in that slot
    await sleep(1200);
    const fetchedSigs = M.rpcCalls.filter((r) => r.method === 'getTransaction').map((r) => r.params[0]);
    assert.equal(fetchedSigs.length, before, `should not fetch tail/spam txs, fetched: ${fetchedSigs.slice(before)}`);

    // 3) Same buy later shows up in pump.fun's feed -> no duplicate alert
    M.trades.push({ tx: buy.sig, isBuy: true, timestamp: iso(Date.now()), amountUsd: 96, baseAmount: 21878355.984281, priceUsd: 0, mint: SSD, walletAddress: W, amountSol: 1, kind: 'trade' });
    await sleep(2500);
    assert.equal(sentMatching(/NEW ENTRY/).length, 1, 'no duplicate entry alert');

    // 4) Partial sell seen only in pump.fun's feed; remaining balance checked on-chain
    M.balances[SSD] = 21878355.984281 / 2;
    M.trades.push({ tx: 'PartialSellSig', isBuy: false, timestamp: iso(Date.now()), amountUsd: 120, baseAmount: 21878355.984281 / 2, priceUsd: 0, mint: SSD, walletAddress: W, amountSol: 1.25, kind: 'trade' });
    const partial = await waitFor('partial sell alert', () => sentMatching(/SOLD 50%/)[0]);
    assert.match(partial.text, /Sold for <b>1\.25 SOL<\/b>/);
    assert.match(partial.text, /Still holding ~50%/);
    assert.match(partial.text, /via pump\.fun feed/);

    // 5) Full exit on-chain -> FULLY SOLD OUT, then edited with the trip result + pump.fun PnL
    const sell = fx.txs.ssdSell;
    notifyAccount(sell.c.slot);
    await sleep(100);
    notifyLogs(sell.sig, sell.c.slot, tradeLogs);
    const exit = await waitFor('full exit alert', () => sentMatching(/FULLY SOLD OUT/)[0]);
    assert.match(exit.text, /\$SSD/);
    assert.match(exit.text, /Sold for <b>2\.73 SOL<\/b>/);
    assert.match(exit.text, /completely out/);
    assert.match(exit.text, /This trip: in 1\.00 SOL → out 3\.98 SOL = <b>\+2\.98 SOL<\/b>/);
    const pnlEdit = await waitFor('pnl edit', () => TG.edits.find((e) => e.message_id === exit.message_id && /pump\.fun PnL on this coin: <b>\$455<\/b>/.test(e.text)), 12000);
    assert.ok(pnlEdit);

    // 6) Burst of 3 quick buys of a new coin -> one alert, edited twice
    for (let i = 0; i < 3; i++) {
      M.trades.push({ tx: `PlumberBuy${i}`, isBuy: true, timestamp: iso(Date.now()), amountUsd: 48, baseAmount: 1e6, priceUsd: 0, mint: PLUMBER, walletAddress: W, amountSol: 0.5, kind: 'trade' });
      await sleep(400);
    }
    const pl = await waitFor('plumber entry', () => sentMatching(/NEW ENTRY.*\$PLUMBER/)[0]);
    await waitFor('plumber merged edits', () => TG.edits.some((e) => e.message_id === pl.message_id && /3 buys/.test(e.text) && /1\.50 SOL/.test(e.text)), 8000);
    assert.equal(sentMatching(/\$PLUMBER/).length, 1, 'burst should be one message');
    assert.match(pl.text, /Off his usual meta|Partial meta match/);

    // 7) New callout
    M.callouts.push({ calloutId: 'c-new', userId: W, coinMint: ABTC, marketCap: 35411, createdAt: Date.now(), thesis: 'Watching serial deployers vamp everything is so funny.', updateCount: 0, updates: [], multiple: 1, maxMultiplier: 1 });
    const call = await waitFor('callout alert', () => sentMatching(/CALLOUT<\/b>/)[0]);
    assert.match(call.text, /\$ABTC/);
    assert.match(call.text, /serial deployers vamp everything/);
    assert.match(call.text, /MC at call \$35\.4K/);
    assert.match(call.text, /He's holding it · cost \$16\.5K · \+265%/);
    assert.ok(call.reply_markup.inline_keyboard.flat().some((b) => b.url.includes('highlight_callout=c-new')));

    // 8) Callout update
    M.replies['c-new'] = [{ id: 'u1', content: 'still not selling', createdAt: iso(Date.now()), userId: 'U1', walletAddress: W }];
    M.callouts.find((c) => c.calloutId === 'c-new').updateCount = 1;
    const upd = await waitFor('callout update alert', () => sentMatching(/CALLOUT UPDATE/)[0]);
    assert.match(upd.text, /still not selling/);

    // 8b) pump.fun's callout list starts refusing us (503) -> callouts still arrive through his positions
    M.calloutListDown = true;
    M.positions[PLUMBER] = [{ coinMint: PLUMBER, isExited: false, amountHeld: 3e6, costBasisUsd: 144, pnlPercentage: 10,
      callout: { calloutId: 'c-pos', calledOutAtMcap: 120000, calloutTimestamp: iso(Date.now()), thesis: 'plumbing szn', updateCount: 0, updates: [], multiple: 1, maxMultiplier: 1 } }];
    const posCall = await waitFor('callout via positions fallback', () => sentMatching(/CALLOUT<\/b> <b>\$PLUMBER/)[0], 20000);
    assert.match(posCall.text, /plumbing szn/);
    assert.match(posCall.text, /MC at call \$120\.0K/);
    // (positions are checked between list reads anyway, so the callout can land before the list is even retried)
    await waitFor('list-unavailable notice', () => /reading callouts from his positions instead/.test(out), 10000);
    await sleep(6000);
    assert.equal(sentMatching(/CALLOUT<\/b> <b>\$PLUMBER/).length, 1, 'fallback must not repeat the callout');

    // 9) New launch (pump.fun created-coins feed)
    M.created.push({ mint: NEWC, name: 'Massive Sweaty Titties Rising', symbol: 'MSTR', created_timestamp: Date.now() });
    const launch = await waitFor('launch alert', () => sentMatching(/LAUNCHED A COIN/)[0], 15000);
    assert.match(launch.text, /\$MSTR/);
    assert.match(launch.text, /BIG TITTY COIN FORMULA/);

    // 10) Commands
    tgPush('/meta');
    const meta = await waitFor('/meta reply', () => sentMatching(/slingoor's meta/)[0]);
    assert.match(meta.text, /Big Titty Coin formula/);
    tgPush(BTC);
    await waitFor('paste-a-CA check', () => sentMatching(/🔎 <b>\$BTC<\/b>/)[0]);
    tgPush('/recent');
    await waitFor('/recent', () => sentMatching(/Last alerts/)[0]);
    tgPush('/status', 222); // a stranger's chat gets nothing
    tgPush('/start', 222);
    await waitFor('stranger refused', () => sentMatching(/This tracker is private/)[0]);
    assert.equal(TG.sent.filter((s) => s.chat_id === 222 && /Tracker status/.test(s.text)).length, 0);

    // 11) Websocket drops -> bot reconnects and re-subscribes
    const subsBefore = WS.subscribeCount;
    WS.sock.terminate();
    await waitFor('resubscribe after drop', () => WS.subscribeCount >= subsBefore + 2, 10000);

    // every message and edit the bot produced is valid Telegram HTML with valid buttons
    for (const m of [...TG.sent, ...TG.edits]) {
      assert.deepEqual(checkTelegramHtml(m.text), [], m.text);
      assert.deepEqual(checkButtons(m.reply_markup), []);
      assert.deepEqual(m.link_preview_options, { is_disabled: true });
      assert.equal(m.parse_mode, 'HTML');
    }

    // every alert went only to the registered chat
    assert.ok(TG.sent.filter((s) => /NEW ENTRY|SOLD|CALLOUT|LAUNCHED/.test(s.text)).every((s) => s.chat_id === '111'));
    // state persisted
    const st = JSON.parse(fs.readFileSync(path.join(tmp, 'state.json'), 'utf8'));
    assert.deepEqual(st.chats, ['111']);
  } finally {
    bot.kill('SIGTERM');
    await sleep(300);
    wss.close();
    server.close();
    if (process.env.SHOW_BOT_OUTPUT) console.log(out);
    if (process.env.SHOW_MESSAGES) for (const s of TG.sent) console.log('-----\n' + s.text);
  }
});
