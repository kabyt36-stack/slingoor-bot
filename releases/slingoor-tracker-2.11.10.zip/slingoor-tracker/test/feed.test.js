import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { syncFeed, loadFeedTraders, feedName, expandHome } from '../src/feed.js';
import { loadConfig } from '../src/config.js';
import { b58encode } from '../src/solana.js';
import { startWorld } from './mock.js';

const WS_LIB = process.env.WS_LIB;
const tmpdir = () => fs.mkdtempSync(path.join(os.tmpdir(), 'feed-'));
const addr = () => b58encode(crypto.randomBytes(32));
const pick = (wallet, extra = {}) => ({ wallet, name: null, greenStreak: 5, pnlSol: 9.1, pnl7dSol: 9.1, winRate: 0.7, wins: 14, losses: 6, winsInARow: 3, ...extra });
const writeFeed = (file, picks, extra = {}) => fs.writeFileSync(file, JSON.stringify({ bot: 'wallet-leaderboard-bot', version: '1.1.0', updatedAt: Date.now(), picks, wallets: {}, coins: {}, paper: null, ...extra }));

test('feed: new picks are taken in once, named lb_xxxx, capped, and never duplicate a followed wallet', () => {
  const dir = tmpdir();
  const feedFile = path.join(dir, 'feed.json');
  const storeFile = path.join(dir, 'data', 'feed-traders.json');
  const [a, b, c, d] = [addr(), addr(), addr(), addr()];
  writeFeed(feedFile, [pick(a), pick(b), pick(c), pick(d)]);
  const r = syncFeed({ feedFile, storeFile, knownWallets: new Set([b]), max: 2 });
  assert.deepEqual(r.added.map((t) => t.wallet), [a, c]); // b is already followed, d is over the limit
  assert.equal(r.added[0].name, `lb_${a.slice(0, 4)}`);
  assert.equal(r.added[0].greenStreak, 5);
  assert.deepEqual(loadFeedTraders(storeFile).map((t) => t.wallet), [a, c]);
  // again: nothing new
  assert.deepEqual(syncFeed({ feedFile, storeFile, knownWallets: new Set([b]), max: 2 }).added, []);
  // one of them was removed for being cold: its place is free, but it is not taken in again
  const r2 = syncFeed({ feedFile, storeFile, knownWallets: new Set([b]), retired: new Set([r.added[0].name]), max: 2 });
  assert.deepEqual(r2.added.map((t) => t.wallet), [d]);
  // a name that's taken gets a longer one
  assert.equal(feedName(a, new Set([`lb_${a.slice(0, 4)}`])), `lb_${a.slice(0, 5)}`);
  assert.equal(expandHome('~/x.json'), path.join(os.homedir(), 'x.json'));
});

test('feed: a missing, old, foreign or broken file changes nothing', () => {
  const dir = tmpdir();
  const feedFile = path.join(dir, 'feed.json');
  const storeFile = path.join(dir, 'feed-traders.json');
  assert.equal(syncFeed({ feedFile, storeFile }).reason, 'no feed file');
  writeFeed(feedFile, [pick(addr())], { updatedAt: Date.now() - 3 * 3600000 });
  assert.match(syncFeed({ feedFile, storeFile }).reason, /old/);
  writeFeed(feedFile, [pick(addr())], { bot: 'something-else' });
  assert.match(syncFeed({ feedFile, storeFile }).reason, /not a leaderboard feed/);
  fs.writeFileSync(feedFile, '{ half a fi');
  assert.match(syncFeed({ feedFile, storeFile }).reason, /unreadable/);
  writeFeed(feedFile, [{ wallet: 'not-an-address' }, null, pick('x')]);
  assert.deepEqual(syncFeed({ feedFile, storeFile }).added, []);
  assert.ok(!fs.existsSync(storeFile));
});

test('settings: stored feed traders become tracked traders (not devs, not watch-only wallets); off switch', () => {
  const dir = tmpdir();
  const storeFile = path.join(dir, 'feed-traders.json');
  const base = loadConfig('/nonexistent');
  const n0 = base.traders.length;
  const fresh = addr();
  const watchOnly = base.copy.watchWallets[0].wallet;
  const tracked = base.traders[1].wallets[0];
  fs.writeFileSync(storeFile, JSON.stringify({ traders: [{ name: 'lb_new1', wallet: fresh }, { name: 'lb_w', wallet: watchOnly }, { name: 'lb_t', wallet: tracked }, { name: 'bad name!', wallet: addr() }, { name: 'lb_x', wallet: 'nope' }] }));
  const f = path.join(dir, 's.txt');
  fs.writeFileSync(f, `TELEGRAM_BOT_TOKEN=1:x\nFEED_TRADERS_FILE=${storeFile}\n`);
  const c = loadConfig(f);
  assert.equal(c.traders.length, n0 + 1);
  const t = c.traders.find((x) => x.name === 'lb_new1');
  assert.deepEqual(t.wallets, [fresh]);
  assert.ok(t.fromFeed && !t.isDev);
  assert.ok(c.wallets.includes(fresh));
  assert.equal(c.copy.feed.max, 10);
  fs.appendFileSync(f, 'FEED_TRADERS=off\n');
  const off = loadConfig(f);
  assert.equal(off.traders.length, n0);
  assert.equal(off.copy.feed.enabled, false);
});

test('bot: a trader sent by the leaderboard bot is announced, the bot restarts and then follows him — once', { skip: !WS_LIB, timeout: 90000 }, async () => {
  const w = await startWorld(WS_LIB);
  const feedFile = path.join(w.tmp, 'feed.json');
  const storeFile = path.join(w.tmp, 'feed-traders.json');
  const star = addr();
  const env = { FEED_TRADERS: 'on', FEED_FILE: feedFile, FEED_TRADERS_FILE: storeFile, FEED_FIRST_MS: '700', FEED_FORCE: '1' };
  try {
    const p1 = w.startBot(env);
    w.tgPush('/start');
    await w.waitFor('registered', () => w.sent(/You're set/).length);
    await new Promise((r) => setTimeout(r, 1500)); // no feed file yet: nothing happens
    assert.equal(p1.exitCode, null);
    writeFeed(feedFile, [pick(star)]);
    // no restart until the next check; force one by restarting the bot ourselves
    await w.stopBot();
    const p2 = w.startBot(env);
    const code = await new Promise((r) => p2.on('exit', r));
    assert.equal(code, 75); // asks the watchdog for a restart
    const note = w.sent(/Leaderboard scanner sent 1 trader/);
    assert.equal(note.length, 1);
    assert.match(note[0].text, new RegExp(`lb_${star.slice(0, 4)} \\(5d green, \\+9\\.1 SOL 7d\\)`));
    assert.match(note[0].text, /copied only if they turn hot/);
    // started again: it follows the wallet now, and doesn't restart or announce a second time
    w.out = '';
    const p3 = w.startBot(env);
    await w.waitFor('following the new wallet', () => w.out.includes(`${star.slice(0, 4)}`) && /Starting tracker/.test(w.out));
    await new Promise((r) => setTimeout(r, 2500));
    assert.equal(p3.exitCode, null);
    assert.equal(w.sent(/Leaderboard scanner sent/).length, 1);
    assert.ok(!/Unhandled|Crashed|Fatal/.test(w.out), w.out.slice(-1500));
  } finally {
    await w.close();
  }
});
