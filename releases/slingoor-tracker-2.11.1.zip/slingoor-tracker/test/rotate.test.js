import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { Rotator } from '../src/rotate.js';
import { GhostBook } from '../src/ghost.js';

const H = 3600000;
const file = () => path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'rot-')), 'r.json');
const R = (coins, gains, losses, last10) => ({ coins, pnl: gains - losses, gains, losses, last10 });

test('auto-rotate on the last 30 trades: +31 vs -3 gets copied; a copied trader who lost more than he won over his last 30 is dropped, break-even stays; new wallets wait 2 days', () => {
  let now = 1000 * H;
  const res = {
    t1: R(30, 31, 3, 2), // very positive
    schoen: R(30, 1.0, 0.8, 0.1), // positive, but winners not 2x the losers: not "obviously" hot
    dilly: R(30, 1, 3, -0.5), // copied, red overall and red right now
    sling: R(12, 2, 0.1, 1), // great but only 12 trades
    newbie: R(30, 20, 1, 3), // great but tracked under 2 days
    cupsey: R(30, 2, 7, 0.4), // copied: lost 7, won 2 -> stopped (Khalil's example: cupsey loses you 5)
    killua: R(30, 5, 5, 0), // copied, break-even -> stays (Khalil's example: dilly +5 / -5)
  };
  const r = new Rotator({ file: file(), now: () => now, recent: (n) => res[n], traders: () => Object.keys(res), start: ['dilly', 'cupsey', 'killua'] });
  for (const n of Object.keys(res)) {
    if (n === 'newbie') continue;
    now -= 49 * H;
    r.seen(n);
    now += 49 * H;
  }
  r.seen('newbie');
  const out = r.run();
  assert.deepEqual(out.added.map((x) => x.name), ['t1']);
  assert.deepEqual(out.dropped.map((x) => x.name).sort(), ['cupsey', 'dilly'], 'lost more than they won: stopped');
  assert.deepEqual(r.copying.sort(), ['killua', 't1'], 'break-even killua stays, +31/-3 t1 added');
  // later the same hour schoen gets clearly hot -> copied right away (no waiting for a day)
  res.schoen = R(30, 3, 1, 0.5);
  assert.deepEqual(r.run().added.map((x) => x.name), ['schoen']);
  // newbie after 2 days
  now += 48 * H;
  assert.deepEqual(r.run().added.map((x) => x.name), ['newbie']);
  // status (no command needed: shown in /ghosts)
  const st = r.statusText();
  assert.match(st, /Copying now<\/b> \(picked automatically\): <b>/);
  assert.match(st, /<b>t1<\/b>: 🟢 copied · last 30: \+28\.000 \(won \+31\.000, lost -3\.000\)/);
  assert.match(st, /<b>sling<\/b>: ⚪ not enough trades yet \(12\/20\)/);
  assert.match(st, /<b>dilly<\/b>: 🧊 cold/);
  // restart keeps the picks
  assert.deepEqual(new Rotator({ file: r.file, recent: (n) => res[n], traders: () => Object.keys(res) }).copying.sort(), ['killua', 'newbie', 'schoen', 't1']);
});

test('ghost lastTrades: his last 30 coins, all 4 pretend wallets, winners vs losers, newest 10', () => {
  let now = 5_000_000;
  const g = new GhostBook({ file: file(), now: () => now, fee: 0, entryPenaltyPct: 0 });
  // 35 coins: the 5 oldest are big losers (outside the last 30), then 25 winners, then 5 losers
  const run = (i, exit) => {
    g.open('t1', `M${i}`, 1);
    now += 1000;
    g.price(`M${i}`, exit);
    g.hisSell('t1', `M${i}`, 100, true);
  };
  for (let i = 0; i < 5; i++) run(i, 0.5);
  for (let i = 5; i < 30; i++) run(i, 1.2);
  for (let i = 30; i < 35; i++) run(i, 0.9);
  const r = g.lastTrades('t1', 30);
  assert.equal(r.coins, 30);
  assert.equal(r.won, 25);
  // a 1.2x coin: sides sold at +25%? no (1.2 < 1.25) -> all 4 sold at his exit: 0.1*0.2 + 3*0.05*(1.2/1.02-1)
  const win = 0.1 * 0.2 + 3 * 0.05 * (1.2 / 1.02 - 1);
  const loss = 0.1 * 0.1 + 3 * 0.05 * (1 - 0.9 / 1.02);
  assert.ok(Math.abs(r.gains - 25 * win) < 1e-4, `${r.gains}`);
  assert.ok(Math.abs(r.losses - 5 * loss) < 1e-4, `${r.losses}`);
  assert.ok(r.last10 < r.pnl, 'newest 10 include the 5 losers');
});

test("V2.11.1 wallets sent tonight don't wait; after that new wallets wait 2 days again", async () => {
  const { loadConfig } = await import('../src/config.js');
  const f = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'cfg-')), 'settings.txt');
  fs.writeFileSync(f, 'TELEGRAM_BOT_TOKEN=1:x\n');
  const cfg = loadConfig(f);
  assert.equal(cfg.copy.rotateNewMs, 48 * H);
  assert.equal(cfg.copy.rotateNoWaitUntil, Date.parse('2026-11-13T09:00:00Z'));
  let now = Date.parse('2026-11-13T02:10:00Z'); // Nov 12, 9:10pm ET
  const res = { t1: R(20, 3, 1, 1), t2: R(20, 3, 1, 1) };
  const r = new Rotator({ file: file(), now: () => now, recent: (n) => res[n], traders: () => ['t1', 't2'], newMs: cfg.copy.rotateNewMs, noWaitUntil: cfg.copy.rotateNoWaitUntil });
  r.seen('t1'); // sent tonight
  now = Date.parse('2026-11-14T15:00:00Z');
  r.seen('t2'); // sent the day after
  assert.deepEqual(r.run().added.map((x) => x.name), ['t1'], 'tonight: no wait; later: 2 days');
  assert.match(r.statusText(), /<b>t2<\/b>: 🆕 new — usable in 48h/);
});
