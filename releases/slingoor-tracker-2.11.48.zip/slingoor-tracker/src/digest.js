// Quiet mode: instead of a Telegram message for every trade, everything that happened goes into ONE
// summary sent at the start of every hour. Only alerts that need you (a sell that failed, the 30-min
// warning before an 8h sell) and cooks (COOKED / MINI COOK) still ping right away.
// The summary is saved to disk so a restart (or an auto-update) never loses what it collected.
import fs from 'node:fs';
import path from 'node:path';
import { log } from './log.js';
import { escHtml as e } from './util.js';

// Copy-trade / bot messages that still go out instantly
// + the bot entering a coin (COPY BUY) and EVERY sell it makes (they all have the 💸 Got line)
export const URGENT_RE = /COPY SELL FAILED|COPY SELL DELAYED|HEADS UP|gets sold in ~|COOKED|MINI COOK|was (?:off|asleep)|COPY BUY<\/b> <b>|📊 Trip:|💸 Got|COPY SELL \d+%<\/b>.*✅|^🟢 Bought <b>| — got <b>/;

// V2.7.5: a sell that went through but is NOT a cook -> no ping, it only goes in the hourly summary
const SOLD_RE = /💸 Got|📊 Trip:| — got <b>|^💸 Sold|COPY SELL \d+%<\/b>.*✅|SOLD (?:ALL|\d+%)/;
const COOK_RE = /COOKED|MINI COOK|cook<\/b>/i;
export const isPlainSell = (html) => SOLD_RE.test(html) && !COOK_RE.test(html) && !/FAILED|DELAYED/.test(html);

// V2.8.5 the summary lists only coins that made you money: no buys (or failed/skipped buys), and no
// sells that lost or broke even. Everything else (updates, rent back...) still shows.
const BUY_RE = /🟢 Bought|COPY (?:BUY|ADD)\b|BOT SKIPPED|TAKING OVER/;
export function summaryKeeps(html) {
  const h = String(html);
  if (BUY_RE.test(h)) return false;
  if (!SOLD_RE.test(h) || /FAILED|DELAYED/.test(h)) return true;
  if (COOK_RE.test(h) || /TAKE PROFIT|QUICK PROFIT/.test(h)) return true;
  const trip = /= <b>([+-])/.exec(h);
  if (trip) return trip[1] === '+';
  const x = /\((\d+(?:\.\d+)?)x\)/.exec(h);
  return x ? +x[1] > 1.0001 : false;
}

const MAX_LINES = 40;
const fmt = (n) => (n >= 10 ? n.toFixed(1) : n >= 1 ? n.toFixed(2) : n.toFixed(3));

// "🤖 <b>COPY BUY</b> <b>$X</b> ✅\n💰 Spent ...\n<code>mint</code>" -> one short line (header + money line)
export function oneLine(html) {
  const lines = String(html)
    .split('\n')
    .map((l) => l.trim())
    .filter((l) => l && !/^<code>[^<]*<\/code>$/.test(l));
  if (!lines.length) return '';
  const head = lines[0].replace(/\s*✅\s*$/, '');
  const detail = lines.slice(1).find((l) => /^(💸|💰|❓|📊|🛟)/.test(l));
  const out = detail ? `${head} · ${detail}` : head;
  return out.length > 400 ? out.slice(0, 400).replace(/<[^>]*$/, '') + '…' : out;
}

export class Digest {
  constructor({ file, send, name = 'he', others = [], minute = 0, status = null, now = () => Date.now() }) {
    this.file = file;
    this.send = send; // async (html) => void
    this.name = name;
    this.others = others; // other traders followed (cupsey...), always listed in the summary
    this.minute = minute;
    this.status = status; // async () => [lines] (wallet balance etc.), optional
    this.now = now;
    this.d = this._load();
  }

  _empty() {
    return { since: this.now(), coins: {}, lines: [], launches: [], callouts: [], lastHour: this.d?.lastHour ?? null };
  }

  _load() {
    try {
      const d = JSON.parse(fs.readFileSync(this.file, 'utf8'));
      if (d && d.coins && Array.isArray(d.lines)) return { launches: [], callouts: [], ...d };
    } catch {}
    return { since: this.now(), coins: {}, lines: [], launches: [], callouts: [], lastHour: null };
  }

  save() {
    try {
      fs.mkdirSync(path.dirname(this.file), { recursive: true });
      fs.writeFileSync(this.file + '.tmp', JSON.stringify(this.d));
      fs.renameSync(this.file + '.tmp', this.file);
    } catch (err) {
      log.warn('Could not save the hourly summary:', err.message);
    }
  }

  // one of his trades (ENTRY / ADD / PARTIAL / EXIT / MOVED), merged per coin
  trade({ kind, mint, sym, sol, side, trader }) {
    // V2: coins the traders bought go to /traded (kept across hours), not the hourly summary
    if (side === 'BUY' || kind === 'ENTRY' || kind === 'ADD') {
      const h = (this.d.history ||= []);
      h.push({ at: this.now(), trader: trader || this.name, sym, sol: sol || 0, kind });
      if (h.length > 100) h.splice(0, h.length - 100);
    }
    const c = (this.d.coins[`${trader || ''}|${mint}`] ||= { trader: trader || null, sym: null, kinds: [], buySol: 0, buys: 0, sells: 0, sellSol: 0, exit: false });
    if (sym) c.sym = sym;
    if (!c.kinds.includes(kind)) c.kinds.push(kind);
    if (side === 'BUY' || kind === 'ENTRY' || kind === 'ADD') {
      c.buys++;
      c.buySol += sol || 0;
    } else if (kind === 'PARTIAL' || kind === 'EXIT') {
      c.sells++;
      c.sellSol += sol || 0;
      if (kind === 'EXIT') c.exit = true;
    }
    this.save();
  }

  launch(sym) {
    this.d.launches.push(sym);
    this.save();
  }

  callout(text) {
    this.d.callouts.push(text);
    this.save();
  }

  // a bot message (copy buy, skip, take profit, update notice...)
  note(html) {
    if (!summaryKeeps(html)) return;
    // V2.8.10: coins are never listed one by one (it filled the chat): a profitable sell only adds to the counts
    if (SOLD_RE.test(String(html)) && !/FAILED|DELAYED/.test(String(html))) {
      const t = (this.d.tally ||= { n: 0, cooks: 0, best: 0 });
      t.n++;
      if (COOK_RE.test(String(html))) t.cooks++;
      const x = /(\d+(?:\.\d+)?)x\b/.exec(String(html).replace(/<[^>]+>/g, ''));
      if (x) t.best = Math.max(t.best, +x[1]);
      this.save();
      return;
    }
    const l = oneLine(html);
    if (!l) return;
    this.d.lines.push(l);
    if (this.d.lines.length > 200) this.d.lines.splice(0, this.d.lines.length - 200);
    this.save();
  }

  async build() {
    const d = this.d;
    const out = [this.title || `🕐 <b>Hourly summary</b>`];
    const coins = Object.values(d.coins);
    // V2: traders' coins are no longer listed here (see /traded)
    const names = [...new Set([this.name, ...this.others, ...coins.map((c) => c.trader || this.name)])];
    for (const name of this.hideTraders ? [] : names) {
      const mine = coins.filter((c) => (c.trader || this.name) === name);
      const main = name === this.name;
      if (!mine.length && !(main && (d.launches.length || d.callouts.length))) {
        out.push('', `👤 ${e(name)}: no trades this hour`);
        continue;
      }
      out.push('', `👤 <b>${e(name)}</b>:`);
      for (const c of mine.slice(0, 25)) {
        const bits = [];
        if (c.buys) bits.push(`${c.kinds.includes('ENTRY') ? 'new buy' : 'added'} ${fmt(c.buySol)} SOL${c.buys > 1 ? ` (${c.buys}×)` : ''}`);
        if (c.exit) bits.push(`sold all${c.sellSol ? ` (${fmt(c.sellSol)} SOL)` : ''}`);
        else if (c.sells) bits.push(`sold some${c.sellSol ? ` (${fmt(c.sellSol)} SOL)` : ''}`);
        if (!bits.length && c.kinds.includes('MOVED')) bits.push('moved tokens');
        out.push(`• <b>${e(c.sym || '?')}</b> ${bits.join(' · ')}`);
      }
      if (mine.length > 25) out.push(`…and ${mine.length - 25} more coins`);
      if (main) {
        for (const l of d.launches) out.push(`🚀 Launched <b>${e(l)}</b>`);
        for (const l of d.callouts.slice(0, 10)) out.push(`📣 ${l}`);
      }
    }
    out.push('', '🤖 <b>Bot</b>:');
    const t = d.tally;
    if (t?.n) out.push(`• ${t.n} sell${t.n > 1 ? 's' : ''} in profit${t.cooks ? ` (${t.cooks} cook${t.cooks > 1 ? 's' : ''})` : ''}${t.best ? ` · best ${t.best.toFixed(2)}x` : ''}`);
    for (const l of d.lines.slice(-3)) out.push(`• ${l}`); // other notes (updates...): the last 3 only
    if (!t?.n && !d.lines.length) out.push('• nothing to do this hour');
    if (this.status) {
      try {
        const s = await this.status();
        if (s?.length) out.push('', ...s);
      } catch {}
    }
    return out.join('\n');
  }

  // /traded: the last coins the traders bought (newest first)
  tradedText(n = 25) {
    const h = (this.d.history || []).slice(-n).reverse();
    if (!h.length) return '📋 No trader buys recorded yet.';
    const ago = (t) => {
      const m = Math.round((this.now() - t) / 60000);
      return m < 60 ? `${m}m` : `${Math.round(m / 60)}h`;
    };
    return [`📋 <b>Coins the traders bought</b> (last ${h.length})`, ...h.map((x) => `• ${e(x.trader)}: <b>${e(x.sym || '?')}</b> ${fmt(x.sol)} SOL${x.kind === 'ADD' ? ' (add)' : ''} · ${ago(x.at)} ago`)].join('\n');
  }

  _hourKey(t) {
    const d = new Date(t);
    return `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}-${d.getHours()}`;
  }

  // Sends the summary once per hour, at the set minute (default: the start of the hour).
  async tick() {
    const t = this.now();
    const d = new Date(t);
    if (d.getMinutes() < this.minute) return false;
    const key = this._hourKey(t);
    if (this.d.lastHour === key) return false;
    if (this.d.lastHour == null) {
      // first run ever: start collecting, first summary at the next hour
      this.d.lastHour = key;
      this.save();
      return false;
    }
    const html = await this.build();
    this.d = { ...this._empty(), lastHour: key, history: this.d.history || [] };
    this.save();
    try {
      await this.send(html);
    } catch (err) {
      log.warn('Hourly summary send failed:', err.message);
    }
    return true;
  }

  start(everyMs = 15000) {
    this._t = setInterval(() => this.tick().catch(() => {}), everyMs);
    this._t.unref?.();
  }

  stop() {
    clearInterval(this._t);
  }
}
