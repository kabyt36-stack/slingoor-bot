import { EventEmitter } from 'node:events';
import { isCandidateLogs, isTruncatedTrade, parseWalletTx, tradesFromParsed, pumpTradeEvents, QUOTES } from './parse.js';

const QUOTE_MINTS = Object.keys(QUOTES);
import { sleep, redact, BoundedSet } from './util.js';
import { log } from './log.js';

// Real-time on-chain watcher.
//
// His wallet is "mentioned" in a flood of other people's transactions (spam token
// transfers, people tailing his callouts through pump.fun's router). Fetching all of those
// would burn RPC limits. So we combine two subscriptions:
//   - accountSubscribe(wallet): fires only in slots where HIS account was written
//     (he pays the fee on his own trades, so his SOL balance always changes)
//   - logsSubscribe(mentions wallet): gives the transaction signatures + logs
// and only fetch a transaction when it touched a real program AND his account changed in
// that slot. Anything this misses (rare edge cases) is still caught by the pump.fun poller.
export class ChainWatcher extends EventEmitter {
  constructor({ wsUrlFn = null, wsUrl, rpc, wallets, commitment = 'confirmed' }) {
    super();
    // 'processed' on a good RPC (Helius): his trades arrive ~0.3s sooner than at 'confirmed' (measured)
    this.commitment = commitment;
    this.wsUrl = wsUrl;
    this.wsUrlFn = wsUrlFn;
    this.rpc = rpc;
    this.wallets = wallets;
    this.ws = null;
    this.subs = new Map(); // subscription id -> {type, wallet}
    this.pendingReq = new Map(); // request id -> {type, wallet}
    this.hot = new Map(); // `${wallet}:${slot}` -> time
    this.cands = new Map(); // `${wallet}:${slot}` -> [{sig, logs}]
    this.fetched = new Set();
    this.reqId = 1;
    this.connected = false;
    this.stopped = false;
    this.lastMsgAt = 0;
    this.connectedAt = 0;
    this.backoff = 1000;
    this.stats = { notifications: 0, candidates: 0, fetched: 0, his: 0, fast: 0, reconnects: 0 };
    this.fastSeen = new BoundedSet(2000);
    this.recentCatches = []; // timing of the last transactions of his we caught
  }

  start() {
    this._connect();
    this._keepalive = setInterval(() => this._tick(), 15000);
  }

  stop() {
    this.stopped = true;
    clearInterval(this._keepalive);
    try {
      this.ws?.close();
    } catch {}
  }

  _connect() {
    if (this.stopped) return;
    let ws;
    try {
      if (this.wsUrlFn) this.wsUrl = this.wsUrlFn(); // Helius key failover: reconnect with the key in use
      ws = new WebSocket(this.wsUrl);
    } catch (e) {
      log.error('WebSocket create failed:', e.message);
      return this._reconnectLater();
    }
    this.ws = ws;
    this.connectStartedAt = Date.now();
    this.subs.clear();
    this.pendingReq.clear();
    ws.onopen = () => {
      this.connected = true;
      this.lastProblem = null;
      this.connectedAt = Date.now();
      this.lastMsgAt = Date.now();
      if (this.stats.reconnects < 3 || this.stats.reconnects % 20 === 0) log.info(`Chain stream connected (${redact(this.wsUrl)})`);
      for (const w of this.wallets) {
        this._send('accountSubscribe', [w, { commitment: this.commitment, encoding: 'base64' }], { type: 'account', wallet: w });
        // 'confirmed' (measured: on the public RPC, 'processed' notifications actually arrive ~1s later)
        this._send('logsSubscribe', [{ mentions: [w] }, { commitment: this.commitment }], { type: 'logs', wallet: w });
        // Paid Helius plans: every transaction of his arrives WHOLE (balances included), so nothing has to be
        // downloaded before acting on it. Free plans refuse this; then the logs + download path is used.
        if (this.fullTx !== false && /helius/i.test(this.wsUrl)) this._send('transactionSubscribe', [{ accountInclude: [w], vote: false, failed: false }, { commitment: this.commitment, encoding: 'json', transactionDetails: 'full', maxSupportedTransactionVersion: 1 }], { type: 'tx', wallet: w });
        this._watchQuoteAccounts(w, ws);
      }
      this.emit('status', 'connected');
    };
    ws.onmessage = (ev) => {
      this.lastMsgAt = Date.now();
      let m;
      try {
        m = JSON.parse(typeof ev.data === 'string' ? ev.data : Buffer.from(ev.data).toString());
      } catch {
        return;
      }
      this._onMessage(m);
    };
    ws.onerror = (e) => {
      log.debug('WebSocket error', e?.message || '');
      if (!this.connected) this._diagnose();
    };
    ws.onclose = (e) => {
      const was = this.connected;
      this.connected = false;
      if (this.ws !== ws) return;
      // only reset the backoff if the connection had been healthy for a while
      if (was && Date.now() - this.connectedAt > 5000) this.backoff = 1000;
      if (was && (this.stats.reconnects < 3 || this.stats.reconnects % 20 === 0)) log.warn(`Chain stream closed (${e?.code ?? ''}), reconnecting… (${this.stats.reconnects} reconnects so far)`);
      this.emit('status', 'disconnected');
      this._reconnectLater();
    };
  }

  // Some of his buys are paid in USDC through a relayer that pays the fee, so his SOL balance
  // doesn't move. Watching his USDC/USDT/USD1/WSOL token accounts catches those slots too.
  async _watchQuoteAccounts(wallet, ws) {
    if (!this.quoteAccounts) this.quoteAccounts = new Map();
    let accts = this.quoteAccounts.get(wallet);
    if (!accts) {
      accts = [];
      for (const mint of QUOTE_MINTS) {
        try {
          const r = await this.rpc.call('getTokenAccountsByOwner', [wallet, { mint }, { encoding: 'jsonParsed', commitment: 'confirmed' }]);
          for (const a of r?.value || []) accts.push(a.pubkey);
        } catch (e) {
          log.debug('quote account lookup failed', e.message);
        }
      }
      this.quoteAccounts.set(wallet, accts);
    }
    if (this.ws !== ws || !this.connected) return;
    for (const a of accts) this._send('accountSubscribe', [a, { commitment: this.commitment, encoding: 'base64' }], { type: 'account', wallet, quote: true });
  }

  _reconnectLater() {
    if (this.stopped) return;
    this.stats.reconnects++;
    const wait = this.backoff;
    this.backoff = Math.min(this.backoff * 2, 15000);
    setTimeout(() => this._connect(), wait);
  }

  _send(method, params, meta) {
    const id = this.reqId++;
    if (meta) this.pendingReq.set(id, meta);
    try {
      this.ws.send(JSON.stringify({ jsonrpc: '2.0', id, method, params }));
    } catch {}
  }

  // The websocket can't say why it was refused, so ask the same server over plain HTTP
  // (a bad Helius key gives "401 invalid api key" there). Shown in /status and the log.
  async _diagnose() {
    if (this._diagAt && Date.now() - this._diagAt < 60000) return;
    this._diagAt = Date.now();
    try {
      await this.rpc.call('getSlot', []);
      this.lastProblem = 'the server accepts normal requests but refuses the live connection';
    } catch (e) {
      this.lastProblem = /401|403|api.?key|unauthori/i.test(e.message) ? `the Helius key is not accepted (${e.message.slice(0, 80)}) — check HELIUS_API_KEY in settings.txt` : e.message.slice(0, 120);
    }
    log.warn(`Chain stream can't connect: ${this.lastProblem}`);
  }

  _forceReconnect(reason) {
    log.warn(`Chain stream ${reason}, reconnecting`);
    const old = this.ws;
    if (old) {
      old.onclose = null;
      old.onmessage = null;
      try {
        old.close();
      } catch {}
    }
    this.ws = null;
    this.connected = false;
    this.emit('status', 'disconnected');
    this._reconnectLater();
  }

  _tick() {
    if (!this.connected) {
      if (this.ws && this.ws.readyState === 0 && Date.now() - this.connectStartedAt > 20000) this._forceReconnect('stuck connecting');
      return;
    }
    // Keep the socket busy so proxies don't drop it, and detect silent dead sockets.
    this._send('slotUnsubscribe', [0]);
    if (Date.now() - this.lastMsgAt > 70000) this._forceReconnect('silent for 70s');
    // prune slot maps
    const cutoff = Date.now() - 120000;
    for (const [k, t] of this.hot) if (t < cutoff) this.hot.delete(k);
    for (const [k, v] of this.cands) if (v.t < cutoff) this.cands.delete(k);
    if (this.fetched.size > 5000) this.fetched = new Set([...this.fetched].slice(-2000));
  }

  _onMessage(m) {
    if (m.id != null && this.pendingReq.has(m.id)) {
      const meta = this.pendingReq.get(m.id);
      this.pendingReq.delete(m.id);
      if (m.error) {
        // A connection without its subscriptions is useless: start over.
        if (meta.type === 'tx') {
          if (this.fullTx !== false) log.info(`Full-transaction stream not available (${m.error.message}); using the standard stream`);
          this.fullTx = false;
          return;
        }
        log.warn(`Subscribe ${meta.type}${meta.quote ? ' (USDC account)' : ''} failed: ${m.error.message}`);
        if (meta.quote) return; // nice to have only; never worth dropping the connection over
        this.lastProblem = `subscription refused: ${String(m.error.message).slice(0, 100)}`;
        setTimeout(() => this.connected && this._forceReconnect('lost its subscription'), 3000);
      } else {
        this.subs.set(m.result, meta);
        if (meta.type === 'tx' && !this.fullTx) {
          this.fullTx = true;
          log.info('Full-transaction stream on (paid Helius): his trades are read without downloading them');
        }
      }
      return;
    }
    const method = m.method;
    if (method === 'transactionNotification') {
      const sub = this.subs.get(m.params?.subscription);
      if (sub) this._onFullTx(m.params.result, sub.wallet);
      return;
    }
    if (method !== 'logsNotification' && method !== 'accountNotification') return;
    const sub = this.subs.get(m.params?.subscription);
    if (!sub) return;
    const slot = m.params.result?.context?.slot;
    const key = `${sub.wallet}:${slot}`;

    if (method === 'accountNotification') {
      this.hot.set(key, Date.now());
      const c = this.cands.get(key);
      if (c) for (const it of c.list) this._fetchOrWait(it.sig, sub.wallet, slot);
      return;
    }

    // logsNotification
    this.stats.notifications++;
    const v = m.params.result.value;
    if (!v || v.err) return;
    // fast path: his pump.fun buys AND sells, straight from the logs (no transaction download)
    const isCreate = (v.logs || []).some((l) => /Instruction: (Create|CreateV2)$/.test(l));
    for (const t of pumpTradeEvents(v.logs)) {
      if (t.user !== sub.wallet) continue;
      const fk = `${v.signature}:${t.mint}`;
      if (this.fastSeen.has(fk)) continue;
      this.fastSeen.add(fk);
      this.stats.fast++;
      if (!t.isBuy) this.stats.fastSells = (this.stats.fastSells || 0) + 1;
      this.emit('trade', {
        key: fk,
        sig: v.signature,
        wallet: sub.wallet,
        mint: t.mint,
        side: t.isBuy ? 'BUY' : 'SELL',
        amountUi: t.tokenAmount,
        preUi: null,
        postUi: null,
        quote: 'SOL',
        solAmount: t.solAmount,
        priceSol: t.priceSol,
        usdAmount: 0,
        time: null,
        detectedAt: Date.now(),
        source: 'chain',
        fast: true,
        devBuy: isCreate && t.isBuy, // his own launch: the buy in the same transaction that creates the coin
      });
    }
    if (!isCandidateLogs(v.logs)) return;
    this.stats.candidates++;
    const launchLike = v.logs.some((l) => /Instruction: (Create|CreateV2|InitializeMint)/.test(l));
    const truncated = isTruncatedTrade(v.logs);
    if (this.hot.has(key) || launchLike || truncated) return this._fetchOrWait(v.signature, sub.wallet, slot);
    const c = this.cands.get(key) || { t: Date.now(), list: [] };
    c.list.push({ sig: v.signature });
    this.cands.set(key, c);
  }

  async _fetch(sig, wallet, slot) {
    const k = `${sig}:${wallet}`;
    if (this.fetched.has(k)) return;
    this.fetched.add(k);
    this.stats.fetched++;
    const seenAt = Date.now();
    let tx = null;
    for (let i = 0; i < 6 && !tx; i++) {
      try {
        tx = await this.rpc.getTransaction(sig);
      } catch (e) {
        log.debug('getTransaction failed', sig.slice(0, 8), e.message);
      }
      if (!tx) await sleep((this.commitment === 'processed' ? 250 : 400) + i * 300);
    }
    if (!tx) {
      log.warn(`Could not load tx ${sig.slice(0, 10)}… (pump.fun poller will cover it)`);
      return;
    }
    this._process(tx, sig, wallet, slot, seenAt);
  }

  // With the full-transaction stream the download is only a backup (if a notification ever goes missing).
  _fetchOrWait(sig, wallet, slot) {
    if (!this.fullTx) return this._fetch(sig, wallet, slot);
    setTimeout(() => {
      if (!this.fetched.has(`${sig}:${wallet}`)) this._fetch(sig, wallet, slot);
    }, 1500).unref?.();
  }

  _onFullTx(r, wallet) {
    const sig = r?.signature;
    const t = r?.transaction;
    if (!sig || !t?.meta || t.meta.err) return;
    const k = `${sig}:${wallet}`;
    if (this.fetched.has(k)) return;
    this.fetched.add(k);
    this.stats.notifications++;
    this.stats.fullTx = (this.stats.fullTx || 0) + 1;
    this._process({ slot: r.slot, blockTime: null, version: t.version, transaction: t.transaction, meta: t.meta }, sig, wallet, r.slot, Date.now());
  }

  _process(tx, sig, wallet, slot, seenAt) {
    const p = parseWalletTx(tx, wallet);
    if (!p) return; // not his transaction
    this.stats.his++;
    this.recentCatches.push({ sig, slot, lagMs: Date.now() - p.blockTime, fetchMs: Date.now() - seenAt, at: Date.now() });
    if (this.recentCatches.length > 20) this.recentCatches.shift();
    const events = tradesFromParsed(p);
    for (const ev of events) {
      ev.detectedAt = seenAt;
      this.emit('trade', ev);
    }
    for (const mint of p.newMints) {
      this.emit('launch', { mint, wallet, sig, time: p.blockTime, source: 'chain', devBuy: events.find((e) => e.mint === mint && e.side === 'BUY') || null });
    }
  }
}
