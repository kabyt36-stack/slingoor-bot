// V2.12.0 new-pair sniper (paper): Khalil's rules, replayed with a fake feed, clock and wallets.
import test from 'node:test';
import assert from 'node:assert/strict';
import { Sniper } from '../src/sniper.js';

const SOL = 100; // $ per SOL
// pump.fun curve at launch: 30 SOL / 1.073B tokens virtual; mc in SOL = price * 1e9
const curve = (vS, vT = (30 * 1073e6) / vS) => ({ vSolInBondingCurve: vS, vTokensInBondingCurve: vT, marketCapSol: (vS / vT) * 1e9 });

function world({ fresh = {}, meta = { twitter: 'https://x.com/thecoin' }, cfg = {} } = {}) {
  let t = 1_000_000;
  const sent = [];
  const txCount = (a) => (a in fresh ? fresh[a] : 50);
  const rpc = { call: async (m, [a]) => (m === 'getSignaturesForAddress' ? Array.from({ length: Math.min(txCount(a), 5) }, () => ({})) : null) };
  const s = new Sniper({ cfg: { watchMs: 0, minBuyers: 0, ...cfg }, rpc, broadcast: async (h) => sent.push(h), getSolPrice: () => SOL, fetchMeta: async () => meta, now: () => t, WebSocketImpl: null });
  const create = (mint, extra = {}) => s.onEvent({ txType: 'create', mint, name: extra.name || `Coin ${mint}`, symbol: extra.symbol || mint, traderPublicKey: `dev${mint}`, initialBuy: extra.devTokens ?? 20e6, uri: 'https://ipfs.example/x', ...curve(30.5), ...extra });
  const trade = (mint, who, side, tokens, vS) => s.onEvent({ txType: side, mint, traderPublicKey: who, tokenAmount: tokens, ...curve(vS) });
  return { s, sent, create, trade, at: (ms) => (t += ms), now: () => t };
}

test('buys a young, cheap launch with an X link and 1-20% insiders; skips no X, too few or too many insiders', async () => {
  const w = world();
  w.create('A1'); // dev 2% of supply
  w.trade('A1', 'b1', 'buy', 5e6, 31);
  await w.s.decide('A1');
  assert.ok(w.s.d.positions.A1, 'bought');
  assert.equal(w.sent.at(-1), '🎯🧪 <b>Bought</b> <a href="https://pump.fun/coin/A1">A1</a> · 0.1 SOL at $' + ((w.s.d.positions.A1.mcIn) / 1000).toFixed(1) + 'k', 'short: coin with its pump.fun link, size, market cap — no address, insiders, fresh wallets or age');
  assert.ok(Math.abs(w.s.d.positions.A1.insiderPct - 2.5) < 1e-9, 'insiders still checked (2.5%)');

  const n = world({ meta: { website: 'https://site' } });
  n.create('N1');
  await n.s.decide('N1');
  assert.equal(n.s.d.positions.N1, undefined);
  assert.match(n.s.d.skips.at(-1).why, /no X link/);

  const lo = world();
  lo.create('L1', { devTokens: 2e6 }); // 0.2%
  await lo.s.decide('L1');
  assert.match(lo.s.d.skips.at(-1).why, /insiders 0\.2% \(under 1%\)/);

  const hi = world();
  hi.create('H1', { devTokens: 250e6 }); // 25%
  await hi.s.decide('H1');
  assert.match(hi.s.d.skips.at(-1).why, /insiders 25% \(over 20%\)/);
});

test('too old or over $6k is skipped', async () => {
  const w = world();
  w.create('O1');
  w.at(61000);
  await w.s.decide('O1');
  assert.match(w.s.d.skips.at(-1).why, /older than 60s/);
  w.create('M1');
  w.trade('M1', 'b', 'buy', 1e6, 70); // mc way over $6k
  await w.s.decide('M1');
  assert.match(w.s.d.skips.at(-1).why, /over \$6k/);
});

test('fresh wallets: a launch bought mostly by fresh wallets is skipped; a vamp is held to a stricter bar and a fresh dev', async () => {
  const w = world({ fresh: { f1: 0, f2: 1, f3: 2, ok1: 40 } });
  w.create('F1');
  for (const b of ['f1', 'f2', 'f3', 'ok1']) w.trade('F1', b, 'buy', 1e6, 31);
  await w.s.decide('F1');
  assert.match(w.s.d.skips.at(-1).why, /3 of 4 first buyers are fresh wallets/);
  // a vamp (same name as an earlier launch): 1 fresh of 3 passes normally but not for a vamp
  const v = world({ fresh: { f1: 0, ok1: 40, ok2: 40 } });
  v.create('V0', { name: 'Gregory McCarthy', symbol: 'GREG', devTokens: 0 }); // the earlier coin: skipped (no insiders)
  await v.s.decide('V0');
  v.create('V1', { name: 'gregory mccarthy', symbol: 'GREGORY' });
  for (const b of ['f1', 'ok1', 'ok2']) v.trade('V1', b, 'buy', 1e6, 31);
  await v.s.decide('V1');
  assert.match(v.s.d.skips.at(-1).why, /1 of 3 first buyers are fresh wallets \(vamp: stricter\)/);
  const d = world({ fresh: { devV2: 1 } });
  d.create('V0', { name: 'Same Name', devTokens: 0 });
  await d.s.decide('V0');
  d.create('V2', { name: 'Same Name' });
  await d.s.decide('V2');
  assert.match(d.s.d.skips.at(-1).why, /vamp with a fresh dev/);
});

test('no second copy of a coin it traded (same name or ticker) within 30 min; a skipped one does not block a later copy', async () => {
  const w = world();
  w.create('S1', { name: 'Moon Dog', symbol: 'MDOG' });
  await w.s.decide('S1');
  assert.ok(w.s.d.positions.S1);
  w.create('S2', { name: 'MOON DOG!', symbol: 'MD' });
  assert.match(w.s.d.skips.at(-1).why, /too similar/);
  w.create('S3', { name: 'Other', symbol: 'MDOG' });
  assert.match(w.s.d.skips.at(-1).why, /too similar/);
  // a skipped launch (no X) frees its name again
  const k = world({ meta: {} });
  k.create('K1', { name: 'Cat Coin' });
  await k.s.decide('K1');
  k.s.fetchMeta = async () => ({ twitter: 'https://x.com/cat' });
  k.create('K2', { name: 'Cat Coin' });
  await k.s.decide('K2');
  assert.ok(k.s.d.positions.K2, 'a later copy is judged on its own');
});

test('sells: strict -10% stop, take profit armed at +15% (sells on a dip), all out at +75%, dev sells, big dump, 5 min, dying coin', async () => {
  const run = async (fn) => {
    const w = world();
    w.create('P');
    await w.s.decide('P');
    const p = w.s.d.positions.P;
    const vS0 = p.last.vSolInBondingCurve;
    await fn(w, vS0);
    return w;
  };
  // the price follows vS^2 on this curve: x = (vS/vS0)^2 roughly; push it with buys/sells
  const toX = (vS0, x) => vS0 * Math.sqrt(x);
  let w = await run(async (w, v) => w.trade('P', 'z', 'sell', 1e6, toX(v, 0.88)));
  assert.match(w.s.d.trips.at(-1).why, /stop loss/);
  assert.ok(w.s.d.trips.at(-1).pnl < 0);
  w = await run(async (w, v) => {
    w.trade('P', 'z', 'buy', 1e6, toX(v, 1.3));
    assert.ok(w.s.d.positions.P, 'not sold on the way up');
    w.trade('P', 'z', 'sell', 1e6, toX(v, 1.18));
  });
  assert.match(w.s.d.trips.at(-1).why, /took profit at \+\d+% \(top \+2\d%\)/);
  assert.ok(w.s.d.trips.at(-1).pnl > 0);
  w = await run(async (w, v) => w.trade('P', 'z', 'buy', 1e6, toX(v, 1.9)));
  assert.match(w.s.d.trips.at(-1).why, /took profit at \+\d+%/);
  w = await run(async (w, v) => w.trade('P', 'devP', 'sell', 1e6, v));
  assert.match(w.s.d.trips.at(-1).why, /dev sold/);
  w = await run(async (w, v) => w.trade('P', 'whale', 'sell', 40e6, v));
  assert.match(w.s.d.trips.at(-1).why, /a holder dumped 4% of supply/);
  w = await run(async (w) => {
    w.at(5 * 60000);
    await w.s.tick();
  });
  assert.match(w.s.d.trips.at(-1).why, /held 5 min|no trades/);
  w = await run(async (w) => {
    w.at(46000);
    await w.s.tick();
  });
  assert.match(w.s.d.trips.at(-1).why, /no trades for 45s/);
  assert.doesNotMatch(w.sent.join('\n'), /SNIPE SELL|Sold/, 'no sell alerts');
});

test('fees count: a coin that goes nowhere loses a little (pump.fun 1% each way + priority fee + delay)', async () => {
  const w = world();
  w.create('Z');
  await w.s.decide('Z');
  const v = w.s.d.positions.Z.last.vSolInBondingCurve;
  w.trade('Z', 'x', 'buy', 1, v);
  w.s.sell('Z', 'manual');
  const tr = w.s.d.trips.at(-1);
  assert.ok(tr.pnl < 0 && tr.pnl > -0.01, `flat coin loses only fees: ${tr.pnl}`);
  assert.ok(Math.abs(w.s.d.sol - (0.25 + tr.pnl)) < 1e-4, 'wallet adds up');
  assert.match(w.s.report(), /New-pair sniper.*1 coins, 0 won/s);
});

test('max 3 open and never more than the wallet holds', async () => {
  const w = world();
  for (const m of ['a', 'b', 'c', 'd']) {
    w.create(m, { name: `n${m}xx`, symbol: `s${m}xx` });
    await w.s.decide(m);
  }
  assert.equal(Object.keys(w.s.d.positions).length, 2, '0.25 SOL buys two 0.1 SOL coins (+fees)');
  assert.match(w.s.d.skips.at(-1).why, /out of SOL|already 3/);
});

test('trades come from the Solana logs: logsSubscribe per coin, pump.fun TradeEvent decoded (buyer, size, curve), unsubscribed when done', async () => {
  const { LogsTradeFeed } = await import('../src/sniper.js');
  const { PUMP_PROGRAM } = await import('../src/parse.js');
  const { b58decode } = await import('../src/solana.js');
  const MINT = 'So11111111111111111111111111111111111111112';
  const USER = '5YRgrP3mjGzrzirYYN5HAQH19cTYREYwGxW6XRJQUzij';
  const sentWs = [];
  let sock;
  class FakeWS {
    constructor() {
      sock = this;
      this.readyState = 1;
      setImmediate(() => this.onopen?.());
    }
    send(m) {
      sentWs.push(JSON.parse(m));
    }
    close() {}
  }
  const feed = new LogsTradeFeed({ wsUrl: 'ws://x', WebSocketImpl: FakeWS });
  const got = [];
  feed.onTrade = (ev) => got.push(ev);
  feed.start();
  await new Promise((r) => setImmediate(r));
  feed.sub(MINT);
  const req = sentWs.find((m) => m.method === 'logsSubscribe');
  assert.deepEqual(req.params[0], { mentions: [MINT] });
  sock.onmessage({ data: JSON.stringify({ jsonrpc: '2.0', id: req.id, result: 77 }) });
  const b = Buffer.alloc(401);
  Buffer.from([189, 219, 127, 211, 78, 230, 97, 238]).copy(b, 0);
  Buffer.from(b58decode(MINT)).copy(b, 8);
  b.writeBigUInt64LE(500_000_000n, 40); // 0.5 SOL
  b.writeBigUInt64LE(15_000_000_000_000n, 48); // 15M tokens
  b[56] = 0; // sell
  Buffer.from(b58decode(USER)).copy(b, 57);
  b.writeBigUInt64LE(32_000_000_000n, 97);
  b.writeBigUInt64LE(1_000_000_000_000_000n, 105);
  sock.onmessage({ data: JSON.stringify({ jsonrpc: '2.0', method: 'logsNotification', params: { subscription: 77, result: { value: { signature: 'S', err: null, logs: [`Program ${PUMP_PROGRAM} invoke [1]`, `Program data: ${b.toString('base64')}`, `Program ${PUMP_PROGRAM} success`] } } } }) });
  assert.equal(got.length, 1);
  assert.equal(got[0].txType, 'sell');
  assert.equal(got[0].traderPublicKey, USER);
  assert.equal(got[0].tokenAmount, 15e6);
  assert.equal(got[0].vSolInBondingCurve, 32);
  assert.equal(got[0].vTokensInBondingCurve, 1e9);
  assert.ok(Math.abs(got[0].marketCapSol - 32) < 1e-9);
  feed.unsub(MINT);
  assert.deepEqual(sentWs.at(-1).params, [77]);
  assert.equal(sentWs.at(-1).method, 'logsUnsubscribe');
  // the sniper uses it: a watched launch is subscribed, and dropped when skipped
  const subs = [];
  const tf = { sub: (m) => subs.push(['+', m]), unsub: (m) => subs.push(['-', m]) };
  const { Sniper } = await import('../src/sniper.js');
  const s = new Sniper({ cfg: { watchMs: 0 }, getSolPrice: () => 100, fetchMeta: async () => ({}), WebSocketImpl: null, tradeFeed: tf });
  s.onEvent({ txType: 'create', mint: 'Q1', name: 'Qq coin', symbol: 'QQ', traderPublicKey: 'd', initialBuy: 2e7, vSolInBondingCurve: 30.5, vTokensInBondingCurve: 1.055e9, marketCapSol: 28.9 });
  await s.decide('Q1');
  assert.deepEqual(subs, [['+', 'Q1'], ['-', 'Q1']], 'no X link: skipped and unsubscribed');
  tf.onTrade({ txType: 'buy', mint: 'none' }); // wired: trades reach the sniper (an unknown coin is ignored)
});

test('V2.12.1 no buy until 2 other buyers have shown up and been checked (inside the 60s); none by 60s = skipped', async () => {
  const w = world({ cfg: { minBuyers: 2, retryMs: 5 } });
  w.create('B1');
  await w.s.decide('B1');
  assert.equal(w.s.d.positions.B1, undefined, '0 buyers: waits');
  w.trade('B1', 'u1', 'buy', 1e6, 31);
  await new Promise((r) => setTimeout(r, 20));
  assert.equal(w.s.d.positions.B1, undefined, '1 buyer: still waits');
  w.trade('B1', 'u2', 'buy', 1e6, 31.2);
  await new Promise((r) => setTimeout(r, 20));
  assert.ok(w.s.d.positions.B1, '2 checked buyers: bought');
  const n = world({ cfg: { minBuyers: 2, retryMs: 5 } });
  n.create('B2');
  n.at(59000);
  await n.s.decide('B2');
  assert.match(n.s.d.skips.at(-1).why, /only 0 buyers to check by 60s/);
  // a losing sell says nothing
  const before = w.sent.length;
  w.s.sell('B1', 'manual');
  assert.equal(w.sent.length, before, 'no alert for a loss');
});

test('V2.12.2 alerts like copy trading: "Bought", no sell alerts, a cook only when the coin made money and the day is up', async () => {
  const w = world();
  const buyAndSellAt = async (m, x) => {
    w.create(m, { name: `name ${m}`, symbol: m });
    await w.s.decide(m);
    const p = w.s.d.positions[m];
    p.last = { ...p.last, vSolInBondingCurve: p.last.vSolInBondingCurve * Math.sqrt(x), vTokensInBondingCurve: p.last.vTokensInBondingCurve / Math.sqrt(x) };
    w.s.sell(m, 'test');
  };
  await buyAndSellAt('C1', 1.4); // profitable, day up
  assert.match(w.sent.at(-1), /^🍳🎯 <b>mini cook<\/b> on <a href="https:\/\/pump\.fun\/coin\/C1">C1<\/a> — got <b>0\.\d+ SOL<\/b> \(\+0\.\d+\)$/);
  await buyAndSellAt('C2', 0.4); // a big loss: the day is now down
  assert.match(w.sent.at(-1), /Bought<\/b> <a href="https:\/\/pump\.fun\/coin\/C2"/, 'no alert for the loss');
  w.s.d.sol = 0.25; // keep buying
  await buyAndSellAt('C3', 1.2); // a winner, but the day is still down: no cook
  assert.match(w.sent.at(-1), /Bought<\/b> <a href="https:\/\/pump\.fun\/coin\/C3"/);
  const x = world();
  x.create('D1');
  await x.s.decide('D1');
  const p = x.s.d.positions.D1;
  p.last = { ...p.last, vSolInBondingCurve: p.last.vSolInBondingCurve * 1.6, vTokensInBondingCurve: p.last.vTokensInBondingCurve / 1.6 };
  x.s.sell('D1', 'test'); // ~2.5x
  assert.match(x.sent.at(-1), /^🔥🎯 <b>2\.\dx cook<\/b> on/);
});

test('V2.12.3 serial dev: a dev who already launched another coin in the last 24h is skipped (create, buy, dump, repeat)', async () => {
  const w = world();
  w.create('R1', { traderPublicKey: 'serialDev', name: 'all in', symbol: 'allin' });
  await w.s.decide('R1');
  assert.ok(w.s.d.positions.R1, 'his first launch looks normal');
  w.at(60 * 60000);
  w.create('R2', { traderPublicKey: 'serialDev', name: 'other', symbol: 'oth' });
  await w.s.decide('R2');
  assert.equal(w.s.d.positions.R2, undefined);
  assert.match(w.s.d.skips.at(-1).why, /serial dev: launched 1 other coin in the last 24h/);
  // a day later he's forgotten
  w.at(25 * 3600000);
  w.create('R3', { traderPublicKey: 'serialDev', name: 'third', symbol: 'thr' });
  await w.s.decide('R3');
  assert.ok(w.s.d.positions.R3);
});

test('V2.12.3 learns from rugs: a kind of coin that keeps rugging (here: coins linking someone\'s tweet) gets skipped; /snipe shows it', async () => {
  const w = world({ meta: { twitter: 'https://x.com/someone/status/123' } });
  w.s.d.sol = 100;
  w.s.cfg.maxOpen = 99;
  for (let i = 0; i < 6; i++) {
    // a tweet coin that rugs...
    w.s.fetchMeta = async () => ({ twitter: 'https://x.com/someone/status/123' });
    const m = `T${i}`;
    w.create(m, { name: `tweet coin ${i}`, symbol: `tw${i}` });
    await w.s.decide(m);
    assert.ok(w.s.d.positions[m], `bought ${m}`);
    w.trade(m, `dev${m}`, 'sell', 1e6, 30.6); // the dev dumps: a rug
    // ...and a coin with its own X account that runs
    w.s.fetchMeta = async () => ({ twitter: 'https://x.com/realcoin' });
    const g = `G${i}`;
    w.create(g, { name: `good coin ${i}`, symbol: `gd${i}` });
    await w.s.decide(g);
    const v = w.s.d.positions[g].last.vSolInBondingCurve;
    w.trade(g, 'z', 'buy', 1e6, v * Math.sqrt(1.9));
  }
  assert.ok(w.s.d.trips.filter((t) => t.keys.includes('x:tweet')).every((t) => t.rug));
  assert.equal(w.s.d.badKeys['dev:small'], undefined, 'a trait all coins share is not singled out');
  w.s.fetchMeta = async () => ({ twitter: 'https://x.com/someone/status/123' });
  assert.ok(w.s.d.badKeys['x:tweet'], 'learned');
  w.create('T9', { name: 'another tweet coin', symbol: 'tw9' });
  await w.s.decide('T9');
  assert.equal(w.s.d.positions.T9, undefined);
  assert.match(w.s.d.skips.at(-1).why, /learned: coins linking someone's tweet rug a lot \(6 of 6\)/);
  // a coin linking its own X account is still bought
  w.s.fetchMeta = async () => ({ twitter: 'https://x.com/realcoin' });
  w.create('A9', { name: 'account coin', symbol: 'acc9' });
  await w.s.decide('A9');
  assert.ok(w.s.d.positions.A9, 'other kinds still trade');
  assert.match(w.s.report(), /Learned from rugs, skipping: .*coins linking someone's tweet \(6\/6 rugged\)/);
  // the lesson ages out after 48h
  w.at(49 * 3600000);
  w.s.learn();
  assert.equal(w.s.d.badKeys['x:tweet'], undefined);
});
