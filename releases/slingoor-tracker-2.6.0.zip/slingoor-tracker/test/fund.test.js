import test from 'node:test';
import assert from 'node:assert/strict';
import os from 'node:os';
import fs from 'node:fs';
import path from 'node:path';
import { AutoFunder, buildTransferTx } from '../src/fund.js';
import { b58encode, parseTx } from '../src/solana.js';
import crypto from 'node:crypto';

const addr = () => b58encode(crypto.randomBytes(32));

test('transfer tx: one System transfer per side wallet, main pays', () => {
  const from = addr();
  const a = addr();
  const b = addr();
  const tx = buildTransferTx(from, [{ to: a, lamports: 100000000 }, { to: b, lamports: 100000000 }], addr());
  const p = parseTx(tx);
  assert.equal(p.keys[0], from);
  assert.deepEqual(p.keys.slice(1, 3), [a, b]);
  assert.equal(p.keys.at(-1), '11111111111111111111111111111111');
});

test('auto-fund: sends 0.1 SOL to each side wallet each time the main wallet reaches a new whole SOL', async () => {
  let bal = 0.7;
  const sent = [];
  const f = new AutoFunder({
    rpc: { call: async () => ({ value: { blockhash: addr() } }) },
    swapper: { send: async (tx) => (sent.push(tx), { sig: 'S' + sent.length }) },
    owner: addr(),
    sideWallets: () => [{ label: 'W2', pub: addr() }, { label: 'W3', pub: addr() }],
    file: path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'fund-')), 'f.json'),
    balance: async () => bal,
  });
  assert.equal(await f.run(), 0, 'first run only remembers 0 SOL');
  bal = 0.95;
  assert.equal(await f.run(), 0);
  bal = 1.05;
  assert.ok(Math.abs((await f.run()) - 0.2) < 1e-9, 'hit 1 SOL -> 0.1 to each of 2 wallets');
  bal = 0.85; // after sending
  assert.equal(await f.run(), 0, 'dropped under 1 again: nothing');
  bal = 1.1;
  assert.ok((await f.run()) > 0, 'climbed back to 1 SOL: sends again');
  bal = 1.6;
  assert.equal(await f.run(), 0, 'same step');
  assert.equal(sent.length, 2);
});
