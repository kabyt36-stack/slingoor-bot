// V2.6 auto-funding: every time the main wallet reaches a new whole AUTO_FUND_EVERY_SOL step (1 SOL, 2 SOL…),
// it sends AUTO_FUND_SOL (default 0.1) to each side (quick-profit) wallet. Plain SOL transfers between
// your own wallets, signed here; never below AUTO_FUND_KEEP_SOL in the main wallet.
import fs from 'node:fs';
import path from 'node:path';
import { b58decode } from './solana.js';
import { log } from './log.js';

const SYSTEM = '11111111111111111111111111111111';

function shortVec(n) {
  const out = [];
  for (;;) {
    let b = n & 0x7f;
    n >>= 7;
    if (n) b |= 0x80;
    out.push(b);
    if (!n) return out;
  }
}

function u64le(n) {
  const b = Buffer.alloc(8);
  b.writeBigUInt64LE(BigInt(n));
  return [...b];
}

// legacy transaction: `from` pays and signs; one System transfer per destination
export function buildTransferTx(from, dests, blockhash) {
  if (!dests.length) throw new Error('no destinations');
  const keys = [from, ...dests.map((d) => d.to), SYSTEM];
  if (new Set(keys).size !== keys.length) throw new Error('duplicate accounts');
  const msg = [1, 0, 1, ...shortVec(keys.length)];
  for (const k of keys) msg.push(...b58decode(k));
  const bh = b58decode(blockhash);
  if (bh.length !== 32) throw new Error('bad blockhash');
  msg.push(...bh, ...shortVec(dests.length));
  dests.forEach((d, i) => {
    msg.push(keys.length - 1, ...shortVec(2), 0, i + 1, ...shortVec(12), 2, 0, 0, 0, ...u64le(d.lamports));
  });
  return Uint8Array.from([...shortVec(1), ...new Uint8Array(64), ...msg]);
}

export class AutoFunder {
  constructor({ rpc, swapper, owner, sideWallets, everySol = 1, sendSol = 0.1, keepSol = 0.3, file, notify, balance }) {
    Object.assign(this, { rpc, swapper, owner, sideWallets, everySol, sendSol, keepSol, file, notify, balance });
    this.state = { step: null };
    try {
      this.state = { ...this.state, ...JSON.parse(fs.readFileSync(file, 'utf8')) };
    } catch {}
    this.running = false;
  }

  save() {
    try {
      fs.mkdirSync(path.dirname(this.file), { recursive: true });
      fs.writeFileSync(this.file, JSON.stringify(this.state));
    } catch {}
  }

  // one check: returns the SOL sent (0 if nothing to do)
  async run() {
    if (this.running || !this.sideWallets().length) return 0;
    this.running = true;
    try {
      const bal = await this.balance();
      if (!(bal >= 0)) return 0;
      const step = Math.floor(bal / this.everySol);
      // first run: remember where we are, send nothing
      if (this.state.step == null) {
        this.state.step = step;
        this.save();
        return 0;
      }
      if (step < this.state.step) {
        this.state.step = step; // went down: a later climb back up counts again
        this.save();
        return 0;
      }
      if (step === this.state.step || step < 1) return 0;
      const ws = this.sideWallets();
      const total = this.sendSol * ws.length;
      if (bal - total < this.keepSol) return 0;
      const bh = await this.rpc.call('getLatestBlockhash', [{ commitment: 'confirmed' }]);
      const tx = buildTransferTx(this.owner, ws.map((w) => ({ to: w.pub, lamports: Math.round(this.sendSol * 1e9) })), bh.value.blockhash);
      const r = await this.swapper.send(tx);
      this.state.step = step;
      this.save();
      log.info(`Auto-fund: sent ${this.sendSol} SOL to ${ws.map((w) => w.label).join(', ')} (${r.sig})`);
      await this.notify?.(`💸 Main wallet hit ${step * this.everySol} SOL: sent <b>${this.sendSol} SOL</b> each to ${ws.map((w) => w.label).join(', ')}`);
      return total;
    } catch (err) {
      log.warn(`Auto-fund failed: ${err.message}`);
      return 0;
    } finally {
      this.running = false;
    }
  }
}
