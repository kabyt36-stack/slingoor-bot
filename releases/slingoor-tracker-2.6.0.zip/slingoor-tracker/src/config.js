import { fileURLToPath } from 'node:url';
import fs from 'node:fs';
import path from 'node:path';
import { isAddress } from './util.js';
import { parseDevs } from './devs.js';

export const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

const DEFAULTS = {
  TELEGRAM_BOT_TOKEN: '',
  TELEGRAM_CHAT_ID: '',
  TARGET_NAME: 'slingoor',
  SELF_KEYWORDS: 'sling',
  TARGET_WALLETS: '5YRgrP3mjGzrzirYYN5HAQH19cTYREYwGxW6XRJQUzij',
  // V2.3: more traders to copy, as name:wallet (several wallets: name:w1;w2), comma separated.
  // Pause/unpause each one in Telegram: /mode <name> off|on
  TRADERS: 'schoen:5hAgYC8TJCcEZV7LTXAzkTrm7YL29YXyQQJPCNrG84zM,ansem:GV6UUmNxz2RpKxmNAPadYKb7uQpszwqQAu3qLJxVdC52,killua:95TWoKkvv2z85EXBzd2z6NwbxH2f54AvwuCA9x3NoKep,dilly:G9gmk9msvd6wT4hDJFm64vKra5z82YvD9je9WqjBvnuk,bot:BUkpShoEWRiPckdFs3kzYGjBPfUhL6G39ufo84QeogPP,decu:4vw54BmAogeRV3vPKWyFet5yf8DTLcREzdSzx4rw9Ud9',
  // V2.5 mini toaster: known farmers -> always quick profit (sell 100% at +20% to +40%)
  MINI_TOASTER: 'bot,decu',
  // fixed buy size per trader (name:SOL), e.g. decu is risky -> small
  TRADER_BUY_SOL: 'decu:0.05',
  // don't copy these traders' buys when the coin has fewer holders than this (name:holders)
  TRADER_MIN_HOLDERS: 'bot:20',
  // if the second trader buys a coin we copied from the first, hold for the jump and sell 100% when either sells
  TRADER_BOOSTERS: 'decu>bot',
  // V2.4 devs: coins these devs launch get bought. name:wallet:mode (instant | dip | momentum)
  DEVS: 'pattersin:AoGefnxF5CbZvbd2cvxv4Ex1E5j86dqEjehazRuMcMFe:instant,claudia:bwamJzztZsepfkteWRChggmXuiiCQvpLqPietdNfSXa:momentum,ya:21s7TyYFofbS9vAvLrxWVhKQScJAv7rrTSm1gTtt1dqv:dip,nig:gVDXhoGbePACvSqN7CZBtQXFW9eyJwsgudPEwSydAkx:dip,rugdev:H9SaZazTkfFYgqXoEYDzfQNVLnDLph7C65BB4vX9c9Sw:rug',
  // V2.5 rug-dev experiment: only buy while the market cap is at most this (USD), sell very fast
  DEV_RUG_MAX_MC_USD: '3000',
  DEV_RUG_MAX_HOLD_MINUTES: '5',
  // V2.4 watch-only wallets (never copied): if one buys into a coin the bot holds AFTER the bot bought,
  // the bot holds that coin longer for more profit. name:wallet, comma separated.
  WATCH_WALLETS: 'jackduval:BAr5csYtpWoNpwhUjixX7ZPHXkUciFZzjBp9uNxZXJPh,kimchi:Gs5FHwYLrDBmCmiv5VhBLCvyiBmBYfcPedZDqR88GYeX,million:4ugDhHJ8XDXAeABmrNmGffFaLbJb9BkPyiFGVSV9ocwo,henry:CuDe51GPh5qGsmYBJDxSsufhQQhA618uDbkaXFZ4pztL,cyberleek:PrEytJ4nKqKcLwzHrxLZT3JcZHfr2NnMGMDcQWkj8dS',
  DEV_BUY_SOL: '0.1',
  DEV_QUICK_WALLET_BUY_SOL: '0.05',
  DEV_DIP_PERCENT: '20',
  DEV_MOMENTUM_HOLDERS: '40',
  DEV_MOMENTUM_UP_PERCENT: '30',
  DEV_WATCH_MINUTES: '20',
  // Cupsey mode: also copy cupsey's brand-new coins, same rules, same bot wallet
  CUPSEY_MODE: 'off', // V2.3: cupsey removed (not profitable)
  CUPSEY_NAME: 'cupsey',
  CUPSEY_WALLETS: '6DQAGJT7VZPVBsuG4kn3AvpyHCEi7B2RFFvMZdbqQqqP',
  // cupsey trades fresh new pairs that often rug: his coins sell faster (see settings.txt)
  CUPSEY_FAST_EXIT: 'on',
  // dead coin: sell all when a losing coin goes quiet and more people are selling than buying
  // sling's coins: sell all if the coin has fewer holders than this (after the first minutes)
  COPY_MIN_HOLDERS: '80',
  COPY_MIN_HOLDERS_AFTER_MINUTES: '10',
  // sells at a loss: no Telegram alert, listed in the 11:59pm daily recap instead
  COPY_LOSS_ALERTS: 'off',
  // V2 weak-buy rule: trader bought under this much SOL and the chart is fading -> sell all (0 = off)
  COPY_WEAK_BUY_SOL: '3',
  COPY_WEAK_MIN_MINUTES: '3',
  COPY_WEAK_MAX_X: '1.1',
  // V2: traders the bot does NOT copy by default (sling retired). /mode <name> on to copy again.
  COPY_TRADERS_OFF: 'slingoor,cupsey,decu',
  // V2: one-line Telegram alerts (bought X for Y SOL; Nx cook / mini cook / sold, got Y SOL)
  SHORT_ALERTS: 'on',
  COPY_DEAD_COIN: 'on',
  COPY_DEAD_MIN_MINUTES: '20',
  COPY_DEAD_MAX_TRADES_5M: '10',
  COPY_DEAD_MAX_VOLUME_5M_USD: '300',
  CUPSEY_MINI_SELL_PERCENT: '100',
  CUPSEY_STOP_LOSS_X: '0.7',
  CUPSEY_CRASH_DROP_PERCENT: '20',
  CUPSEY_TRAIL_AFTER_X: '1.3',
  CUPSEY_TRAIL_DROP_PERCENT: '25',
  CUPSEY_PROFIT_FLOOR_X: '1.05',
  HELIUS_API_KEY: '',
  HELIUS_BACKUP_KEYS: '',
  USE_PUMPFUN: 'off',
  CHAIN_COMMITMENT: 'auto',
  RPC_URL: 'https://api.mainnet-beta.solana.com',
  WS_URL: 'wss://api.mainnet-beta.solana.com',
  PUMP_TRADES_POLL_SECONDS: '2',
  CALLOUT_POLL_SECONDS: '5',
  CALLOUT_LIST_SECONDS: '20',
  LAUNCH_POLL_SECONDS: '60',
  MERGE_WINDOW_SECONDS: '20',
  MIN_ALERT_SOL: '0',
  QUIET_MODE: 'on',
  SUMMARY_MINUTE: '0',
  ALERT_NEW_ENTRIES: 'on',
  ALERT_ADDS: 'on',
  ALERT_PARTIAL_SELLS: 'on',
  ALERT_FULL_EXITS: 'on',
  ALERT_TRANSFERS: 'on',
  ALERT_CALLOUTS: 'on',
  ALERT_CALLOUT_UPDATES: 'on',
  ALERT_LAUNCHES: 'on',
  META_ONLY_ENTRIES: 'off',
  // Copy trading
  COPY_TRADE: 'off',
  COPY_PRIVATE_KEY: '',
  COPY_KEY_FILE: 'wallet-key.txt',
  // V2 quick-profit wallets: extra wallets that buy the same coins as the main wallet and sell 100% at +25%
  QUICK_WALLETS: 'on',
  QUICK_WALLET_KEY_FILES: 'wallet-key-2.txt,wallet-key-3.txt,wallet-key-4.txt',
  QUICK_WALLET_BUY_SOL: '0.05',
  QUICK_WALLET_SELL_X: '1.25',
  // V2.6 auto-fund: each time the main wallet reaches a new whole AUTO_FUND_EVERY_SOL, send AUTO_FUND_SOL to each side wallet
  AUTO_FUND: 'on',
  AUTO_FUND_EVERY_SOL: '1',
  AUTO_FUND_SOL: '0.1',
  AUTO_FUND_KEEP_SOL: '0.3',
  COPY_BUY_SOL: '0.1',
  COPY_SIZE_MODE: 'scale',
  COPY_SCALE_AT_1_SOL: '0.5',
  COPY_MAX_BUY_SOL: '1',
  COPY_SCALE_MAX_AT_SOL: '1000',
  COPY_MAX_WALLET_PERCENT: '20',
  COPY_MAX_PER_COIN_SOL: '2',
  COPY_MIN_BUY_SOL: '0.01',
  COPY_ADDS: 'on',
  COPY_ONLY_NEW_COINS: 'on',
  COPY_REENTRIES: 'off',
  COPY_SKIP_ALERTS: 'on',
  COPY_ONE_BUY_PER_COIN: 'on',
  COPY_FEE_MODE: 'low',
  COPY_MAX_SLIPPAGE: '50',
  COPY_MAX_COIN_AGE_HOURS: '3',
  COPY_PROTECT: 'on',
  COPY_CRASH_DROP_PERCENT: '35',
  COPY_CRASH_MINUTES: '5',
  COPY_TRAIL_AFTER_X: '1.5',
  COPY_TRAIL_DROP_PERCENT: '40',
  COPY_PROFIT_FLOOR_X: '1.15',
  COPY_MAX_HOLD_HOURS: '8',
  COPY_FLOOR_BUY_SOL: '0.1',
  COPY_ROUTE_WAIT_SECONDS: '45',
  COPY_TP_LADDER: '2x:50,4x:25,6x:25,8x:25',
  // Quick profit mode (also /quick on|off in Telegram): every coin sells 100% once up 25%, on the
  // first 7% dip, or at +75% at the latest
  QUICK_PROFIT_MODE: 'off',
  QUICK_PROFIT_FROM_X: '1.25',
  QUICK_PROFIT_TO_X: '1.75',
  QUICK_PROFIT_PULLBACK_PERCENT: '7',
  COPY_MINI_COOK: 'on',
  COPY_MINI_COOK_FROM_X: '1.75',
  COPY_MINI_COOK_TO_X: '2.5',
  COPY_MINI_COOK_PULLBACK_PERCENT: '10',
  COPY_MINI_COOK_SELL_PERCENT: '50',
  COPY_MINI_COOK_MIN_SOL: '0.1',
  COPY_NEW_COIN_MINUTES: '10',
  COPY_RECLAIM_RENT: 'on',
  JUPITER_RPS: '',
  COPY_QUICK_TP_X: '1.5',
  COPY_QUICK_TP_PERCENT: '35',
  COPY_QUICK_TP_HIS_MIN_SOL: '1',
  COPY_SLIPPAGE: '10',
  COPY_PRIORITY_FEE: '0.002',
  COPY_MIRROR_SELLS: 'on',
  COPY_TAKE_PROFIT_X: '2',
  COPY_TAKE_PROFIT_SELL_PERCENT: '25',
  COPY_MAX_OPEN_POSITIONS: '10',
  COPY_DAILY_LIMIT_SOL: '0',
  COPY_MIN_HIS_BUY_SOL: '0',
  COPY_MAX_DELAY_SECONDS: '30',
  COPY_KEEP_SOL: '0.02',
  COPY_TP_CHECK_SECONDS: '5',
  COPY_SELL_RETRY_SECONDS: '15',
  COPY_SELL_RETRY_MINUTES: '10',
  COPY_SELL_CHECK_DELAY_SECONDS: '3',
  PUMPPORTAL_API_BASE: 'https://pumpportal.fun/api',
  JUPITER_API_BASE: 'https://lite-api.jup.ag/swap/v1',
  JUPITER_API_KEY: '',
  COPY_JITO: 'on',
  JITO_URLS: 'https://mainnet.block-engine.jito.wtf/api/v1/transactions,https://ny.mainnet.block-engine.jito.wtf/api/v1/transactions',
  COPY_FILE: 'data/copytrade.json',
  // Advanced / testing overrides
  PUMP_API_BASE: 'https://frontend-api-v3.pump.fun',
  PROFILE_API_BASE: 'https://profile-api.pump.fun',
  TELEGRAM_API_BASE: 'https://api.telegram.org',
  DEX_API_BASE: 'https://api.dexscreener.com',
  STATE_FILE: 'data/state.json',
  LOG_FILE: 'logs/bot.log',
};

function parseFile(file) {
  const out = {};
  if (!fs.existsSync(file)) return out;
  for (const raw of fs.readFileSync(file, 'utf8').replace(/^\uFEFF/, '').split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith('#')) continue;
    const i = line.indexOf('=');
    if (i < 1) continue;
    const k = line.slice(0, i).trim();
    let v = line.slice(i + 1).trim();
    // strip inline comment " # ..." and surrounding quotes
    const hash = v.search(/\s+#/);
    if (hash >= 0) v = v.slice(0, hash).trim();
    v = v.replace(/^["'“”‘’]+|["'“”‘’]+$/g, ''); // TextEdit may turn quotes into “smart quotes”
    out[k] = v;
  }
  return out;
}

const on = (v) => /^(on|true|yes|1)$/i.test(String(v).trim());
const num = (v, d) => (Number.isFinite(+v) && String(v).trim() !== '' ? +v : d);

export function cleanHeliusKey(v) {
  let k = String(v || '').trim().replace(/^["'“”‘’<]+|["'“”‘’>]+$/g, '');
  const m = k.match(/api[-_]key=([^&\s"'<>]+)/i);
  if (m) k = m[1];
  const uuid = k.match(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i);
  if (uuid) k = uuid[0];
  return k.replace(/[^\w-]/g, '');
}

export function loadConfig(settingsFile = process.env.SETTINGS_FILE || path.join(ROOT, 'settings.txt')) {
  const fileVals = parseFile(settingsFile);
  const raw = { ...DEFAULTS, ...fileVals };
  // Environment variables win (used by tests and power users)
  for (const k of Object.keys(DEFAULTS)) if (process.env[k] != null && process.env[k] !== '') raw[k] = process.env[k];

  let rpcUrl = raw.RPC_URL;
  let wsUrl = raw.WS_URL;
  // People paste the whole Helius URL (https://mainnet.helius-rpc.com/?api-key=...) instead of the key.
  raw.HELIUS_API_KEY = cleanHeliusKey(raw.HELIUS_API_KEY);
  // ...or put the Helius link in RPC_URL / WS_URL: use its key for both, so the live stream
  // never ends up on the public Solana server (which blocks many home connections).
  if (!raw.HELIUS_API_KEY) {
    for (const u of [raw.RPC_URL, raw.WS_URL]) if (/helius/i.test(u || '') && /api[-_]key=/i.test(u)) raw.HELIUS_API_KEY ||= cleanHeliusKey(u);
  }
  if (raw.HELIUS_API_KEY) {
    rpcUrl = `https://mainnet.helius-rpc.com/?api-key=${raw.HELIUS_API_KEY}`;
    wsUrl = `wss://mainnet.helius-rpc.com/?api-key=${raw.HELIUS_API_KEY}`;
  }
  // a custom RPC_URL without its own WS_URL: use the same server for the live stream
  if (!raw.HELIUS_API_KEY && rpcUrl !== DEFAULTS.RPC_URL && wsUrl === DEFAULTS.WS_URL) wsUrl = rpcUrl.replace(/^http/i, 'ws');
  const isPublicRpc = /api\.mainnet-beta\.solana\.com/.test(rpcUrl);
  // V2.5 backup Helius keys (keys or full links, comma separated): used when the main key runs out
  const heliusKeys = raw.HELIUS_API_KEY
    ? [raw.HELIUS_API_KEY, ...String(raw.HELIUS_BACKUP_KEYS || '').split(/[\s,]+/).filter(Boolean).map((k) => cleanHeliusKey(k)).filter((k) => /^[0-9a-f-]{20,}$/i.test(k || ''))]
    : [];

  const wallets = raw.TARGET_WALLETS.split(/[\s,]+/).filter(Boolean);
  const bad = wallets.filter((w) => !isAddress(w));
  if (bad.length) throw new Error(`TARGET_WALLETS has invalid address(es): ${bad.join(', ')}`);
  if (!wallets.length) throw new Error('TARGET_WALLETS is empty');
  // every trader the bot follows: [{ name, wallets }]; the main one (TARGET_*) first
  const traders = [{ name: raw.TARGET_NAME || 'target', wallets: [...wallets] }];
  if (on(raw.CUPSEY_MODE)) {
    const cw = raw.CUPSEY_WALLETS.split(/[\s,]+/).filter(Boolean).filter((w) => !wallets.includes(w));
    const badC = cw.filter((w) => !isAddress(w));
    if (badC.length) throw new Error(`CUPSEY_WALLETS has invalid address(es): ${badC.join(', ')}`);
    if (cw.length) {
      traders.push({ name: raw.CUPSEY_NAME || 'cupsey', wallets: cw });
      wallets.push(...cw);
    }
  }
  for (const part of String(raw.TRADERS || '').split(',').map((x) => x.trim()).filter(Boolean)) {
    const [name, ws] = part.split(':').map((x) => (x || '').trim());
    const tw = String(ws || '').split(/[;\s]+/).filter(Boolean).filter((w) => !wallets.includes(w));
    if (!name || !tw.length) continue;
    const badT = tw.filter((w) => !isAddress(w));
    if (badT.length) throw new Error(`TRADERS: ${name} has invalid wallet(s): ${badT.join(', ')}`);
    traders.push({ name, wallets: tw });
    wallets.push(...tw);
  }
  // devs are followed like traders (their launches come in as their buys), flagged isDev
  const devs = parseDevs(raw.DEVS, isAddress).filter((d) => !wallets.includes(d.wallet));
  for (const d of devs) {
    traders.push({ name: d.name, wallets: [d.wallet], isDev: true, devMode: d.mode });
    wallets.push(d.wallet);
  }
  const traderOf = (w) => (traders.find((t) => t.wallets.includes(w)) || traders[0]).name;

  const resolve = (p) => (path.isAbsolute(p) ? p : path.join(ROOT, p));

  return {
    settingsFile,
    telegramToken: raw.TELEGRAM_BOT_TOKEN,
    chatIds: raw.TELEGRAM_CHAT_ID.split(/[\s,]+/).filter(Boolean),
    targetName: raw.TARGET_NAME || 'target',
    selfWords: raw.SELF_KEYWORDS.split(/[\s,]+/).filter(Boolean),
    wallets,
    traders,
    traderOf,
    devs,
    rpcUrl,
    wsUrl,
    heliusKeys: [...new Set(heliusKeys)],
    isPublicRpc,
    tradesPollMs: Math.max(1, num(raw.PUMP_TRADES_POLL_SECONDS, 2)) * 1000,
    calloutPollMs: Math.max(2, num(raw.CALLOUT_POLL_SECONDS, 5)) * 1000,
    calloutListMs: Math.max(2, num(raw.CALLOUT_LIST_SECONDS, 20)) * 1000,
    launchPollMs: Math.max(5, num(raw.LAUNCH_POLL_SECONDS, 60)) * 1000,
    mergeWindowMs: Math.max(0, num(raw.MERGE_WINDOW_SECONDS, 20)) * 1000,
    minAlertSol: num(raw.MIN_ALERT_SOL, 0),
    // one summary every hour instead of an alert per trade (urgent ones still ping right away)
    quietMode: on(raw.QUIET_MODE),
    summaryMinute: Math.min(59, Math.max(0, Math.round(num(raw.SUMMARY_MINUTE, 0)))),
    alerts: {
      entry: on(raw.ALERT_NEW_ENTRIES),
      add: on(raw.ALERT_ADDS),
      partial: on(raw.ALERT_PARTIAL_SELLS),
      exit: on(raw.ALERT_FULL_EXITS),
      transfer: on(raw.ALERT_TRANSFERS),
      callout: on(raw.ALERT_CALLOUTS),
      calloutUpdate: on(raw.ALERT_CALLOUT_UPDATES),
      launch: on(raw.ALERT_LAUNCHES),
    },
    metaOnlyEntries: on(raw.META_ONLY_ENTRIES),
    // processed = sees his trades ~0.3s sooner; the public Solana server is slower at it, so only on others
    usePumpfun: on(raw.USE_PUMPFUN),
    chainCommitment: /^(processed|confirmed)$/i.test(raw.CHAIN_COMMITMENT) ? raw.CHAIN_COMMITMENT.toLowerCase() : isPublicRpc ? 'confirmed' : 'processed',
    copy: copyConfig(raw, resolve),
    pumpApi: raw.PUMP_API_BASE.replace(/\/$/, ''),
    profileApi: raw.PROFILE_API_BASE.replace(/\/$/, ''),
    telegramApi: raw.TELEGRAM_API_BASE.replace(/\/$/, ''),
    dexApi: raw.DEX_API_BASE.replace(/\/$/, ''),
    stateFile: resolve(raw.STATE_FILE),
    logFile: resolve(raw.LOG_FILE),
  };
}

// Sell rules for dev coins. instant devs (pump fast, dump fast): take the best quick profit, +25% to +40%.
// dip / momentum devs: ride it up and sell near the top, sell all fast if it turns down.
function pairs(text) {
  const out = {};
  for (const p of String(text || '').split(/[\s,]+/).filter(Boolean)) {
    const [k, v] = p.split(':');
    if (k && +v > 0) out[k.trim()] = +v;
  }
  return out;
}

function devRules(raw) {
  const out = {};
  // mini toaster traders: quick profit, all out
  for (const n of String(raw.MINI_TOASTER || '').split(/[\s,]+/).filter(Boolean)) out[n] = { miniFromX: 1.2, miniToX: 1.4, miniPullbackPct: 5, miniPct: 100, stopLossX: 0.8, crashDropPct: 20, trailArmX: 1.15, trailDropPct: 15, floorX: 1.03 };
  for (const d of parseDevs(raw.DEVS, isAddress)) {
    out[d.name] =
      d.mode === 'rug'
        ? { miniFromX: 1.1, miniToX: 1.3, miniPullbackPct: 3, miniPct: 100, stopLossX: 0.85, crashDropPct: 10, trailArmX: 1.08, trailDropPct: 8, floorX: 1.02, maxHoldMinutes: Math.max(1, num(raw.DEV_RUG_MAX_HOLD_MINUTES, 5)) }
        : d.mode === 'instant'
        ? { miniFromX: 1.25, miniToX: 1.4, miniPullbackPct: 5, miniPct: 100, stopLossX: 0.8, crashDropPct: 20, trailArmX: 1.15, trailDropPct: 15, floorX: 1.03 }
        : { miniFromX: 1.5, miniToX: 3, miniPullbackPct: 12, miniPct: 100, stopLossX: 0.85, crashDropPct: 20, trailArmX: 1.2, trailDropPct: 15, floorX: 1.05 };
  }
  return out;
}

function copyConfig(raw, resolve) {
  let key = raw.COPY_PRIVATE_KEY;
  const keyFile = resolve(raw.COPY_KEY_FILE);
  if (!key && fs.existsSync(keyFile)) key = fs.readFileSync(keyFile, 'utf8').replace(/^\uFEFF/, '').trim();
  // quick-profit wallets: one key per file (missing files are skipped)
  const quickWallets = on(raw.QUICK_WALLETS)
    ? String(raw.QUICK_WALLET_KEY_FILES || '')
        .split(/[\s,]+/)
        .filter(Boolean)
        .map((f, i) => {
          const p = resolve(f);
          if (!fs.existsSync(p)) return null;
          const k = fs.readFileSync(p, 'utf8').replace(/^\uFEFF/, '').trim();
          return k ? { label: `W${i + 2}`, key: k, file: p } : null;
        })
        .filter(Boolean)
    : [];
  const c = {
    enabled: on(raw.COPY_TRADE),
    privateKey: key || '',
    quickWallets,
    quickWalletBuySol: Math.max(0.001, num(raw.QUICK_WALLET_BUY_SOL, 0.05)),
    quickWalletSellX: Math.max(1.03, num(raw.QUICK_WALLET_SELL_X, 1.25)),
    autoFund: on(raw.AUTO_FUND),
    autoFundEverySol: Math.max(0.1, num(raw.AUTO_FUND_EVERY_SOL, 1)),
    autoFundSol: Math.max(0.001, num(raw.AUTO_FUND_SOL, 0.1)),
    autoFundKeepSol: Math.max(0, num(raw.AUTO_FUND_KEEP_SOL, 0.3)),
    keyFile,
    buySol: num(raw.COPY_BUY_SOL, 0.1),
    sizeMode: /^fixed$/i.test(raw.COPY_SIZE_MODE) ? 'fixed' : 'scale',
    scaleAt1: Math.max(0, num(raw.COPY_SCALE_AT_1_SOL, 0.5)),
    maxBuySol: Math.max(0, num(raw.COPY_MAX_BUY_SOL, 1)),
    scaleMaxAt: Math.max(10, num(raw.COPY_SCALE_MAX_AT_SOL, 1000)),
    maxWalletPct: Math.min(100, Math.max(0, num(raw.COPY_MAX_WALLET_PERCENT, 20))),
    maxPerCoinSol: Math.max(0, num(raw.COPY_MAX_PER_COIN_SOL, 2)),
    minBuySol: Math.max(0.001, num(raw.COPY_MIN_BUY_SOL, 0.01)),
    copyAdds: on(raw.COPY_ADDS),
    onlyNewCoins: on(raw.COPY_ONLY_NEW_COINS),
    copyReentries: on(raw.COPY_REENTRIES),
    skipAlerts: on(raw.COPY_SKIP_ALERTS),
    oneBuyPerCoin: on(raw.COPY_ONE_BUY_PER_COIN),
    maxSlippage: Math.min(90, Math.max(1, num(raw.COPY_MAX_SLIPPAGE, 50))),
    maxCoinAgeMs: Math.max(0, num(raw.COPY_MAX_COIN_AGE_HOURS, 3)) * 3600000,
    protect: on(raw.COPY_PROTECT),
    crashDropPct: Math.min(90, Math.max(5, num(raw.COPY_CRASH_DROP_PERCENT, 35))),
    crashWindowMs: Math.max(1, num(raw.COPY_CRASH_MINUTES, 5)) * 60000,
    trailArmX: Math.max(1.05, num(raw.COPY_TRAIL_AFTER_X, 1.5)),
    trailDropPct: Math.min(90, Math.max(5, num(raw.COPY_TRAIL_DROP_PERCENT, 40))),
    floorX: Math.max(0, num(raw.COPY_PROFIT_FLOOR_X, 1.15)),
    maxHoldHours: Math.max(0, num(raw.COPY_MAX_HOLD_HOURS, 8)),
    floorBuySol: Math.max(0, num(raw.COPY_FLOOR_BUY_SOL, 0.1)),
    deadCoin: on(raw.COPY_DEAD_COIN),
    shortAlerts: on(raw.SHORT_ALERTS),
    weakBuySol: Math.max(0, num(raw.COPY_WEAK_BUY_SOL, 3)),
    weakMinMs: Math.max(0, num(raw.COPY_WEAK_MIN_MINUTES, 3)) * 60000,
    weakMaxX: Math.max(1, num(raw.COPY_WEAK_MAX_X, 1.1)),
    tradersOffDefault: String(raw.COPY_TRADERS_OFF || '').split(/[\s,]+/).filter(Boolean),
    lossAlerts: on(raw.COPY_LOSS_ALERTS),
    minHolders: Math.max(0, Math.round(num(raw.COPY_MIN_HOLDERS, 80))),
    minHoldersAfterMs: Math.max(0, num(raw.COPY_MIN_HOLDERS_AFTER_MINUTES, 10)) * 60000,
    deadMinMs: Math.max(1, num(raw.COPY_DEAD_MIN_MINUTES, 20)) * 60000,
    deadMaxTrades5m: Math.max(0, num(raw.COPY_DEAD_MAX_TRADES_5M, 10)),
    deadMaxVol5m: Math.max(0, num(raw.COPY_DEAD_MAX_VOLUME_5M_USD, 300)),
    // per-trader sell rules: coins copied from these traders use them instead of the normal ones
    leaderRules: Object.assign(devRules(raw), on(raw.CUPSEY_MODE) && on(raw.CUPSEY_FAST_EXIT)
      ? {
          [raw.CUPSEY_NAME || 'cupsey']: {
            miniPct: Math.min(100, Math.max(1, Math.round(num(raw.CUPSEY_MINI_SELL_PERCENT, 100)))),
            stopLossX: Math.min(0.99, Math.max(0, num(raw.CUPSEY_STOP_LOSS_X, 0.7))),
            crashDropPct: Math.min(90, Math.max(5, num(raw.CUPSEY_CRASH_DROP_PERCENT, 20))),
            trailArmX: Math.max(1.05, num(raw.CUPSEY_TRAIL_AFTER_X, 1.3)),
            trailDropPct: Math.min(90, Math.max(5, num(raw.CUPSEY_TRAIL_DROP_PERCENT, 25))),
            floorX: Math.max(0, num(raw.CUPSEY_PROFIT_FLOOR_X, 1.05)),
          },
        }
      : {}),
    devNames: parseDevs(raw.DEVS, isAddress).map((d) => d.name),
    toasters: String(raw.MINI_TOASTER || '').split(/[\s,]+/).filter(Boolean),
    traderBuySol: pairs(raw.TRADER_BUY_SOL),
    traderMinHolders: pairs(raw.TRADER_MIN_HOLDERS),
    boosters: String(raw.TRADER_BOOSTERS || '').split(/[\s,]+/).filter((x) => x.includes('>')).map((x) => x.split('>').map((y) => y.trim())),
    watchWallets: String(raw.WATCH_WALLETS || '')
      .split(',')
      .map((x) => x.trim().split(':').map((y) => y.trim()))
      .filter(([n, w]) => n && w && isAddress(w))
      .map(([name, wallet]) => ({ name, wallet })),
    devBuySol: Math.max(0.001, num(raw.DEV_BUY_SOL, 0.1)),
    rugNames: parseDevs(raw.DEVS, isAddress).filter((d) => d.mode === 'rug').map((d) => d.name),
    rugMaxMcUsd: Math.max(100, num(raw.DEV_RUG_MAX_MC_USD, 3000)),
    devQuickWalletBuySol: Math.max(0.001, num(raw.DEV_QUICK_WALLET_BUY_SOL, 0.05)),
    devDipPct: Math.min(90, Math.max(1, num(raw.DEV_DIP_PERCENT, 20))),
    devMomentumHolders: Math.max(1, Math.round(num(raw.DEV_MOMENTUM_HOLDERS, 40))),
    devMomentumUpPct: Math.max(1, num(raw.DEV_MOMENTUM_UP_PERCENT, 30)),
    devWatchMs: Math.max(1, num(raw.DEV_WATCH_MINUTES, 20)) * 60000,
    // Mini cook (safety net): on buys of COPY_MINI_COOK_MIN_SOL+, once a coin is up 75%+ (1.75x) sell part of it
    // when it starts to pull back, or at 2.5x at the latest. The rest keeps riding the ladder.
    miniCook: on(raw.COPY_MINI_COOK),
    quickMode: on(raw.QUICK_PROFIT_MODE),
    quickFromX: Math.max(1.03, num(raw.QUICK_PROFIT_FROM_X, 1.25)),
    quickToX: Math.max(1.05, num(raw.QUICK_PROFIT_TO_X, 1.75)),
    quickPullbackPct: Math.min(50, Math.max(1, num(raw.QUICK_PROFIT_PULLBACK_PERCENT, 7))),
    miniFromX: Math.max(1.05, num(raw.COPY_MINI_COOK_FROM_X, 1.75)),
    miniToX: Math.max(1.1, num(raw.COPY_MINI_COOK_TO_X, 2.5)),
    miniPullbackPct: Math.min(50, Math.max(1, num(raw.COPY_MINI_COOK_PULLBACK_PERCENT, 10))),
    miniPct: Math.min(100, Math.max(1, Math.round(num(raw.COPY_MINI_COOK_SELL_PERCENT, 50)))),
    miniMinSol: Math.max(0, num(raw.COPY_MINI_COOK_MIN_SOL, 0.1)),
    routeWaitMs: Math.max(0, num(raw.COPY_ROUTE_WAIT_SECONDS, 45)) * 1000,
    // "2x:50,4x:25,..." -> at 2x the entry price sell 50% of what's left, at 4x 25%, ... (never 100%: the rest
    // follows his sells). off/empty = use COPY_TAKE_PROFIT_X and the quick profit instead.
    tpLadder: /^(off|no|0)?$/i.test(String(raw.COPY_TP_LADDER).trim())
      ? []
      : String(raw.COPY_TP_LADDER)
          .split(/[,\s]+/)
          .map((s) => s.match(/^(\d+(?:\.\d+)?)x?:(\d+(?:\.\d+)?)%?$/i))
          .filter(Boolean)
          .map((m) => ({ x: +m[1], pct: Math.min(90, Math.max(1, Math.round(+m[2]))) }))
          .filter((s) => s.x > 1)
          .sort((a, b) => a.x - b.x),
    reclaimRent: on(raw.COPY_RECLAIM_RENT),
    newCoinWindowMs: Math.max(1, num(raw.COPY_NEW_COIN_MINUTES, 10)) * 60000,
    quickTpX: Math.max(0, num(raw.COPY_QUICK_TP_X, 1.5)),
    quickTpPercent: Math.min(90, Math.max(0, num(raw.COPY_QUICK_TP_PERCENT, 35))), // never sells out on profit
    quickTpHisMinSol: Math.max(0, num(raw.COPY_QUICK_TP_HIS_MIN_SOL, 1)),
    slippage: num(raw.COPY_SLIPPAGE, 25),
    // low (default): Jupiter's 'high' fee level, at most 0.0005 SOL a trade (measured: usually ~0.00001 SOL);
    // fast: 'veryHigh' up to COPY_PRIORITY_FEE (was ~0.0018 SOL a trade).
    feeMode: /^fast$/i.test(raw.COPY_FEE_MODE) ? 'fast' : 'low',
    priorityFee: /^fast$/i.test(raw.COPY_FEE_MODE) ? num(raw.COPY_PRIORITY_FEE, 0.002) : Math.min(num(raw.COPY_PRIORITY_FEE, 0.002), 0.0005),
    priorityLevel: /^fast$/i.test(raw.COPY_FEE_MODE) ? 'veryHigh' : 'high',
    mirrorSells: on(raw.COPY_MIRROR_SELLS),
    tpX: num(raw.COPY_TAKE_PROFIT_X, 2),
    tpPercent: Math.min(90, Math.max(0, num(raw.COPY_TAKE_PROFIT_SELL_PERCENT, 25))), // take-profit never sells out
    maxOpen: Math.max(1, num(raw.COPY_MAX_OPEN_POSITIONS, 10)),
    dailyLimitSol: num(raw.COPY_DAILY_LIMIT_SOL, 0),
    minHisBuySol: num(raw.COPY_MIN_HIS_BUY_SOL, 0),
    maxDelayMs: Math.max(3, num(raw.COPY_MAX_DELAY_SECONDS, 30)) * 1000,
    keepSol: Math.max(0, num(raw.COPY_KEEP_SOL, 0.02)),
    tpCheckMs: Math.max(3, num(raw.COPY_TP_CHECK_SECONDS, 5)) * 1000,
    sellRetryMs: Math.max(0.05, num(raw.COPY_SELL_RETRY_SECONDS, 15)) * 1000,
    sellRetryMax: Math.max(0, Math.round(num(raw.COPY_SELL_RETRY_MINUTES, 10) * 60 / Math.max(0.05, num(raw.COPY_SELL_RETRY_SECONDS, 15)))),
    sellCheckDelayMs: Math.max(0, num(raw.COPY_SELL_CHECK_DELAY_SECONDS, 3)) * 1000,
    portalBase: raw.PUMPPORTAL_API_BASE.replace(/\/$/, ''),
    jupKey: raw.JUPITER_API_KEY,
    jupRps: Math.max(0, num(raw.JUPITER_RPS, 0)),
    jitoUrls: on(raw.COPY_JITO) ? raw.JITO_URLS.split(/[\s,]+/).filter(Boolean) : [],
    // with a key, use the main Jupiter API (higher limits)
    jupBase: (raw.JUPITER_API_KEY && raw.JUPITER_API_BASE === DEFAULTS.JUPITER_API_BASE ? 'https://api.jup.ag/swap/v1' : raw.JUPITER_API_BASE).replace(/\/$/, ''),
    file: resolve(raw.COPY_FILE),
  };
  if (c.enabled) {
    if (!(c.buySol > 0)) throw new Error('COPY_BUY_SOL must be more than 0');
    if (c.buySol > 50) throw new Error('COPY_BUY_SOL is over 50 SOL — that looks like a typo');
    if (c.maxBuySol > 50) throw new Error('COPY_MAX_BUY_SOL is over 50 SOL — that looks like a typo');
    if (!(c.slippage > 0 && c.slippage <= 100)) throw new Error('COPY_SLIPPAGE must be between 1 and 100');
    if (c.priorityFee < 0 || c.priorityFee > 0.1) throw new Error('COPY_PRIORITY_FEE must be between 0 and 0.1 SOL');
  }
  return c;
}
