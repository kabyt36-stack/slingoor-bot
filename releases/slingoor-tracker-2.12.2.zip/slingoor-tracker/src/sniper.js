import fs from 'node:fs';
import { log } from './log.js';
import { nameKey } from './versions.js';
import { withTimeout } from './util.js';
import { pumpTradeEvents } from './parse.js';

// V2.12.0 (Khalil, Nov 15 10:34am): NEW PAIR SNIPER — its own paper wallet, separate from copy trading.
// Trades brand-new pump.fun launches the way the trader "bot" does, with Khalil's rules:
//   - under 60s old and under $6k market cap, with an X link
//   - insiders (dev's launch buy + wallets buying in the first ~2s) between 1% and 20% of supply
//   - the early buyers' wallets checked: too many fresh wallets (no history) = a bundle, skipped
//   - not a near-copy of a coin it already traded or saw; a vamp (same name as an earlier coin) gets a stricter
//     wallet check (fewer fresh wallets allowed, dev must not be fresh)
//   - take profit +15%..+75% (armed at +15%, sells on a small dip from the top, all out at +75%), strict stop,
//     fast sells: dev selling or a big holder dumping = out right away; out after 5 min regardless
// Paper only: fills use the coin's bonding curve from the live feed, minus pump.fun's 1% fee, a priority fee and
// a little slippage for our delay. Feed: PumpPortal's free websocket (new tokens + each candidate's trades).
const SUPPLY = 1e9;
const FEE = 0.01;

export class Sniper {
  constructor({ cfg = {}, rpc, file, broadcast = async () => {}, getSolPrice = () => 0, fetchMeta, now = () => Date.now(), coinBook = null, wsUrl = 'wss://pumpportal.fun/api/data', WebSocketImpl = globalThis.WebSocket, tradeFeed = null }) {
    this.cfg = {
      maxAgeMs: 60000,
      maxMcUsd: 6000,
      needX: true,
      minInsiderPct: 1,
      maxInsiderPct: 20,
      earlyMs: 2000, // buyers this soon after the launch count as insiders (same block or so)
      watchMs: 4000, // how long to watch a launch before deciding (first buyers, dev behavior)
      buySol: 0.1,
      startSol: 0.25,
      maxOpen: 3,
      takeFromX: 1.15,
      takeToX: 1.75,
      pullbackPct: 7,
      stopX: 0.9,
      maxHoldMs: 5 * 60000,
      staleMs: 45000,
      bigDumpPct: 3, // someone (not us) selling 3%+ of supply while we hold = out
      maxFreshPct: 50,
      vampMaxFreshPct: 25,
      vampDevMinTx: 5,
      freshMaxTx: 3, // a wallet with this many transactions or fewer counts as fresh
      walletCheckMax: 8,
      similarMs: 30 * 60000,
      priorityFee: 0.0005,
      lagPct: 1.5,
      ...cfg,
    };
    this.rpc = rpc;
    this.file = file;
    this.broadcast = broadcast;
    this.getSolPrice = getSolPrice;
    this.fetchMeta = fetchMeta || defaultFetchMeta;
    this.now = now;
    this.coinBook = coinBook;
    this.wsUrl = wsUrl;
    this.WebSocketImpl = WebSocketImpl;
    this.tradeFeed = tradeFeed; // each watched/held coin's trades (from the Solana logs; PumpPortal's trade stream is paid)
    if (tradeFeed) tradeFeed.onTrade = (ev) => this.onTrade(ev);
    this.watch = new Map(); // mint -> launch being watched
    this.names = new Map(); // name/symbol key -> { at, mint }
    this.walletCache = new Map(); // wallet -> { tx, at }
    this.d = { on: true, sol: this.cfg.startSol, start: this.cfg.startSol, positions: {}, trips: [], skips: [], startedAt: this.now() };
    this.load();
  }

  load() {
    if (!this.file) return;
    try {
      const j = JSON.parse(fs.readFileSync(this.file, 'utf8'));
      this.d = { ...this.d, ...j, positions: j.positions || {}, trips: j.trips || [], skips: j.skips || [] };
    } catch {}
  }

  save() {
    if (!this.file) return;
    try {
      const tmp = `${this.file}.tmp`;
      fs.writeFileSync(tmp, JSON.stringify({ ...this.d, trips: this.d.trips.slice(-500), skips: this.d.skips.slice(-50) }));
      fs.renameSync(tmp, this.file);
    } catch (e) {
      log.debug('sniper save failed', e.message);
    }
  }

  get on() {
    return this.d.on !== false;
  }

  set on(v) {
    this.d.on = !!v;
    this.save();
  }

  reset() {
    this.d = { on: this.on, sol: this.cfg.startSol, start: this.cfg.startSol, positions: {}, trips: [], skips: [], startedAt: this.now() };
    for (const m of [...this.watch.keys()]) this._unwatch(m);
    this.save();
  }

  // ---------- feed ----------
  start() {
    if (!this.WebSocketImpl || this.ws) return;
    const open = () => {
      let ws;
      try {
        ws = new this.WebSocketImpl(this.wsUrl);
      } catch (e) {
        log.warn('Sniper: feed connect failed', e.message);
        return setTimeout(open, 10000).unref?.();
      }
      this.ws = ws;
      ws.onopen = () => {
        this._send({ method: 'subscribeNewToken' });
        log.info('Sniper: new-pair feed connected');
      };
      ws.onmessage = (m) => {
        try {
          this.onEvent(JSON.parse(typeof m.data === 'string' ? m.data : m.data.toString()));
        } catch {}
      };
      ws.onclose = () => {
        this.ws = null;
        if (!this.stopped) setTimeout(open, 5000).unref?.();
      };
      ws.onerror = () => {};
    };
    open();
    this.tradeFeed?.start?.();
    for (const m of Object.keys(this.d.positions)) this.tradeFeed?.sub(m); // coins held across a restart
    this._tick = setInterval(() => this.tick().catch(() => {}), 2000);
    this._tick.unref?.();
  }

  stop() {
    this.stopped = true;
    clearInterval(this._tick);
    try {
      this.ws?.close();
    } catch {}
    this.tradeFeed?.stop?.();
  }

  _send(o) {
    try {
      if (this.ws && this.ws.readyState === 1) this.ws.send(JSON.stringify(o));
    } catch {}
  }

  _unwatch(mint) {
    this.watch.delete(mint);
    if (!this.d.positions[mint]) this.tradeFeed?.unsub(mint);
  }

  mcUsd(ev) {
    const sol = this.getSolPrice();
    return ev?.marketCapSol > 0 && sol > 0 ? ev.marketCapSol * sol : null;
  }

  onEvent(ev) {
    if (!ev || !ev.mint) return;
    if (ev.txType === 'create') return this.onCreate(ev);
    if (ev.txType === 'buy' || ev.txType === 'sell') return this.onTrade(ev);
  }

  onCreate(ev) {
    if (!this.on) return;
    const t = this.now();
    // remember every launch's name (for near-copies and vamps), even ones we don't trade
    const keys = [nameKey(ev.name), ev.symbol ? `$${String(ev.symbol).toLowerCase().replace(/[^a-z0-9]/g, '')}` : null].filter((k) => k && k.length > 2);
    const earlier = keys.map((k) => this.names.get(k)).find((x) => x && x.mint !== ev.mint);
    for (const k of keys) if (!this.names.has(k)) this.names.set(k, { at: t, mint: ev.mint });
    if (this.names.size > 20000) this.names.delete(this.names.keys().next().value);
    const mc = this.mcUsd(ev);
    if (mc != null && mc > this.cfg.maxMcUsd) return;
    if (Object.keys(this.d.positions).length >= this.cfg.maxOpen) return;
    if (this.watch.size >= 30) return; // never more than 30 launches watched at once
    // same coin again (a near-copy of one it holds, is watching or traded in the last 30 min): skipped
    this.tradedNames ||= new Map();
    const similar = keys.some((k) => {
      const at = this.tradedNames.get(k);
      return at != null && t - at < this.cfg.similarMs;
    });
    if (similar) return this._skip(ev, 'too similar to a coin it already traded');
    for (const k of keys) this.tradedNames.set(k, t); // being watched counts too: no second copy at the same time
    if (this.tradedNames.size > 5000) this.tradedNames.delete(this.tradedNames.keys().next().value);
    const bookOlder = this.coinBook?.byName?.get(nameKey(ev.name));
    const vamp = !!earlier || !!(bookOlder && bookOlder.size);
    const w = { keys, mint: ev.mint, name: ev.name, symbol: ev.symbol, dev: ev.traderPublicKey, uri: ev.uri, createdAt: t, vamp, last: ev, devTokens: +ev.initialBuy || 0, early: new Map(), buyers: [], devSold: false, decided: false };
    this.watch.set(ev.mint, w);
    this.tradeFeed?.sub(ev.mint);
    w.metaP = withTimeout(Promise.resolve(this.fetchMeta(ev.uri)), 2500, null).catch(() => null);
    setTimeout(() => this.decide(ev.mint).catch((e) => log.debug('sniper decide failed', e.message)), this.cfg.watchMs).unref?.();
  }

  onTrade(ev) {
    const t = this.now();
    const p = this.d.positions[ev.mint];
    const w = this.watch.get(ev.mint);
    if (w) {
      w.last = ev;
      if (ev.traderPublicKey === w.dev && ev.txType === 'sell') w.devSold = true;
      if (ev.txType === 'buy' && ev.traderPublicKey !== w.dev) {
        if (!w.buyers.includes(ev.traderPublicKey)) w.buyers.push(ev.traderPublicKey);
        if (t - w.createdAt <= this.cfg.earlyMs) w.early.set(ev.traderPublicKey, (w.early.get(ev.traderPublicKey) || 0) + (+ev.tokenAmount || 0));
      }
    }
    if (p) {
      p.last = ev;
      p.lastAt = t;
      const x = this.xOf(p, ev);
      if (x != null) p.peak = Math.max(p.peak || 1, x);
      // fast sells: the dev selling, or anyone else dumping a big bag
      if (ev.txType === 'sell' && ev.traderPublicKey === p.dev) return this.sell(ev.mint, 'dev sold');
      if (ev.txType === 'sell' && (+ev.tokenAmount || 0) >= (this.cfg.bigDumpPct / 100) * SUPPLY) return this.sell(ev.mint, `a holder dumped ${Math.round(((+ev.tokenAmount || 0) / SUPPLY) * 100)}% of supply`);
      this.checkExit(ev.mint);
    }
  }

  // ---------- buy decision ----------
  async decide(mint) {
    const w = this.watch.get(mint);
    if (!w || w.decided) return;
    w.decided = true;
    const skip = (why) => {
      this._unwatch(mint);
      this._skip(w, why);
      for (const k of w.keys || []) this.tradedNames?.delete(k); // skipped, not traded: a later copy can still be judged
    };
    const t = this.now();
    if (!this.on) return skip('sniper off');
    if (t - w.createdAt > this.cfg.maxAgeMs) return skip('older than 60s');
    if (w.devSold) return skip('dev already sold');
    const mc = this.mcUsd(w.last);
    if (mc == null) return skip('no price yet');
    if (mc > this.cfg.maxMcUsd) return skip(`market cap $${Math.round(mc / 1000)}k is over $${Math.round(this.cfg.maxMcUsd / 1000)}k`);
    const meta = await w.metaP;
    const x = meta?.twitter || meta?.x || '';
    if (this.cfg.needX && !/(x|twitter)\.com\//i.test(String(x))) return skip('no X link');
    w.website = meta?.website || null;
    const insiderTokens = w.devTokens + [...w.early.values()].reduce((a, b) => a + b, 0);
    const insiderPct = (insiderTokens / SUPPLY) * 100;
    w.insiderPct = insiderPct;
    if (insiderPct < this.cfg.minInsiderPct) return skip(`insiders ${insiderPct.toFixed(1)}% (under ${this.cfg.minInsiderPct}%)`);
    if (insiderPct > this.cfg.maxInsiderPct) return skip(`insiders ${insiderPct.toFixed(0)}% (over ${this.cfg.maxInsiderPct}%)`);
    // fresh wallets among the first buyers (and the dev, for vamps), checked in parallel, ~1.5s max
    const check = w.buyers.slice(0, this.cfg.walletCheckMax);
    const [txs, devTx] = await Promise.all([Promise.all(check.map((a) => this.walletTx(a))), w.vamp ? this.walletTx(w.dev) : Promise.resolve(null)]);
    const known = txs.filter((n) => n != null);
    const fresh = known.filter((n) => n <= this.cfg.freshMaxTx).length;
    const freshPct = known.length ? (fresh / known.length) * 100 : 0;
    w.fresh = fresh;
    w.checked = known.length;
    // V2.12.1 (Khalil's 11:05am buy showed "0/0 fresh wallets"): no buy until at least SNIPE_MIN_BUYERS (2) other
    // buyers have shown up and been checked — still inside the 60s window; checked again every 2s
    if (known.length < (this.cfg.minBuyers ?? 2)) {
      if (this.now() - w.createdAt + 2000 > this.cfg.maxAgeMs) return skip(`only ${known.length} buyer${known.length === 1 ? '' : 's'} to check by 60s`);
      w.decided = false;
      setTimeout(() => this.decide(mint).catch(() => {}), this.cfg.retryMs ?? 2000).unref?.();
      return null;
    }
    const maxFresh = w.vamp ? this.cfg.vampMaxFreshPct : this.cfg.maxFreshPct;
    if (known.length >= 2 && freshPct > maxFresh) return skip(`${fresh} of ${known.length} first buyers are fresh wallets${w.vamp ? ' (vamp: stricter)' : ''}`);
    if (w.vamp && devTx != null && devTx < this.cfg.vampDevMinTx) return skip(`vamp with a fresh dev (${devTx} transactions)`);
    if (this.now() - w.createdAt > this.cfg.maxAgeMs) return skip('older than 60s after the checks');
    if (Object.keys(this.d.positions).length >= this.cfg.maxOpen) return skip(`already ${this.cfg.maxOpen} coins open`);
    if (this.d.sol < this.cfg.buySol + this.cfg.priorityFee) return skip('sniper wallet is out of SOL');
    this.watch.delete(mint);
    return this.buy(w);
  }

  // how many transactions a wallet has (cached 10 min); null = unknown
  async walletTx(a) {
    if (!a || !this.rpc) return null;
    const hit = this.walletCache.get(a);
    if (hit && this.now() - hit.at < 600000) return hit.tx;
    const lim = this.cfg.freshMaxTx + 2;
    const sigs = await withTimeout(this.rpc.call('getSignaturesForAddress', [a, { limit: lim }]), 1500, null).catch(() => null);
    const tx = Array.isArray(sigs) ? sigs.length : null;
    if (tx != null) this.walletCache.set(a, { tx, at: this.now() });
    if (this.walletCache.size > 5000) this.walletCache.delete(this.walletCache.keys().next().value);
    return tx;
  }

  // ---------- paper fills on the bonding curve ----------
  _curve(ev) {
    const vS = +ev?.vSolInBondingCurve;
    const vT = +ev?.vTokensInBondingCurve;
    return vS > 0 && vT > 0 ? { vS, vT } : null;
  }

  priceOf(ev) {
    const c = this._curve(ev);
    return c ? c.vS / c.vT : ev?.marketCapSol > 0 ? ev.marketCapSol / SUPPLY : null;
  }

  xOf(p, ev) {
    const px = this.priceOf(ev);
    return px && p.entryPx ? px / p.entryPx : null;
  }

  buy(w) {
    const c = this._curve(w.last);
    const px = this.priceOf(w.last);
    if (!px) return this._skip(w, 'no price');
    const lag = 1 + this.cfg.lagPct / 100;
    const inSol = this.cfg.buySol * (1 - FEE);
    const tokens = c ? (c.vT - (c.vS * c.vT) / (c.vS + inSol)) / lag : inSol / (px * lag);
    const cost = this.cfg.buySol + this.cfg.priorityFee;
    this.d.sol -= cost;
    const p = { mint: w.mint, name: w.name, symbol: w.symbol, dev: w.dev, tokens, cost, entryPx: cost / tokens, at: this.now(), last: w.last, lastAt: this.now(), peak: 1, vamp: w.vamp, insiderPct: w.insiderPct, fresh: w.fresh, checked: w.checked, mcIn: this.mcUsd(w.last) };
    this.d.positions[w.mint] = p;
    this.save();
    log.info(`Sniper: bought ${w.symbol || w.mint.slice(0, 6)} (${(this.now() - w.createdAt) / 1000}s old, $${Math.round((p.mcIn || 0) / 1000)}k, insiders ${w.insiderPct.toFixed(1)}%, ${w.fresh}/${w.checked} fresh)`);
    // V2.12.1 (Khalil): short alert — coin, size, market cap and its pump.fun link
    this.broadcast(`🎯🧪 <b>Bought</b> <a href="https://pump.fun/coin/${w.mint}">${esc(w.symbol || 'coin')}</a> · ${this.cfg.buySol} SOL at $${((p.mcIn || 0) / 1000).toFixed(1)}k`).catch?.(() => {});
    return p;
  }

  checkExit(mint) {
    const p = this.d.positions[mint];
    if (!p) return;
    const x = this.xOf(p, p.last);
    if (x == null) return;
    if (x <= this.cfg.stopX) return this.sell(mint, `stop loss (${pct(x)})`);
    if (x >= this.cfg.takeToX) return this.sell(mint, `took profit at ${pct(x)}`);
    if ((p.peak || 1) >= this.cfg.takeFromX && x <= p.peak * (1 - this.cfg.pullbackPct / 100) && x >= this.cfg.takeFromX * 0.97)
      return this.sell(mint, `took profit at ${pct(x)} (top ${pct(p.peak)})`);
    if ((p.peak || 1) >= this.cfg.takeFromX && x < this.cfg.takeFromX * 0.97) return this.sell(mint, `gave back the win (top ${pct(p.peak)}) — out at ${pct(x)}`);
  }

  sell(mint, why) {
    const p = this.d.positions[mint];
    if (!p) return null;
    const c = this._curve(p.last);
    const px = this.priceOf(p.last) || 0;
    const lag = 1 + this.cfg.lagPct / 100;
    const gross = c ? c.vS - (c.vS * c.vT) / (c.vT + p.tokens) : p.tokens * px;
    const got = Math.max(0, (gross * (1 - FEE)) / lag - this.cfg.priorityFee);
    this.d.sol += got;
    delete this.d.positions[mint];
    const pnl = got - p.cost;
    const trip = { mint, sym: p.symbol, cost: +p.cost.toFixed(5), got: +got.toFixed(5), pnl: +pnl.toFixed(5), x: +(got / p.cost).toFixed(3), heldS: Math.round((this.now() - p.at) / 1000), why, at: this.now(), vamp: p.vamp, insiderPct: p.insiderPct, fresh: p.fresh };
    this.d.trips.push(trip);
    if (this.d.trips.length > 1000) this.d.trips.splice(0, this.d.trips.length - 1000);
    this.save();
    this.tradeFeed?.unsub(mint);
    log.info(`Sniper: sold ${p.symbol || mint.slice(0, 6)} ${pnl >= 0 ? '+' : ''}${pnl.toFixed(4)} SOL — ${why}`);
    // V2.12.2 (Khalil: "same rules as copy trading"): no sell alerts — only a cook when the coin made money after fees
    // and the sniper's last 24h is up too; 2x+ is a 🔥 cook
    const day = this.stats(24 * 3600000);
    if (pnl > 0 && day.pnl > 0) {
      const link = `<a href="https://pump.fun/coin/${mint}">${esc(p.symbol || 'coin')}</a>`;
      const x = got / p.cost;
      this.broadcast(x >= 2 ? `🔥🎯 <b>${x.toFixed(1)}x cook</b> on ${link} — got <b>${got.toFixed(3)} SOL</b> (+${pnl.toFixed(3)})` : `🍳🎯 <b>mini cook</b> on ${link} — got <b>${got.toFixed(3)} SOL</b> (+${pnl.toFixed(3)})`).catch?.(() => {});
    }
    return trip;
  }

  // every 2s: out after 5 min, or when nobody has traded it for 45s (dying)
  async tick() {
    const t = this.now();
    for (const [mint, p] of Object.entries(this.d.positions)) {
      if (t - p.at >= this.cfg.maxHoldMs) this.sell(mint, 'held 5 min');
      else if (t - (p.lastAt || p.at) >= this.cfg.staleMs) this.sell(mint, 'no trades for 45s (dying)');
    }
    for (const [mint, w] of this.watch) if (t - w.createdAt > this.cfg.maxAgeMs + 10000) this._unwatch(mint);
  }

  _skip(w, why) {
    this.d.skips.push({ sym: w.symbol || '', why, at: this.now() });
    if (this.d.skips.length > 60) this.d.skips.shift();
  }

  stats(sinceMs = Infinity) {
    const from = this.now() - sinceMs;
    const tr = this.d.trips.filter((x) => x.at >= from);
    const pnl = tr.reduce((a, x) => a + x.pnl, 0);
    return { n: tr.length, won: tr.filter((x) => x.pnl > 0).length, pnl, open: Object.keys(this.d.positions).length };
  }

  report() {
    const all = this.stats();
    const day = this.stats(24 * 3600000);
    const openVal = Object.values(this.d.positions).reduce((a, p) => {
      const x = this.xOf(p, p.last);
      return a + (x ? p.cost * x : p.cost);
    }, 0);
    const total = this.d.sol + openVal;
    const lines = [
      `🎯🧪 <b>New-pair sniper</b> (paper, its own wallet) — ${this.on ? 'ON' : 'OFF'}`,
      `👛 ${this.d.sol.toFixed(3)} SOL${all.open ? ` + ${all.open} coin(s) ~${openVal.toFixed(3)}` : ''} · total <b>${total.toFixed(3)}</b> (started ${this.d.start.toFixed(3)}) · ${total - this.d.start >= 0 ? '🟢 +' : '🔴 '}${(total - this.d.start).toFixed(3)} SOL`,
      `📊 Last 24h: ${day.n} coins, ${day.won} won · ${day.pnl >= 0 ? '+' : ''}${day.pnl.toFixed(4)} SOL`,
      `Rules: under ${Math.round(this.cfg.maxAgeMs / 1000)}s, under $${Math.round(this.cfg.maxMcUsd / 1000)}k, X link, insiders ${this.cfg.minInsiderPct}-${this.cfg.maxInsiderPct}%, fresh wallets ≤${this.cfg.maxFreshPct}% (vamps ≤${this.cfg.vampMaxFreshPct}%) · take +${Math.round((this.cfg.takeFromX - 1) * 100)}..+${Math.round((this.cfg.takeToX - 1) * 100)}% · stop ${Math.round((this.cfg.stopX - 1) * 100)}% · out by ${Math.round(this.cfg.maxHoldMs / 60000)} min`,
    ];
    const sk = this.d.skips.slice(-5).reverse();
    if (sk.length) lines.push('', 'Last skips:', ...sk.map((s) => `• ${esc(s.sym)}: ${esc(s.why)}`));
    lines.push('', '/snipe on|off · /snipe reset');
    return lines.join('\n');
  }
}

function pct(x) {
  const v = Math.round((x - 1) * 100);
  return `${v >= 0 ? '+' : ''}${v}%`;
}

function esc(s) {
  return String(s ?? '').replace(/[&<>]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' })[c]);
}

// the coin's metadata (name, X link, website) from its uri (IPFS / pump.fun metadata)
async function defaultFetchMeta(uri) {
  if (!uri || !/^https?:\/\//.test(uri)) return null;
  const r = await fetch(uri, { signal: AbortSignal.timeout(2500) });
  if (!r.ok) return null;
  return r.json();
}

// V2.12.0 trades of the coins the sniper watches or holds, straight from the Solana logs (the bot's own RPC
// websocket): one logsSubscribe per coin, pump.fun's TradeEvent decoded from the log (no transaction download).
export class LogsTradeFeed {
  constructor({ wsUrl, WebSocketImpl = globalThis.WebSocket, commitment = 'processed' }) {
    this.wsUrl = wsUrl;
    this.WebSocketImpl = WebSocketImpl;
    this.commitment = commitment;
    this.want = new Set();
    this.subs = new Map(); // mint -> subscription id
    this.pending = new Map(); // request id -> mint
    this.byId = new Map(); // subscription id -> mint
    this.nextId = 1;
    this.onTrade = () => {};
  }

  start() {
    if (this.ws || !this.WebSocketImpl || !this.wsUrl) return;
    let ws;
    try {
      ws = new this.WebSocketImpl(this.wsUrl);
    } catch (e) {
      log.warn('Sniper: trade feed connect failed', e.message);
      return void setTimeout(() => this.start(), 10000).unref?.();
    }
    this.ws = ws;
    ws.onopen = () => {
      this.subs.clear();
      this.byId.clear();
      this.pending.clear();
      for (const m of this.want) this._subscribe(m);
    };
    ws.onmessage = (msg) => {
      let j;
      try {
        j = JSON.parse(typeof msg.data === 'string' ? msg.data : msg.data.toString());
      } catch {
        return;
      }
      if (j.id != null && this.pending.has(j.id)) {
        const mint = this.pending.get(j.id);
        this.pending.delete(j.id);
        if (typeof j.result === 'number') {
          if (!this.want.has(mint)) return this._send({ jsonrpc: '2.0', id: this.nextId++, method: 'logsUnsubscribe', params: [j.result] });
          this.subs.set(mint, j.result);
          this.byId.set(j.result, mint);
        }
        return;
      }
      if (j.method !== 'logsNotification') return;
      const mint = this.byId.get(j.params?.subscription);
      const v = j.params?.result?.value;
      if (!mint || !v || v.err) return;
      for (const t of pumpTradeEvents(v.logs)) {
        if (t.mint !== mint) continue;
        this.onTrade({ txType: t.isBuy ? 'buy' : 'sell', mint, traderPublicKey: t.user, tokenAmount: t.tokenAmount, solAmount: t.solAmount, vSolInBondingCurve: t.vSol, vTokensInBondingCurve: t.vTok, marketCapSol: t.priceSol ? t.priceSol * 1e9 : null, signature: v.signature });
      }
    };
    ws.onclose = () => {
      this.ws = null;
      if (!this.stopped) setTimeout(() => this.start(), 3000).unref?.();
    };
    ws.onerror = () => {};
  }

  stop() {
    this.stopped = true;
    try {
      this.ws?.close();
    } catch {}
  }

  _send(o) {
    try {
      if (this.ws && this.ws.readyState === 1) this.ws.send(JSON.stringify(o));
    } catch {}
  }

  _subscribe(mint) {
    const id = this.nextId++;
    this.pending.set(id, mint);
    this._send({ jsonrpc: '2.0', id, method: 'logsSubscribe', params: [{ mentions: [mint] }, { commitment: this.commitment }] });
  }

  sub(mint) {
    if (this.want.has(mint)) return;
    this.want.add(mint);
    if (this.want.size > 60) this.unsub(this.want.values().next().value);
    this._subscribe(mint);
  }

  unsub(mint) {
    this.want.delete(mint);
    const id = this.subs.get(mint);
    if (id == null) return;
    this.subs.delete(mint);
    this.byId.delete(id);
    this._send({ jsonrpc: '2.0', id: this.nextId++, method: 'logsUnsubscribe', params: [id] });
  }
}
