// V2.8 learning: the bot watches how every wallet's coins move after we copy them (while we hold AND
// for 30 minutes after we sell), then replays those real price paths against other sell settings to
// find what would have made the most for that wallet. Nothing changes until you approve it:
// suggestions go out at 6am, 12pm, 6pm and 12am (and on /suggestions). Unanswered ones are sent again
// next time; only /apply puts them to work.
import fs from 'node:fs';
import path from 'node:path';
import { log } from './log.js';

const SAMPLE_MS = 5000; // one price point every 5s
const POST_MS = 30 * 60000; // keep watching 30 min after we sold
const MAX_POINTS = 800;
const KEEP_TRIPS = 60; // per wallet
const r3 = (n) => Math.round(n * 1000) / 1000;

function readJson(file, d) {
  try {
    return { ...d, ...JSON.parse(fs.readFileSync(file, 'utf8')) };
  } catch {
    return d;
  }
}
function writeJson(file, v) {
  try {
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.writeFileSync(file + '.tmp', JSON.stringify(v));
    fs.renameSync(file + '.tmp', file);
  } catch (err) {
    log.warn('learn save failed', err.message);
  }
}

// Replay one price path with these sell settings -> the x we would have sold at (on average).
// Same mini-cook logic the bot uses: armed at fromX, sells pct% at toX or on a pull back from the top.
export function simulate(points, R) {
  const fromX = R.miniFromX ?? 1.25;
  const toX = R.miniToX ?? 1.8;
  const pull = (R.miniPullbackPct ?? 10) / 100;
  const pct = Math.min(1, (R.miniPct ?? 100) / 100);
  const sl = R.stopLossX > 0 ? R.stopLossX : 0;
  let armed = false;
  let peak = 0;
  for (const [t, x] of points) {
    if (sl && x <= sl && t > 60) return x; // stop loss sells everything
    if (x >= fromX) armed = true;
    if (!armed) continue;
    peak = Math.max(peak, x);
    if (x >= toX || (x <= peak * (1 - pull) && x > 1.05)) {
      if (pct >= 1) return x;
      const end = points.at(-1)[1];
      return pct * x + (1 - pct) * end;
    }
  }
  return points.length ? points.at(-1)[1] : 1;
}

const GRID_TO = Array.from({ length: 28 }, (_, i) => r3(1.3 + i * 0.1)); // 1.3x .. 4.0x
const GRID_PULL = Array.from({ length: 13 }, (_, i) => 5 + i * 2.5); // 5% .. 35%

export class Learner {
  constructor({ file, now = () => Date.now(), minTrades = 15 }) {
    this.file = file;
    this.now = now;
    this.minTrades = minTrades;
    this.d = readJson(file, { live: {}, post: {}, done: {} });
    this._dirty = false;
  }

  save(force) {
    if (!force && !this._dirty) return;
    this._dirty = false;
    writeJson(this.file, this.d);
  }

  // while we hold: one point every 5s (x = what our coins are worth vs what they cost)
  sample(mint, p, x) {
    if (!(x > 0) || !p.leader) return;
    const l = (this.d.live[mint] ||= { leader: p.leader, cost: p.costSol, start: p.openedAt || this.now(), pts: [] });
    const t = Math.round((this.now() - l.start) / 1000);
    const last = l.pts.at(-1);
    if (last && t - last[0] < SAMPLE_MS / 1000) return;
    if (l.pts.length < MAX_POINTS) l.pts.push([t, r3(x)]);
    this._dirty = true;
  }

  // we sold out: keep following its price for 30 more minutes (did we leave money on the table?)
  closed(mint, p) {
    const l = this.d.live[mint];
    delete this.d.live[mint];
    if (!l || !l.pts.length) return;
    const perToken = p.costSol / (p.boughtTokens || p.tokens || 1);
    if (!(perToken > 0)) return;
    this.d.post[mint] = { ...l, perToken, exitIdx: l.pts.length, until: this.now() + POST_MS };
    this._dirty = true;
  }

  watching() {
    return Object.keys(this.d.post);
  }

  // price (SOL per token) of a coin we already sold
  postPrice(mint, pxSol) {
    const w = this.d.post[mint];
    if (!w) return;
    if (pxSol > 0) {
      const t = Math.round((this.now() - w.start) / 1000);
      const last = w.pts.at(-1);
      if ((!last || t - last[0] >= SAMPLE_MS / 1000) && w.pts.length < MAX_POINTS) w.pts.push([t, r3(pxSol / w.perToken)]);
      this._dirty = true;
    }
    if (this.now() >= w.until) this._finish(mint);
  }

  tick() {
    for (const [mint, w] of Object.entries(this.d.post)) if (this.now() >= w.until) this._finish(mint);
    // a position that vanished without a sell (sold by hand outside the bot): drop after 12h
    for (const [mint, l] of Object.entries(this.d.live)) if (this.now() - l.start > 12 * 3600000) delete this.d.live[mint];
    this.save();
  }

  _finish(mint) {
    const w = this.d.post[mint];
    delete this.d.post[mint];
    const list = (this.d.done[w.leader] ||= []);
    list.push({ at: this.now(), cost: w.cost, pts: w.pts, exitIdx: w.exitIdx });
    if (list.length > KEEP_TRIPS) list.splice(0, list.length - KEEP_TRIPS);
    this._dirty = true;
  }

  trades(leader) {
    return (this.d.done[leader] || []).length;
  }

  // Best sell-x and pull-back for one wallet, vs its current settings. null = not enough trades or
  // no clear win (needs +0.02 SOL and +3% of what was spent, so random noise doesn't move your settings).
  best(leader, cur) {
    const trips = this.d.done[leader] || [];
    if (trips.length < this.minTrades) return null;
    const total = (R) => trips.reduce((a, t) => a + (simulate(t.pts, R) - 1) * (t.cost || 0.1), 0);
    const base = total(cur);
    // among equally good settings, the one closest to what you have now (smallest change)
    const dist = (toX, pull) => Math.abs(toX - cur.miniToX) / cur.miniToX + Math.abs(pull - cur.miniPullbackPct) / 100;
    let top = { gain: 0, toX: cur.miniToX, pull: cur.miniPullbackPct, d: 0 };
    for (const toX of GRID_TO)
      for (const pull of GRID_PULL) {
        const g = total({ ...cur, miniToX: toX, miniPullbackPct: pull }) - base;
        const d = dist(toX, pull);
        if (g > top.gain + 1e-9 || (g > 1e-9 && Math.abs(g - top.gain) <= 1e-9 && d < top.d)) top = { gain: g, toX, pull, d };
      }
    const spent = trips.reduce((a, t) => a + (t.cost || 0.1), 0);
    if (top.gain < Math.max(0.02, spent * 0.03)) return null;
    if (top.toX === cur.miniToX && top.pull === cur.miniPullbackPct) return null;
    // how often we sold before the coin went higher (shown with the suggestion)
    const early = trips.filter((t) => {
      const ex = t.pts[Math.max(0, (t.exitIdx || t.pts.length) - 1)]?.[1] ?? 1;
      return t.pts.slice(t.exitIdx || t.pts.length).some((p) => p[1] > ex * 1.2);
    }).length;
    return { leader, n: trips.length, gain: r3(top.gain), from: { miniToX: cur.miniToX, miniPullbackPct: cur.miniPullbackPct }, to: { miniToX: top.toX, miniPullbackPct: top.pull }, early };
  }
}

// Suggestions: sent at set hours, wait for /apply. Approved settings are saved here and used by the bot.
export class Suggestions {
  constructor({ file, learner, rulesFor, leaders, onApplied = () => {}, send, hours = [0, 6, 12, 18], now = () => Date.now() }) {
    this.file = file;
    this.learner = learner;
    this.rulesFor = rulesFor; // leader -> current sell settings (with anything already applied)
    this.leaders = leaders; // () => wallet names
    this.onApplied = onApplied;
    this.send = send;
    this.hours = hours;
    this.now = now;
    this.d = readJson(file, { pending: {}, applied: {}, lastSlot: null });
  }

  save() {
    writeJson(this.file, this.d);
  }

  applied() {
    return this.d.applied;
  }

  // recompute: a newer, better answer replaces that wallet's old one; old unanswered ones stay
  refresh() {
    for (const leader of this.leaders()) {
      const s = this.learner.best(leader, this.rulesFor(leader));
      const old = this.d.pending[leader];
      if (s) this.d.pending[leader] = { ...s, firstAt: old?.firstAt ?? this.now(), sent: old?.sent ?? 0 };
    }
    this.save();
    return Object.values(this.d.pending);
  }

  text() {
    const list = Object.values(this.d.pending);
    if (!list.length) {
      const counts = this.leaders().map((l) => `${l} ${this.learner.trades(l)}`).join(' · ');
      return `🧠 <b>No suggestions right now</b> — your settings already beat everything it tested, or it's still learning (needs ${this.learner.minTrades} trades per wallet).\nTrades learned: ${counts || 'none yet'}`;
    }
    const pct = (p) => `${Math.round(p)}%`;
    const when = (t) => new Date(t).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
    const lines = ['🧠 <b>Suggestions</b> (learned from real trades)'];
    const script = [];
    for (const s of list) {
      const waiting = s.sent > 0 ? ` <i>(waiting since ${when(s.firstAt)})</i>` : '';
      lines.push(
        '',
        `<b>${s.leader}</b>${waiting}: sell at <b>${s.to.miniToX}x</b> (now ${s.from.miniToX}x), dip <b>${pct(s.to.miniPullbackPct)}</b> (now ${pct(s.from.miniPullbackPct)})`,
        `+${s.gain.toFixed(3)} SOL better over ${s.n} trades · sold too early ${s.early}×`,
        `/apply_${s.leader} · /skip_${s.leader}`,
      );
      script.push(`- ${s.leader}: sell all at ${s.to.miniToX}x (was ${s.from.miniToX}x), sell on a ${s.to.miniPullbackPct}% dip from the top (was ${s.from.miniPullbackPct}%) — ${s.n} trades, +${s.gain.toFixed(3)} SOL better`);
    }
    lines.push('', '/apply — apply all · /skip — skip all', '', '📋 <b>Or paste this to Claude:</b>');
    lines.push(`<pre>Make these learned sell settings the defaults in my slingoor copy bot, test and publish:\n${script.join('\n')}</pre>`);
    return lines.join('\n');
  }

  apply(leader) {
    const names = leader ? [leader] : Object.keys(this.d.pending);
    const done = [];
    for (const n of names) {
      const s = this.d.pending[n];
      if (!s) continue;
      this.d.applied[n] = { ...(this.d.applied[n] || {}), ...s.to };
      delete this.d.pending[n];
      done.push(n);
    }
    this.save();
    if (done.length) this.onApplied(this.d.applied);
    return done;
  }

  skip(leader) {
    const names = leader ? [leader] : Object.keys(this.d.pending);
    for (const n of names) delete this.d.pending[n];
    this.save();
    return names;
  }

  reset() {
    this.d.applied = {};
    this.d.pending = {};
    this.save();
    this.onApplied({});
  }

  _slot(t) {
    const d = new Date(t);
    return this.hours.includes(d.getHours()) ? `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}-${d.getHours()}` : null;
  }

  // at 12am, 6am, 12pm, 6pm: send new + still-unanswered suggestions (nothing if there are none)
  async tick() {
    const slot = this._slot(this.now());
    if (!slot || slot === this.d.lastSlot) return false;
    this.d.lastSlot = slot;
    const list = this.refresh();
    if (!list.length) return false;
    const html = this.text();
    for (const s of list) s.sent = (s.sent || 0) + 1;
    this.save();
    await this.send(html).catch(() => {});
    return true;
  }
}
