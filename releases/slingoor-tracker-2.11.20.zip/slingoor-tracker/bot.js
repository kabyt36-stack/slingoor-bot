#!/usr/bin/env node
// slingoor tracker — Telegram alerts for a pump.fun trader's buys, full sells, callouts and launches,
// with narrative ("meta") matching against the coins he usually plays.
import fs from 'node:fs';
import path from 'node:path';
import { loadConfig, ROOT } from './src/config.js';
import { log, setLogFile } from './src/log.js';
import { State } from './src/state.js';
import { Telegram } from './src/telegram.js';
import { PumpApi } from './src/pumpapi.js';
import { Rpc } from './src/rpc.js';
import { Coins } from './src/coins.js';
import { MetaProfile, tagText } from './src/narrative.js';
import { Tracker } from './src/tracker.js';
import { ChainWatcher } from './src/chainwatch.js';
import { PumpTradesPoller, CalloutPoller, LaunchPoller } from './src/pollers.js';
import { metaSummary, metaBlock, coinLine, mcLine, linkButtons } from './src/format.js';
import { escHtml as e, fmtUsd, fmtAgo, fmtNum, fmtSol, shortAddr, sleep, isAddress, redact, withTimeout } from './src/util.js';
import { loadKeypair, signTx, verifyTxSignature, b58encode } from './src/solana.js';
import { PaperBook, PaperRpc, PaperSwapper, traderReport } from './src/paper.js';
import crypto from 'node:crypto';
import { Swapper, CopyTrader } from './src/copytrade.js';
import { RentReclaimer } from './src/reclaim.js';
import { Digest, URGENT_RE, isPlainSell } from './src/digest.js';
import { Learner, Suggestions } from './src/learn.js';
import { HourlyGoal, DailyGoal } from './src/goal.js';
import { GhostBook, bandOf, hourName } from './src/ghost.js';
import { Rotator } from './src/rotate.js';
import { DevWatcher } from './src/devs.js';
import { KeyPool } from './src/keys.js';
import { AutoFunder } from './src/fund.js';

const TEST_MINT = 'C5xph2yL6gMdxmuLGxJBkGpmuDFfyi5fqkBNhvL6pump'; // $BTC, used to test building a swap (never sent)
// one-line description of how buys are sized
const sizeText = (c) =>
  c.sizeMode === 'scale'
    ? `buys scaled to his (1 SOL → ${fmtSol(c.scaleAt1)}, max ${fmtSol(c.maxBuySol)} SOL, ≤${c.maxWalletPct}% of wallet per buy)`
    : `${fmtSol(c.buySol)} SOL per buy`;

const startedAt = Date.now();
// side wallets never alert anything about buying
const MAIN_COOK_RE = /cook<\/b>|COOKED|MINI COOK|QUICK PROFIT|TAKE PROFIT/i;
const SIDE_BUY_RE = /🟢 Bought|COPY (?:BUY|ADD)\b|BOT SKIPPED|TAKING OVER/;
const VERSION = (() => {
  try {
    return JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8')).version;
  } catch {
    return '?';
  }
})();
const SUPERVISED = process.env.SUPERVISED === '1';
// Exit code 2 = a settings problem: the start script won't auto-restart on it.
const CONFIG_ERROR = 2;

// `node bot.js --check` tests every connection once and prints the result (used by 1-Setup).
async function selfCheck(cfg) {
  const results = [];
  const step = async (name, fn, critical = true) => {
    try {
      const detail = await fn();
      results.push({ ok: true, name, detail, critical });
      console.log(`  ✅ ${name}${detail ? ` — ${detail}` : ''}`);
    } catch (err) {
      results.push({ ok: false, name, critical });
      console.log(`  ${critical ? '❌' : '⚠️ '} ${name} — ${redact(err.message).slice(0, 160)}`);
    }
  };
  console.log('\nChecking connections…');
  await step('Node.js version', async () => {
    if (typeof WebSocket === 'undefined') throw new Error(`Node ${process.versions.node} is too old, need 22+`);
    return process.versions.node;
  });
  await step('Telegram bot token', async () => {
    if (!cfg.telegramToken) throw new Error('TELEGRAM_BOT_TOKEN is empty in settings.txt');
    const me = await new Telegram({ token: cfg.telegramToken, apiBase: cfg.telegramApi }).getMe();
    return `@${me.username}`;
  });
  const pump = new PumpApi({ base: cfg.pumpApi, profileBase: cfg.profileApi, dexApi: cfg.dexApi, enabled: cfg.usePumpfun });
  let userId = null;
  if (cfg.usePumpfun) await step('pump.fun profile', async () => {
    const u = await pump.getUser(cfg.wallets[0]);
    userId = u.userId;
    return `@${u.username} · ${fmtNum(u.followers || 0)} followers`;
  }, false);
  if (userId) {
    await step('pump.fun callouts', async () => {
      try {
        return `${(await pump.getCallouts(userId, 5)).length} recent callouts readable`;
      } catch {
        const { tokens } = await pump.getHoldings(cfg.wallets[0], 1, 20);
        const ps = await pump.getPositions(cfg.wallets[0], tokens.map((t) => t.token_mint));
        return `callout list is blocked right now — reading them from his positions instead (${ps.filter((p) => p.callout).length} found)`;
      }
    }, false);
    await step('pump.fun trades feed', async () => `${(await pump.getUserTrades(userId, 5)).trades.length} recent trades readable`, false);
  }
  const rpc = new Rpc(cfg.rpcUrl);
  await step('Solana RPC', async () => `slot ${await rpc.call('getSlot', [])}`);
  await step('Solana live stream (websocket)', () =>
    new Promise((resolve, reject) => {
      const ws = new WebSocket(cfg.wsUrl);
      const t = setTimeout(() => {
        try {
          ws.close();
        } catch {}
        reject(new Error('no answer in 10s'));
      }, 10000);
      ws.onopen = () => ws.send(JSON.stringify({ jsonrpc: '2.0', id: 1, method: 'accountSubscribe', params: [cfg.wallets[0], { commitment: 'confirmed', encoding: 'base64' }] }));
      ws.onmessage = (m) => {
        clearTimeout(t);
        ws.close();
        const j = JSON.parse(m.data);
        j.error ? reject(new Error(j.error.message)) : resolve('subscribed');
      };
      ws.onerror = () => {
        clearTimeout(t);
        reject(new Error('could not connect'));
      };
    }),
  );
  if (cfg.copy.enabled) {
    let kp = null;
    await step('Copy trading wallet', async () => {
      if (!cfg.copy.privateKey) throw new Error('COPY_TRADE is on but no private key (run "3 - Copy Trade Setup")');
      kp = loadKeypair(cfg.copy.privateKey);
      if (cfg.wallets.includes(kp.publicKey)) throw new Error('that key is for the wallet you are tracking — use your own wallet');
      const bal = await rpc.call('getBalance', [kp.publicKey, { commitment: 'confirmed' }]);
      const sol = (bal?.value ?? 0) / 1e9;
      const first = cfg.copy.sizeMode === 'scale' ? cfg.copy.scaleAt1 : cfg.copy.buySol;
      const need = first + cfg.copy.keepSol + cfg.copy.priorityFee + 0.003;
      return `${kp.publicKey} · ${fmtSol(sol)} SOL${sol < need ? ` — ⚠️ low: a typical ${fmtSol(first)} SOL copy buy needs ${fmtSol(need)} SOL (smaller buys still work: max ${cfg.copy.maxWalletPct}% of the wallet each)` : ''}`;
    });
    if (kp) {
      await step('Copy trading: build + sign a test swap (not sent)', async () => {
        const sw = new Swapper({ rpc, kp, jupBase: cfg.copy.jupBase, jupKey: cfg.copy.jupKey, portalBase: cfg.copy.portalBase, slippage: cfg.copy.slippage, priorityFee: cfg.copy.priorityFee });
        const bytes = await sw._jupBuild({ inputMint: 'So11111111111111111111111111111111111111112', outputMint: TEST_MINT, amount: Math.round((cfg.copy.sizeMode === 'scale' ? cfg.copy.scaleAt1 : cfg.copy.buySol) * 1e9) }, { allowSimError: true });
        const { bytes: signed } = signTx(bytes, kp);
        if (!verifyTxSignature(signed, kp.publicKey)) throw new Error('signature check failed');
        // ask the Solana network to check our signature (nothing is sent or spent)
        const sim = await rpc.call('simulateTransaction', [Buffer.from(signed).toString('base64'), { encoding: 'base64', sigVerify: true, commitment: 'confirmed' }]);
        if (/Signature/i.test(JSON.stringify(sim?.value?.err || ''))) throw new Error('the network rejected our signature');
        return 'Jupiter + signing work (Solana accepted the signature)';
      });
    }
  }
  const bad = results.filter((r) => !r.ok && r.critical);
  const warn = results.filter((r) => !r.ok && !r.critical);
  console.log('');
  if (bad.length) console.log('❌ Fix the items above, then run the check again.');
  else if (warn.length) console.log('⚠️  Trades will still be caught on-chain, but pump.fun callouts/feeds are not reachable right now.');
  else console.log('✅ Everything works. Start the bot and send /start to it in Telegram.');
  process.exit(bad.length ? 1 : 0);
}

async function main() {
  let cfg;
  try {
    cfg = loadConfig();
  } catch (err) {
    console.error(`Settings problem: ${err.message}`);
    process.exit(CONFIG_ERROR);
  }
  if (process.argv.includes('--check')) return selfCheck(cfg);
  setLogFile(cfg.logFile);
  // V2.11.5 traders removed for being cold a whole week (data/retired.json): not followed at all any more
  // (saves the load). Never the main trader. Re-added only if he's sent again (REVIVE_TRADERS).
  const retiredFile = process.env.RETIRED_FILE || path.join(ROOT, 'data', 'retired.json');
  let retired = {};
  try {
    retired = JSON.parse(fs.readFileSync(retiredFile, 'utf8')) || {};
  } catch {}
  for (const n of String(process.env.REVIVE_TRADERS ?? cfg.reviveTraders ?? '').split(/[\s,]+/).filter(Boolean)) delete retired[n];
  const saveRetired = () => {
    try {
      fs.mkdirSync(path.dirname(retiredFile), { recursive: true });
      fs.writeFileSync(retiredFile, JSON.stringify(retired, null, 1));
    } catch {}
  };
  saveRetired();
  for (let i = cfg.traders.length - 1; i >= 1; i--) {
    const t = cfg.traders[i];
    if (!retired[t.name]) continue;
    cfg.traders.splice(i, 1);
    for (const w of t.wallets) {
      const k = cfg.wallets.indexOf(w);
      if (k >= 0) cfg.wallets.splice(k, 1);
    }
  }
  log.info(`Starting tracker for ${cfg.targetName} (${cfg.wallets.map((w) => shortAddr(w)).join(', ')})`);

  if (typeof WebSocket === 'undefined' || typeof fetch === 'undefined') {
    log.error('This bot needs Node.js 22 or newer. Run 1-Setup again.');
    process.exit(CONFIG_ERROR);
  }
  if (!cfg.telegramToken) {
    log.error('TELEGRAM_BOT_TOKEN is empty. Open settings.txt (or run 1-Setup) and paste your bot token from @BotFather.');
    process.exit(CONFIG_ERROR);
  }

  // copy-trading key is checked before anything else, so a bad key stops the bot right away
  let copyKp = null;
  if (cfg.copy.enabled) {
    try {
      copyKp = loadKeypair(cfg.copy.privateKey);
    } catch (err) {
      log.error(`Copy trading is on but the wallet key can't be used: ${err.message}. Run "3 - Copy Trade Setup" again, or set COPY_TRADE=off.`);
      process.exit(CONFIG_ERROR);
    }
    if (cfg.wallets.includes(copyKp.publicKey)) {
      log.error("The copy-trading key is for the wallet you're tracking. Use your own wallet's key.");
      process.exit(CONFIG_ERROR);
    }
  }

  // Only one copy of the bot may run on this Mac (two copies = every copy trade done twice).
  // The lock lives in the home folder, so a copy started from another folder is caught too.
  const lockFile = process.env.LOCK_FILE || path.join((await import('node:os')).homedir(), '.slingoor-tracker.lock');
  try {
    const other = JSON.parse(fs.readFileSync(lockFile, 'utf8'));
    let alive = false;
    if (other?.pid && other.pid !== process.pid) {
      try {
        process.kill(other.pid, 0);
        alive = true;
      } catch (e) {
        alive = e.code === 'EPERM';
      }
    }
    if (alive) {
      const msg = `Another copy of the bot is already running (from ${other.dir}, started ${new Date(other.startedAt).toLocaleString()}). This copy is stopping so trades aren't done twice. Close the other one (its "2 - Start Bot" window, or Auto-start OFF) if you want this one instead.`;
      log.error(msg);
      try {
        const t = new Telegram({ token: cfg.telegramToken, apiBase: cfg.telegramApi });
        const st = new State(cfg.stateFile);
        for (const chatId of [...new Set([...cfg.chatIds, ...(st.chats || [])])]) await t.send(chatId, `⚠️ <b>Two copies of the bot were running</b> — that's why trades were doubled.\n${e(msg)}`).catch(() => {});
      } catch {}
      process.exit(CONFIG_ERROR);
    }
  } catch {}
  try {
    fs.writeFileSync(lockFile, JSON.stringify({ pid: process.pid, dir: ROOT, startedAt: Date.now() }));
  } catch {}
  const dropLock = () => {
    try {
      if (JSON.parse(fs.readFileSync(lockFile, 'utf8')).pid === process.pid) fs.rmSync(lockFile, { force: true });
    } catch {}
  };
  process.on('exit', dropLock);

  const state = new State(cfg.stateFile);
  stateRef = state;
  const tg = new Telegram({ token: cfg.telegramToken, apiBase: cfg.telegramApi });
  for (let i = 0; ; i++) {
    try {
      const me = await tg.getMe();
      log.info(`Telegram bot: @${me.username}`);
      break;
    } catch (err) {
      if (/401|Unauthorized|404/i.test(err.message)) {
        log.error('Telegram rejected the bot token. Check TELEGRAM_BOT_TOKEN in settings.txt.');
        process.exit(CONFIG_ERROR);
      }
      log.warn('Telegram not reachable yet:', err.message);
      await sleep(Math.min(30000, 2000 * (i + 1)));
    }
  }

  const pump = new PumpApi({ base: cfg.pumpApi, profileBase: cfg.profileApi, dexApi: cfg.dexApi, enabled: cfg.usePumpfun });
  // V2.5 Helius key failover: main key first, backups when it runs out of credits
  const keyPool = cfg.heliusKeys?.length > 1 ? new KeyPool(cfg.heliusKeys) : null;
  if (keyPool) log.info(`Helius: main key + ${keyPool.keys.length - 1} backup key(s) ready`);
  const rpc = new Rpc(cfg.rpcUrl, cfg.isPublicRpc ? { minGapMs: 250, concurrency: 2 } : { minGapMs: 40, concurrency: 4, pool: keyPool });
  const coins = new Coins({ pump, dexApi: cfg.dexApi, rpcUrl: cfg.rpcUrl });
  const profile = new MetaProfile({ selfWords: cfg.selfWords });
  // Separate lane for the quick balance checks that decide "new entry or add?" / "fully out?", so they
  // never queue behind the chain watcher's transaction downloads (which back off when rate-limited).
  const fastRpc = new Rpc(cfg.rpcUrl, cfg.isPublicRpc ? { minGapMs: 100, concurrency: 2 } : { minGapMs: 20, concurrency: 4, pool: keyPool });
  const tracker = new Tracker({ cfg, state, tg, pump, rpc: fastRpc, coins, profile });
  // Quiet mode: one summary at the start of every hour instead of a message per trade
  let digest = null;
  let copierRef = null;
  let learner = null;
  let ghosts = null;
  let rotator = null;
  let devRotator = null; // V2.11.4 devs have their own hot / neutral / cold ranking (for the devs wallet set)
  let sweet = { on: false };
  let saveSweet = () => {};
  // his price per token: the pump.fun trade record, else what he paid (SOL spent / tokens got)
  const hisPrice = (sig) => (sig.ev?.priceSol > 0 ? sig.ev.priceSol : sig.sol > 0 && sig.post > (sig.pre || 0) ? sig.sol / (sig.post - (sig.pre || 0)) : null);
  let walletTraders = {};
  let goal = null;
  // closed trades of this clock hour, all wallets (main + side)
  const hourPnl = () => {
    const start = new Date();
    start.setMinutes(0, 0, 0);
    return [copierRef, ...extraCopiers].filter(Boolean).flatMap((c) => c._today?.().trips || []).filter((t) => (t.at || 0) >= start.getTime()).reduce((a, t) => a + (t.pnl || 0), 0);
  };
  const dayPnl = () => [copierRef, ...extraCopiers].filter(Boolean).flatMap((c) => c._today?.().trips || []).reduce((a, t) => a + (t.pnl || 0), 0);
  let dayGoal = null;
  const goalLine = () => [...(goal?.line() || []), ...(dayGoal?.line() || [])];
  let saveWalletTraders = () => {};
  let suggestions = null;
  const tradersOff = new Set(); // traders whose new buys are not copied right now (/mode)
  let saveModes = () => {};
  if (cfg.quietMode) {
    digest = new Digest({
      file: process.env.SUMMARY_FILE || path.join(ROOT, 'data', 'summary.json'),
      name: cfg.targetName,
      others: cfg.traders.slice(1).map((t) => t.name),
      minute: cfg.summaryMinute,
      send: (html) => tracker.broadcast(html),
      status: async () => {
        if (!copierRef) return [];
        if (paperBook) return paperStatus();
        const sol = await copierRef.solBalance().catch(() => null);
        const open = Object.values(copierRef.positions).filter((p) => p.tokens > 0).map((p) => p.symbol || '?');
        // V2.7.5: my PnL across ALL wallets (main + side wallets), this hour and today
        const all = [copierRef, ...extraCopiers].flatMap((c) => c._today?.().trips || []);
        const hr = Date.now() - 3600000;
        const sum = (a) => a.reduce((x, t) => x + (t.pnl || 0), 0);
        const sg = (n) => `${n >= 0 ? '+' : '-'}${fmtSol(Math.abs(n))}`;
        const mine = extraCopiers.length
          ? [`💼 <b>My PnL (all wallets)</b>: this hour <b>${sg(sum(all.filter((t) => (t.at || 0) >= hr)))} SOL</b> · today <b>${sg(sum(all))} SOL</b>`, ...sideLine(), '<i>main wallet:</i>']
          : [];
        return [...mine, ...goalLine(), ...copierRef.pnlLines(), `👛 Bot wallet: ${sol != null ? `<b>${fmtSol(sol)} SOL</b>` : '?'}${open.length ? ` · holding ${open.length} coin${open.length > 1 ? 's' : ''}` : ' · no coins'}`];
      },
    });
    tracker.digest = digest;
    digest.hideTraders = cfg.copy.shortAlerts; // V2: traders' coins -> /traded
    digest.start();
  }
  // V2.8.7 what the side wallets made: one line for every summary (real and paper)
  const sideLine = () => {
    const hr = Date.now() - 3600000;
    const sum = (a) => a.reduce((x, t) => x + (t.pnl || 0), 0);
    const sg = (n) => `${n >= 0 ? '+' : '-'}${fmtSol(Math.abs(n))}`;
    const line = (title, cs) => {
      const per = cs.map((c) => ({ label: c.label, trips: c._today?.().trips || [] }));
      const all = per.flatMap((x) => x.trips);
      return `${title}: this hour <b>${sg(sum(all.filter((t) => (t.at || 0) >= hr)))} SOL</b> · today <b>${sg(sum(all))} SOL</b> (${per.map((x) => `${x.label} ${sg(sum(x.trips))}`).join(' · ')})`;
    };
    const out = [];
    const mainSide = extraCopiers.filter((c) => !c.set);
    if (mainSide.length) out.push(line('📲 <b>Side wallets</b>', mainSide));
    // V2.9.3 every other wallet set: its own line (its main + its minis)
    for (const name of [...new Set(extraCopiers.filter((c) => c.set).map((c) => c.set))]) out.push(line(`🗂 <b>${e(name)} set</b>`, extraCopiers.filter((c) => c.set === name)));
    return out;
  };
  // V2.8.3 paper mode: the hourly summary becomes a PAPER summary (paper wallets, paper PnL), never mixed with real
  const paperStatus = async () => {
    const all = [copierRef, ...extraCopiers].filter(Boolean);
    const hr = Date.now() - 3600000;
    const trips = all.flatMap((c) => c._today?.().trips || []);
    const sum = (a) => a.reduce((x, t) => x + (t.pnl || 0), 0);
    const sg = (n) => `${n >= 0 ? '+' : '-'}${fmtSol(Math.abs(n))}`;
    const won = trips.filter((t) => t.pnl > 0).length;
    const lines = [`💼 <b>Paper PnL (all wallets)</b>: this hour <b>${sg(sum(trips.filter((t) => (t.at || 0) >= hr)))} SOL</b> · today <b>${sg(sum(trips))} SOL</b>`, ...sideLine(), `🤖 Today: ${trips.length} coin${trips.length === 1 ? '' : 's'} closed (${won} won, ${trips.length - won} lost)`];
    const ws = paperBook?.d.wallets || {};
    const start = paperBook?.d.start || {};
    const parts = Object.entries(ws).map(([l, w]) => {
      const n = Object.keys(w.tokens || {}).length;
      return `${l} <b>${fmtSol(w.sol)}</b>${start[l] != null ? ` (${sg(w.sol - start[l])})` : ''}${n ? ` +${n} coin${n > 1 ? 's' : ''}` : ''}`;
    });
    lines.push(...goalLine());
    if (parts.length) lines.push(`👛 Paper wallets: ${parts.join(' · ')}`);
    if (paperBook?.d.startedAt) lines.push(`🕐 Paper started ${fmtAgo(Date.now() - paperBook.d.startedAt)} ago · /paperwallet for details`);
    return lines;
  };
  // copy-trade messages: urgent ones right away, the rest into the hourly summary
  const botNotify = (html, buttons) => {
    // V2: skip alerts are dropped entirely (no instant message, not in the summary)
    if (cfg.copy.shortAlerts && /SKIPPED|^⏭|COPY BUY WAITING/.test(html)) return;
    // V2.7.5: only cooks ping when the bot sells; other sells go in the hourly summary
    if (cfg.copy.shortAlerts && isPlainSell(html)) return digest?.note(html);
    return digest && !URGENT_RE.test(html) ? digest.note(html) : tracker.broadcast(html, buttons);
  };
  const users = {}; // wallet -> {userId, username, followers}

  // ---------- Copy trading ----------
  let copier = null;
  const extraCopiers = []; // V2 quick-profit wallets
  let saveHib = () => {};
  let getHib = () => null;
  const walletsOff = new Set(); // 'main', 'W2'... switched off for new buys
  let saveWallets = () => {};
  // tracked traders' wallets (not devs): a dev coin they're in gets held longer
  cfg.copy.traderWallets = cfg.traders.filter((t) => !t.isDev).flatMap((t) => t.wallets);
  // V2.7 paper mode: data/paper-mode.json { on, reset, start }. /paper on|off switches and restarts the bot.
  const paperFile = process.env.PAPER_MODE_FILE || path.join(ROOT, 'data', 'paper-mode.json');
  let paperMode = { on: false, reset: false, start: null };
  try {
    paperMode = { ...paperMode, ...JSON.parse(fs.readFileSync(paperFile, 'utf8')) };
  } catch {}
  const savePaperMode = () => {
    try {
      fs.mkdirSync(path.dirname(paperFile), { recursive: true });
      fs.writeFileSync(paperFile, JSON.stringify(paperMode));
    } catch {}
  };
  const throwawayKey = () => {
    const { privateKey, publicKey } = crypto.generateKeyPairSync('ed25519');
    const seed = privateKey.export({ format: 'der', type: 'pkcs8' }).subarray(-32);
    const pub = publicKey.export({ format: 'der', type: 'spki' }).subarray(-32);
    return b58encode(Buffer.concat([seed, pub]));
  };
  // V2.9.8 one-time (Khalil, Nov 12 4:52pm): paper restarts with main 0.1 SOL and the rest spread over the side
  // wallets (0.3 each). Kept as his starting amounts; /paper set still changes them.
  // Then (4:54pm): the side wallets get RANDOM amounts each time paper starts, always 1 SOL in total.
  if (!paperMode.layout298) {
    paperMode.random = { total: 1, main: 0.1 };
    paperMode.layout298 = true;
    if (paperMode.on) paperMode.reset = true;
    savePaperMode();
    log.info('Paper: main 0.1 SOL, side wallets random, 1 SOL in total' + (paperMode.on ? ' — paper restarts now' : ''));
  }
  // random split of what's left after main over the side wallets (each at least 0.05), rounded to 0.01
  const randomSides = (labels, left) => {
    const n = labels.length;
    if (!n) return {};
    const min = Math.min(0.05, left / n);
    const w = labels.map(() => Math.random() + 0.2);
    const tot = w.reduce((a, b) => a + b, 0);
    const out = {};
    let used = 0;
    labels.forEach((l, i) => {
      out[l] = i === n - 1 ? Math.round((left - used) * 100) / 100 : Math.round((min + ((left - min * n) * w[i]) / tot) * 100) / 100;
      used += out[l];
    });
    return out;
  };
  const paperStart = () => {
    const base = { ...cfg.copy.paperStart, ...(paperMode.start || {}) };
    const r = paperMode.random;
    if (!r) return base;
    const sides = Object.keys(base).filter((l) => l !== 'main');
    // V2.11.9 random mode: the 10 side wallets W2-W11
    const ten = Array.from({ length: 10 }, (_, i) => `W${i + 2}`);
    // V2.11.14 r.sides = how many side wallets trade (W2 ... up to W11; 10 slots)
    const n = Math.max(1, Math.min(10, Math.round(r.sides || 0)));
    return { main: r.main, ...randomSides(r.sides ? ten.slice(0, n) : sides.length ? sides : ['W2', 'W3', 'W4'], Math.max(0, r.total - r.main)) };
  };
  // V2.11.9 one-time (Khalil, Nov 12 10:40pm: "bigger wins", "10 side wallets"): paper restarts with main 0.1 SOL
  // and 10 side wallets (W2-W11) with random amounts, 3 SOL in total (about 0.3 per side wallet, like before)
  if (!paperMode.layout2119) {
    paperMode.random = { total: 3, main: 0.1, sides: 10 };
    paperMode.layout2119 = true;
    if (paperMode.on) paperMode.reset = true;
    savePaperMode();
    log.info('Paper: main 0.1 SOL + 10 side wallets random, 3 SOL in total' + (paperMode.on ? ' — paper restarts now' : ''));
  }
  // V2.11.10 (Khalil, Nov 12 10:50pm): paper = 10 side wallets adding up to 1 SOL, NO SOL in the main wallet;
  // the main wallet doesn't buy, it's the bank: side wallets send it their profits, like real transfers
  if (!paperMode.layout21110) {
    paperMode.random = { total: 1, main: 0, sides: 10 };
    paperMode.mainBank = true;
    paperMode.layout21110 = true;
    if (paperMode.on) paperMode.reset = true;
    savePaperMode();
    log.info('Paper: 10 side wallets random, 1 SOL in total, main 0 SOL (main = bank: side wallets send it their profits)' + (paperMode.on ? ' — paper restarts now' : ''));
  }
  // V2.11.14 (Khalil, Nov 13 7:08am, after -0.39 SOL in 2h with 10 sides all in the same rugs): back to 3 side
  // wallets (W2-W4) with the 1 SOL, main 0 (bank). The 10 slots stay: /paper random 1 0 10 uses all 10 again.
  if (!paperMode.layout21114) {
    paperMode.random = { total: 1, main: 0, sides: 3 };
    paperMode.mainBank = true;
    paperMode.layout21114 = true;
    if (paperMode.on) paperMode.reset = true;
    savePaperMode();
    log.info('Paper: 3 side wallets random, 1 SOL in total, main 0 SOL (the bank)' + (paperMode.on ? ' — paper restarts now' : ''));
  }
  // V2.11.15 paper: pump.fun bonding-curve reserves of a coin (for coins Jupiter can't route; the real bot uses
  // PumpPortal for those). null when it's not on the curve any more (graduated) or pump.fun doesn't answer.
  const paperCurve = async (mint) => {
    const c = await pump.getCoin(mint).catch(() => null);
    if (!c || c.complete) return null;
    const vs = BigInt(Math.round(+c.virtual_sol_reserves || 0));
    const vt = BigInt(Math.round(+c.virtual_token_reserves || 0));
    return vs > 0n && vt > 0n ? { vs, vt } : null;
  };
  // V2.11.15 (Khalil, Nov 13 7:13am): paper default = main 0.1 SOL + 3 side wallets 0.3 SOL each (1 SOL). Main trades
  // again; side wallets still send their profits to main (like real transfers).
  if (!paperMode.layout21115) {
    paperMode.random = null;
    paperMode.start = { main: 0.1, W2: 0.3, W3: 0.3, W4: 0.3 };
    paperMode.mainBank = false;
    paperMode.bank = true;
    paperMode.layout21115 = true;
    if (paperMode.on) paperMode.reset = true;
    savePaperMode();
    log.info('Paper: main 0.1 SOL + 3 side wallets 0.3 SOL each (1 SOL); side wallets send their profits to main' + (paperMode.on ? ' — paper restarts now' : ''));
  }
  let paperBook = null;
  if (cfg.copy.enabled) {
    const kp = copyKp;
    if (paperMode.on) {
      paperBook = new PaperBook(process.env.PAPER_BOOK_FILE || path.join(ROOT, 'data', 'paper-book.json'));
      if (paperMode.reset || !paperBook.d.startedAt) {
        // fresh start: balances back to the starting amounts, no paper positions
        paperBook.reset(paperStart());
        try {
          for (const f of fs.readdirSync(path.dirname(cfg.copy.file))) if (/-paper(-[\w-]+)?\.json$/.test(f)) fs.rmSync(path.join(path.dirname(cfg.copy.file), f), { force: true });
        } catch {}
        paperMode.reset = false;
        savePaperMode();
      }
      log.info(`PAPER MODE: no real trades. Balances: ${Object.entries(paperBook.d.wallets).map(([l, w]) => `${l} ${w.sol.toFixed(3)}`).join(', ')}`);
    }
    const realTradeRpc = new Rpc(cfg.rpcUrl, cfg.isPublicRpc ? { minGapMs: 120, concurrency: 3 } : { minGapMs: 20, concurrency: 6, pool: keyPool });
    const tradeRpc = paperBook ? new PaperRpc(realTradeRpc, paperBook, 'main', kp.publicKey) : realTradeRpc;
    // V2.9.4 devs that buy at launch (instant, rug): no holder minimum (a brand-new coin has none yet)
    cfg.copy.launchBuyers = cfg.traders.filter((t) => t.isDev && (t.devMode === 'instant' || t.devMode === 'rug')).map((t) => t.name);
    const realSwapper = new Swapper({ rpc: realTradeRpc, kp, jitoUrls: cfg.copy.jitoUrls, jupBase: cfg.copy.jupBase, jupKey: cfg.copy.jupKey, portalBase: cfg.copy.portalBase, slippage: cfg.copy.slippage, priorityFee: cfg.copy.priorityFee });
    realSwapper.priorityLevel = cfg.copy.priorityLevel;
    if (cfg.copy.jupRps > 0) realSwapper.jupWindowMax = Math.max(2, Math.round(cfg.copy.jupRps * 10));
    const swapper = paperBook ? new PaperSwapper(realSwapper, paperBook, 'main', realTradeRpc, { curve: paperCurve }) : realSwapper;
    copier = new CopyTrader({
      cfg: cfg.copy,
      rpc: tradeRpc,
      kp,
      swapper,
      pump,
      coins,
      // V2.8.9: main wallet cooks say so (side wallet cooks end with · W2 / W3 / W4)
      broadcast: (html, b) => {
        const h = MAIN_COOK_RE.test(html) ? `🏦 <b>MAIN WALLET COOK</b> · ${html}` : html;
        return botNotify(paperBook ? `${h} · 🧪 paper` : h, b);
      },
      getSolPrice: () => tracker.solPrice,
      file: paperBook ? cfg.copy.file.replace(/(\.json)?$/, '-paper.json') : cfg.copy.file,
      targets: cfg.wallets,
      targetName: cfg.targetName,
      traderOf: cfg.traderOf,
    });
    // /mode <trader> off: stop copying that trader's NEW buys (coins already bought still follow his sells)
    const modeFile = process.env.TRADERS_OFF_FILE || path.join(ROOT, 'data', 'traders-off.json');
    // V2: saved as { v: 2, off: [...] }. The first V2 start turns off COPY_TRADERS_OFF (sling, who retired);
    // after that /mode decides and is remembered.
    let modeSaved = null;
    try {
      modeSaved = JSON.parse(fs.readFileSync(modeFile, 'utf8'));
    } catch {}
    const savedOff = Array.isArray(modeSaved) ? modeSaved : modeSaved?.off || [];
    for (const t of savedOff) tradersOff.add(t);
    saveModes = () => {
      try {
        fs.mkdirSync(path.dirname(modeFile), { recursive: true });
        fs.writeFileSync(modeFile, JSON.stringify({ v: 4, v5: true, v6: true, off: [...tradersOff] }));
      } catch {}
    };
    if (!modeSaved || (modeSaved.v ?? 0) < 4) {
      for (const n of cfg.copy.tradersOffDefault || []) {
        const t = cfg.traders.find((x) => x.name.toLowerCase() === n.toLowerCase());
        if (t) tradersOff.add(t.name);
      }
      saveModes();
    }
    // V2.10.1 (Khalil, Nov 12): sling is trading again and cupsey is back — both on (auto-rotate decides who's copied)
    if ((modeSaved?.v ?? 4) < 5 || !modeSaved?.v5) {
      tradersOff.delete(cfg.targetName);
      for (const t of cfg.traders) if (/^cupsey$/i.test(t.name)) tradersOff.delete(t.name);
      try {
        fs.mkdirSync(path.dirname(modeFile), { recursive: true });
        fs.writeFileSync(modeFile, JSON.stringify({ v: 4, v5: true, off: [...tradersOff] }));
      } catch {}
    }
    // V2.11.8 (Khalil, Nov 12 10:31pm): "Turn decu trades on" — once; /mode decu off still works
    if (!modeSaved?.v6) {
      for (const t of cfg.traders) if (/^decu$/i.test(t.name)) tradersOff.delete(t.name);
      saveModes();
    }
    // V2.5 wallet switches: /wallet main|W2|W3|W4 on|off, /wallets <n> (how many side wallets buy).
    // A switched-off wallet makes no new buys; coins it already holds still sell normally.
    const walletsFile = process.env.WALLETS_OFF_FILE || path.join(ROOT, 'data', 'wallets-off.json');
    try {
      for (const w of JSON.parse(fs.readFileSync(walletsFile, 'utf8'))) walletsOff.add(w);
    } catch {}
    saveWallets = () => {
      try {
        fs.mkdirSync(path.dirname(walletsFile), { recursive: true });
        fs.writeFileSync(walletsFile, JSON.stringify([...walletsOff]));
      } catch {}
    };
    // V2.9 one trader per wallet set (WALLET_TRADERS, changed with /wallettraders): a wallet only BUYS
    // for its own traders. Sells always go through, so a coin a wallet holds is still sold with him.
    const wtFile = process.env.WALLET_TRADERS_FILE || path.join(ROOT, 'data', 'wallet-traders.json');
    walletTraders = { ...(cfg.copy.walletTraders || {}) };
    try {
      walletTraders = { ...walletTraders, ...JSON.parse(fs.readFileSync(wtFile, 'utf8')) };
    } catch {}
    saveWalletTraders = () => {
      try {
        fs.mkdirSync(path.dirname(wtFile), { recursive: true });
        fs.writeFileSync(wtFile, JSON.stringify(walletTraders));
      } catch {}
    };
    const copiesFor = (label, name) => {
      const list = walletTraders[label];
      return !list || (name != null && list.some((n) => n.toLowerCase() === String(name).toLowerCase()));
    };
    // V2.9.1 hourly PnL goal (/goal 0.05): once this clock hour's closed trades (all wallets) reach it,
    // no new buys until the next hour starts. Sells keep going.
    goal = new HourlyGoal({
      file: process.env.GOAL_FILE || path.join(ROOT, 'data', 'goal.json'),
      sol: cfg.copy.hourlyGoalSol || 0,
      pnl: hourPnl,
      onRaise: ({ from, to }) => log.info(`Hourly goal raised ${from} -> ${to} SOL (last hour hit it)`),
      onHit: ({ pnl, goal: g, until }) => {
        log.info(`Hourly goal hit (+${pnl.toFixed(4)} SOL): no new buys until the next hour`);
        Promise.resolve(tracker.broadcast(`🎯 <b>Hourly goal hit</b>: +${fmtSol(pnl)} SOL (goal ${fmtSol(g)}) — no new buys until ${new Date(until).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })}. Coins still held keep selling for profit.${paperBook ? ' · 🧪 paper' : ''}`)).catch(() => {});
      },
    });
    setInterval(() => goal.reached(), 10000).unref?.();
    // V2.11.12 daily goal (DAILY_GOAL_SOL, /daygoal): today's closed trades reach it -> no new buys until midnight
    dayGoal = new DailyGoal({
      file: process.env.DAY_GOAL_FILE || path.join(ROOT, 'data', 'day-goal.json'),
      sol: cfg.copy.dailyGoalSol || 0,
      step: cfg.copy.dailyGoalStepSol || 0,
      pnl: dayPnl,
      onHit: ({ pnl, goal: g }) => {
        log.info(`Daily goal hit (+${pnl.toFixed(4)} SOL): no new buys until midnight`);
        Promise.resolve(tracker.broadcast(`🏁 <b>Daily goal hit</b>: +${fmtSol(pnl)} SOL today (goal ${fmtSol(g)}) — no new buys until midnight. Coins still held keep selling for profit.${paperBook ? ' · 🧪 paper' : ''}`)).catch(() => {});
      },
    });
    setInterval(() => dayGoal.reached(), 10000).unref?.();
    // V2.11 (#2) who bought which coin in the last few minutes (every tracked trader) + (#3) his usual size
    const stackBuys = new Map();
    const STACK_MS = 5 * 60000;
    const isCold = (n) => {
      const r = ghosts?.lastTrades(n, 30);
      return !!r && r.coins >= 10 && r.pnl < 0;
    };
    const noteBuy = (name, mint, sol) => {
      if (!name || !mint) return;
      let m = stackBuys.get(mint);
      if (!m) stackBuys.set(mint, (m = new Map()));
      if (!m.has(name)) m.set(name, Date.now());
      if (stackBuys.size > 2000) for (const k of [...stackBuys.keys()].slice(0, 500)) stackBuys.delete(k);
      ghosts?.noteSize(name, sol);
    };
    const sizeInfo = (name, mint, sol) => {
      if (!name) return {};
      let x = 1;
      let runnerHold = false;
      const why = [];
      // V2.11.2 neutral traders (auto-rotate): smaller buys, and only with room left for the hot ones
      const isDevName = cfg.traders.some((t) => t.name === name && t.isDev);
      const rot = isDevName ? devRotator : rotator;
      const tier = rot?.on ? rot.tier(name) : null;
      if (tier === 'neutral') {
        x *= cfg.copy.neutralSize;
        why.push('🟡 neutral trader');
      } else if (tier === 'proven') {
        x *= cfg.copy.provenSize;
        why.push('✅ proven trader');
      }
      if (cfg.copy.smartSize && ghosts && !isDevName) {
        const t = Date.now();
        // V2.11.16 runner chance from the wallets in this coin (once there's data); replaces the flat "2+ traders in" boost
        const rc = cfg.copy.runnerSize ? ghosts.runnerChance(mint, name) : null;
        const pc = rc ? Math.round(rc.pct * 100) : 0;
        if (rc?.forced?.length || (rc?.ready && rc.base > 0 && rc.pct >= 2 * rc.base)) {
          x *= cfg.copy.runnerBoost;
          runnerHold = !!cfg.copy.runnerHold; // V2.11.19 likely runner: every wallet holds it (25% off at 1.5x)
          why.push(`🏃 ${pc}% runner chance${rc.k > 1 ? ` (${rc.k} wallets in)` : ''}${runnerHold ? ' · holding' : ''}`);
        } else if (rc?.ready && rc.base > 0 && rc.pct <= 0.5 * rc.base) {
          x *= cfg.copy.runnerCut;
          why.push(`🐢 ${pc}% runner chance`);
        } else if (!rc?.ready) {
          const others = [...(stackBuys.get(mint)?.entries() || [])].filter(([n, at]) => n !== name && t - at < STACK_MS && !isCold(n));
          if (others.length) {
            x *= cfg.copy.stackBoost;
            why.push(`👥 ${others.length + 1} traders in`);
          }
        }
        const k = ghosts.betKind(name, sol);
        if (k === 'big') {
          x *= cfg.copy.bigBetBoost;
          why.push('💪 his big bet');
        } else if (k === 'small') {
          x *= cfg.copy.testBuyCut;
          why.push('🧪 his small test buy');
        }
      }
      x = Math.round(Math.min(2, Math.max(0.25, x)) * 100) / 100;
      return { tier, runnerHold, ...(x === 1 ? { sizeX: undefined, sizeWhy: undefined } : { sizeX: x, sizeWhy: `${why.join(' · ')} (${x}x size)` }) };
    };
    const sendAll = (sig) => {
      const buy = sig.kind === 'ENTRY' || sig.kind === 'ADD';
      const name = cfg.traderOf(sig.ev.wallet);
      if (buy && sig.kind === 'ENTRY' && sweet.on && ghosts && !sig.devReady) {
        const px = hisPrice(sig);
        const mc = px && tracker.solPrice > 0 ? px * 1e9 * tracker.solPrice : null;
        if (!ghosts.allowed(name, mc)) {
          const why = `outside ${name}'s sweet spot (${bandOf(mc)} market cap lost money in his pretend wallets)`;
          copier._skip?.(sig.ev.mint, why, { notify: false });
          return log.info(`Copy: skipped ${sig.ev.mint} — ${why}`);
        }
      }
      // V2.11 (#4) his best hours: not copied in an hour of the day where his pretend wallets lost money (8+ coins)
      if (sig.kind === 'ENTRY' && cfg.copy.bestHours && ghosts && name && !ghosts.hourAllowed(name)) {
        const why = `${name} loses money at ${hourName(new Date().getHours())} (his pretend wallets)`;
        copier._skip?.(sig.ev.mint, why, { notify: false });
        return log.info(`Copy: skipped ${sig.ev.mint} — ${why}`);
      }
      if (buy && goal.reached()) return log.info(`Hourly goal reached: not buying ${sig.ev.mint}`);
      if (buy && dayGoal?.reached()) return log.info(`Daily goal reached: not buying ${sig.ev.mint}`);
      // quick-profit wallets get the same signal a moment later, so the main wallet's buy always goes first
      for (const x of extraCopiers) if (!(buy && (walletsOff.has(x.label) || !copiesFor(x.label, name)))) setTimeout(() => x.onSignal(sig), buy && !x.isSetMain ? 400 : 0);
      if (buy && (walletsOff.has('main') || !copiesFor('main', name) || (paperBook && paperMode.mainBank))) return;
      return copier.onSignal(sig);
    };
    // V2.4 devs: "dip" and "momentum" devs are watched after launch and bought when their condition hits
    const devWatcher = new DevWatcher({
      rpc: fastRpc,
      countHolders: (m) => copier.countHolders(m),
      onReady: (sig) => sendAll(sig),
      cfg: { dipPct: cfg.copy.devDipPct, upPct: cfg.copy.devMomentumUpPct, minHolders: cfg.copy.devMomentumHolders, watchMs: cfg.copy.devWatchMs },
    });
    // V2.9.9 ghost wallets: every trader copied by pretend wallets (no SOL, no trades) to see who's worth copying
    ghosts = new GhostBook({
      file: process.env.GHOST_FILE || path.join(ROOT, 'data', 'ghosts.json'),
      fee: (cfg.copy.priorityFee || 0) + 0.000005,
      stopLossX: cfg.copy.stopLossX || 0.8,
      rulesFor: (n) => ({ ...cfg.copy, ...(cfg.copy.leaderRules?.[n] || {}) }),
      solUsd: () => tracker.solPrice || 0,
      // his own buy filters the bot would apply (cupsey: low market caps only)
      accept: (n, mc) => !(cfg.copy.traderMaxMc?.[n] > 0 && mc > cfg.copy.traderMaxMc[n]),
      runnerX: cfg.copy.runnerX || 2,
      runnerForce: cfg.copy.runnerForce || {},
    });
    // V2.9.12 sweet spot (on since V2.11.8): each trader is only copied at the market caps where his pretend
    // wallets made money (a range needs 8+ coins before it can be skipped). Off until you turn it on.
    const sweetFile = process.env.SWEET_FILE || path.join(ROOT, 'data', 'sweetspot.json');
    try {
      sweet = { on: true, ...JSON.parse(fs.readFileSync(sweetFile, 'utf8')) };
    } catch {
      sweet = { on: true };
    }
    // V2.11.8 Khalil (Nov 12 10:26pm): "Sweet spot should always b on" — on once for everyone; /sweetspot off still works
    if (!sweet.alwaysOn1112) {
      sweet.on = true;
      sweet.alwaysOn1112 = true;
      try {
        fs.mkdirSync(path.dirname(sweetFile), { recursive: true });
        fs.writeFileSync(sweetFile, JSON.stringify(sweet));
      } catch {}
    }
    saveSweet = () => {
      try {
        fs.mkdirSync(path.dirname(sweetFile), { recursive: true });
        fs.writeFileSync(sweetFile, JSON.stringify(sweet));
      } catch {}
    };
    // V2.11.5 with dozens of traders: at most 60 coins priced per pass (12 price-site calls), taking turns,
    // so the price site is never flooded (every coin still gets a price every ~15-75s)
    let ghostTurn = 0;
    const ghostPass = async () => {
      if (ghostBusy) return;
      ghostBusy = true;
      try {
        let ms = ghosts.watching();
        if (ms.length > 60) {
          const from = ghostTurn % ms.length;
          ms = [...ms, ...ms].slice(from, from + 60);
          ghostTurn = from + 60;
        }
        if (ms.length) {
          const px = await coins.pricesSol(ms, tracker.solPrice).catch(() => ({}));
          for (const m of ms) ghosts.price(m, px[m]);
        }
        ghosts.save();
      } finally {
        ghostBusy = false;
      }
    };
    let ghostBusy = false;
    setInterval(() => ghostPass().catch(() => {}), 15000).unref?.();
    process.on('exit', () => ghosts.save(true));
    // every night at 11:58pm: today's ghost results
    let ghostDay = null;
    setInterval(() => {
      const d = new Date();
      const key = d.toDateString();
      if (d.getHours() === 23 && d.getMinutes() >= 58 && ghostDay !== key) {
        ghostDay = key;
        Promise.resolve(tracker.broadcast(ghosts.report({ sinceMs: (d.getHours() * 60 + d.getMinutes()) * 60000, title: '👻 <b>Ghost wallets — today</b>' }))).catch(() => {});
      }
    }, 30000).unref?.();
    tracker.onSignal = (sig) => {
      const who = cfg.traders.find((t) => t.name === cfg.traderOf(sig.ev.wallet));
      // V2.11 (#2 + #3) buy size: bigger when another tracked trader is in the same coin or it's his big bet,
      // smaller on his small test buys. Then his buy is remembered for the next ones.
      if (sig.kind === 'ENTRY' && who && !sig.devReady) {
        Object.assign(sig.ev, sizeInfo(who.name, sig.ev.mint, sig.sol || sig.ev.solAmount));
        noteBuy(who.name, sig.ev.mint, sig.sol || sig.ev.solAmount);
        // V2.11.16 what the bot thought of this coin, to learn from when it closes
        if (ghosts) {
          const rc = ghosts.runnerChance(sig.ev.mint, who.name);
          ghosts.notePred(sig.ev.mint, rc.raw, rc.k);
        }
      }
      // V2.9.9 ghosts see every trader's buys and sells (copied or not, paused or not). Devs that wait for a dip
      // or holders aren't simulated (their buy isn't at launch).
      if (who && !retired[who.name] && !(who.isDev && (who.devMode === 'dip' || who.devMode === 'momentum')) && !sig.devReady) {
        // his price: from the pump.fun trade record, else what he paid per token (SOL spent / tokens got) —
        // that works for every coin, also the ones already on PumpSwap / Raydium (dilly, schoen ...)
        if (sig.kind === 'ENTRY') ghosts.open(who.name, sig.ev.mint, hisPrice(sig));
        else if ((sig.kind === 'PARTIAL' || sig.kind === 'EXIT') && sig.pre > 0) ghosts.hisSell(who.name, sig.ev.mint, Math.round(((sig.pre - (sig.post || 0)) / sig.pre) * 100), sig.kind === 'EXIT');
      }
      // V2.8.1 learn from every coin each wallet buys (copied or not, even while that wallet is paused)
      if (sig.kind === 'ENTRY' && who && !sig.devReady) copier.learnSeen(sig.ev.mint, who.name, sig.sol);
      // booster (decu buying into a coin we copied from bot): counts even while decu's own copying is off
      if (sig.kind === 'ENTRY' || sig.kind === 'ADD') {
        let boosted = copier.noteBooster(sig);
        for (const x of extraCopiers) boosted = x.noteBooster(sig) || boosted;
        if (boosted) return;
      }
      if ((sig.kind === 'ENTRY' || sig.kind === 'ADD') && tradersOff.has(who?.name)) return;
      if (who?.isDev && sig.kind === 'ENTRY' && !sig.devReady && (who.devMode === 'dip' || who.devMode === 'momentum')) {
        if (copier.traded.has(sig.ev.mint) || copier.positions[sig.ev.mint]) return; // already in it
        return devWatcher.watch(sig, { name: who.name, mode: who.devMode });
      }
      if (who?.isDev && sig.kind === 'ADD') return; // a dev buying more of his own coin isn't a new entry
      // V2.5 rug-dev experiment: buy only while the market cap is tiny (DEV_RUG_MAX_MC_USD)
      if (who?.isDev && who.devMode === 'rug' && sig.kind === 'ENTRY') {
        const mcOf = (px) => (px > 0 && tracker.solPrice > 0 ? px * 1e9 * tracker.solPrice : null);
        const fast = mcOf(sig.ev.priceSol);
        const go = (mc) => {
          if (mc == null) return log.info(`Rug test: ${sig.ev.mint} market cap unknown — not bought`);
          if (mc > cfg.copy.rugMaxMcUsd) return log.info(`Rug test: ${sig.ev.mint} at $${Math.round(mc)} market cap (over $${cfg.copy.rugMaxMcUsd}) — not bought`);
          sendAll({ ...sig, devReady: true });
        };
        if (fast != null) return go(fast);
        return devWatcher.priceOf(sig.ev.mint).then((px) => go(mcOf(px))).catch(() => go(null));
      }
      return sendAll(sig);
    };
    copierRef = copier;
    // V2.8 learning + suggestions (main wallet's trades; approved settings are used by the main wallet)
    if (cfg.learn?.on) {
      learner = new Learner({ file: process.env.LEARN_FILE || path.join(ROOT, 'data', 'learn.json'), minTrades: cfg.learn.minTrades });
      copier.learner = learner;
      const rulesFor = (n) => {
        const R = { ...cfg.copy, ...(cfg.copy.leaderRules?.[n] || {}), ...(copier.learned?.[n] || {}) };
        return { miniFromX: R.miniFromX, miniToX: R.miniToX, miniPullbackPct: R.miniPullbackPct, miniPct: R.miniPct, stopLossX: R.stopLossX };
      };
      suggestions = new Suggestions({
        file: process.env.SUGGEST_FILE || path.join(ROOT, 'data', 'suggestions.json'),
        learner,
        rulesFor,
        leaders: () => cfg.traders.map((t) => t.name).filter((n) => !copier.quickFor?.has(n)),
        hours: cfg.learn.hours.length ? cfg.learn.hours : [0, 6, 12, 18],
        onApplied: (a) => (copier.learned = { ...a }),
        send: (html) => tracker.broadcast(html),
      });
      suggestions.paper = !!paperBook;
      copier.learned = { ...suggestions.applied() };
      setInterval(() => suggestions.tick().catch(() => {}), 20000).unref?.();
      // a wallet's cut-off logs, trades seen after a restart... also keep the file fresh when nothing's open
      setInterval(() => learner.tick(), 60000).unref?.();
      process.on('exit', () => learner.save(true)); // restarts / updates keep what it learned
    }
    // V2.7 hibernation (/hibernate): tonight from 12:01am until the wake hour (default 8am) no new buys;
    // coins already held keep selling with all the normal rules. One night only.
    const hibFile = process.env.HIBERNATE_FILE || path.join(ROOT, 'data', 'hibernate.json');
    let hib = null;
    try {
      hib = JSON.parse(fs.readFileSync(hibFile, 'utf8'));
    } catch {}
    saveHib = (v) => {
      hib = v;
      try {
        fs.mkdirSync(path.dirname(hibFile), { recursive: true });
        fs.writeFileSync(hibFile, JSON.stringify(v));
      } catch {}
    };
    getHib = () => hib;
    const hibTick = () => {
      if (!hib) return;
      const t = Date.now();
      if (!hib.asleep && t >= hib.from && t < hib.until) {
        hib.wasPaused = copier.paused;
        hib.asleep = true;
        saveHib(hib);
        copier.setPaused(true);
        for (const x of extraCopiers) x.setPaused(true);
        tracker.broadcast(`😴 <b>Hibernating</b> until ${new Date(hib.until).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })}: no new buys. Coins it holds still sell normally.`).catch(() => {});
      } else if (t >= hib.until) {
        if (hib.asleep && !hib.wasPaused) {
          copier.setPaused(false);
          for (const x of extraCopiers) x.setPaused(false);
        }
        if (hib.asleep) tracker.broadcast('☀️ <b>Awake</b> — copying again.').catch(() => {});
        saveHib(null);
      }
    };
    setInterval(hibTick, 20000).unref?.();
    setTimeout(hibTick, 3000).unref?.();
    if (paperBook) copier.isPaper = true;
    if (paperBook && digest) digest.title = '🧪 <b>Paper trading summary</b> <i>(practice — no real trades)</i>';
    // daily recap at 11:59pm (instant message, not part of the hourly summary)
    setInterval(() => copier.checkDailyRecap((html) => tracker.broadcast(html)).catch(() => {}), 20000).unref?.();
    tracker.onMaybeEntry = (ev) => {
      const name = cfg.traderOf(ev.wallet);
      if (tradersOff.has(name)) return;
      Object.assign(ev, sizeInfo(name, ev.mint, ev.solAmount)); // same size as the real buy, so the prebuilt one is used
      if (copiesFor('main', name) && !(paperBook && paperMode.mainBank)) copier.onMaybeEntry(ev);
      for (const x of extraCopiers) if (copiesFor(x.label, name)) setTimeout(() => x.onMaybeEntry(ev), x.isSetMain ? 0 : 400);
    };
    copier.start();
    // ---- V2 quick-profit wallets: same coins as the main wallet, small fixed buy, sell 100% at +25% ----
    const setLabel = (l) => (cfg.copy.walletSets || []).some((ws) => l === ws.name || l.startsWith(`${ws.name}-W`));
    const paperLabels = paperBook ? Object.keys(paperBook.d.wallets).filter((l) => l !== 'main' && !setLabel(l)) : [];
    const sideList = paperBook
      ? paperLabels.map((label) => (cfg.copy.quickWallets || []).find((q) => q.label === label) || { label, key: null, file: '(paper)' })
      : cfg.copy.quickWallets || [];
    const startSide = (qw, set = null) => {
      let qkp;
      try {
        // paper side wallet without a key file: a throwaway keypair just to tell it apart
        qkp = qw.key ? loadKeypair(qw.key) : loadKeypair(throwawayKey());
      } catch (err) {
        log.warn(`Quick wallet ${qw.label}: key in ${path.basename(qw.file)} can't be read (${err.message}) — skipped`);
        return null;
      }
      if (qkp.publicKey === kp.publicKey || extraCopiers.some((x) => x.kp.publicKey === qkp.publicKey)) {
        log.warn(`Quick wallet ${qw.label} is the same wallet as another one — skipped`);
        return null;
      }
      const qRealSw = new Swapper({ rpc: realTradeRpc, kp: qkp, jitoUrls: cfg.copy.jitoUrls, jupBase: cfg.copy.jupBase, jupKey: cfg.copy.jupKey, portalBase: cfg.copy.portalBase, slippage: cfg.copy.slippage, priorityFee: cfg.copy.priorityFee });
      qRealSw.priorityLevel = cfg.copy.priorityLevel;
      qRealSw.jupWindowMax = realSwapper.jupWindowMax;
      qRealSw.jl = realSwapper.jl; // one shared Jupiter limit for all wallets
      const qsw = paperBook ? new PaperSwapper(qRealSw, paperBook, qw.label, realTradeRpc, { curve: paperCurve }) : qRealSw;
      const qRpc = paperBook ? new PaperRpc(realTradeRpc, paperBook, qw.label, qkp.publicKey) : realTradeRpc;
      const x = cfg.copy.quickWalletSellX;
      const qcfg = {
        ...cfg.copy,
        sizeMode: 'fixed',
        buySol: cfg.copy.quickWalletBuySol,
        devBuySol: cfg.copy.devQuickWalletBuySol,
        maxBuySol: cfg.copy.quickWalletBuySol,
        floorBuySol: 0,
        miniCook: false,
        tpLadder: [],
        tpX: 0,
        quickTpX: 0,
        quickFromX: x,
        quickToX: x,
        quickPullbackPct: 1,
        lossAlerts: false,
        sellAllAlways: true,
      };
      const label = qw.label;
      const qc = new CopyTrader({
        cfg: qcfg,
        rpc: qRpc,
        kp: qkp,
        swapper: qsw,
        pump,
        coins,
        // side wallets: no buy alerts (too many pings); their sells still alert
        // V2.8.3: nothing about buying from a side wallet at all (bought, landed late, waiting, failed, skipped, taking over)
        broadcast: (html, buttons) => (SIDE_BUY_RE.test(html) ? undefined : botNotify(`${html} · <i>${label}</i>${paperBook ? ' · 🧪 paper' : ''}`, buttons)),
        getSolPrice: () => tracker.solPrice,
        file: cfg.copy.file.replace(/(\.json)?$/, paperBook ? `-paper-${label}.json` : `-${label}.json`),
        targets: cfg.wallets,
        targetName: cfg.targetName,
        traderOf: cfg.traderOf,
      });
      qc.quickMode = true; // always: sell 100% once up 25%
      if (paperBook) qc.isPaper = true;
      qc.label = label;
      qc.set = set; // V2.9.3 null = the main set (dilly's), else its wallet set's name
      extraCopiers.push(qc);
      // V2.8.2: side wallets get back the ~0.002 SOL rent of every coin account they sold out of (was only main)
      if (cfg.copy.reclaimRent && !paperBook) {
        const rc = new RentReclaimer({
          rpc,
          swapper: qRealSw,
          owner: qkp.publicKey,
          isBusy: (m) => qc.isBusy(m),
          isOurs: (m) => qc.traded.has(m),
          notify: () => {}, // quiet: it's in the log
          minAgeMs: Math.max(0, +(process.env.RECLAIM_MIN_AGE_MS ?? 120000)),
        });
        const every = Math.max(5000, +(process.env.RECLAIM_EVERY_MS ?? 600000));
        setTimeout(() => {
          rc.run().catch(() => {});
          setInterval(() => rc.run().catch((err) => log.warn(`${label} rent reclaim failed`, err.message)), every).unref?.();
        }, Math.min(every, 150000) + extraCopiers.length * 7000).unref?.();
      }
      setInterval(() => qc.checkDailyRecap((html) => tracker.broadcast(html.replace(/Daily recap|PAPER recap/, (m) => `${m} (${label} quick wallet)`))).catch(() => {}), 20000).unref?.();
      qc.start();
      log.info(`Quick wallet ${label} LIVE (${qkp.publicKey}): ${fmtSol(qcfg.buySol)} SOL per buy, sells 100% at ${x}x`);
      return qc;
    };
    for (const qw of sideList) startSide(qw);
    // V2.11.10 paper bank: once a minute, side wallets (main set) send what they made above their starting SOL
    // to the main wallet, like a real transfer (0.000005 SOL fee); they keep trading with their starting amount
    if (paperBook && (paperMode.bank ?? paperMode.mainBank)) {
      const bankTick = () => {
        const labels = extraCopiers.filter((x) => !x.set).map((x) => x.label);
        const moved = paperBook.bankProfits(labels);
        if (moved.length) {
          for (const x of extraCopiers) if (moved.some((m) => m.label === x.label)) x.refreshBalance?.();
          copier.refreshBalance?.();
          log.info(`Paper bank: ${moved.map((m) => `${m.label} sent ${fmtSol(m.sol)} SOL`).join(', ')} to main (main now ${fmtSol(paperBook.w('main').sol)} SOL)`);
        }
      };
      setInterval(bankTick, Math.max(1000, +(process.env.PAPER_BANK_MS ?? 60000))).unref?.();
    }
    // ---- V2.9.3 more wallet sets (WALLET_SETS): each has its own main wallet + mini wallets and its own
    // traders, so they never spend each other's SOL. Its main trades like the main wallet (normal sizes and
    // sell rules), its minis like the side wallets (small buys, sell 100% at +25%).
    for (const ws of cfg.copy.walletSets || []) {
      let skp;
      try {
        skp = loadKeypair(ws.main.key);
      } catch (err) {
        log.warn(`Wallet set ${ws.name}: key in ${path.basename(ws.main.file)} can't be read (${err.message}) — skipped`);
        continue;
      }
      if (skp.publicKey === kp.publicKey || extraCopiers.some((x) => x.kp.publicKey === skp.publicKey)) {
        log.warn(`Wallet set ${ws.name}: its main wallet is the same as another wallet — skipped`);
        continue;
      }
      for (const l of [ws.name, ...ws.minis.map((m) => m.label)]) if (!(l in walletTraders)) walletTraders[l] = ws.traders;
      const sRealSw = new Swapper({ rpc: realTradeRpc, kp: skp, jitoUrls: cfg.copy.jitoUrls, jupBase: cfg.copy.jupBase, jupKey: cfg.copy.jupKey, portalBase: cfg.copy.portalBase, slippage: cfg.copy.slippage, priorityFee: cfg.copy.priorityFee });
      sRealSw.priorityLevel = cfg.copy.priorityLevel;
      sRealSw.jupWindowMax = realSwapper.jupWindowMax;
      sRealSw.jl = realSwapper.jl; // one shared Jupiter limit for all wallets
      const ssw = paperBook ? new PaperSwapper(sRealSw, paperBook, ws.name, realTradeRpc, { curve: paperCurve }) : sRealSw;
      const sRpc = paperBook ? new PaperRpc(realTradeRpc, paperBook, ws.name, skp.publicKey) : realTradeRpc;
      const NAME = ws.name.toUpperCase();
      const sc = new CopyTrader({
        cfg: cfg.copy,
        rpc: sRpc,
        kp: skp,
        swapper: ssw,
        pump,
        coins,
        broadcast: (html, b) => {
          if (SIDE_BUY_RE.test(html) && /COPY BUY FAILED|SKIPPED|WAITING/.test(html)) return undefined;
          const h = MAIN_COOK_RE.test(html) ? `🏦 <b>${NAME} WALLET COOK</b> · ${html}` : `${html} · <i>${ws.name}</i>`;
          return botNotify(paperBook ? `${h} · 🧪 paper` : h, b);
        },
        getSolPrice: () => tracker.solPrice,
        file: cfg.copy.file.replace(/(\.json)?$/, paperBook ? `-paper-${ws.name}.json` : `-${ws.name}.json`),
        targets: cfg.wallets,
        targetName: cfg.targetName,
        traderOf: cfg.traderOf,
      });
      sc.label = ws.name;
      sc.set = ws.name;
      sc.isSetMain = true;
      if (paperBook) sc.isPaper = true;
      extraCopiers.push(sc);
      setInterval(() => sc.checkDailyRecap((html) => tracker.broadcast(html.replace(/Daily recap|PAPER recap/, (m) => `${m} (${ws.name} wallet set)`))).catch(() => {}), 20000).unref?.();
      sc.start();
      log.info(`Wallet set ${ws.name} LIVE: main ${skp.publicKey}, ${ws.minis.length} mini wallet(s), copies ${ws.traders.join(', ') || 'nobody'}`);
      for (const m of ws.minis) startSide(m, ws.name);
      if (cfg.copy.reclaimRent && !paperBook) {
        const rc = new RentReclaimer({ rpc, swapper: sRealSw, owner: skp.publicKey, isBusy: (mm) => sc.isBusy(mm), isOurs: (mm) => sc.traded.has(mm), notify: () => {}, minAgeMs: Math.max(0, +(process.env.RECLAIM_MIN_AGE_MS ?? 120000)) });
        const every = Math.max(5000, +(process.env.RECLAIM_EVERY_MS ?? 600000));
        setTimeout(() => {
          rc.run().catch(() => {});
          setInterval(() => rc.run().catch(() => {}), every).unref?.();
        }, Math.min(every, 150000) + extraCopiers.length * 7000).unref?.();
      }
      // its own auto-fund + nightly refill: this set's main only ever funds this set's minis
      const minisOf = () => extraCopiers.filter((x) => x.set === ws.name && !x.isSetMain && !walletsOff.has(x.label)).map((x) => ({ label: x.label, pub: x.kp.publicKey }));
      if (cfg.copy.autoFund && ws.minis.length && !paperBook) {
        const sf = new AutoFunder({
          rpc: realTradeRpc,
          swapper: sRealSw,
          owner: skp.publicKey,
          sideWallets: minisOf,
          everySol: cfg.copy.autoFundEverySol,
          sendSol: cfg.copy.autoFundSol,
          keepSol: cfg.copy.autoFundKeepSol,
          mainSharePct: cfg.copy.autoFundMainSharePct,
          file: path.join(path.dirname(process.env.FUND_FILE || path.join(ROOT, 'data', 'auto-fund.json')), `auto-fund-${ws.name}.json`),
          notify: (html) => tracker.broadcast(`${html} · <i>${ws.name}</i>`),
          balance: () => sc.solBalance(),
        });
        setInterval(() => sf.run().catch(() => {}), 60000).unref?.();
        if (cfg.copy.autoFundRefill) {
          const minSol = cfg.copy.quickWalletBuySol + (cfg.copy.priorityFee || 0) + 0.008;
          setInterval(() => sf.refill({ minSol, refillSol: cfg.copy.autoFundRefillSol, at: cfg.copy.autoFundRefillAt, mainMinSol: cfg.copy.autoFundRefillMainMin }).catch(() => {}), 60000).unref?.();
        }
      }
    }
    // ---- V2.10 auto-rotate: the main wallet + its side wallets copy whoever is hot (pretend-wallet results,
    // last 24h); a copied trader who turns red gets a day; new wallets wait 2 days. /rotate on|off.
    const mainLabels = () => ['main', ...extraCopiers.filter((x) => !x.set).map((x) => x.label)];
    // every trader you gave is in it (sling, cupsey, t1, t2 ...); V2.11.4 devs are ranked on their own (below)
    const rotNames = () => cfg.traders.filter((t) => !t.isDev).map((t) => t.name);
    const devNames = () => cfg.traders.filter((t) => t.isDev).map((t) => t.name);
    // wallet sets that only copy devs (the devs set): their wallets copy the hot + neutral devs
    const devSets = (cfg.copy.walletSets || []).filter((ws) => ws.traders.length && ws.traders.every((n) => devNames().includes(n))).map((ws) => ws.name);
    const devLabels = () => extraCopiers.filter((x) => devSets.includes(x.set)).map((x) => x.label);
    const startList = walletTraders.main ? walletTraders.main.filter((n) => rotNames().includes(n)) : rotNames();
    rotator = new Rotator({
      file: process.env.ROTATE_FILE || path.join(ROOT, 'data', 'rotate.json'),
      recent: (n, w) => ghosts.lastTrades(n, w),
      traders: rotNames,
      minCoins: cfg.copy.rotateMinCoins || 20,
      newMs: cfg.copy.rotateNewMs ?? 48 * 3600000,
      noWaitUntil: cfg.copy.rotateNoWaitUntil || 0,
      start: startList,
      retireMs: (cfg.copy.retireColdDays || 0) * 24 * 3600000,
      always: (cfg.copy.alwaysCopy || []).filter((n) => rotNames().includes(n)),
    });
    if (cfg.copy.autoRotate === false && rotator.d.on && !rotator.d.touched) rotator.on = false;
    const devStart = [...new Set(devSets.flatMap((s) => walletTraders[s] || []))].filter((n) => devNames().includes(n));
    devRotator = new Rotator({
      file: process.env.ROTATE_DEVS_FILE || path.join(ROOT, 'data', 'rotate-devs.json'),
      recent: (n, w) => ghosts.lastTrades(n, w),
      traders: devNames,
      minCoins: cfg.copy.rotateMinCoins || 20,
      newMs: cfg.copy.rotateNewMs ?? 48 * 3600000,
      noWaitUntil: cfg.copy.rotateNoWaitUntil || 0,
      start: devStart.length ? devStart : devNames(),
      retireMs: (cfg.copy.retireColdDays || 0) * 24 * 3600000,
    });
    if (cfg.copy.autoRotate === false && devRotator.d.on && !devRotator.d.touched) devRotator.on = false;
    const applyRotation = () => {
      if (rotator.on) for (const l of mainLabels()) walletTraders[l] = rotator.copying.filter((n) => rotNames().includes(n));
      if (devRotator.on) for (const l of devLabels()) walletTraders[l] = devRotator.copying.filter((n) => devNames().includes(n));
      saveWalletTraders();
    };
    // V2.11 (#1 + #5) per trader, the way of selling his pretend wallets showed makes the most (sell before
    // him, 1.5x, 2x, ride the top...) — used by the wallets copying him once it clearly beats following him
    let exitLabels = {};
    const exitTick = (announce) => {
      if (!cfg.copy.exitPick) return;
      const main = {};
      const side = {};
      const lines = [];
      const next = {};
      for (const n of [...rotNames(), ...devNames()]) {
        const pm = ghosts.exitPick(n, 'main');
        const ps = ghosts.exitPick(n, 'side');
        if (pm.rule) main[n] = pm.rule;
        if (ps.rule) side[n] = ps.rule;
        next[n] = `${pm.rule ? pm.label : ''}|${ps.rule ? ps.label : ''}`;
        if (announce && next[n] !== (exitLabels[n] ?? '|')) {
          const pct = (p) => `${Math.round(p.rets[p.best].ret * 100)}% vs ${Math.round(p.rets[p.best].vs * 100)}%`;
          if (pm.rule) lines.push(`🎯 <b>${e(n)}</b> main wallet: ${e(pm.label)} (${pct(pm)} following him)`);
          if (ps.rule) lines.push(`🎯 <b>${e(n)}</b> side wallets: ${e(ps.label)} (${pct(ps)} with +25%)`);
          if (!pm.rule && !ps.rule) lines.push(`🎯 <b>${e(n)}</b>: back to the normal sells`);
        }
      }
      exitLabels = next;
      copier.exitPick = main;
      for (const x of extraCopiers) x.exitPick = x.isSetMain ? main : side;
      if (lines.length) log.info(`Best exits: ${lines.map((l) => l.replace(/<[^>]+>/g, '')).join(' | ')}`); // V2.11.8 quiet: shown in /ghosts
    };
    exitTick(false);
    setInterval(() => exitTick(true), 10 * 60000).unref?.();
    const keepsForProfit = (n) => (ghosts.recent(n, Number.MAX_SAFE_INTEGER)?.pnl || 0) > 0;
    const keptNoted = new Set();
    const rotateTick = () => {
      const sg = (n) => `${n >= 0 ? '+' : '-'}${fmtSol(Math.abs(n))}`;
      const nums = (x) => `last ${x.coins} trades ${sg(x.pnl)} SOL (won ${sg(x.gains)}, lost -${fmtSol(x.losses)})`;
      const one = (rot, title) => {
        if (!rot.on) return;
        const r = rot.run();
        const lines = [
          ...r.added.map((x) => `🔥 <b>${e(x.name)}</b> is hot — full size: ${nums(x)}`),
          ...(r.proven || []).map((x) => `✅ <b>${e(x.name)}</b> is proven — 3/4 size: ${nums(x)}`),
          ...r.neutral.map((x) => `🟡 <b>${e(x.name)}</b> ${x.from === 'hot' ? 'cooled down to' : 'is'} neutral — copied smaller: ${nums(x)}`),
          ...r.dropped.map((x) => `🧊 Stopped copying <b>${e(x.name)}</b> — lost more than he won: ${nums(x)}`),
        ];
        // V2.11.5 cold for a whole week: removed (no more tracking); takes effect at the next restart / update
        for (const x of r.retire) {
          if (x.name === cfg.targetName || retired[x.name]) continue;
          // V2.11.6 Khalil: a trader who made you a lot of SOL is never removed, even after a cold week
          const made = Math.max([copier, ...extraCopiers].reduce((s, c) => s + (c.lifeByLeader?.[x.name] || 0), 0), ghosts.lifePnl(x.name));
          if (cfg.copy.keepIfMadeSol > 0 && made >= cfg.copy.keepIfMadeSol) {
            if (!keptNoted.has(x.name)) log.info(`Auto-rotate: ${x.name} is cold for a week but made +${fmtSol(made)} SOL — kept`);
            keptNoted.add(x.name);
            continue;
          }
          // V2.11.6 Khalil: one that made you SOL overall (all his pretend trades) is never removed, only paused (cold)
          if (keepsForProfit(x.name)) continue;
          const t = cfg.traders.find((tt) => tt.name === x.name);
          retired[x.name] = { wallets: t?.wallets || [], at: Date.now(), pnl: x.pnl, coins: x.coins };
          saveRetired();
          lines.push(`🗑 Removed <b>${e(x.name)}</b> — cold for ${Math.round(x.coldMs / 86400000)} days: ${nums(x)}\n<code>${(t?.wallets || []).join(' ')}</code>\nSend it to Claude again if you want him back.`);
        }
        const hot = rot.copying.filter((n) => rot.tier(n) === 'hot');
        const neu = rot.copying.filter((n) => rot.tier(n) === 'neutral');
        // V2.11.8 Khalil: no message when it rotates (/ghosts shows who's copied) — only a removal is sent
        const removed = lines.filter((l) => l.startsWith('🗑'));
        if (lines.length) log.info(`${title.replace(/<[^>]+>/g, '')}: ${lines.filter((l) => !l.startsWith('🗑')).map((l) => l.replace(/<[^>]+>/g, '')).join(' | ')}`);
        if (removed.length) Promise.resolve(tracker.broadcast(`${title}${paperBook ? ' · 🧪 paper' : ''}\n${removed.join('\n')}`)).catch(() => {});
      };
      one(rotator, '🔄 <b>Auto-rotate</b>');
      if (devSets.length) one(devRotator, '🛠 <b>Auto-rotate — devs</b> (devs wallet set)');
      applyRotation();
    };
    // new traders' 2-day trial starts when they're first seen
    for (const n of rotNames()) rotator.seen(n);
    for (const n of devNames()) devRotator.seen(n);
    applyRotation();
    setInterval(rotateTick, 10 * 60000).unref?.();
    setTimeout(rotateTick, Math.max(500, +(process.env.ROTATE_FIRST_MS ?? 60000))).unref?.();
    // V2.6 auto-fund the side wallets from the main wallet as it grows
    if (cfg.copy.autoFund && extraCopiers.some((x) => !x.set) && !paperBook) {
      const funder = new AutoFunder({
        rpc: tradeRpc,
        swapper,
        owner: kp.publicKey,
        sideWallets: () => extraCopiers.filter((x) => !x.set && !walletsOff.has(x.label)).map((x) => ({ label: x.label, pub: x.kp.publicKey })),
        everySol: cfg.copy.autoFundEverySol,
        sendSol: cfg.copy.autoFundSol,
        keepSol: cfg.copy.autoFundKeepSol,
        mainSharePct: cfg.copy.autoFundMainSharePct,
        file: process.env.FUND_FILE || path.join(ROOT, 'data', 'auto-fund.json'),
        notify: (html) => tracker.broadcast(html),
        balance: () => copier.solBalance(),
      });
      setInterval(() => funder.run().catch(() => {}), 60000).unref?.();
      // V2.8.4 end-of-day refill of drained side wallets (too low for one buy)
      if (cfg.copy.autoFundRefill) {
        const minSol = cfg.copy.quickWalletBuySol + (cfg.copy.priorityFee || 0) + 0.008;
        setInterval(() => funder.refill({ minSol, refillSol: cfg.copy.autoFundRefillSol, at: cfg.copy.autoFundRefillAt, mainMinSol: cfg.copy.autoFundRefillMainMin }).catch(() => {}), 60000).unref?.();
      }
      log.info(`Auto-fund ON: every ${cfg.copy.autoFundEverySol} SOL the main wallet reaches, ${cfg.copy.autoFundSol} SOL goes to each side wallet`);
    }
    if (cfg.copy.reclaimRent && !paperBook) {
      const reclaimer = new RentReclaimer({
        rpc,
        swapper,
        owner: kp.publicKey,
        isBusy: (m) => copier.isBusy(m),
        isOurs: (m) => copier.traded.has(m),
        notify: (html) => botNotify(html),
        minAgeMs: Math.max(0, +(process.env.RECLAIM_MIN_AGE_MS ?? 120000)),
      });
      const every = Math.max(5000, +(process.env.RECLAIM_EVERY_MS ?? 600000));
      setTimeout(() => {
        reclaimer.run().catch((err) => log.warn('rent reclaim failed', err.message));
        setInterval(() => reclaimer.run().catch((err) => log.warn('rent reclaim failed', err.message)), every);
      }, Math.min(every, 120000));
    }
    log.info(`Copy trading LIVE with wallet ${kp.publicKey}: ${sizeText(cfg.copy)}, adds ${cfg.copy.copyAdds ? 'on' : 'off'}, mirror sells ${cfg.copy.mirrorSells ? 'on' : 'off'}, TP ${cfg.copy.tpPercent}% at ${cfg.copy.tpX}x${copier.paused ? ' (currently PAUSED — /resume in Telegram)' : ''}`);
  }
  const pollers = [];

  // ---------- Telegram commands ----------
  const isAllowed = (chatId) => (cfg.chatIds.length ? cfg.chatIds.includes(chatId) : state.chats.includes(chatId));

  async function statusText() {
    const lines = [`📡 <b>Tracker status — ${e(cfg.targetName)}</b>`];
    for (const w of cfg.wallets.filter((x) => !(cfg.chainOnlyWallets || []).includes(x))) {
      const u = users[w];
      lines.push(`👛 <code>${w}</code>${u ? `\n     pump.fun @${e(u.username)}${u.followers ? ` · ${fmtNum(u.followers)} followers` : ''}` : ''}`);
    }
    if (cfg.chainOnlyWallets?.length) lines.push(`👛 +${cfg.chainOnlyWallets.length} more wallets you sent (t1, t2 …), watched on the chain`);
    const s = chain.stats;
    const rpcName = cfg.rpcUrl.includes('helius') ? 'Helius' : cfg.isPublicRpc ? 'public Solana RPC' : 'custom RPC';
    lines.push(
      `${chain.connected ? '🟢' : '🔴'} On-chain stream (${rpcName}): ${chain.connected ? `connected ${fmtAgo(Date.now() - chain.connectedAt)}` : `reconnecting…${chain.lastProblem ? ` (${e(chain.lastProblem)})` : ''}`} · ${fmtNum(s.notifications)} mentions · ${s.fetched} checked · ${s.his} his txs${s.fast ? ` · ${s.fast} read straight from the stream` : ''}${s.reconnects > 3 ? ` · ${s.reconnects} reconnects` : ''}`,
    );
    const rc = chain.recentCatches;
    if (rc.length) {
      const lags = rc.map((x) => x.lagMs).sort((a, b) => a - b);
      lines.push(`⚡ Chain speed: his last ${rc.length} txs caught a median ${fmtAgo(lags[Math.floor(lags.length / 2)])} after they landed`);
    }
    for (const p of pollers) {
      const l = p.loop;
      const ok = l.lastOkAt && Date.now() - l.lastOkAt < Math.max(30000, l.intervalMs * 4);
      const via = p.via === 'positions' ? ' (via his positions — pump.fun callout list is blocking us)' : '';
      lines.push(`${ok ? '🟢' : l.lastOkAt ? '🟠' : '🔴'} ${l.name}: ${l.lastOkAt ? `ok ${fmtAgo(Date.now() - l.lastOkAt)} ago` : 'not working yet'}${via}${!ok && l.lastError ? ` (${e(l.lastError.slice(0, 80))})` : ''}`);
    }
    if (!cfg.usePumpfun) lines.push('⚪️ pump.fun: not used — everything comes from the chain (callouts off)');
    else if (!pollers.length) lines.push('🟠 pump.fun feeds: waiting for pump.fun profile lookup' + (pump.lastError ? ` (${e(pump.lastError.slice(0, 80))})` : ''));
    const top = profile.topTags(3).map((t) => `${tagText([t.tag])} ${Math.round(t.share * 100)}%`).join(', ');
    lines.push(`🧠 Meta learned from ${profile.coins.size} coins${top ? ` — ${top}` : ''}`);
    const c = tracker.counts;
    lines.push(`📬 Since start: ${c.entries} entries · ${c.adds} adds · ${c.partials} partial sells · ${c.exits} full exits · ${c.callouts} callouts · ${c.launches} launches`);
    if (copier) lines.push(`🤖 Copy trading: ${copier.paused ? '⏸ paused' : '🟢 live'} · ${copier.stats.buys} buys · ${copier.stats.sells} sells · ${Object.values(copier.positions).filter((p) => p.tokens > 0).length} open (/copy)`);
    lines.push(`⏱ Up ${fmtAgo(Date.now() - startedAt)} · v${VERSION}${SUPERVISED ? ' · auto-restart + auto-update on' : ''}`);
    return lines.join('\n');
  }

  async function checkCoin(chatId, mint) {
    const coin = await coins.get(mint, { timeoutMs: 5000 });
    if (!coin?.name) return tg.send(chatId, `Couldn't find that coin (<code>${e(mint)}</code>).`);
    const m = profile.match({ ...coin, mint });
    const holding = await tracker.holdingFor(cfg.wallets[0], mint);
    const lines = [`🔎 ${coinLine(coin, mint)}`];
    const mc = mcLine(coin);
    if (mc) lines.push(mc);
    if (holding) lines.push(holding.held ? `👜 ${e(cfg.targetName)} is holding it${holding.pnlPct != null ? ` (${holding.pnlPct.toFixed(0)}%)` : ''}` : holding.exited ? `👜 ${e(cfg.targetName)} traded it and is out` : `👜 ${e(cfg.targetName)} doesn't hold it`);
    lines.push('', ...metaBlock(m), '', `<code>${mint}</code>`);
    return tg.send(chatId, lines.join('\n'), linkButtons(mint));
  }

  async function handleMessage(msg) {
    const chatId = String(msg.chat.id);
    const text = msg.text.trim();
    const [rawCmd, ...args] = text.split(/\s+/);
    const cmd = rawCmd.split('@')[0].toLowerCase();

    if (cmd === '/id') return tg.send(chatId, `This chat's id: <code>${chatId}</code>`);
    if (cmd === '/start') {
      if (!isAllowed(chatId)) {
        if (!cfg.chatIds.length && !state.chats.length) {
          state.chats.push(chatId);
          state.saveNow();
          log.info(`Chat ${chatId} registered for alerts`);
        } else {
          return tg.send(chatId, '🔒 This tracker is private. To add this chat, put its id (send /id) in TELEGRAM_CHAT_ID in settings.txt and restart.');
        }
      }
      await tg.send(
        chatId,
        `✅ <b>You're set.</b> Alerts for <b>${e(cfg.targetName)}</b> will land in this chat:\n` +
          '🟢 new entries · ➕ adds · 🟠 partial sells · 🔴 full sell-outs · 📣 callouts · 🚀 launches\n' +
          'Every buy is tagged with its narrative and how well it matches his meta.\n\n' +
          'Commands: /status /meta /bags /recent /callouts /check &lt;CA&gt; /test /help' +
          (copier ? `\n\n🤖 <b>Copy trading is ${copier.paused ? 'PAUSED' : 'LIVE'}</b> — /copy for details, /pause to stop buying.` : ''),
      );
      return tg.send(chatId, await statusText());
    }
    if (!isAllowed(chatId)) return;

    // V2.8 /apply, /apply_bot, /skip, /skip_bot (tap them right in the suggestions message)
    const sm = /^\/(apply|skip)(?:_(.+))?$/.exec(cmd);
    if (sm) {
      if (!suggestions) return tg.send(chatId, '🧠 Learning is off (LEARN=off in settings.txt).');
      const who = sm[2] ? cfg.traders.find((t) => t.name.toLowerCase() === sm[2])?.name || sm[2] : args[0] ? cfg.traders.find((t) => t.name.toLowerCase() === String(args[0]).toLowerCase())?.name : null;
      if (sm[1] === 'apply') {
        const done = suggestions.apply(who);
        if (!done.length) return tg.send(chatId, '🧠 Nothing to apply. /suggestions to see what it learned.');
        const a = suggestions.applied();
        return tg.send(chatId, `✅ <b>Applied</b>: ${done.map((n) => `${e(n)} → sell at ${a[n].miniToX}x, dip ${a[n].miniPullbackPct}%`).join(' · ')}
Used from the next check. /suggestions reset to go back to your settings.`);
      }
      const gone = suggestions.skip(who);
      return tg.send(chatId, gone.length ? `⏭ Skipped: ${gone.map(e).join(', ')}. It keeps learning and may suggest again.` : '🧠 Nothing to skip.');
    }

    switch (cmd) {
      case '/help':
        return tg.send(
          chatId,
          [
            '<b>Commands</b>',
            '/status — is everything connected',
            "/meta — the narratives he plays (his meta)",
            '/bags — his biggest current bags',
            '/recent — last alerts',
            '/callouts — his latest pump.fun callouts and how they did',
            '/check &lt;CA&gt; — does a coin fit his meta? (or just paste a CA)',
            '/test — send a sample alert',
            '/id — show this chat id',
            '/version — bot version · /update — check for an update now',
            ...(copier
              ? ['', '<b>Copy trading</b>', '/copy — your wallet, settings and open copy positions', '/pause — stop copying new buys (sells still follow him)', '/resume — start copying again', '/sell &lt;CA&gt; [percent] — sell a copy position yourself (default 100%)', '/hold &lt;CA&gt; — only sell that coin when he sells (no take-profit / 8h) · /unhold &lt;CA&gt; to undo', '/mode — who is copied · /mode traders off|on · /mode devs off|on · /mode &lt;name&gt; off|on', '/recap — today so far (it also comes by itself at 11:59pm)', '/quick on|off — quick profit mode for every coin · /quick dilly on|off — just one trader\'s coins', '/traded — the last coins the traders bought', '/wallets — your wallets · /wallets 2 · /wallet W3 off|on · /wallet main off', '/sweetspot — the market caps each trader makes money at · /sweetspot on|off (only copy each trader in his good ranges)', '/ghosts — every trader copied by pretend wallets (main + side style): who would make you SOL · /ghosts today · /ghosts reset', '/wins [trader] — biggest winning coins (all wallets) and the market cap the bot bought at', '/goal 0.05 — hourly PnL goal: once hit, no new buys until the next hour · /goal off', '/daygoal 1 — daily goal: once today made 1 SOL, no new buys until midnight · /daygoal off', '/wallettraders — who each wallet copies · /wallettraders W2 dilly · /wallettraders main dilly+schoen · /wallettraders W3 all', '/paper on|off — paper trading (fake money, real prices) · /paper set W2 0.2 · /paper random 1 0 3 (1 SOL total, main 0, 3 side wallets; up to 10) · /paperwallet — paper balances and PnL', '/hibernate [wake hour] — sleep tonight from 12:01am (default wake 8am) · /hibernate off', '/skips — why recent buys were not copied', '/suggestions — better sell settings it learned per wallet (also sent at 6am, 12pm, 6pm, 12am) · /apply · /skip · /suggestions reset']
              : []),
          ].join('\n'),
        );
      case '/status':
        return tg.send(chatId, await statusText());
      case '/meta':
        return tg.send(chatId, metaSummary(profile, cfg.targetName));
      case '/recent': {
        const r = state.recent.slice(-15).reverse();
        return tg.send(chatId, r.length ? `<b>Last alerts</b>\n${r.map((x) => `${fmtAgo(Date.now() - x.t)} ago — ${e(x.line)}`).join('\n')}` : 'No alerts yet.');
      }
      case '/bags': {
        const bags = await loadBags(cfg.wallets[0], { maxPages: 1, maxRpcCoins: 25 }).catch(() => []);
        if (!bags.length) return tg.send(chatId, "Couldn't load his bags right now.");
        const lines = [`👜 <b>${e(cfg.targetName)}'s biggest bags</b>`];
        for (const t of bags.slice(0, 15)) {
          const m = profile.match({ name: t.name, symbol: t.symbol, mint: t.mint });
          lines.push(`${m.level === 3 ? '🔥' : m.level === 2 ? '🟢' : '▫️'} <b>$${e(t.symbol || '?')}</b> ${e(t.name || '')} — ${t.value ? fmtUsd(t.value) : 'value n/a'}`);
        }
        return tg.send(chatId, lines.join('\n'));
      }
      case '/callouts': {
        if (!cfg.usePumpfun) return tg.send(chatId, '📣 Callouts come only from pump.fun, which this bot no longer uses (USE_PUMPFUN=off in settings.txt).');
        const u = users[cfg.wallets[0]];
        if (!u) return tg.send(chatId, 'pump.fun profile not loaded yet.');
        const cp = pollers.find((p) => p instanceof CalloutPoller);
        const list = (await pump.getCallouts(u.userId, 6).catch(() => null)) || (cp?.lastList || []).slice(0, 6);
        const lines = [`📣 <b>${e(cfg.targetName)}'s latest callouts</b>`];
        for (const c of list) {
          const coin = await coins.get(c.coinMint, { fresh: false, timeoutMs: 2000 });
          lines.push(`• <b>$${e(coin?.symbol || shortAddr(c.coinMint))}</b> ${fmtAgo(Date.now() - c.createdAt)} ago @ ${fmtUsd(c.marketCap)} → now ${(+c.multiple || 0).toFixed(2)}x · peak ${(+c.maxMultiplier || 0).toFixed(1)}x`);
        }
        return tg.send(chatId, list.length ? lines.join('\n') : "Couldn't load callouts right now.");
      }
      case '/version':
        return tg.send(chatId, `🏷 Version <b>v${e(VERSION)}</b>${SUPERVISED ? '\n♻️ Auto-restart and auto-update are on (checks every 10 min). /update to check now.' : '\n⚠️ Started without the watchdog — use “2 - Start Bot” or “Auto-start ON” from the latest package for auto-restart and auto-update.'}`);
      case '/update':
        if (!SUPERVISED) return tg.send(chatId, '⚠️ Auto-update needs the watchdog: start the bot with “2 - Start Bot” or “Auto-start ON” from the latest package.');
        try {
          fs.mkdirSync(path.join(ROOT, 'data'), { recursive: true });
          fs.writeFileSync(path.join(ROOT, 'data', 'update-now'), String(Date.now()));
        } catch {}
        return tg.send(chatId, '🔎 Checking for an update… if there is one it gets tested on your Mac first (about a minute), then the bot restarts on it.');
      case '/copy':
        if (!copier) return tg.send(chatId, '🤖 Copy trading is off. Run "3 - Copy Trade Setup" to turn it on.');
        return tg.send(chatId, (await copier.statusText()).replace('\n', `\n👥 Copying: ${cfg.traders.map((t) => `${e(t.name)} ${tradersOff.has(t.name) ? '⏸' : '🟢'}`).join(' · ')}\n`));
      case '/quick': {
        // /quick on|off -> quick profit mode: sell 100% of every coin between +25% and +75%
        if (!copier) return tg.send(chatId, '🤖 Copy trading is off.');
        const v = String(args[0] || '').toLowerCase();
        // /quick <trader> on|off: quick profit only for that trader's coins (e.g. /quick dilly on)
        const qt = cfg.traders.find((x) => x.name.toLowerCase() === v);
        if (qt) {
          const on2 = String(args[1] || '').toLowerCase();
          if (on2 === 'on') copier.quickFor.add(qt.name);
          else if (on2 === 'off') copier.quickFor.delete(qt.name);
          copier.save();
          return tg.send(chatId, `⚡ Quick profit for <b>${e(qt.name)}</b>'s coins: <b>${copier.quickFor.has(qt.name) ? 'ON' : 'OFF'}</b> (sell 100% at +${Math.round((cfg.copy.quickFromX - 1) * 100)}% to +${Math.round((cfg.copy.quickToX - 1) * 100)}%). /quick ${e(qt.name)} ${copier.quickFor.has(qt.name) ? 'off' : 'on'}`);
        }
        if (v === 'on' || v === 'off') {
          copier.quickMode = v === 'on';
          copier.save();
        }
        const c = cfg.copy;
        return tg.send(chatId, copier.quickMode
          ? `⚡ <b>Quick profit mode: ON</b>\nEvery coin sells <b>100%</b> once it's up ${Math.round((c.quickFromX - 1) * 100)}%: on the first ${c.quickPullbackPct}% dip, or at +${Math.round((c.quickToX - 1) * 100)}% at the latest. Profit is checked with a real quote first.\n/quick off to go back to normal.`
          : `⚡ Quick profit mode: <b>OFF</b> (normal sells: mini cook + take-profit ladder).\n/quick on to sell everything at +${Math.round((c.quickFromX - 1) * 100)}% to +${Math.round((c.quickToX - 1) * 100)}%.`);
      }
      case '/traded':
        if (!digest) return tg.send(chatId, 'Turn on QUIET_MODE to keep the list of traders\' buys.');
        return tg.send(chatId, digest.tradedText());
      case '/paperwallet':
      case '/pw':
        args.length = 0;
      // falls through: /paperwallet = /paper (wallet view)
      case '/paper': {
        // /paper on|off · /paper set W2 0.2 (starting amount, used at the next /paper on) · /paper
        const v = String(args[0] || '').toLowerCase();
        if (v === 'random') {
          // /paper random [total] [main]: side wallets get random amounts each start, total stays the same
          paperMode.random = { total: +args[1] > 0 ? +args[1] : 1, main: +args[2] >= 0 && args[2] != null ? +args[2] : 0, sides: Math.max(1, Math.min(10, Math.round(+args[3] || paperMode.random?.sides || 3))) };
          paperMode.mainBank = paperMode.random.main === 0; // no SOL in main: main is the bank, it doesn't buy
          savePaperMode();
          return tg.send(chatId, `🧪 Paper starts: main ${paperMode.random.main} SOL, ${paperMode.random.sides} side wallets random, ${paperMode.random.total} SOL in total (next /paper on)`);
        }
        if (v === 'set' && args[1] && +args[2] >= 0) {
          paperMode.random = null; // your own amounts from now on (/paper random to go back)
          paperMode.start = { ...(paperMode.start || {}), [args[1] === 'main' ? 'main' : String(args[1]).toUpperCase()]: +args[2] };
          savePaperMode();
          return tg.send(chatId, `🧪 Paper starting amounts: ${Object.entries(paperStart()).map(([l, s2]) => `${e(l)} ${s2} SOL`).join(' · ')} (used every time you turn paper on)`);
        }
        if (v === 'on' || v === 'off') {
          if ((v === 'on') === !!paperMode.on && v === 'off') return tg.send(chatId, '🧪 Paper mode is already off.');
          paperMode.on = v === 'on';
          paperMode.reset = v === 'on'; // every /paper on starts again from the starting amounts
          savePaperMode();
          await tg.send(chatId, v === 'on' ? `🧪 <b>Paper mode ON</b> — no real trades. Starting from ${Object.entries(paperStart()).map(([l, s2]) => `${e(l)} ${s2} SOL`).join(' · ')}. Restarting the bot…` : '💰 <b>Paper mode OFF</b> — back to REAL trading. Restarting the bot…').catch(() => {});
          setTimeout(() => process.exit(75), 1500);
          return;
        }
        if (!paperBook) return tg.send(chatId, `🧪 Paper mode is <b>OFF</b> (real trading). /paper on to practise with ${Object.entries(paperStart()).map(([l, s2]) => `${e(l)} ${s2}`).join(' · ')} SOL · /paper set W2 0.2`);
        // paper wallets: SOL, value of the coins held (real prices), and profit/loss vs the starting amount
        const all = [copier, ...extraCopiers];
        const rows = [];
        let totNow = 0;
        let totStart = 0;
        for (const [l, w] of Object.entries(paperBook.d.wallets)) {
          const c = all.find((x) => (x.label || 'main') === l);
          let coinVal = 0;
          for (const [m, t] of Object.entries(w.tokens)) coinVal += (await withTimeout(c ? c.valueSol(m, t.ui) : Promise.resolve(null), 2500, null).catch(() => null)) || 0;
          const now = w.sol + coinVal;
          const start = paperBook.d.start?.[l] ?? 0;
          totNow += now;
          totStart += start;
          const pnl = now - start;
          rows.push(`${pnl >= 0 ? '🟢' : '🔴'} <b>${e(l)}</b>: ${w.sol.toFixed(3)} SOL${Object.keys(w.tokens).length ? ` + ${Object.keys(w.tokens).length} coin(s) ~${coinVal.toFixed(3)}` : ''} · ${pnl >= 0 ? '+' : ''}${pnl.toFixed(3)} SOL`);
        }
        const tp = totNow - totStart;
        return tg.send(chatId, [`🧪 <b>Paper wallets</b> (since ${fmtAgo(Date.now() - paperBook.d.startedAt)} ago)`, ...rows, '', `${tp >= 0 ? '💰' : '📉'} Total: <b>${totNow.toFixed(3)} SOL</b> (started ${totStart.toFixed(3)}) · PnL <b>${tp >= 0 ? '+' : ''}${tp.toFixed(3)} SOL</b>`, '', '/paper off · /recap'].join('\n'));
      }
      case '/sweetspot':
      case '/sweet': {
        // /sweetspot — each trader's market-cap ranges · /sweetspot on|off
        if (!ghosts) return tg.send(chatId, '🤖 Copy trading is off.');
        const a0 = String(args[0] || '').toLowerCase();
        if (a0 === 'on' || a0 === 'off') {
          sweet.on = a0 === 'on';
          saveSweet();
        }
        const names = cfg.traders.map((t) => t.name);
        return tg.send(chatId, `${ghosts.sweetSpotText(names)}\n\nSweet spot is <b>${sweet.on ? 'ON' : 'OFF'}</b>${sweet.on ? ': buys in a ⛔ range are skipped' : ' — /sweetspot on to only copy each trader in his ✅ / ⏳ ranges'}`);
      }
      case '/ghosts':
      case '/ghost': {
        // /ghosts — every trader copied by pretend wallets · /ghosts today · /ghosts reset
        if (!ghosts) return tg.send(chatId, '🤖 Copy trading is off.');
        const a0 = String(args[0] || '').toLowerCase();
        if (a0 === 'reset') {
          ghosts.reset();
          return tg.send(chatId, '👻 Ghost wallets reset — every trader starts from zero now.');
        }
        if (a0 === 'today') {
          const d = new Date();
          return tg.send(chatId, ghosts.report({ sinceMs: (d.getHours() * 60 + d.getMinutes()) * 60000 + 60000, title: '👻 <b>Ghost wallets — today</b>' }));
        }
        // V2.11.14 short by default (Khalil: "just send traders"); /ghosts full = every detail
        if (a0 === 'full') return tg.send(chatId, ghosts.report() + (rotator?.on ? `\n\n${rotator.statusText()}` : '') + (devRotator?.on && devRotator.traders().length ? `\n\n🛠 <b>Devs</b>\n${devRotator.statusText()}` : ''));
        if (!rotator?.on) return tg.send(chatId, ghosts.report());
        const devs = devRotator?.traders().length ? `\n🛠 Devs copied: ${e(devRotator.copying.join(', ') || 'none')}` : '';
        // V2.11.16 🏃 = share of his coins that ran 2x+ after he bought (5+ coins)
        const run = (n) => {
          const s = ghosts.runnerStats(n);
          return s.coins >= 5 ? ` 🏃${Math.round((100 * s.runners) / s.coins)}%` : '';
        };
        return tg.send(chatId, `${rotator.compactText(undefined, run)}${devs}\n🔥 full size · ✅ 3/4 · 🟡 half · 🧊 not copied · 🏃 his coins that ran ${cfg.copy.runnerX || 2}x+ · /ghosts full`);
      }
      case '/wins': {
        // /wins [trader] — the coins that made the most (all wallets) + the market caps we bought at
        if (!copier) return tg.send(chatId, '🤖 Copy trading is off.');
        const who = args[0] ? cfg.traders.find((t) => t.name.toLowerCase() === String(args[0]).toLowerCase())?.name || String(args[0]) : null;
        const trips = [copier, ...extraCopiers].flatMap((c) => (c.tripLog || []).map((t) => ({ ...t, wallet: c.label || 'main' })));
        return tg.send(chatId, (paperBook ? '🧪 <i>paper</i>\n' : '') + copier.winsText({ leader: who, trips }));
      }
      case '/daygoal':
      case '/dailygoal': {
        // /daygoal · /daygoal 1 · /daygoal off
        if (!dayGoal) return tg.send(chatId, 'Copy trading is off.');
        const a = String(args[0] || '').toLowerCase();
        if (a === 'off' || a === '0') dayGoal.set(0);
        else if (+a > 0) dayGoal.set(+a, args[1] != null ? +args[1] : undefined);
        if (!(dayGoal.sol > 0)) return tg.send(chatId, '🏁 No daily goal. /daygoal 1 sets one (SOL per day, all wallets).');
        return tg.send(chatId, `${dayGoal.line()[0]}\nOnce today's closed trades reach it, no new buys until midnight (coins held still sell). It grows ${fmtSol(dayGoal.d.step || 0)} SOL every day. /daygoal 1 0.5 (start, daily step) · /daygoal off`);
      }
      case '/goal': {
        // /goal 0.05 -> hourly goal · /goal off
        if (!copier) return tg.send(chatId, '🤖 Copy trading is off.');
        const a0 = String(args[0] || '').toLowerCase();
        if (a0 === 'off' || a0 === '0') {
          goal.set(0);
          return tg.send(chatId, '🎯 Hourly goal off — the bot buys all hour.');
        }
        if (a0) {
          const v = parseFloat(a0);
          if (!(v > 0) || v > 1000) return tg.send(chatId, 'Usage: /goal 0.05 (SOL per hour) · /goal off');
          goal.set(v);
        }
        if (!(goal.base > 0)) return tg.send(chatId, '🎯 No hourly goal set. /goal 0.05 sets one (SOL per hour, all wallets).');
        const p = goal.hourPnl();
        const hit = goal.reached();
        const up = goal.sol > goal.base + 1e-9 ? ` (raised from your ${fmtSol(goal.base)})` : '';
        return tg.send(chatId, `🎯 <b>Hourly goal: ${fmtSol(goal.sol)} SOL</b>${up} (all wallets, closed trades)\nThis hour: ${p >= 0 ? '+' : '-'}${fmtSol(Math.abs(p))} SOL${hit ? ' — <b>hit</b>: no new buys until the next hour (coins held still sell for profit)' : ''}\nAn hour that hits it raises the next hour's goal (never lower); midnight goes back to ${fmtSol(goal.base)}.\n/goal off to stop`);
      }
      case '/hibernate':
      case '/hibernation': {
        // /hibernate [wake hour, default 8] · /hibernate off · /hibernate status
        if (!copier) return tg.send(chatId, '🤖 Copy trading is off.');
        const v = String(args[0] || '').toLowerCase();
        const cur = getHib();
        if (v === 'off' || v === 'cancel') {
          if (cur?.asleep && !cur.wasPaused) {
            copier.setPaused(false);
            for (const x of extraCopiers) x.setPaused(false);
          }
          saveHib(null);
          return tg.send(chatId, '☀️ Hibernation cancelled — copying as normal.');
        }
        if (v === 'status' || (!v && cur)) {
          if (!cur) return tg.send(chatId, '😴 No hibernation planned. /hibernate to sleep tonight from 12:01am.');
          const f2 = (ms) => new Date(ms).toLocaleString('en-US', { weekday: 'short', hour: 'numeric', minute: '2-digit' });
          return tg.send(chatId, `😴 Hibernation ${cur.asleep ? 'ON now' : 'planned'}: ${f2(cur.from)} → ${f2(cur.until)}. /hibernate off to cancel.`);
        }
        const wake = Math.min(23, Math.max(1, Math.round(+v || 8)));
        const now = new Date();
        const from = new Date(now);
        from.setHours(0, 1, 0, 0);
        if (from.getTime() <= now.getTime()) from.setDate(from.getDate() + 1); // tonight's 12:01am
        const until = new Date(from);
        until.setHours(wake, 0, 0, 0);
        saveHib({ from: from.getTime(), until: until.getTime(), asleep: false });
        return tg.send(chatId, `😴 <b>Hibernation set</b>: the bot sleeps tonight at 12:01am and wakes at ${wake > 12 ? wake - 12 : wake}:00${wake >= 12 ? 'pm' : 'am'}. No new buys while asleep; coins it holds still sell. Just this one night. /hibernate off to cancel.`);
      }
      case '/suggestions':
      case '/suggest': {
        if (!suggestions) return tg.send(chatId, '🧠 Learning is off (LEARN=off in settings.txt).');
        if (String(args[0] || '').toLowerCase() === 'reset') {
          suggestions.reset();
          return tg.send(chatId, '🧠 Learned settings cleared — back to your own settings. It keeps learning.');
        }
        suggestions.refresh();
        const a = suggestions.applied();
        const using = Object.keys(a).length ? `\n\n✅ In use now: ${Object.entries(a).map(([n, r]) => `${e(n)} ${r.miniToX}x / ${r.miniPullbackPct}%`).join(' · ')}` : '';
        return tg.send(chatId, suggestions.text() + using);
      }
      case '/skips': {
        // why recent buys were NOT copied
        if (!copier) return tg.send(chatId, '🤖 Copy trading is off.');
        const list = (copier.skips || []).slice(-15).reverse();
        if (!list.length) return tg.send(chatId, '⏭ No skipped buys since the bot started.');
        const rows = [];
        for (const s2 of list) rows.push(`• ${fmtAgo(Date.now() - s2.at)} ago <b>${e(s2.sym || (await copier._sym(s2.mint).catch(() => s2.mint.slice(0, 6))))}</b>: ${e(s2.why)}`);
        return tg.send(chatId, ['⏭ <b>Last skipped buys</b> (main wallet)', ...rows].join('\n'));
      }
      case '/wallettraders':
      case '/wt': {
        // /wallettraders                 -> who each wallet copies
        // /wallettraders W2 dilly         -> W2 copies only dilly   (dilly+schoen for two, all for everyone)
        if (!copier) return tg.send(chatId, '🤖 Copy trading is off.');
        const labels = ['main', ...extraCopiers.map((x) => x.label)];
        const a0 = String(args[0] || '');
        if (a0) {
          const l = labels.find((x) => x.toLowerCase() === a0.toLowerCase());
          const list = String(args.slice(1).join(' ') || '').split(/[\s,+/|]+/).filter(Boolean);
          if (!l || !list.length) return tg.send(chatId, `Usage: /wallettraders W2 dilly · /wallettraders main dilly+schoen · /wallettraders W3 all\nWallets: ${labels.join(', ')}`);
          const known = cfg.traders.map((t) => t.name);
          const bad = list.filter((n) => n.toLowerCase() !== 'all' && !known.some((k) => k.toLowerCase() === n.toLowerCase()));
          if (bad.length) return tg.send(chatId, `❓ Unknown trader: ${bad.map(e).join(', ')}\nTraders: ${known.map(e).join(', ')}`);
          walletTraders[l] = list.some((n) => n.toLowerCase() === 'all') ? null : list.map((n) => known.find((k) => k.toLowerCase() === n.toLowerCase()));
          saveWalletTraders();
        }
        const rows = labels.map((l) => `${walletsOff.has(l) ? '⏸' : '🟢'} <b>${e(l)}</b> copies: ${walletTraders[l] ? walletTraders[l].map(e).join(', ') : 'everyone'}`);
        const used = new Set(labels.flatMap((l) => walletTraders[l] || cfg.traders.map((t) => t.name)));
        const idle = cfg.traders.map((t) => t.name).filter((n) => !used.has(n));
        return tg.send(chatId, [`👛 <b>Who each wallet copies</b>`, ...rows, idle.length ? `\n📋 Tracked, not copied: ${idle.map(e).join(', ')}` : '', '\n/wallettraders W2 dilly · main dilly+schoen · W3 all'].filter(Boolean).join('\n'));
      }
      case '/wallet':
      case '/wallets': {
        // /wallets            -> list
        // /wallets 2          -> buy with the first 2 side wallets (0 = none)
        // /wallet W3 off|on   -> one wallet;  /wallet main off -> side wallets only
        if (!copier) return tg.send(chatId, '🤖 Copy trading is off.');
        const labels = extraCopiers.map((x) => x.label);
        const a0 = String(args[0] || '').toLowerCase();
        const v = String(args[1] || '').toLowerCase();
        if (/^\d+$/.test(a0)) {
          // /wallets 2: the main set's side wallets only (other wallet sets keep their own switches)
          const own = extraCopiers.filter((x) => !x.set).map((x) => x.label);
          const n = Math.min(own.length, +a0);
          own.forEach((l, i) => (i < n ? walletsOff.delete(l) : walletsOff.add(l)));
          saveWallets();
        } else if (a0 && (v === 'on' || v === 'off')) {
          const l = a0 === 'main' ? 'main' : labels.find((x) => x.toLowerCase() === a0);
          if (!l) return tg.send(chatId, `Wallets: main${labels.length ? ', ' + labels.join(', ') : ''}`);
          if (v === 'off') walletsOff.add(l);
          else walletsOff.delete(l);
          saveWallets();
        } else if (a0) return tg.send(chatId, 'Usage: /wallets · /wallets 2 · /wallet W3 off|on · /wallet main off|on');
        const bal = async (c) => {
          const s2 = await c.solBalance().catch(() => null);
          return s2 != null ? fmtSol(s2) + ' SOL' : '?';
        };
        const rows = [`${walletsOff.has('main') ? '⏸' : '🟢'} main · ${await bal(copier)}`];
        for (const x of extraCopiers) rows.push(`${walletsOff.has(x.label) ? '⏸' : '🟢'} ${x.label} (${x.isSetMain ? `${x.set} set main` : x.set ? `${x.set} set mini` : 'quick'}) · ${await bal(x)}`);
        if (!extraCopiers.length) rows.push('(no side wallets: add wallet-key-2.txt … in the bot folder)');
        return tg.send(chatId, ['👛 <b>Wallets</b>', ...rows, '', '/wallets 2 · /wallet W3 off|on · /wallet main off (side wallets only)'].join('\n'));
      }
      case '/recap':
        if (!copier) return tg.send(chatId, '🤖 Copy trading is off.');
        return tg.send(chatId, await copier.dailyRecapText());
      case '/mode': {
        // /mode                     -> who is being copied
        // /mode <name> off|on       -> stop / start copying one trader or dev
        // /mode traders off|on      -> all traders at once;  /mode devs off|on -> all devs at once
        const a0 = String(args[0] || '').toLowerCase();
        const v = String(args[1] || '').toLowerCase();
        const group = a0 === 'traders' ? cfg.traders.filter((x) => !x.isDev) : a0 === 'devs' ? cfg.traders.filter((x) => x.isDev) : null;
        const one = cfg.traders.find((x) => x.name.toLowerCase() === a0);
        const targets = group || (one ? [one] : null);
        if (targets && (v === 'on' || v === 'off')) {
          for (const t of targets) {
            if (v === 'off') tradersOff.add(t.name);
            else tradersOff.delete(t.name);
          }
          saveModes();
        } else if (a0) return tg.send(chatId, `Usage: /mode traders on|off · /mode devs on|off · /mode &lt;name&gt; on|off\nNames: ${cfg.traders.map((x) => e(x.name)).join(', ')}`);
        const row = (x) => `${tradersOff.has(x.name) ? '⏸' : '🟢'} ${e(x.name)}`;
        const tr = cfg.traders.filter((x) => !x.isDev);
        const dv = cfg.traders.filter((x) => x.isDev);
        return tg.send(chatId, [`👥 <b>Traders</b>: ${tr.map(row).join(' · ') || 'none'}`, `👨‍💻 <b>Devs</b>: ${dv.map(row).join(' · ') || 'none'}`, '', '/mode traders off|on · /mode devs off|on · /mode &lt;name&gt; off|on'].join('\n'));
      }
      case '/pause':
        if (!copier) return tg.send(chatId, '🤖 Copy trading is off.');
        copier.setPaused(true);
        for (const x of extraCopiers) x.setPaused(true);
        return tg.send(chatId, '⏸ <b>Copy trading paused.</b> No new buys. Coins you already hold still sell when he sells (and at take profit). /resume to start again.');
      case '/resume':
        if (!copier) return tg.send(chatId, '🤖 Copy trading is off.');
        copier.setPaused(false);
        for (const x of extraCopiers) x.setPaused(false);
        return tg.send(chatId, `▶️ <b>Copy trading is live again.</b> Next buy of his gets copied: ${sizeText(cfg.copy)}.`);
      case '/hold':
      case '/unhold': {
        if (!copier) return tg.send(chatId, '🤖 Copy trading is off.');
        if (!isAddress(args[0])) return tg.send(chatId, `Usage: ${cmd} &lt;coin address&gt;`);
        const keep = cmd === '/hold';
        if (!copier.setKeep(args[0], keep)) {
          // in the wallet but not taken over yet (e.g. bought by hand): take it over now
          copier.adoptChecked?.delete(args[0]);
          await copier.adoptStrays().catch(() => {});
          if (!copier.setKeep(args[0], keep)) return tg.send(chatId, "The bot doesn't hold that coin (or he doesn't hold it, so there's nothing to follow).");
        }
        return tg.send(chatId, keep ? `🔒 Holding <code>${e(args[0])}</code> until ${e(copier.positions[args[0]]?.leader || cfg.targetName)} sells — no take-profit, no dying-coin sells, no ${cfg.copy.maxHoldHours}h limit. It sells the same % he sells. /unhold to undo.` : `⏰ The ${cfg.copy.maxHoldHours}h auto-sell is back on for <code>${e(args[0])}</code>.`);
      }
      case '/sell': {
        if (!copier) return tg.send(chatId, '🤖 Copy trading is off.');
        if (!isAddress(args[0])) return tg.send(chatId, 'Usage: /sell &lt;coin address&gt; [percent]   e.g. /sell 7xKX…pump 50');
        const pct = args[1] ? Math.round(+String(args[1]).replace('%', '')) : 100;
        if (!(pct >= 1 && pct <= 100)) return tg.send(chatId, 'Percent must be 1–100.');
        const bal = await copier.tokenBalance(args[0]).catch(() => null);
        if (bal === 0) return tg.send(chatId, "Your wallet doesn't hold that coin.");
        await tg.send(chatId, `⏳ Selling ${pct}% of <code>${e(args[0])}</code>…`);
        copier.manualSell(args[0], pct);
        return;
      }
      case '/check':
        if (!isAddress(args[0])) return tg.send(chatId, 'Usage: /check &lt;coin address&gt;');
        return checkCoin(chatId, args[0]);
      case '/test': {
        const html =
          `🧪 <b>TEST ALERT</b> (this is what a buy alert looks like)\n\n🟢 <b>${e(cfg.targetName.toUpperCase())} NEW ENTRY</b> <b>$BTC</b> — Big Titty Coin\n💰 Bought <b>2.50 SOL</b>\n` +
          metaBlock(profile.match({ name: 'Big Titty Coin', symbol: 'BTC', mint: 'test' })).join('\n');
        return tg.send(chatId, html);
      }
      default:
        if (isAddress(cmd) || isAddress(text)) return checkCoin(chatId, isAddress(cmd) ? rawCmd : text);
    }
  }

  // ---------- Sources ----------
  const chain = new ChainWatcher({ wsUrl: cfg.wsUrl, wsUrlFn: keyPool ? () => keyPool.wsUrl() : null, rpc, wallets: cfg.wallets, commitment: cfg.chainCommitment });
  chain.on('trade', (ev) => tracker.handleTrade(ev));
  chain.on('launch', (l) => {
    tracker.handleLaunch(l).catch((err) => log.error('launch alert failed', err.message));
    // a tracked dev launched WITHOUT buying his own coin: no trade comes in, so start the copy from the launch
    const who = cfg.traders.find((t) => t.isDev && t.wallets.includes(l.wallet));
    if (who && !l.devBuy && tracker.onSignal) {
      tracker.onSignal({ ev: { mint: l.mint, wallet: l.wallet, sig: l.sig, time: l.time || Date.now(), side: 'BUY', key: `${l.sig}:${l.mint}`, detectedAt: Date.now(), source: 'chain' }, kind: 'ENTRY', pre: 0, post: 0, sol: 0 });
    }
  });
  chain.start();
  tg.poll(handleMessage);
  log.info(`RPC: ${redact(cfg.rpcUrl)}${cfg.isPublicRpc ? ' (public — add a free Helius key in settings.txt for faster, more reliable alerts)' : ''}`);

  // coins to check for callouts if pump.fun's callout list is unavailable: newest activity first, then biggest bags
  const watchMints = () =>
    Object.entries(state.positions)
      .filter(([, p]) => p.ui > 0 || Date.now() - (p.lastAt || 0) < 6 * 3600000)
      .sort((a, b) => (b[1].lastAt || 0) - (a[1].lastAt || 0) || (b[1].valueUsd || 0) - (a[1].valueUsd || 0))
      .map(([m]) => m);

  const startPollersFor = (wallet, u) => {
    // one trades/callout feed per pump.fun account, one launch feed per wallet
    if (!pollers.some((p) => p.userId === u.userId && p instanceof PumpTradesPoller)) {
      const tp = new PumpTradesPoller({ pump, state, userId: u.userId, wallet, intervalMs: cfg.tradesPollMs });
      tp.on('trade', (ev) => tracker.handleTrade(ev));
      tp.on('solPrice', (p) => {
        if (!tracker.solPrice) tracker.solPrice = p;
      });
      const cp = new CalloutPoller({ pump, state, userId: u.userId, wallet, intervalMs: cfg.calloutPollMs, listEveryMs: cfg.calloutListMs, watchMints });
      cp.on('callout', (c, w) => tracker.handleCallout(c, w).catch((err) => log.error('callout alert failed', err.message)));
      cp.on('calloutUpdate', (c, w, txt) => tracker.handleCallout(c, w, { isUpdate: true, updateText: txt }).catch((err) => log.error('update alert failed', err.message)));
      pollers.push(tp, cp);
      tp.start();
      cp.start();
    }
    const lp = new LaunchPoller({ pump, state, wallet, intervalMs: cfg.launchPollMs });
    lp.on('launch', (l) => tracker.handleLaunch(l).catch((err) => log.error('launch alert failed', err.message)));
    pollers.push(lp);
    lp.start();
  };

  // V2.11.4 the wallets you sent (t1, t2 ...) are watched on the chain only: no pump.fun lookups or feeds for them
  const pumpWallets = cfg.wallets.filter((w) => !(cfg.chainOnlyWallets || []).includes(w));
  const resolveUsers = async () => {
    for (const w of pumpWallets) {
      if (users[w]) continue;
      try {
        const u = await pump.getUser(w);
        if (!u?.userId) throw new Error('no pump.fun profile for this wallet');
        users[w] = { userId: u.userId, username: u.username || shortAddr(w), followers: u.followers };
        state.callers[w] = users[w];
        log.info(`pump.fun profile: @${users[w].username} (${fmtNum(u.followers || 0)} followers)`);
        startPollersFor(w, users[w]);
      } catch (err) {
        if (!err.cloudflare) log.warn(`pump.fun profile lookup for ${shortAddr(w)} failed: ${err.message} — retrying in 60s`);
      }
    }
    if (pumpWallets.some((w) => !users[w])) setTimeout(resolveUsers, 60000);
  };
  if (cfg.usePumpfun) await resolveUsers();
  else log.info('pump.fun not used: trades, launches and coin info come from the chain, DexScreener and Helius (callouts off)');

  // ---------- His bags ----------
  // pump.fun's bag list (profile-api) is behind Cloudflare and sometimes blocks home connections
  // ("Just a moment..."). Then his bags are read straight from the chain instead.
  let bagsBlockedLogged = false;
  async function loadBags(wallet, { maxPages = 25, maxRpcCoins = 60 } = {}) {
    const out = [];
    try {
      for (let page = 1; page <= maxPages; page++) {
        const { tokens, totalPages } = await pump.getHoldings(wallet, page, 20);
        for (const t of tokens) out.push({ mint: t.token_mint, name: t.token_name, symbol: t.token_symbol, image: t.token_image, balance: +t.balance || 0, value: +t.value || 0 });
        if (page >= totalPages) break;
      }
      return out;
    } catch (err) {
      if (out.length) return out;
      if (!bagsBlockedLogged && !err.disabled) {
        bagsBlockedLogged = true;
        log.info(`pump.fun bag list unavailable (${/403|Just a moment/i.test(err.message) ? 'blocked by Cloudflare' : err.message.slice(0, 60)}); reading his bags from the chain instead`);
      }
    }
    const accts = [];
    for (const programId of ['TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA', 'TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb']) {
      const r = await rpc.call('getTokenAccountsByOwner', [wallet, { programId }, { encoding: 'jsonParsed', commitment: 'confirmed' }]).catch(() => null);
      for (const a of r?.value || []) {
        const info = a.account?.data?.parsed?.info;
        const ui = +info?.tokenAmount?.uiAmount || 0;
        if (info?.mint && ui > 0) accts.push({ mint: info.mint, balance: ui });
      }
    }
    const QUOTES = new Set(['EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v', 'Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB', 'So11111111111111111111111111111111111111112', 'USD1ttGY1N17NEEHLmELoaybftRBUSErhqYiQzvEmuB']);
    // biggest balances first (pump coins all have 1B supply, so balance is a fair first guess at size)
    const pick = accts.filter((a) => !QUOTES.has(a.mint)).sort((a, b) => b.balance - a.balance).slice(0, maxRpcCoins);
    let i = 0;
    await Promise.all(
      Array.from({ length: 4 }, async () => {
        while (i < pick.length) {
          const a = pick[i++];
          const c = await coins.get(a.mint, { fresh: false, timeoutMs: 5000 }).catch(() => null);
          if (!c?.name) continue;
          out.push({ mint: a.mint, name: c.name, symbol: c.symbol, image: c.image, balance: a.balance, value: c.mc ? (a.balance * c.mc) / 1e9 : 0 });
        }
      }),
    );
    return out.sort((a, b) => b.value - a.value);
  }

  // ---------- Learn his meta ----------
  const learnMeta = async () => {
    // Build from scratch each time so old data doesn't pile up, then swap it in.
    const next = new MetaProfile({ selfWords: cfg.selfWords });
    for (const w of cfg.wallets) {
      // 1) current bags, weighted by size
      try {
        for (const t of await loadBags(w)) {
          next.add({ mint: t.mint, name: t.name, symbol: t.symbol, valueUsd: t.value }, 1 + Math.log10(1 + t.value / 1000), 'bag');
          coins.remember(t.mint, { name: t.name, symbol: t.symbol, image: t.image });
          const p = tracker.pos(t.mint);
          if (!p.tracked) p.ui = t.balance; // starting bag sizes
          p.valueUsd = t.value;
        }
      } catch (err) {
        log.warn('Could not load his bags:', err.message);
      }
      if (!cfg.usePumpfun) continue;
      // 2) coins he launched
      try {
        const { coins: created } = await pump.getCreatedCoins(w, 100, 0);
        for (const c of created) next.add({ mint: c.mint, name: c.name, symbol: c.symbol, twitter: c.twitter, nsfw: c.nsfw }, 1, 'launch');
      } catch {}
      const u = users[w];
      if (!u) continue;
      // 3) coins from his recent trades
      try {
        const { coins: tc } = await pump.getUserTrades(u.userId, 100);
        for (const c of Object.values(tc)) {
          next.add({ mint: c.mint, name: c.name, symbol: c.symbol }, 0.5, 'trade');
          coins.remember(c.mint, { name: c.name, symbol: c.symbol });
        }
      } catch {}
      // 4) his callouts (needs a name lookup per coin)
      try {
        const cp = pollers.find((p) => p instanceof CalloutPoller);
        const calls = (await pump.getCallouts(u.userId, 100).catch(() => null)) || cp?.lastList || [];
        for (const c of calls) {
          const coin = await coins.get(c.coinMint, { fresh: false, timeoutMs: 4000 });
          if (coin?.name) next.add({ mint: c.coinMint, name: coin.name, symbol: coin.symbol, twitter: coin.twitter, nsfw: coin.nsfw }, 1, 'callout');
        }
      } catch {}
    }
    if (next.coins.size) {
      // keep coins learned live since the last rebuild
      for (const [mint, c] of profile.coins) if (!next.coins.has(mint)) next.coins.set(mint, c);
      profile.coins = next.coins;
      profile._recount();
    }
    tracker.prunePositions();
    state.save();
    const top = profile.topTags(4).map((t) => `${t.tag} ${Math.round(t.share * 100)}%`).join(', ');
    log.info(`Meta learned from ${profile.coins.size} coins: ${top}`);
  };
  learnMeta().catch((err) => log.warn('meta learning failed', err.message));
  setInterval(() => learnMeta().catch(() => {}), 6 * 3600 * 1000);

  // ---------- SOL price ----------
  const refreshSol = async () => {
    const p = await pump.getSolPrice().catch(() => null);
    if (p) tracker.solPrice = p;
  };
  refreshSol();
  setInterval(refreshSol, 60000);

  // ---------- Startup notice + health ----------
  // (quiet mode: no 'online' ping on every restart/update; the hourly summary shows the bot is alive)
  for (const chatId of digest ? [] : tracker.chats()) {
    tg.send(chatId, `✅ <b>Tracker online</b> (v${e(VERSION)}) — watching ${cfg.traders.map((t) => `<b>${e(t.name)}</b> (${t.wallets.map((w) => `<code>${shortAddr(w)}</code>`).join(', ')})`).join(' + ')}. Send /status anytime.${copier ? `\n🤖 Copy trading <b>${copier.paused ? 'PAUSED' : 'LIVE'}</b>: ${sizeText(cfg.copy)}, wallet <code>${shortAddr(copier.kp.publicKey)}</code> — /copy` : ''}`).catch(() => {});
  }
  if (!tracker.chats().length) log.info('No Telegram chat yet: open your bot in Telegram and send /start');

  // ---------- Watchdog heartbeat + messages from the supervisor ----------
  const dataDir = path.join(ROOT, 'data');
  const beat = () => {
    try {
      fs.mkdirSync(dataDir, { recursive: true });
      const f = path.join(dataDir, 'heartbeat.json');
      fs.writeFileSync(f + '.tmp', JSON.stringify({ at: Date.now(), pid: process.pid, version: VERSION, chain: chain.connected }));
      fs.renameSync(f + '.tmp', f);
    } catch {}
  };
  // Missed time: the Mac slept or the bot was off. Trades in that window can't be copied, so say so.
  const aliveFile = path.join(dataDir, 'last-alive.json');
  const hhmm = (t) => new Date(t).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
  const warnGap = (from, to, why) => {
    if (to - from < 120000) return;
    const mins = Math.round((to - from) / 60000);
    log.warn(`Missed ${mins} min (${why}): ${new Date(from).toISOString()} -> ${new Date(to).toISOString()}`);
    const text = `⚠️ <b>The bot was ${why} for ${mins >= 120 ? `${Math.round(mins / 60)}h` : `${mins} min`}</b> (${hhmm(from)} → ${hhmm(to)}). ${e(cfg.targetName)}'s trades in that time were <b>not</b> copied.${/asleep/.test(why) ? '\nKeep the Mac plugged in and the lid open while the bot runs.' : ''}`;
    for (const chatId of tracker.chats()) tg.send(chatId, text).catch(() => {});
  };
  try {
    const prev = JSON.parse(fs.readFileSync(aliveFile, 'utf8'));
    if (prev?.at) warnGap(prev.at, startedAt, 'off (or the Mac was asleep)');
  } catch {}
  let lastTick = Date.now();
  setInterval(() => {
    const now = Date.now();
    if (now - lastTick > 90000) warnGap(lastTick, now, 'asleep with the Mac'); // timers stop while the Mac sleeps
    lastTick = now;
    try {
      fs.writeFileSync(aliveFile, JSON.stringify({ at: now }));
    } catch {}
  }, 10000);
  beat();
  setInterval(beat, 20000);
  const deliverNotices = () => {
    const f = path.join(dataDir, 'notices.json');
    let list = [];
    try {
      list = JSON.parse(fs.readFileSync(f, 'utf8'));
      fs.rmSync(f, { force: true });
    } catch {
      return;
    }
    for (const n of list.slice(-10)) {
      if (digest) digest.note(n.text.replace(/\n+/g, ' — '));
      else for (const chatId of tracker.chats()) tg.send(chatId, n.text).catch(() => {});
    }
  };
  deliverNotices();
  setInterval(deliverNotices, 15000);

  let chainDownSince = 0;
  setInterval(() => {
    const s = chain.stats;
    log.info(
      `alive · chain ${chain.connected ? 'up' : 'DOWN'} (${s.notifications} mentions, ${s.fetched} checked, ${s.his} his)${cfg.usePumpfun ? ` · pump ${pump.ok} ok/${pump.fail} err` : ''} · rpc ${rpc.ok} ok/${rpc.fail} err`,
    );
    // The chain stream is what matters (pump.fun isn't used). If it has been down for 10 minutes,
    // a fresh start usually fixes a stuck socket/DNS. No Telegram message for this.
    if (chain.connected) chainDownSince = 0;
    else if (!chainDownSince) chainDownSince = Date.now();
    if (chainDownSince && Date.now() - chainDownSince > 600000 && Date.now() - startedAt > 600000) {
      log.warn('Chain stream down for 10+ minutes; restarting the bot');
      try {
        state.saveNow();
        copier?.save();
      } catch {}
      process.exit(1);
    }
  }, 60000);

  const shutdown = () => {
    log.info('Shutting down…');
    state.saveNow();
    chain.stop();
    copier?.stop();
    copier?.save();
    tg.stop();
    pollers.forEach((p) => p.stop());
    process.exit(0);
  };
  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
}

let stateRef = null;
process.on('unhandledRejection', (err) => log.error('Unhandled:', err?.stack || err));
process.on('uncaughtException', (err) => {
  log.error('Crashed:', err?.stack || err);
  try {
    stateRef?.saveNow(); // so nothing gets alerted twice after the automatic restart
  } catch {}
  process.exit(1);
});
main().catch((err) => {
  log.error('Fatal:', err.stack || err.message);
  process.exit(1);
});
