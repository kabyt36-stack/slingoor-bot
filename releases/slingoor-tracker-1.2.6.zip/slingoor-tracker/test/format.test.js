import test from 'node:test';
import assert from 'node:assert/strict';
import { tradeMessage, calloutMessage, launchMessage, metaSummary, linkButtons, metaBlock } from '../src/format.js';
import { MetaProfile } from '../src/narrative.js';
import { checkTelegramHtml, checkButtons } from './tg-html.js';
import { realCoins } from './helpers.js';

const nasty = { name: 'Tits & <Ass> "Coin" 🍈', symbol: 'T&A<>', mc: 12345, isPump: true, complete: false, ageMs: 5000 };
const MINT = '5zNrC96R7vwWD6bfbTeUBseFztQY4Pr1iSgwoj7mpump';

const profile = new MetaProfile();
let i = 0;
for (const [s, n, v] of realCoins().holdings) profile.add({ mint: 'H' + i++, name: n, symbol: s, valueUsd: v }, 2, 'bag');
profile.add({ mint: 'X1', name: 'Evil <b>name</b> & co', symbol: '<i>', valueUsd: 1 }, 1, 'bag');

const ok = (html, what) => assert.deepEqual(checkTelegramHtml(html), [], `${what}:\n${html}`);

test('every trade alert kind is valid Telegram HTML, even with hostile coin names', () => {
  for (const kind of ['ENTRY', 'ADD', 'PARTIAL', 'EXIT', 'MOVED']) {
    for (const coin of [nasty, null, { name: null, symbol: null }]) {
      const g = {
        kind,
        side: kind === 'ENTRY' || kind === 'ADD' ? 'BUY' : 'SELL',
        mint: MINT,
        wallet: 'W',
        coin,
        count: 3,
        sol: 1.5,
        usd: 0,
        tokens: 1e6,
        firstTime: 1,
        lastTime: 5000,
        lagMs: 900,
        source: 'chain',
        pctSold: 40,
        pctLeft: 60,
        postUi: 10,
        trip: { in: 1, out: 2, pnl: 1, pct: 100, heldMs: 60000 },
        pnl: { usd: 455, pct: 242 },
        meta: profile.match({ ...nasty, mint: MINT }),
      };
      ok(tradeMessage(g, { name: 'sling<oor>&', solPrice: 96, multiWallet: true }), `${kind}`);
    }
  }
});

test('callout, callout update, launch and /meta messages are valid Telegram HTML', () => {
  const c = { calloutId: 'abc', coinMint: MINT, marketCap: 35411, thesis: 'buy <now> & "hold" ' + 'x'.repeat(2000), multiple: 1.2, maxMultiplier: 3 };
  const meta = profile.match({ ...nasty, mint: MINT });
  for (const holding of [null, { held: true, costUsd: 100, pnlPct: 50 }, { held: false, exited: true }, { held: false }]) {
    ok(calloutMessage(c, { name: 'slingoor', coin: nasty, meta, holding }), 'callout');
  }
  ok(calloutMessage(c, { name: 'slingoor', coin: nasty, meta, isUpdate: true, updateText: '<script> & stuff' }), 'update');
  ok(launchMessage({ mint: MINT, devBuy: { solAmount: 2 } }, { name: 'slingoor', coin: nasty, meta, solPrice: 96 }), 'launch');
  ok(metaSummary(profile, 'slin<g>'), 'meta summary');
  ok(metaBlock(meta).join('\n'), 'meta block');
});

test('buttons are valid', () => {
  assert.deepEqual(checkButtons({ inline_keyboard: linkButtons(MINT, { sig: 'abc', calloutId: 'c1' }) }), []);
});

test('the checker itself catches broken HTML', () => {
  assert.ok(checkTelegramHtml('a & b').length);
  assert.ok(checkTelegramHtml('<b>x').length);
  assert.ok(checkTelegramHtml('<div>x</div>').length);
  assert.ok(checkTelegramHtml('1 < 2').length);
  assert.deepEqual(checkTelegramHtml('<b>ok</b> &amp; <code>x</code>'), []);
});
