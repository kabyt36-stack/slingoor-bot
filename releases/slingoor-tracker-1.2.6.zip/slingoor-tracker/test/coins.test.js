// Coin name lookups when pump.fun and DexScreener don't know the coin: Helius getAsset.
import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import { Coins } from '../src/coins.js';

test('coins: falls back to Helius getAsset for a brand-new coin, keeps a curve market cap hint', async () => {
  const calls = [];
  const srv = http.createServer(async (req, res) => {
    let body = '';
    for await (const c of req) body += c;
    calls.push(req.url);
    res.setHeader('content-type', 'application/json');
    if (req.url.startsWith('/dex/')) return res.end(JSON.stringify({ pairs: [] }));
    const r = JSON.parse(body);
    assert.equal(r.method, 'getAsset');
    res.end(JSON.stringify({ jsonrpc: '2.0', id: r.id, result: { content: { metadata: { name: 'Fresh Coin', symbol: 'FRSH' }, links: { image: 'https://img/x.png' } }, token_info: { supply: 1e15, decimals: 6 } } }));
  });
  await new Promise((r) => srv.listen(0, '127.0.0.1', r));
  const base = `http://127.0.0.1:${srv.address().port}`;
  try {
    const pump = { getCoin: async () => { const e = new Error('HTTP 403 Just a moment'); e.status = 403; throw e; } };
    const coins = new Coins({ pump, dexApi: `${base}/dex`, rpcUrl: 'https://mainnet.helius-rpc.com/?api-key=x' });
    coins.dasUrl = `${base}/rpc`; // point the Helius lookup at the local server
    const c = await coins.get('Fresh1111111111111111111111111111111111pump', { hint: { mc: 7500, mcAt: Date.now() } });
    assert.equal(c.name, 'Fresh Coin');
    assert.equal(c.symbol, 'FRSH');
    assert.equal(c.image, 'https://img/x.png');
    assert.equal(c.mc, 7500, 'curve market cap from his trade is kept');
    assert.ok(calls.some((u) => u === '/rpc'));
    // not a Helius RPC -> no getAsset calls
    const c2 = new Coins({ pump, dexApi: `${base}/dex`, rpcUrl: 'https://api.mainnet-beta.solana.com' });
    assert.equal(c2.dasUrl, '');
  } finally {
    srv.close();
  }
});
