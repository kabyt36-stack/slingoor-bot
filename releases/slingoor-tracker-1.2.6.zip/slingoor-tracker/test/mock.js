// Reusable mock world for failure tests: pump.fun API, Solana RPC + websocket, Telegram Bot API,
// plus a helper to run the real bot.js as a child process against it.
import http from 'node:http';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';

export const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
export const W = '5YRgrP3mjGzrzirYYN5HAQH19cTYREYwGxW6XRJQUzij';
export const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
export const iso = (t) => new Date(t).toISOString();

export async function startWorld(WS_LIB) {
  const { WebSocketServer } = await import(WS_LIB);
  const now = Date.now();
  const M = {
    callouts: [],
    trades: [],
    tradeCoins: [],
    positions: {},
    coins: {},
    created: [],
    holdings: [],
    balances: {},
    txs: {},
    rpcCalls: [],
    pumpCalls: [],
    // fault switches
    fail: { calloutList: 0, trades: 0, rpcTx: 0, tg: null },
  };
  const TG = { sent: [], edits: [], updates: [], nextId: 1, updateId: 1, failNext: [] };
  const WS = { sock: null, subs: {}, subscribeCount: 0 };

  const server = http.createServer(async (req, res) => {
    const url = new URL(req.url, 'http://x');
    let body = '';
    for await (const chunk of req) body += chunk;
    const json = (o, status = 200) => {
      res.writeHead(status, { 'content-type': 'application/json' });
      res.end(JSON.stringify(o));
    };
    const p = url.pathname;
    if (p.startsWith('/tg/bot')) {
      const method = p.split('/').pop();
      const params = body ? JSON.parse(body) : {};
      if (method === 'getMe') return json({ ok: true, result: { id: 1, username: 'test_bot' } });
      if (method === 'sendMessage' || method === 'editMessageText') {
        const f = TG.failNext.shift();
        if (f) return json(f.body, f.status);
        if (method === 'sendMessage') {
          const id = TG.nextId++;
          TG.sent.push({ ...params, message_id: id, at: Date.now() });
          return json({ ok: true, result: { message_id: id } });
        }
        TG.edits.push(params);
        return json({ ok: true, result: true });
      }
      if (method === 'getUpdates') {
        for (let i = 0; i < 10 && !TG.updates.length; i++) await sleep(100);
        return json({ ok: true, result: TG.updates.splice(0) });
      }
      return json({ ok: false, description: 'unknown' }, 404);
    }
    if (p.startsWith('/pump/') || p.startsWith('/profile/')) M.pumpCalls.push(p);
    if ((p.startsWith('/pump/') || p.startsWith('/profile/')) && M.fail.cloudflare) {
      res.writeHead(403, { 'content-type': 'text/html' });
      return res.end('<!DOCTYPE html><html lang="en-US"><head><title>Just a moment...</title></head></html>');
    }
    if (p === `/pump/users/${W}`) return json({ address: W, userId: 'U1', username: 'slingoor', followers: 205538 });
    if (p === '/pump/callout/list/U1') {
      if (M.fail.calloutList) return json({ message: 'Too Many Requests' }, M.fail.calloutList);
      return json({ callouts: [...M.callouts].sort((a, b) => b.createdAt - a.createdAt), nextPageToken: '' });
    }
    let m;
    if ((m = /^\/pump\/callout\/([^/]+)\/replies$/.exec(p))) return json({ replies: [] });
    if (p === '/pump/user-trades/U1') {
      if (M.fail.trades) return json({ message: 'down' }, M.fail.trades);
      return json({ trades: [...M.trades].sort((a, b) => Date.parse(b.timestamp) - Date.parse(a.timestamp)).slice(0, 20), coins: M.tradeCoins, nextCursor: null });
    }
    if (p === `/pump/user-positions/${W}`) {
      const mints = (url.searchParams.get('mints') || '').split(',');
      return json({ positions: mints.flatMap((x) => M.positions[x] || []) });
    }
    if (p === `/pump/coins-v2/user-created-coins/${W}`) return json({ count: M.created.length, coins: M.created });
    if ((m = /^\/pump\/coins-v2\/(\w+)$/.exec(p))) return M.coins[m[1]] ? json(M.coins[m[1]]) : json({ statusCode: 404 }, 404);
    if (p === '/pump/sol-price') return json({ solPrice: 96 });
    if (p === `/profile/balance/tokens/${W}` && M.fail.profile) {
      res.writeHead(403, { 'content-type': 'text/html' });
      return res.end('<!DOCTYPE html><html lang="en-US"><head><title>Just a moment...</title></head></html>');
    }
    if (p === `/profile/balance/tokens/${W}`) return json({ data: { tokens: M.holdings }, pagination: { totalPages: 1 } });
    if (p.startsWith('/dex/')) {
      const mint = p.split('/').pop();
      if (mint === 'So11111111111111111111111111111111111111112') return json({ pairs: [{ baseToken: { address: mint, symbol: 'SOL' }, quoteToken: { symbol: 'USDC' }, priceUsd: '150', liquidity: { usd: 1e7 } }] });
      const c = (M.dexCoins || {})[mint];
      return json({ pairs: c ? [{ baseToken: { address: mint, name: c.name, symbol: c.symbol }, marketCap: c.mc, liquidity: { usd: 1000 } }] : [] });
    }
    if (p === '/jito') {
      const r = JSON.parse(body);
      (M.jitoSends ||= []).push({ tx: r.params?.[0], at: Date.now() });
      if (M.jitoDown) return json({ jsonrpc: '2.0', id: r.id, error: { code: -32000, message: 'down' } }, 500);
      return json({ jsonrpc: '2.0', id: r.id, result: 'jito-ok' });
    }
    if (p.startsWith('/jup/')) {
      if (!M.jup) return json({ error: 'no jupiter' }, 500);
      const out = await M.jup(p.slice(4), Object.fromEntries(url.searchParams), body ? JSON.parse(body) : null);
      return json(out.body, out.status || 200);
    }
    if (p === '/portal/trade-local') {
      if (!M.portal) return json({ error: 'no portal' }, 500);
      const out = await M.portal(JSON.parse(body));
      if (out.status && out.status !== 200) {
        res.writeHead(out.status, { 'content-type': 'text/plain' });
        return res.end(out.text || 'error');
      }
      res.writeHead(200, { 'content-type': 'application/octet-stream' });
      return res.end(Buffer.from(out.bytes));
    }
    if (p === '/rpc') {
      const r = JSON.parse(body);
      M.rpcCalls.push(r);
      if (M.rpcHook) {
        const out = await M.rpcHook(r);
        if (out !== undefined) return json({ jsonrpc: '2.0', id: r.id, result: out });
      }
      if (r.method === 'getTransaction') {
        if (M.fail.rpcTx) return json({ jsonrpc: '2.0', id: r.id, error: { code: 429, message: 'Too many requests' } }, 429);
        return json({ jsonrpc: '2.0', id: r.id, result: M.txs[r.params[0]] || null });
      }
      if (r.method === 'getTokenAccountsByOwner' && r.params[1]?.programId) {
        // all his token accounts for one token program
        const t22 = r.params[1].programId === 'TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb';
        if (!t22 && !r.params[1].programId.startsWith('Tokenkeg')) return json({ jsonrpc: '2.0', id: r.id, error: { code: -32602, message: 'Invalid param: unrecognized Token program id' } });
        const value = Object.entries(M.balances)
          .filter(([mint]) => !!(M.token2022 || []).includes(mint) === t22)
          .map(([mint, ui]) => ({ pubkey: `Acct${mint.slice(0, 8)}`, account: { data: { parsed: { info: { mint, tokenAmount: { amount: String(Math.round(ui * 1e6)), decimals: 6, uiAmount: ui, uiAmountString: String(ui) } } } } } }));
        return json({ jsonrpc: '2.0', id: r.id, result: { value } });
      }
      if (r.method === 'getTokenAccountsByOwner') {
        const own = M.ownerBalances?.[r.params[0]];
        const ui = own ? own[r.params[1].mint] : M.balances[r.params[1].mint];
        const value = ui == null ? [] : [{ pubkey: `Acct${r.params[1].mint.slice(0, 8)}`, account: { data: { parsed: { info: { tokenAmount: { amount: String(Math.round(ui * 1e6)), decimals: 6, uiAmountString: String(ui) } } } } } }];
        return json({ jsonrpc: '2.0', id: r.id, result: { value } });
      }
      return json({ jsonrpc: '2.0', id: r.id, result: null });
    }
    json({ error: 'not found' }, 404);
  });
  const wss = new WebSocketServer({ server, path: '/ws' });
  wss.on('connection', (sock) => {
    WS.sock = sock;
    sock.on('message', (raw) => {
      const r = JSON.parse(String(raw));
      if (r.method === 'accountSubscribe' || r.method === 'logsSubscribe') {
        WS.subscribeCount++;
        const id = (r.method === 'accountSubscribe' ? 100 : 200) + WS.subscribeCount;
        WS.subs[r.method] = id;
        if (r.method === 'accountSubscribe') (WS.accountSubs ||= {})[r.params[0]] = id;
        sock.send(JSON.stringify({ jsonrpc: '2.0', id: r.id, result: id }));
      } else sock.send(JSON.stringify({ jsonrpc: '2.0', id: r.id, error: { code: -32602, message: 'Invalid subscription id' } }));
    });
  });
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  const port = server.address().port;
  const base = `http://127.0.0.1:${port}`;

  const world = {
    M,
    TG,
    WS,
    now,
    tmp: fs.mkdtempSync(path.join(os.tmpdir(), 'tracker-f-')),
    tgPush(text, chatId = 111) {
      TG.updates.push({ update_id: TG.updateId++, message: { message_id: 1, date: Math.floor(Date.now() / 1000), chat: { id: chatId, type: 'private' }, text } });
    },
    notifyLogs(sig, slot, logs) {
      WS.sock.send(JSON.stringify({ jsonrpc: '2.0', method: 'logsNotification', params: { subscription: WS.subs.logsSubscribe, result: { context: { slot }, value: { signature: sig, err: null, logs } } } }));
    },
    notifyAccount(slot, account = W) {
      WS.sock.send(JSON.stringify({ jsonrpc: '2.0', method: 'accountNotification', params: { subscription: (WS.accountSubs || {})[account] ?? WS.subs.accountSubscribe, result: { context: { slot }, value: { lamports: 1 } } } }));
    },
    addTrade(t) {
      M.trades.push({ walletAddress: W, kind: 'trade', priceUsd: 0, timestamp: iso(Date.now()), ...t });
    },
    sent: (re) => TG.sent.filter((s) => re.test(s.text)),
    bot: null,
    out: '',
    startBot(extraEnv = {}) {
      const settings = path.join(world.tmp, 'settings.txt');
      if (!fs.existsSync(settings)) fs.writeFileSync(settings, 'TELEGRAM_BOT_TOKEN=123:abc\nTARGET_NAME=slingoor\n');
      const env = {
        ...process.env,
        SETTINGS_FILE: settings,
        PUMP_API_BASE: `${base}/pump`,
        PROFILE_API_BASE: `${base}/profile`,
        TELEGRAM_API_BASE: `${base}/tg`,
        DEX_API_BASE: `${base}/dex`,
        PUMPPORTAL_API_BASE: `${base}/portal`,
        JUPITER_API_BASE: `${base}/jup`,
        JITO_URLS: `${base}/jito`,
        COPY_FILE: path.join(world.tmp, 'copytrade.json'),
        RPC_URL: `${base}/rpc`,
        WS_URL: `ws://127.0.0.1:${port}/ws`,
        STATE_FILE: path.join(world.tmp, 'state.json'),
        LOG_FILE: path.join(world.tmp, 'bot.log'),
        PUMP_TRADES_POLL_SECONDS: '1',
        CALLOUT_POLL_SECONDS: '2',
        CALLOUT_LIST_SECONDS: '2',
        LAUNCH_POLL_SECONDS: '5',
        MERGE_WINDOW_SECONDS: '4',
        USE_PUMPFUN: 'on', // most tests exercise the pump.fun feeds too; the chain-only mode has its own test
        ...extraEnv,
      };
      const supervised = env.SUPERVISE === '1';
      if (supervised) Object.assign(env, { AUTO_UPDATE: 'off', UPDATE_URL: 'http://127.0.0.1:1/x/y/update.json', SUP_TICK_MS: '200', SUP_RESTART_MIN_MS: '200' });
      world.bot = spawn(process.execPath, [supervised ? 'scripts/supervisor.js' : 'bot.js'], { cwd: ROOT, env });
      world.bot.stdout.on('data', (d) => (world.out += d));
      world.bot.stderr.on('data', (d) => (world.out += d));
      return world.bot;
    },
    async stopBot(signal = 'SIGTERM') {
      if (!world.bot) return;
      const b = world.bot;
      if (b.exitCode !== null || b.signalCode !== null) {
        world.bot = null; // already gone (e.g. it crashed)
        return;
      }
      const done = new Promise((r) => b.on('exit', r));
      b.kill(signal);
      await done;
      world.bot = null;
    },
    async waitFor(what, fn, ms = 15000) {
      const t0 = Date.now();
      while (Date.now() - t0 < ms) {
        const v = fn();
        if (v) return v;
        await sleep(100);
      }
      throw new Error(`Timed out waiting for: ${what}\n--- bot output ---\n${world.out.slice(-2500)}`);
    },
    async close() {
      await world.stopBot();
      wss.close();
      server.close();
    },
  };
  return world;
}
