// Tracker logic with fake Telegram / pump.fun / RPC: entry vs add, re-entry after a full exit,
// burst merging, and the stale-PnL guard.
import test from 'node:test';
import assert from 'node:assert/strict';
import { Tracker } from '../src/tracker.js';
import { MetaProfile } from '../src/narrative.js';
import { BoundedSet } from '../src/util.js';

function setup({ balances = {}, positions = {} } = {}) {
  const sent = [];
  const edits = [];
  let id = 1;
  const tg = {
    send: async (chatId, text) => (sent.push({ chatId, text, id }), id++),
    edit: async (chatId, msgId, text) => edits.push({ msgId, text }),
  };
  const state = { chats: ['1'], seenTrades: new BoundedSet(100), positions: {}, recent: [], createdMints: new BoundedSet(100), save() {}, pushRecent() {} };
  const cfg = { chatIds: [], targetName: 'slingoor', wallets: ['W'], mergeWindowMs: 20000, minAlertSol: 0, metaOnlyEntries: false,
    alerts: { entry: true, add: true, partial: true, exit: true, transfer: true, callout: true, calloutUpdate: true, launch: true } };
  const pump = { getPositions: async (w, m) => positions[m[0]] || [] };
  const rpc = { getTokenBalance: async (w, m) => ({ ui: balances[m] ?? 0 }) };
  const coins = { get: async (m) => ({ name: 'Big Titty Coin', symbol: 'BTC', mc: 1000 }) };
  const t = new Tracker({ cfg, state, tg, pump, rpc, coins, profile: new MetaProfile() });
  return { t, sent, edits, state };
}
const ev = (o) => ({ key: Math.random().toString(36), sig: 's' + Math.random(), wallet: 'W', mint: 'M', time: Date.now(), source: 'chain', amountUi: 100, solAmount: 1, ...o });

test('entry, merged adds, exit, then a quick re-entry is a NEW alert', async () => {
  const { t, sent, edits } = setup();
  await t.handleTrade(ev({ side: 'BUY', preUi: 0, postUi: 100 }));
  await t.handleTrade(ev({ side: 'BUY', preUi: 100, postUi: 200 }));
  await t.handleTrade(ev({ side: 'BUY', preUi: 200, postUi: 300 }));
  assert.equal(sent.length, 1);
  assert.match(sent[0].text, /NEW ENTRY/);
  assert.match(edits.at(-1).text, /3 buys/);
  await t.handleTrade(ev({ side: 'SELL', preUi: 300, postUi: 0, solAmount: 5, amountUi: 300 }));
  assert.match(sent[1].text, /FULLY SOLD OUT/);
  assert.match(sent[1].text, /in 3\.00 SOL → out 5\.00 SOL = <b>\+2\.00 SOL<\/b>/);
  await t.handleTrade(ev({ side: 'BUY', preUi: 0, postUi: 50 }));
  assert.equal(sent.length, 3);
  assert.match(sent[2].text, /NEW ENTRY/);
});

test('feed-only buy of a coin he already holds (not in our records) is an ADD, checked on-chain', async () => {
  const { t, sent } = setup({ balances: { M: 1100 } });
  await t.handleTrade(ev({ side: 'BUY', preUi: null, postUi: null, source: 'pump', amountUi: 100 }));
  assert.match(sent[0].text, /ADDED MORE/);
});

test('feed-only sell: remaining bag read on-chain decides partial vs full exit', async () => {
  const a = setup({ balances: { M: 40 } });
  a.state.positions.M = { ui: 100 };
  await a.t.handleTrade(ev({ side: 'SELL', preUi: null, postUi: null, source: 'pump', amountUi: 60 }));
  assert.match(a.sent[0].text, /SOLD 60%/);
  const b = setup({ balances: { M: 0 } });
  b.state.positions.M = { ui: 100 };
  await b.t.handleTrade(ev({ side: 'SELL', preUi: null, postUi: null, source: 'pump', amountUi: 100 }));
  assert.match(b.sent[0].text, /FULLY SOLD OUT/);
});

test('the same trade from both sources alerts once', async () => {
  const { t, sent } = setup();
  const e1 = ev({ side: 'BUY', preUi: 0, postUi: 100, key: 'tx1:M' });
  await t.handleTrade(e1);
  await t.handleTrade({ ...e1, source: 'pump', preUi: null, postUi: null });
  assert.equal(sent.length, 1);
});
