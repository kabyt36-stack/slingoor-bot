import test from 'node:test';
import assert from 'node:assert/strict';
import { parseWalletTx, tradesFromParsed, isCandidateLogs, PUMP_PROGRAM } from '../src/parse.js';
import { realTxs, buildTx } from './helpers.js';

const fx = realTxs();
const W = fx.wallet;

for (const [name, t] of Object.entries(fx.txs)) {
  test(`real tx ${name} parses to what pump.fun reported`, () => {
    const tx = buildTx(t.c, W, t.sig);
    const p = parseWalletTx(tx, W);
    assert.ok(p, 'should be recognised as his tx');
    const evs = tradesFromParsed(p);
    assert.equal(evs.length, 1, JSON.stringify(evs));
    const ev = evs[0];
    assert.equal(ev.side, t.expect.side);
    assert.equal(ev.mint, t.expect.mint);
    assert.equal(ev.sig, t.sig);
    assert.ok(Math.abs(ev.amountUi - t.expect.amount) < 1e-6, `amount ${ev.amountUi} vs ${t.expect.amount}`);
    if (t.expect.sol != null) assert.ok(Math.abs(ev.solAmount - t.expect.sol) < 0.0005, `sol ${ev.solAmount} vs ${t.expect.sol}`);
    if (t.expect.usd != null) assert.ok(Math.abs(ev.usdAmount - t.expect.usd) < 0.001, `usd ${ev.usdAmount} vs ${t.expect.usd}`);
    assert.equal(ev.preUi === 0, t.expect.entry, 'new entry flag');
    assert.equal(ev.postUi === 0, t.expect.exit, 'full exit flag');
  });
}

test('someone else tailing him (his wallet read-only, not signer) is ignored', () => {
  const c = { ...fx.txs.ssdBuy.c, wi: 24 }; // where his wallet sits in tail trades
  const tx = buildTx(c, W, 'tailSig');
  assert.equal(parseWalletTx(tx, W), null);
});

test('failed transaction is ignored', () => {
  const tx = buildTx(fx.txs.ssdBuy.c, W, 's');
  tx.meta.err = { InstructionError: [2, { Custom: 6001 }] };
  assert.equal(parseWalletTx(tx, W), null);
});

test('moving the whole bag to another wallet is a transfer, not a sell', () => {
  const c = structuredClone(fx.txs.ssdSell.c);
  c.post = c.pre - 5000; // only paid the fee
  c.inv = ['TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA'];
  const evs = tradesFromParsed(parseWalletTx(buildTx(c, W, 'x'), W));
  assert.equal(evs.length, 1);
  assert.equal(evs[0].side, 'XFER_OUT');
  assert.equal(evs[0].postUi, 0);
});

test('receiving tokens while paying only ATA rent is not a buy', () => {
  const c = structuredClone(fx.txs.ssdBuy.c);
  c.post = c.pre - 2039280 - 5000; // rent + fee
  c.ptb = c.ptb.filter((b) => !b[1].endsWith('pump')); // account did not exist before
  const evs = tradesFromParsed(parseWalletTx(buildTx(c, W, 'x'), W));
  assert.equal(evs[0].side, 'XFER_IN');
});

test('pump.fun launch with dev buy is detected', () => {
  const c = structuredClone(fx.txs.ssdBuy.c);
  const newMint = 'NewMintAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAApump';
  c.ptb = [];
  c.qtb = [[17, newMint, 'Token2', '35000000000000', 6]];
  c.inv = [PUMP_PROGRAM];
  const tx = buildTx(c, W, 'launchSig', { extraLogs: [`Program ${PUMP_PROGRAM} invoke [1]`, 'Program log: Instruction: Create', 'Program log: Instruction: Buy'] });
  // the bonding curve's token account also appears only in post
  tx.meta.postTokenBalances.push({ accountIndex: 50, mint: newMint, owner: 'BondingCurve1111111111111111111111111111111', programId: 'x', uiTokenAmount: { amount: '965000000000000', decimals: 6, uiAmountString: '965000000' } });
  const p = parseWalletTx(tx, W);
  assert.deepEqual(p.newMints, [newMint]);
  const evs = tradesFromParsed(p);
  assert.equal(evs[0].side, 'BUY');
  assert.equal(evs[0].devBuy, true);
  assert.ok(Math.abs(evs[0].solAmount - 1.0) < 0.003);
});

test('ordinary buy is not mistaken for a launch', () => {
  const tx = buildTx(fx.txs.ssdBuy.c, W, 's', { extraLogs: ['Program log: CreateIdempotent', 'Program log: Instruction: Buy'] });
  assert.deepEqual(parseWalletTx(tx, W).newMints, []);
});

test('log pre-filter skips spam token transfers, keeps trades', () => {
  const spam = [
    'Program ComputeBudget111111111111111111111111111111 invoke [1]',
    'Program ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL invoke [1]',
    'Program TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA invoke [1]',
    'Program log: Instruction: TransferChecked',
  ];
  assert.equal(isCandidateLogs(spam), false);
  assert.equal(isCandidateLogs([...spam, 'Program 6Vo3245eszAb5wuqEMw8mGdbfRUdKbHhDHP5LcaGuTAB invoke [1]']), true);
  assert.equal(isCandidateLogs(['Program TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb invoke [1]', 'Program log: Instruction: InitializeMint2']), true);
});

test('fast path: reads his pump.fun buy straight from the live logs, even through a router', async () => {
  const { pumpTradeEvents, PUMP_PROGRAM } = await import('../src/parse.js');
  const { b58encode, b58decode } = await import('../src/solana.js');
  const crypto = await import('node:crypto');
  const mint = b58encode(crypto.randomBytes(32));
  const user = '5YRgrP3mjGzrzirYYN5HAQH19cTYREYwGxW6XRJQUzij';
  const ev = (isBuy, sol, tok, who = user) => {
    const b = Buffer.alloc(401);
    Buffer.from([189, 219, 127, 211, 78, 230, 97, 238]).copy(b, 0);
    Buffer.from(b58decode(mint)).copy(b, 8);
    b.writeBigUInt64LE(BigInt(Math.round(sol * 1e9)), 40);
    b.writeBigUInt64LE(BigInt(Math.round(tok * 1e6)), 48);
    b[56] = isBuy ? 1 : 0;
    Buffer.from(b58decode(who)).copy(b, 57);
    return `Program data: ${b.toString('base64')}`;
  };
  const logs = [
    'Program 6Vo3245eszAb5wuqEMw8mGdbfRUdKbHhDHP5LcaGuTAB invoke [1]',
    'Program log: Instruction: MultiHopJupiterBuy',
    'Program pAMMBay6oceH9fJKBRHGP5D4bD4sWpmSwMn52FMfXEA invoke [2]',
    ev(true, 9, 1), // same discriminator but from another program: ignored
    'Program pAMMBay6oceH9fJKBRHGP5D4bD4sWpmSwMn52FMfXEA success',
    `Program ${PUMP_PROGRAM} invoke [2]`,
    'Program log: Instruction: Buy',
    ev(true, 2.5, 172778031.109208),
    `Program ${PUMP_PROGRAM} success`,
    'Program 6Vo3245eszAb5wuqEMw8mGdbfRUdKbHhDHP5LcaGuTAB success',
  ];
  const out = pumpTradeEvents(logs);
  assert.equal(out.length, 1);
  assert.deepEqual(out[0], { mint, solAmount: 2.5, tokenAmount: 172778031.109208, isBuy: true, user, priceSol: null });
  assert.equal(pumpTradeEvents([`Program ${PUMP_PROGRAM} invoke [1]`, ev(false, 1, 5), 'Program data: !!notbase64', 'Program data: AAAA'])[0].isBuy, false);
  assert.deepEqual(pumpTradeEvents(['Program data: x', null, undefined].filter(Boolean)), []);
});

test('fast path: when a routed trade logs 0 SOL, the amount is estimated from the curve price in the record', async () => {
  const { pumpTradeEvents, PUMP_PROGRAM } = await import('../src/parse.js');
  const { b58encode, b58decode } = await import('../src/solana.js');
  const crypto = await import('node:crypto');
  const b = Buffer.alloc(401);
  Buffer.from([189, 219, 127, 211, 78, 230, 97, 238]).copy(b, 0);
  Buffer.from(b58decode(b58encode(crypto.randomBytes(32)))).copy(b, 8);
  b.writeBigUInt64LE(0n, 40); // router: 0 SOL logged
  b.writeBigUInt64LE(1_000_000_000_000n, 48); // 1M tokens
  b[56] = 1;
  Buffer.from(b58decode('5YRgrP3mjGzrzirYYN5HAQH19cTYREYwGxW6XRJQUzij')).copy(b, 57);
  b.writeBigUInt64LE(60_000_000_000n, 97); // 60 SOL virtual
  b.writeBigUInt64LE(600_000_000_000_000n, 105); // 600M tokens virtual -> 1M tokens = 0.1 SOL
  const [ev] = pumpTradeEvents([`Program ${PUMP_PROGRAM} invoke [1]`, `Program data: ${b.toString('base64')}`, `Program ${PUMP_PROGRAM} success`]);
  assert.ok(Math.abs(ev.solAmount - 0.1) < 1e-9, String(ev.solAmount));
  // curve price: 60 SOL / 600M tokens = 1e-7 SOL per token -> 100 SOL market cap at 1B supply
  assert.ok(Math.abs(ev.priceSol * 1e9 - 100) < 1e-6, String(ev.priceSol));
});
