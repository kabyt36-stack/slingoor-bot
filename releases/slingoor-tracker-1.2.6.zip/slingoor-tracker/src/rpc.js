import { fetchJson, sleep } from './util.js';
import { log } from './log.js';

// Minimal Solana JSON-RPC client with a request pacer and retry on rate limits.
export class Rpc {
  constructor(url, { minGapMs = 120, concurrency = 3 } = {}) {
    this.url = url;
    this.minGapMs = minGapMs;
    this.concurrency = concurrency;
    this.active = 0;
    this.queue = [];
    this.nextAt = 0;
    this.maxTxVersion = 1; // Solana now has v1 transactions; fall back to 0 if the RPC doesn't know v1
    this.ok = 0;
    this.fail = 0;
    this.lastError = null;
  }

  call(method, params, { priority = false } = {}) {
    return new Promise((resolve, reject) => {
      const job = { method, params, resolve, reject, priority };
      if (priority) this.queue.unshift(job);
      else this.queue.push(job);
      this._pump();
    });
  }

  async _pump() {
    while (this.active < this.concurrency && this.queue.length) {
      const job = this.queue.shift();
      this.active++;
      this._run(job).finally(() => {
        this.active--;
        this._pump();
      });
    }
  }

  async _run(job) {
    for (let attempt = 0; attempt < 5; attempt++) {
      const wait = this.nextAt - Date.now();
      this.nextAt = Math.max(Date.now(), this.nextAt) + this.minGapMs;
      if (wait > 0) await sleep(wait);
      try {
        const j = await fetchJson(this.url, {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: { jsonrpc: '2.0', id: 1, method: job.method, params: job.params },
          timeout: 12000,
        });
        if (j?.error) {
          const code = j.error.code;
          if (code === 429 || code === -32429) throw Object.assign(new Error('rate limited'), { status: 429 });
          const err = new Error(`${job.method}: ${j.error.message}`);
          err.rpcCode = code;
          throw err;
        }
        this.ok++;
        return job.resolve(j?.result);
      } catch (e) {
        this.fail++;
        this.lastError = e.message;
        const retryable = e.status === 429 || e.status >= 500 || e.timeout || e.cause || /fetch failed/i.test(e.message);
        if (!retryable || attempt === 4) return job.reject(e);
        // trade-critical calls retry fast (rate limits are per second); background calls back off more
        const backoff = e.status === 429 ? (job.priority ? 250 : 1500) * (attempt + 1) : (job.priority ? 150 : 400) * (attempt + 1);
        if (e.status === 429) log.debug(`RPC rate-limited on ${job.method}, retrying in ${backoff}ms`);
        await sleep(backoff);
      }
    }
  }

  async getTransaction(sig, { priority = true } = {}) {
    try {
      return await this.call(
        'getTransaction',
        [sig, { encoding: 'json', maxSupportedTransactionVersion: this.maxTxVersion, commitment: 'confirmed' }],
        { priority },
      );
    } catch (e) {
      if (this.maxTxVersion === 1 && /maxSupportedTransactionVersion|invalid param/i.test(e.message)) {
        log.warn('RPC does not support v1 transactions, falling back to v0');
        this.maxTxVersion = 0;
        return this.getTransaction(sig, { priority });
      }
      throw e;
    }
  }

  // Returns the owner's total balance of a mint (UI units) at "confirmed".
  async getTokenBalance(owner, mint, commitment = 'confirmed') {
    const r = await this.call(
      'getTokenAccountsByOwner',
      [owner, { mint }, { encoding: 'jsonParsed', commitment }],
      { priority: true },
    );
    let ui = 0;
    let raw = 0n;
    for (const acc of r?.value || []) {
      const ta = acc.account?.data?.parsed?.info?.tokenAmount;
      if (!ta) continue;
      ui += +ta.uiAmountString;
      raw += BigInt(ta.amount);
    }
    return { ui, raw, accounts: (r?.value || []).length };
  }

  getSignatures(address, { limit = 50, until } = {}) {
    const opts = { limit, commitment: 'confirmed' };
    if (until) opts.until = until;
    return this.call('getSignaturesForAddress', [address, opts]);
  }
}
