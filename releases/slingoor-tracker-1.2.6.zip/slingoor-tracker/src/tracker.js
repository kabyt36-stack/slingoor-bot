import { log } from './log.js';
import { withTimeout, fmtSol, fmtUsd } from './util.js';
import { tradeMessage, calloutMessage, launchMessage, linkButtons } from './format.js';

const DUST = 0.002; // a bag under 0.2% of what it was counts as fully sold

// The brain: takes raw events from the chain stream / pump.fun pollers, works out
// what they mean (new entry? full exit?), tags the narrative and sends Telegram alerts.
export class Tracker {
  constructor({ cfg, state, tg, pump, rpc, coins, profile }) {
    this.cfg = cfg;
    this.state = state;
    this.tg = tg;
    this.pump = pump;
    this.rpc = rpc;
    this.coins = coins;
    this.profile = profile;
    this.groups = new Map(); // merge bursts of buys/sells into one message
    this.solPrice = null;
    this.lastEventAt = 0;
    this.counts = { entries: 0, adds: 0, partials: 0, exits: 0, moves: 0, callouts: 0, updates: 0, launches: 0 };
  }

  chats() {
    return this.cfg.chatIds.length ? this.cfg.chatIds : this.state.chats;
  }

  async broadcast(html, buttons) {
    const refs = [];
    for (const chatId of this.chats()) {
      try {
        refs.push({ chatId, msgId: await this.tg.send(chatId, html, buttons) });
      } catch (e) {
        if (e.migrateTo) {
          // the group became a supergroup with a new id: follow it
          const list = this.cfg.chatIds.length ? this.cfg.chatIds : this.state.chats;
          const i = list.indexOf(chatId);
          if (i >= 0) list[i] = e.migrateTo;
          this.state.save();
          log.warn(`Chat ${chatId} moved to ${e.migrateTo}, following it`);
          try {
            refs.push({ chatId: e.migrateTo, msgId: await this.tg.send(e.migrateTo, html, buttons) });
          } catch {}
          continue;
        }
        const now = Date.now();
        if (!this._sendErrAt || now - this._sendErrAt > 60000) log.error(`Telegram send to ${chatId} failed:`, e.message);
        this._sendErrAt = now;
      }
    }
    return refs;
  }

  async editAll(refs, html, buttons) {
    for (const r of refs || []) {
      try {
        await this.tg.edit(r.chatId, r.msgId, html, buttons);
      } catch (e) {
        log.warn('Telegram edit failed:', e.message);
      }
    }
  }

  pos(mint) {
    if (!this.state.positions[mint]) this.state.positions[mint] = { ui: 0, solIn: 0, solOut: 0, buys: 0, sells: 0, openedAt: null, tracked: false };
    return this.state.positions[mint];
  }

  // Remaining balance after a sell we only know about from pump.fun's feed.
  async balanceAfter(wallet, mint, estimate) {
    try {
      const b = await withTimeout(this.rpc.getTokenBalance(wallet, mint), 3500, null);
      if (b) return b.ui;
    } catch {}
    try {
      const ps = await withTimeout(this.pump.getPositions(wallet, [mint]), 3500, null);
      if (ps?.length) {
        const open = ps.find((p) => !p.isExited);
        return open ? +open.amountHeld : 0;
      }
    } catch {}
    return Math.max(0, estimate);
  }

  // Events for the same coin are processed one at a time so bag sizes stay consistent.
  handleTrade(ev) {
    if (this.state.seenTrades.has(ev.key)) return Promise.resolve();
    this.state.seenTrades.add(ev.key);
    this.state.save();
    this.lastEventAt = Date.now();
    this.locks ||= new Map();
    const prev = this.locks.get(ev.mint) || Promise.resolve();
    const run = prev.then(() => this._handleTrade(ev)).catch((e) => log.error('Trade handling failed:', e.stack || e.message));
    this.locks.set(ev.mint, run);
    run.finally(() => {
      if (this.locks.get(ev.mint) === run) this.locks.delete(ev.mint);
    });
    return run;
  }

  async _handleTrade(ev) {
    const p = this.pos(ev.mint);
    const sol = ev.solAmount || (ev.usdAmount && this.solPrice ? ev.usdAmount / this.solPrice : 0);
    let kind;

    if (ev.side === 'XFER_IN') {
      p.ui = ev.postUi ?? p.ui + ev.amountUi;
      this.state.save();
      return;
    }

    let hint = ev.coinHint;
    if (ev.priceSol > 0 && this.solPrice > 0) hint = { ...(hint || {}), mc: ev.priceSol * 1e9 * this.solPrice, mcAt: Date.now(), isPump: true };
    const coinP = this.coins.get(ev.mint, { hint });
    let pre;
    let post;
    if (ev.side === 'BUY') {
      pre = ev.preUi ?? p.ui;
      if (ev.preUi == null && !(pre > 0)) {
        // copy trading starts building its buy now, while we check whether this is a new entry
        if (this.onMaybeEntry) {
          try {
            this.onMaybeEntry(ev);
          } catch {}
        }
        // pump.fun's feed doesn't say whether he already held it: ask the chain
        // same commitment as the stream, so the balance already includes this buy
        const b = await withTimeout(this.rpc.getTokenBalance(ev.wallet, ev.mint, this.cfg.chainCommitment || 'confirmed'), 2500, null).catch(() => null);
        if (b) ev.preChecked = true;
        if (b && b.ui - ev.amountUi > ev.amountUi * 0.01) pre = b.ui - ev.amountUi;
      }
      kind = pre > 0 ? 'ADD' : 'ENTRY';
      if (kind === 'ENTRY') Object.assign(p, { solIn: 0, solOut: 0, buys: 0, sells: 0, openedAt: ev.time, tracked: true });
      post = ev.postUi ?? pre + ev.amountUi;
      p.solIn += sol;
      p.buys++;
    } else {
      pre = ev.preUi ?? (p.ui > 0 ? p.ui : null);
      post = ev.postUi;
      if (post == null) {
        // pump.fun's feed doesn't give the bag left. If our own count says plenty is left, use it;
        // if it looks like everything is gone (or we don't know), confirm on-chain.
        const est = pre != null ? pre - ev.amountUi : null;
        post = est != null && est > pre * 0.02 ? est : await this.balanceAfter(ev.wallet, ev.mint, est ?? 0);
      }
      if (pre == null) pre = post + ev.amountUi;
      const gone = post <= pre * DUST;
      kind = ev.side === 'XFER_OUT' ? 'MOVED' : gone ? 'EXIT' : 'PARTIAL';
      p.solOut += sol;
      p.sells++;
    }
    p.ui = post;
    p.lastAt = Date.now();
    this.state.save();
    // copy trading reacts before the alert is even written
    if (this.onSignal) {
      try {
        this.onSignal({ ev, kind, pre, post, sol });
      } catch (err) {
        log.error('copy signal failed', err.message);
      }
    }

    const coin = await coinP;
    const meta = ev.side === 'BUY' && coin?.name ? this.profile.match({ ...coin, mint: ev.mint }) : null;
    if (kind === 'ENTRY' && coin?.name) this.profile.add({ mint: ev.mint, name: coin.name, symbol: coin.symbol, twitter: coin.twitter, nsfw: coin.nsfw }, 1, 'trade');

    // Respect alert settings
    const a = this.cfg.alerts;
    const enabled = { ENTRY: a.entry, ADD: a.add, PARTIAL: a.partial, EXIT: a.exit, MOVED: a.transfer }[kind];
    if (!enabled) return;
    if (kind === 'ENTRY' && this.cfg.metaOnlyEntries && meta && meta.level < 2) return;
    if ((kind === 'ENTRY' || kind === 'ADD' || kind === 'PARTIAL') && sol > 0 && sol < this.cfg.minAlertSol) return;

    await this._alertTrade(ev, { kind, pre, post, sol, coin, meta, pos: p });
  }

  async _alertTrade(ev, { kind, pre, post, sol, coin, meta, pos }) {
    const side = ev.side === 'BUY' ? 'B' : 'S';
    const gk = `${ev.mint}:${side}`;
    const now = Date.now();
    if (this.groups.size > 300) for (const [k, old] of this.groups) if (now - old.lastAt > 600000) this.groups.delete(k);
    let g = this.groups.get(gk);
    // A full exit always gets its own message (edits don't ping your phone); quick follow-up
    // buys/sells of the same coin are merged into one message to avoid spam.
    const fresh =
      !g ||
      now - g.lastAt > this.cfg.mergeWindowMs ||
      kind === 'ENTRY' || // a (re-)entry is always its own alert
      (kind === 'EXIT') !== (g.kind === 'EXIT') ||
      (kind === 'MOVED') !== (g.kind === 'MOVED');
    if (fresh) {
      g = {
        mint: ev.mint,
        wallet: ev.wallet,
        side: ev.side === 'BUY' ? 'BUY' : 'SELL',
        kind,
        count: 0,
        sol: 0,
        usd: 0,
        tokens: 0,
        firstPre: pre,
        firstTime: ev.time,
        lagMs: ev.time ? now - ev.time : null, // alert time vs his tx time
        source: ev.source,
        refs: null,
        sending: null,
      };
      this.groups.set(gk, g);
    }
    g.count++;
    g.sol += sol || 0;
    g.usd += ev.usdAmount || 0;
    g.tokens += ev.amountUi || 0;
    g.lastTime = ev.time;
    g.lastAt = now;
    g.sig = ev.sig;
    g.coin = coin;
    g.postUi = post;
    if (meta) g.meta = meta;
    if (g.side === 'SELL') {
      if (kind === 'EXIT') g.kind = 'EXIT';
      const base = g.firstPre || pre;
      if (base > 0) {
        g.pctSold = Math.min(100, Math.max(0, ((base - post) / base) * 100));
        g.pctLeft = 100 - g.pctSold;
      }
      if (g.kind === 'EXIT' && pos.tracked && pos.solIn > 0) {
        const pnl = pos.solOut - pos.solIn;
        g.trip = { in: pos.solIn, out: pos.solOut, pnl, pct: (pnl / pos.solIn) * 100, heldMs: pos.openedAt ? ev.time - pos.openedAt : null };
      }
    }

    const render = () =>
      tradeMessage(g, { name: this.cfg.targetName, solPrice: this.solPrice, multiWallet: this.cfg.wallets.length > 1 });
    const buttons = linkButtons(ev.mint, { sig: g.sig });

    // Wait for the first send of this group to finish before editing it
    if (g.sending) await g.sending;
    if (!g.refs) {
      g.sending = this.broadcast(render(), buttons).then((refs) => (g.refs = refs));
      await g.sending;
      g.sending = null;
      this._count(kind);
      this.state.pushRecent(`${ev.side === 'BUY' ? '🟢' : '🔴'} ${kind} $${coin?.symbol || ev.mint.slice(0, 6)} ${sol ? fmtSol(sol) + ' SOL' : ''}`);
    } else {
      await this.editAll(g.refs, render(), buttons);
      if (kind === 'EXIT') this._count(kind);
    }

    if (g.kind === 'EXIT' && !g.pnlRequested) {
      g.pnlRequested = true;
      this._addPumpPnl(g, render, buttons).catch(() => {});
    }
  }

  async _addPumpPnl(g, render, buttons) {
    // pump.fun indexes a few seconds behind the chain. Only accept a position that pump.fun
    // closed around THIS exit — never an older round trip on the same coin.
    const exitTime = g.lastTime || Date.now();
    for (const wait of [3000, 6000, 10000]) {
      await new Promise((r) => setTimeout(r, wait));
      const ps = await this.pump.getPositions(g.wallet, [g.mint]).catch(() => null);
      if (!ps || ps.some((p) => !p.isExited && +p.amountHeld > 0)) continue;
      const exited = ps
        .filter((p) => p.isExited && Date.parse(p.updatedAt || 0) >= exitTime - 60000)
        .sort((a, b) => Date.parse(b.updatedAt || 0) - Date.parse(a.updatedAt || 0))[0];
      if (exited && exited.pnlUsd != null) {
        g.pnl = { usd: +exited.pnlUsd, pct: exited.pnlPercentage != null ? +exited.pnlPercentage : null };
        await this.editAll(g.refs, render(), buttons);
        return;
      }
    }
  }

  // Forget coins he's fully out of after a few days so the state file stays small.
  prunePositions(maxAgeMs = 3 * 86400000) {
    const now = Date.now();
    for (const [mint, p] of Object.entries(this.state.positions)) {
      if (p.ui <= 0 && now - (p.lastAt || 0) > maxAgeMs) delete this.state.positions[mint];
    }
    this.state.save();
  }

  _count(kind) {
    const k = { ENTRY: 'entries', ADD: 'adds', PARTIAL: 'partials', EXIT: 'exits', MOVED: 'moves' }[kind];
    if (k) this.counts[k]++;
  }

  async handleLaunch(l) {
    if (!this.state.createdMints.add(l.mint)) return;
    this.state.save();
    this.lastEventAt = Date.now();
    if (!this.cfg.alerts.launch) return;
    // pump.fun may not have indexed a brand-new coin yet; give it a moment
    let coin = await this.coins.get(l.mint, { hint: l.coin ? { name: l.coin.name, symbol: l.coin.symbol, twitter: l.coin.twitter } : null });
    if (!coin?.name) {
      await new Promise((r) => setTimeout(r, 2500));
      coin = await this.coins.get(l.mint);
    }
    const meta = coin?.name ? this.profile.match({ ...coin, mint: l.mint }) : null;
    if (coin?.name) this.profile.add({ mint: l.mint, name: coin.name, symbol: coin.symbol }, 1, 'launch');
    await this.broadcast(launchMessage(l, { name: this.cfg.targetName, coin, meta, solPrice: this.solPrice }), linkButtons(l.mint, { sig: l.sig }));
    this.counts.launches++;
    this.state.pushRecent(`🚀 LAUNCH $${coin?.symbol || l.mint.slice(0, 6)}`);
  }

  async holdingFor(wallet, mint) {
    const ps = await withTimeout(this.pump.getPositions(wallet, [mint]), 4000, null);
    if (ps?.length) {
      const open = ps.find((p) => !p.isExited && +p.amountHeld > 0);
      if (open) return { held: true, costUsd: +open.costBasisUsd || null, pnlPct: open.pnlPercentage != null ? +open.pnlPercentage : null };
      return { held: false, exited: true };
    }
    const p = this.state.positions[mint];
    if (p && p.ui > 0) return { held: true };
    return ps ? { held: false } : null;
  }

  async handleCallout(c, wallet, { isUpdate = false, updateText = null } = {}) {
    this.lastEventAt = Date.now();
    if (isUpdate ? !this.cfg.alerts.calloutUpdate : !this.cfg.alerts.callout) return;
    const [coin, holding] = await Promise.all([this.coins.get(c.coinMint), isUpdate ? null : this.holdingFor(wallet, c.coinMint)]);
    const meta = coin?.name ? this.profile.match({ ...coin, mint: c.coinMint }) : null;
    if (!isUpdate && coin?.name) this.profile.add({ mint: c.coinMint, name: coin.name, symbol: coin.symbol }, 1, 'callout');
    const html = calloutMessage(c, { name: this.cfg.targetName, coin, meta, holding, isUpdate, updateText });
    await this.broadcast(html, linkButtons(c.coinMint, { calloutId: c.calloutId }));
    this.counts[isUpdate ? 'updates' : 'callouts']++;
    this.state.pushRecent(`${isUpdate ? '📝 UPDATE' : '📣 CALLOUT'} $${coin?.symbol || c.coinMint.slice(0, 6)}${c.marketCap ? ' @ ' + fmtUsd(c.marketCap) : ''}`);
  }
}
