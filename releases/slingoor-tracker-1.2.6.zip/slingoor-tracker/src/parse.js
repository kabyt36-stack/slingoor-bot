// Turns a raw Solana transaction into "what did the wallet do" events.
// Works for any venue (pump.fun curve, PumpSwap, Jupiter, Axiom/Padre routers...)
// because it reads the wallet's own balance changes instead of decoding each DEX.

export const QUOTES = {
  So11111111111111111111111111111111111111112: 'SOL',
  EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v: 'USDC',
  Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB: 'USDT',
  USD1ttGY1N17NEEHLmELoaybftRBUSErhqYiQzvEmuB: 'USD1',
};
export const PUMP_PROGRAM = '6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P';

// Programs that show up in spam token transfers / plain SOL sends. A tx that only
// touches these at the top level can't be a trade, so we don't spend an RPC call on it.
export const BORING_PROGRAMS = new Set([
  'ComputeBudget111111111111111111111111111111',
  'ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL',
  'TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA',
  'TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb',
  '11111111111111111111111111111111',
  'MemoSq4gqABAXKb96qnH8TysNcWxMyWCqXgDLGmfcHr',
  'Memo1UhkJRfHyvLMcVucJwxXeuD728EqVDDwQDxFMNo',
  'L2TExMFKdjpN9kozasaurPirfHy9P8sbXoAN1qA3S95',
]);

const ATA_RENT_SOL = 0.00203928;
const MIN_SOL_SPEND = 0.003; // below this a SOL change is just rent/fees, not a buy
const MIN_SOL_GET = 0.0005;
const MIN_STABLE = 1; // USDC/USDT/USD1 moves smaller than $1 are treated as noise

const INVOKE_RE = /^Program (\w+) invoke \[1\]$/;

// Programs that mean "this is a trade". A transaction of his that calls one of these is downloaded right
// away instead of waiting for his balance-change notification.
export const TRADING_PROGRAMS = new Set([
  PUMP_PROGRAM,
  'pAMMBay6oceH9fJKBRHGP5D4bD4sWpmSwMn52FMfXEA', // PumpSwap
  '6Vo3245eszAb5wuqEMw8mGdbfRUdKbHhDHP5LcaGuTAB', // router he uses
  'JUP6LkbZbjS1jKKwapdHNy74zcZ3tLUZoi5QNyVTaV4', // Jupiter
  '675kPX9MHTjS2zt1qfr1NYHuzeLXfQM9H24wFSUt1Mp8', // Raydium AMM
  'CPMMoo8L3F4NbTegBCKVNunggL7H1ZpdTHKxQB5qKP1C', // Raydium CPMM
  'LanMV9sAd7wArD4vJFi2qDdfnVhFxYSUg6eADduJ3uj', // Raydium LaunchLab
  'LBUZKhRxPF3XUpBCjp4YzTKgLccjZhTSDM9YuVaPwxo', // Meteora DLMM
  'dbcij3LWUppWqq96dh6gJWwBifmcGfLSB5D4DuSMaqN', // Meteora DBC
  'whirLbMiicVdio4qvUfM5KAg6Ct8VwpYzGff3uctyCc', // Orca
]);

// Big routed trades (his 10+ SOL buys through his router) have their logs cut off, which hides
// pump.fun's trade event from the fast path. Those are downloaded right away when they call a
// trading program. (Untruncated trades by other people that merely mention him, like trades of coins
// he launched, are NOT: their pump.fun event shows they're someone else's.)
export function isTruncatedTrade(logs) {
  if (!Array.isArray(logs) || !logs.some((l) => /^Log truncated/.test(l))) return false;
  return logs.some((l) => {
    const m = /^Program (\w+) invoke \[\d+\]$/.exec(l);
    return m && TRADING_PROGRAMS.has(m[1]);
  });
}
const CREATE_RE = /^Program log: Instruction: (Create|CreateV2)$/;
const INIT_MINT_RE = /Instruction: InitializeMint/;

// Cheap pre-filter on websocket log notifications.
export function isCandidateLogs(logs) {
  if (!Array.isArray(logs)) return false;
  for (const l of logs) {
    const m = INVOKE_RE.exec(l);
    if (m && !BORING_PROGRAMS.has(m[1])) return true;
    if (INIT_MINT_RE.test(l)) return true;
  }
  return false;
}

export function accountKeysOf(tx) {
  const m = tx.transaction.message;
  const statics = (m.accountKeys || m.staticAccountKeys || []).map((k) => (typeof k === 'string' ? k : k.pubkey));
  const la = tx.meta?.loadedAddresses || {};
  return [...statics, ...(la.writable || []), ...(la.readonly || [])];
}

function isSignerAt(tx, idx) {
  const m = tx.transaction.message;
  const k0 = m.accountKeys?.[0];
  if (k0 && typeof k0 === 'object') return !!m.accountKeys[idx]?.signer; // jsonParsed encoding
  const n = m.header?.numRequiredSignatures ?? 1;
  return idx < n;
}

const toUi = (raw, dec) => Number(raw) / 10 ** dec;

// Returns null if the wallet didn't sign this tx (spam, other people's trades) or the tx failed.
export function parseWalletTx(tx, wallet) {
  if (!tx || !tx.meta || tx.meta.err) return null;
  const keys = accountKeysOf(tx);
  const idx = keys.indexOf(wallet);
  if (idx < 0 || !isSignerAt(tx, idx)) return null;

  const meta = tx.meta;
  let lamports = (meta.postBalances[idx] ?? 0) - (meta.preBalances[idx] ?? 0);
  if (idx === 0) lamports += meta.fee || 0; // ignore the network fee he paid

  // Wallet-owned token balances, summed per mint
  const tok = new Map();
  const touch = (b, field) => {
    if (b.owner !== wallet) return;
    const t = tok.get(b.mint) || { mint: b.mint, decimals: b.uiTokenAmount.decimals, pre: 0n, post: 0n, hadPre: false, hasPost: false, programId: b.programId };
    t[field] += BigInt(b.uiTokenAmount.amount);
    if (field === 'pre') t.hadPre = true;
    else t.hasPost = true;
    tok.set(b.mint, t);
  };
  for (const b of meta.preTokenBalances || []) touch(b, 'pre');
  for (const b of meta.postTokenBalances || []) touch(b, 'post');

  // Mints that did not exist before this tx (for launch detection)
  const preAny = new Set((meta.preTokenBalances || []).map((b) => b.mint));
  const logs = meta.logMessages || [];
  const pumpInvoked = logs.some((l) => l.startsWith(`Program ${PUMP_PROGRAM} invoke`));
  const isCreate = (pumpInvoked && logs.some((l) => CREATE_RE.test(l))) || logs.some((l) => INIT_MINT_RE.test(l));
  const newMints = isCreate
    ? [...new Set((meta.postTokenBalances || []).map((b) => b.mint))].filter((m) => !preAny.has(m) && !QUOTES[m])
    : [];

  const tokens = [...tok.values()].map((t) => ({
    mint: t.mint,
    decimals: t.decimals,
    programId: t.programId,
    preRaw: t.pre,
    postRaw: t.post,
    deltaRaw: t.post - t.pre,
    preUi: toUi(t.pre, t.decimals),
    postUi: toUi(t.post, t.decimals),
    deltaUi: toUi(t.post - t.pre, t.decimals),
    newAccount: !t.hadPre,
    closedAccount: t.hadPre && !t.hasPost,
  }));

  const quotes = { SOL: lamports / 1e9, USD: 0 };
  for (const t of tokens) {
    const q = QUOTES[t.mint];
    if (q === 'SOL') quotes.SOL += t.deltaUi;
    else if (q) quotes.USD += t.deltaUi;
  }

  return {
    sig: tx.transaction.signatures?.[0],
    slot: tx.slot,
    blockTime: tx.blockTime ? tx.blockTime * 1000 : Date.now(),
    wallet,
    feePayer: idx === 0,
    quotes,
    tokens,
    isCreate,
    newMints,
  };
}

// Converts a parsed tx into BUY / SELL / XFER_IN / XFER_OUT events, one per coin.
export function tradesFromParsed(p) {
  if (!p) return [];
  const coins = p.tokens.filter((t) => !QUOTES[t.mint] && t.deltaRaw !== 0n);
  if (!coins.length) return [];
  const ups = coins.filter((t) => t.deltaRaw > 0n);
  const downs = coins.filter((t) => t.deltaRaw < 0n);

  let sol = p.quotes.SOL;
  const usd = p.quotes.USD;
  const useUsd = Math.abs(usd) >= MIN_STABLE;

  // Account rent is not part of the trade price
  for (const t of ups) if (t.newAccount && sol < -0.01) sol += ATA_RENT_SOL;
  for (const t of downs) if (t.closedAccount && sol > 0.01) sol -= ATA_RENT_SOL;

  const spent = useUsd ? (usd < 0 ? { q: 'USD', amt: -usd } : null) : sol <= -MIN_SOL_SPEND ? { q: 'SOL', amt: -sol } : null;
  const got = useUsd ? (usd > 0 ? { q: 'USD', amt: usd } : null) : sol >= MIN_SOL_GET ? { q: 'SOL', amt: sol } : null;

  const base = (t, side, quote, amt, extra = {}) => ({
    key: `${p.sig}:${t.mint}`, // same key the pump.fun feed uses, so a trade is only alerted once
    sig: p.sig,
    wallet: p.wallet,
    mint: t.mint,
    side,
    amountUi: Math.abs(t.deltaUi),
    preUi: t.preUi,
    postUi: t.postUi,
    decimals: t.decimals,
    quote,
    solAmount: quote === 'SOL' ? amt : null,
    usdAmount: quote === 'USD' ? amt : null,
    time: p.blockTime,
    slot: p.slot,
    source: 'chain',
    devBuy: p.newMints.includes(t.mint),
    ...extra,
  });

  const events = [];
  for (const t of ups) {
    if (spent) events.push(base(t, 'BUY', spent.q, spent.amt / ups.length));
    else if (downs.length) events.push(base(t, 'BUY', 'TOKEN', null, { pairedMint: downs[0].mint }));
    else events.push(base(t, 'XFER_IN', null, null));
  }
  for (const t of downs) {
    if (got) events.push(base(t, 'SELL', got.q, got.amt / downs.length));
    else if (ups.length) events.push(base(t, 'SELL', 'TOKEN', null, { pairedMint: ups[0].mint }));
    else events.push(base(t, 'XFER_OUT', null, null));
  }
  return events;
}

// pump.fun's bonding-curve program logs a TradeEvent for every buy/sell, even when the trade goes
// through a router (Axiom, Padre, Jupiter…). Reading it straight from the live log stream tells us
// "he bought coin X" without waiting to download the whole transaction.
const TRADE_EVENT = Buffer.from([189, 219, 127, 211, 78, 230, 97, 238]);
const B58 = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
function b58(bytes) {
  let n = 0n;
  for (const b of bytes) n = (n << 8n) | BigInt(b);
  let s = '';
  while (n > 0n) {
    s = B58[Number(n % 58n)] + s;
    n /= 58n;
  }
  for (const b of bytes) {
    if (b !== 0) break;
    s = '1' + s;
  }
  return s;
}

export function pumpTradeEvents(logs) {
  const out = [];
  const stack = [];
  for (const l of logs || []) {
    let m;
    if ((m = /^Program (\w+) invoke \[\d+\]/.exec(l))) {
      stack.push(m[1]);
      continue;
    }
    if (/^Program \w+ (success|failed)/.test(l)) {
      stack.pop();
      continue;
    }
    if (stack.at(-1) !== PUMP_PROGRAM || !l.startsWith('Program data: ')) continue;
    let b;
    try {
      b = Buffer.from(l.slice(14), 'base64');
    } catch {
      continue;
    }
    if (b.length < 89 || !b.subarray(0, 8).equals(TRADE_EVENT)) continue;
    let solAmount = Number(b.readBigUInt64LE(40)) / 1e9;
    let priceSol = null; // SOL per token on the bonding curve right after this trade
    if (b.length >= 113) {
      const vs = Number(b.readBigUInt64LE(97));
      const vt = Number(b.readBigUInt64LE(105));
      if (vs > 0 && vt > 0) priceSol = vs / 1e9 / (vt / 1e6);
    }
    // trades routed through aggregators can log 0 SOL; estimate it from the curve price in the same record
    if (!(solAmount > 0) && b.length >= 113) {
      const vSol = Number(b.readBigUInt64LE(97));
      const vTok = Number(b.readBigUInt64LE(105));
      if (vSol > 0 && vTok > 0) solAmount = (Number(b.readBigUInt64LE(48)) * vSol) / vTok / 1e9;
    }
    out.push({
      mint: b58(b.subarray(8, 40)),
      solAmount,
      tokenAmount: Number(b.readBigUInt64LE(48)) / 1e6,
      isBuy: b[56] === 1,
      user: b58(b.subarray(57, 89)),
      priceSol,
    });
  }
  return out;
}
