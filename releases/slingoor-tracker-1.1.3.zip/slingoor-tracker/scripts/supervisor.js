#!/usr/bin/env node
// Keeps the bot running: restarts it when it crashes or freezes, installs tested updates,
// and rolls back by itself if a new version keeps crashing.
// Self-contained on purpose (no imports from src/), so a broken update can't break the supervisor.
import { spawn, spawnSync } from 'node:child_process';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = process.env.BOT_ROOT || path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const DATA = path.join(ROOT, 'data');
const UPD = path.join(DATA, 'update');
const HEARTBEAT = path.join(DATA, 'heartbeat.json');
const NOTICES = path.join(DATA, 'notices.json');
const STATE = path.join(UPD, 'state.json');
const UPDATE_NOW = path.join(DATA, 'update-now');
const LOG = path.join(ROOT, 'logs', 'supervisor.log');
// Everything an update may replace. settings.txt, wallet-key.txt, data/, logs/, runtime/ are never touched.
const CODE = ['bot.js', 'package.json', 'src', 'scripts', 'test', 'README.txt', 'settings.example.txt'];
const isCommand = (f) => f.endsWith('.command');

export const RELAUNCH = 75; // "start me again" (after an update or rollback)
const CONFIG_ERROR = 2;

const env = (k, d) => (process.env[k] != null && process.env[k] !== '' ? process.env[k] : d);
const HEARTBEAT_STALE_MS = +env('SUP_HEARTBEAT_STALE_MS', 180000);
const STARTUP_GRACE_MS = +env('SUP_STARTUP_GRACE_MS', 240000);
const PROBATION_MS = +env('SUP_PROBATION_MS', 15 * 60000);
const PROBATION_CRASHES = +env('SUP_PROBATION_CRASHES', 3);
const TEST_TIMEOUT_MS = +env('SUP_TEST_TIMEOUT_MS', 6 * 60000);
const TICK_MS = +env('SUP_TICK_MS', 5000);
const UPDATE_DELAY_MS = +env('SUP_UPDATE_DELAY_MS', 60000); // let the bot settle before the first check
const RESTART_MIN_MS = +env('SUP_RESTART_MIN_MS', 2000);

function log(...a) {
  const line = `[${new Date().toISOString().replace('T', ' ').slice(0, 19)}] SUP ${a.join(' ')}`;
  console.log(line);
  try {
    fs.mkdirSync(path.dirname(LOG), { recursive: true });
    if (fs.existsSync(LOG) && fs.statSync(LOG).size > 2e6) fs.renameSync(LOG, LOG + '.old');
    fs.appendFileSync(LOG, line + '\n');
  } catch {}
}

function readJson(f, d) {
  try {
    return JSON.parse(fs.readFileSync(f, 'utf8'));
  } catch {
    return d;
  }
}
function writeJson(f, v) {
  fs.mkdirSync(path.dirname(f), { recursive: true });
  fs.writeFileSync(f + '.tmp', JSON.stringify(v, null, 1));
  fs.renameSync(f + '.tmp', f);
}

// Messages the bot sends to Telegram the next time it starts.
export function notice(text) {
  if (!text) return;
  const list = readJson(NOTICES, []);
  list.push({ at: Date.now(), text });
  writeJson(NOTICES, list.slice(-20));
}

function settings() {
  const out = {};
  try {
    for (const line of fs.readFileSync(path.join(ROOT, 'settings.txt'), 'utf8').split(/\r?\n/)) {
      const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/);
      if (m) out[m[1]] = m[2].replace(/^["'“”‘’]+|["'“”‘’]+$/g, '');
    }
  } catch {}
  for (const k of ['AUTO_UPDATE', 'UPDATE_URL', 'UPDATE_CHECK_MINUTES']) if (process.env[k]) out[k] = process.env[k];
  return out;
}
const DEFAULT_UPDATE_URL = 'https://raw.githubusercontent.com/kabyt36-stack/slingoor-bot/main/update.json';

export const version = (dir = ROOT) => readJson(path.join(dir, 'package.json'), {}).version || '0.0.0';
export function newer(a, b) {
  const pa = String(a).split('.').map((x) => parseInt(x, 10) || 0);
  const pb = String(b).split('.').map((x) => parseInt(x, 10) || 0);
  for (let i = 0; i < 3; i++) if ((pa[i] || 0) !== (pb[i] || 0)) return (pa[i] || 0) > (pb[i] || 0);
  return false;
}

function lastError() {
  try {
    const lines = fs.readFileSync(path.join(ROOT, 'logs', 'bot.log'), 'utf8').trimEnd().split('\n').slice(-60);
    const err = lines.reverse().find((l) => / ERR /.test(l));
    return err ? err.replace(/^\[[^\]]+\] ERR /, '').slice(0, 300) : '';
  } catch {
    return '';
  }
}

const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

// ---------------- updates ----------------
function copyCode(from, to) {
  for (const name of fs.readdirSync(from)) {
    if (!(CODE.includes(name) || isCommand(name))) continue;
    const src = path.join(from, name);
    const dst = path.join(to, name);
    fs.rmSync(dst, { recursive: true, force: true });
    fs.cpSync(src, dst, { recursive: true, preserveTimestamps: true });
  }
  for (const f of fs.readdirSync(to)) if (isCommand(f)) try { fs.chmodSync(path.join(to, f), 0o755); } catch {}
}

function findPkgRoot(dir, depth = 0) {
  if (fs.existsSync(path.join(dir, 'bot.js')) && fs.existsSync(path.join(dir, 'package.json'))) return dir;
  if (depth > 2) return null;
  for (const d of fs.readdirSync(dir, { withFileTypes: true })) {
    if (d.isDirectory() && !d.name.startsWith('__MACOSX')) {
      const r = findPkgRoot(path.join(dir, d.name), depth + 1);
      if (r) return r;
    }
  }
  return null;
}

function runTests(dir) {
  return new Promise((resolve) => {
    const tdir = path.join(dir, 'test');
    const files = fs.existsSync(tdir) ? fs.readdirSync(tdir).filter((f) => f.endsWith('.test.js')).map((f) => path.join('test', f)) : [];
    if (!files.length) return resolve({ ok: false, pass: 0, fail: 0, out: 'no tests in the update' });
    const c = spawn(process.execPath, ['--test', ...files], {
      cwd: dir,
      env: (() => {
        const e = { ...process.env, SETTINGS_FILE: path.join(dir, '__no_settings__.txt'), BOT_ROOT: dir, SUPERVISED: '' };
        delete e.NODE_TEST_CONTEXT; // so the suite also runs when the supervisor itself is under test
        return e;
      })(),
    });
    let out = '';
    const add = (d) => {
      out += d;
      if (out.length > 4e6) out = out.slice(-2e6);
    };
    c.stdout.on('data', add);
    c.stderr.on('data', add);
    let timedOut = false;
    const t = setTimeout(() => {
      timedOut = true;
      c.kill('SIGKILL');
    }, TEST_TIMEOUT_MS);
    c.on('close', (code) => {
      clearTimeout(t);
      const pass = +(out.match(/^# pass (\d+)/m)?.[1] || 0);
      const fail = +(out.match(/^# fail (\d+)/m)?.[1] || 0);
      resolve({ ok: code === 0 && !timedOut && pass > 0 && fail === 0, pass, fail, timedOut, out: out.slice(-1500) });
    });
  });
}

// Same host and same repo/folder as UPDATE_URL, so a bad manifest can't point somewhere else.
export function sameSource(manifestUrl, zipUrl) {
  try {
    const a = new URL(manifestUrl);
    const b = new URL(zipUrl, manifestUrl);
    if (b.protocol !== 'https:' && !/^(127\.0\.0\.1|localhost)$/.test(b.hostname)) return false;
    if (a.host !== b.host) return false;
    const base = a.pathname.split('/').slice(0, 3).join('/'); // e.g. /owner/repo
    return b.pathname.startsWith(base + '/');
  } catch {
    return false;
  }
}

export async function checkForUpdate({ force = false } = {}) {
  const s = settings();
  if (!force && /^(off|false|no|0)$/i.test(s.AUTO_UPDATE || 'on')) return { skipped: 'off' };
  const url = s.UPDATE_URL || DEFAULT_UPDATE_URL;
  if (!url) return { skipped: 'no UPDATE_URL' };
  const st = readJson(STATE, {});
  const cur = version();
  const res = await fetch(url + (url.includes('?') ? '&' : '?') + 't=' + Date.now(), { signal: AbortSignal.timeout(20000), headers: { 'cache-control': 'no-cache' } });
  if (!res.ok) throw new Error(`update check HTTP ${res.status}`);
  const m = await res.json();
  if (!m?.version || !m.zip || !/^[0-9a-f]{64}$/i.test(m.sha256 || '')) throw new Error('update manifest is incomplete');
  if (!newer(m.version, cur)) return { upToDate: cur };
  if ((st.bad || []).includes(m.version)) return { skipped: `v${m.version} failed before` };
  if (!sameSource(url, m.zip)) throw new Error('update zip is not from the update source, ignored');

  log(`Update found: v${cur} -> v${m.version}`);
  const zipUrl = new URL(m.zip, url).href;
  const z = await fetch(zipUrl, { signal: AbortSignal.timeout(120000) });
  if (!z.ok) throw new Error(`update download HTTP ${z.status}`);
  const buf = Buffer.from(await z.arrayBuffer());
  const sum = crypto.createHash('sha256').update(buf).digest('hex');
  if (sum !== m.sha256.toLowerCase()) throw new Error('update download is corrupted (checksum mismatch)');

  const stage = path.join(UPD, 'stage');
  fs.rmSync(stage, { recursive: true, force: true });
  fs.mkdirSync(stage, { recursive: true });
  const zf = path.join(UPD, 'update.zip');
  fs.writeFileSync(zf, buf);
  const uz = spawnSync('unzip', ['-q', '-o', zf, '-d', stage], { encoding: 'utf8' });
  if (uz.status !== 0) throw new Error('could not unzip the update: ' + (uz.stderr || '').slice(0, 200));
  const pkg = findPkgRoot(stage);
  if (!pkg) throw new Error('update zip has no bot in it');
  if (version(pkg) !== m.version) throw new Error(`update zip says v${version(pkg)}, expected v${m.version}`);

  log(`Testing v${m.version} before installing…`);
  const t = await runTests(pkg);
  if (!t.ok) {
    st.bad = [...new Set([...(st.bad || []), m.version])].slice(-20);
    writeJson(STATE, st);
    log(`v${m.version} FAILED its tests (${t.pass} pass, ${t.fail} fail${t.timedOut ? ', timed out' : ''}); not installed.\n${t.out}`);
    notice(`⚠️ Update v${esc(m.version)} failed its tests on your Mac (${t.pass} passed, ${t.fail} failed) — <b>not installed</b>, still running v${esc(cur)}.`);
    return { failedTests: m.version };
  }

  // install: back up the current code, copy the new code in
  const backup = path.join(UPD, 'backup');
  fs.rmSync(backup, { recursive: true, force: true });
  fs.mkdirSync(backup, { recursive: true });
  copyCode(ROOT, backup);
  copyCode(pkg, ROOT);
  writeJson(STATE, { ...st, current: m.version, previous: cur, appliedAt: Date.now(), probation: true, crashes: [] });
  notice(`🔄 <b>Updated</b> v${esc(cur)} → v${esc(m.version)} (passed ${t.pass} tests on your Mac first).${m.notes ? '\n' + esc(m.notes) : ''}`);
  log(`Installed v${m.version} (${t.pass} tests passed)`);
  fs.rmSync(stage, { recursive: true, force: true });
  fs.rmSync(zf, { force: true });
  return { installed: m.version };
}

export function rollback(reason) {
  const st = readJson(STATE, {});
  const backup = path.join(UPD, 'backup');
  if (!fs.existsSync(path.join(backup, 'bot.js'))) return false;
  const bad = version();
  copyCode(backup, ROOT);
  writeJson(STATE, { ...st, current: version(), probation: false, crashes: [], bad: [...new Set([...(st.bad || []), bad])].slice(-20) });
  notice(`⏪ <b>Rolled back</b> v${esc(bad)} → v${esc(version())}: ${esc(reason)}. It won't be installed again; I'll get a fixed version out.`);
  log(`Rolled back v${bad} -> v${version()}: ${reason}`);
  return true;
}

// ---------------- running the bot ----------------
export async function supervise() {
  fs.mkdirSync(DATA, { recursive: true });
  let child = null;
  let childStart = 0;
  let stopping = false;
  let backoff = RESTART_MIN_MS;
  let configWait = null;
  let updating = false;
  let lastUpdateCheck = 0;
  const crashTimes = [];

  log(`Supervisor started (v${version()}, pid ${process.pid})`);

  let lastBeat = 0; // last heartbeat time seen (a half-written file read doesn't count as a freeze)
  const start = () => {
    if (stopping) return;
    try { fs.rmSync(HEARTBEAT, { force: true }); } catch {}
    lastBeat = 0;
    childStart = Date.now();
    child = spawn(process.execPath, [path.join(ROOT, 'bot.js')], { cwd: ROOT, stdio: 'inherit', env: { ...process.env, SUPERVISED: '1' } });
    const me = child;
    child.on('exit', (code, sig) => {
      if (child === me) child = null;
      if (stopping || me.expected) return;
      onExit(code, sig);
    });
  };

  const stopChild = (why) =>
    new Promise((res) => {
      const c = child;
      if (!c) return res();
      c.expected = true;
      log(`Stopping bot (${why})`);
      const t = setTimeout(() => c.kill('SIGKILL'), 10000);
      c.once('exit', () => {
        clearTimeout(t);
        res();
      });
      c.kill('SIGTERM');
    });

  const relaunch = async (why) => {
    stopping = true;
    await stopChild(why);
    log(`Relaunching (${why})`);
    process.exit(RELAUNCH);
  };

  const onExit = (code, sig) => {
    const ranMs = Date.now() - childStart;
    if (code === 0) {
      log('Bot exited normally');
      stopping = true;
      process.exit(0);
    }
    if (code === RELAUNCH) return relaunch('bot asked to restart');
    if (code === CONFIG_ERROR) {
      // settings problem: wait until settings.txt or the key file changes, then try again
      log('Bot stopped because of a settings problem; waiting for settings.txt to change');
      const mt = () => ['settings.txt', 'wallet-key.txt'].map((f) => { try { return fs.statSync(path.join(ROOT, f)).mtimeMs; } catch { return 0; } }).join();
      const before = mt();
      const since = Date.now();
      configWait = setInterval(() => {
        if (mt() !== before || Date.now() - since > 10 * 60000) {
          clearInterval(configWait);
          configWait = null;
          start();
        }
      }, 3000);
      return;
    }
    const err = lastError();
    crashTimes.push(Date.now());
    log(`Bot crashed (code ${code}${sig ? ', ' + sig : ''}) after ${Math.round(ranMs / 1000)}s${err ? ': ' + err : ''}`);
    const st = readJson(STATE, {});
    if (st.probation) {
      st.crashes = [...(st.crashes || []), Date.now()];
      writeJson(STATE, st);
      if (st.crashes.length >= PROBATION_CRASHES && rollback(`it crashed ${st.crashes.length} times right after updating${err ? ' (' + err.slice(0, 120) + ')' : ''}`)) return relaunch('rolled back');
    }
    if (ranMs > 10 * 60000) backoff = RESTART_MIN_MS;
    const recent = crashTimes.filter((t) => Date.now() - t < 3600000).length;
    if (recent === 1 || recent % 5 === 0) notice(`♻️ Bot crashed and restarted itself${err ? ': <code>' + esc(err.slice(0, 200)) + '</code>' : ''}${recent > 1 ? ` (${recent} times this hour)` : ''}`);
    setTimeout(start, backoff);
    backoff = Math.min(60000, backoff * 2);
  };

  const tick = async () => {
    if (stopping) return;
    // frozen bot: heartbeat stops
    if (child && !child.expected) {
      const hb = readJson(HEARTBEAT, null);
      if (hb?.at > lastBeat) lastBeat = hb.at;
      const since = Date.now() - childStart;
      const stale = lastBeat ? Date.now() - lastBeat > HEARTBEAT_STALE_MS : since > STARTUP_GRACE_MS;
      if (stale && since > Math.min(STARTUP_GRACE_MS, HEARTBEAT_STALE_MS)) {
        log('Bot stopped responding (no heartbeat); restarting it');
        notice('♻️ Bot froze and was restarted automatically.');
        const c = child;
        c.expected = true;
        c.kill('SIGKILL');
        child = null;
        crashTimes.push(Date.now());
        setTimeout(start, 1000);
        return;
      }
      // a fresh update that runs healthy for the probation window is accepted
      const st = readJson(STATE, {});
      if (st.probation && lastBeat && Date.now() - st.appliedAt > PROBATION_MS) {
        st.probation = false;
        st.crashes = [];
        writeJson(STATE, st);
        log(`v${version()} passed probation`);
      }
    }
    // updates
    const s = settings();
    const every = +env('SUP_UPDATE_EVERY_MS', Math.max(2, +(s.UPDATE_CHECK_MINUTES || 10)) * 60000);
    const forced = fs.existsSync(UPDATE_NOW);
    if (!updating && (forced || Date.now() - lastUpdateCheck > every) && Date.now() - childStart > UPDATE_DELAY_MS) {
      updating = true;
      lastUpdateCheck = Date.now();
      if (forced) try { fs.rmSync(UPDATE_NOW, { force: true }); } catch {}
      try {
        const r = await checkForUpdate({ force: forced });
        if (forced && !r.installed) notice(r.upToDate ? `✅ Already on the latest version (v${esc(r.upToDate)}).` : r.failedTests ? '' : `ℹ️ No update installed: ${esc(r.skipped || 'nothing new')}.`);
        if (r.installed) return relaunch(`updated to v${r.installed}`);
      } catch (e) {
        log('Update check failed:', e.message);
        if (forced) notice(`⚠️ Update check failed: ${esc(e.message)}`);
      } finally {
        updating = false;
      }
    }
  };

  const shutdown = async () => {
    stopping = true;
    if (configWait) clearInterval(configWait);
    await stopChild('shutdown');
    process.exit(0);
  };
  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
  process.on('uncaughtException', (e) => log('Supervisor error:', e?.stack || e));
  process.on('unhandledRejection', (e) => log('Supervisor error:', e?.stack || e));

  start();
  setInterval(() => tick().catch((e) => log('tick error', e.message)), TICK_MS);
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) supervise();
