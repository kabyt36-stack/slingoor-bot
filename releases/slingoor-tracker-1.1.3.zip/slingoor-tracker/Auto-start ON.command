#!/bin/bash
# Runs the tracker in the background and starts it automatically every time you log in.
cd "$(dirname "$0")" || exit 1
DIR="$(pwd)"
. ./scripts/find-node.sh
if [ -z "$NODE" ]; then
  echo "Node.js isn't set up yet — double-click “1 - Setup” first."
  read -r -p "Press Enter to close"
  exit 1
fi
if [ -z "$("$NODE" scripts/setting.js TELEGRAM_BOT_TOKEN)" ]; then
  echo "No Telegram bot token yet — run “1 - Setup” first."
  read -r -p "Press Enter to close"
  exit 1
fi
LABEL=com.slingoor.tracker
PLIST="$HOME/Library/LaunchAgents/$LABEL.plist"

# macOS blocks background programs from reading Desktop / Documents / Downloads,
# so the background copy lives in your home folder instead.
case "$DIR" in
  "$HOME/Desktop"*|"$HOME/Documents"*|"$HOME/Downloads"*|*"/Mobile Documents/"*)
    NEWDIR="$HOME/slingoor-tracker"
    echo "Copying the bot to $NEWDIR so it can run in the background…"
    mkdir -p "$NEWDIR"
    ditto "$DIR" "$NEWDIR" || { echo "❌ Copy failed."; read -r -p "Press Enter to close"; exit 1; }
    cd "$NEWDIR" || exit 1
    DIR="$NEWDIR"
    . ./scripts/find-node.sh
    echo "✅ Copied. From now on use the files in your home folder → slingoor-tracker"
    echo "   (edit settings.txt there, and use the Auto-start buttons there)."
    echo
    ;;
esac
mkdir -p "$HOME/Library/LaunchAgents" "$DIR/logs"
esc() { printf '%s' "$1" | sed -e 's/&/\&amp;/g' -e 's/</\&lt;/g' -e 's/>/\&gt;/g'; }
cat > "$PLIST" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key><string>$LABEL</string>
  <key>ProgramArguments</key>
  <array>
    <string>/usr/bin/caffeinate</string>
    <string>-i</string>
    <string>$(esc "$NODE")</string>
    <string>$(esc "$DIR/scripts/supervisor.js")</string>
  </array>
  <key>WorkingDirectory</key><string>$(esc "$DIR")</string>
  <key>RunAtLoad</key><true/>
  <key>KeepAlive</key>
  <dict><key>SuccessfulExit</key><false/></dict>
  <key>ThrottleInterval</key><integer>10</integer>
  <key>StandardOutPath</key><string>$(esc "$DIR/logs/background.log")</string>
  <key>StandardErrorPath</key><string>$(esc "$DIR/logs/background.log")</string>
</dict>
</plist>
EOF
launchctl bootout "gui/$(id -u)/$LABEL" 2>/dev/null
launchctl bootstrap "gui/$(id -u)" "$PLIST" 2>/dev/null || launchctl load -w "$PLIST"
sleep 2
if launchctl list | grep -q "$LABEL"; then
  echo "✅ Auto-start is ON. The tracker is running in the background now"
  echo "   and will start by itself whenever you log in to this Mac."
  echo "   If it crashes or freezes it restarts itself, and updates install themselves"
  echo "   (tested on this Mac first, rolled back automatically if they misbehave)."
  echo "   (Don't also use “2 - Start Bot” — one copy at a time.)"
  echo "   Logs: $DIR/logs/bot.log"
else
  echo "❌ Couldn't start the background service. Try “2 - Start Bot” instead."
fi
read -r -p "Press Enter to close"
