import { fetchJson, withTimeout } from './util.js';
import { log } from './log.js';

// Coin name / ticker / market cap lookups with a cache.
// pump.fun first (covers pump + PumpSwap coins), DexScreener as a fallback for everything else.
export class Coins {
  constructor({ pump, dexApi }) {
    this.pump = pump;
    this.dexApi = dexApi;
    this.cache = new Map();
  }

  remember(mint, info) {
    if (!mint || !info) return;
    const prev = this.cache.get(mint) || {};
    const next = { ...prev };
    for (const [k, v] of Object.entries(info)) if (v != null && v !== '') next[k] = v;
    this.cache.set(mint, next);
  }

  peek(mint) {
    return this.cache.get(mint) || null;
  }

  async _fromPump(mint) {
    const c = await this.pump.getCoin(mint);
    if (!c?.mint) return null;
    return {
      name: c.name,
      symbol: c.symbol,
      image: c.image_uri,
      twitter: c.twitter,
      nsfw: !!c.nsfw,
      complete: !!c.complete,
      isPump: /pump/i.test(c.program || '') || mint.endsWith('pump') || !!c.bonding_curve,
      mc: +c.usd_market_cap || +c.market_cap_usd || null,
      createdAt: c.created_timestamp || null,
      creator: c.creator,
      mcAt: Date.now(),
    };
  }

  async _fromDex(mint) {
    const j = await fetchJson(`${this.dexApi}/latest/dex/tokens/${mint}`, { timeout: 4000 });
    const pairs = (j?.pairs || []).filter((p) => p.baseToken?.address === mint);
    if (!pairs.length) return null;
    pairs.sort((a, b) => (b.liquidity?.usd || 0) - (a.liquidity?.usd || 0));
    const p = pairs[0];
    return {
      name: p.baseToken.name,
      symbol: p.baseToken.symbol,
      mc: p.marketCap || p.fdv || null,
      createdAt: p.pairCreatedAt || null,
      isPump: false,
      mcAt: Date.now(),
    };
  }

  // fresh=true re-fetches market cap if the cached one is older than 15s.
  async get(mint, { hint, fresh = true, timeoutMs = 2500 } = {}) {
    if (hint) this.remember(mint, hint);
    const cached = this.cache.get(mint);
    if (cached?.name && (!fresh || Date.now() - (cached.mcAt || 0) < 15000)) return this._withAge(cached);
    const info = await withTimeout(
      (async () => {
        try {
          const p = await this._fromPump(mint);
          if (p) return p;
        } catch (e) {
          log.debug('pump coin lookup failed', mint.slice(0, 6), e.message);
        }
        try {
          return await this._fromDex(mint);
        } catch (e) {
          log.debug('dex lookup failed', mint.slice(0, 6), e.message);
          return null;
        }
      })(),
      timeoutMs,
      null,
    );
    if (info) this.remember(mint, info);
    return this._withAge(this.cache.get(mint) || { name: null, symbol: null });
  }

  _withAge(c) {
    return { ...c, ageMs: c.createdAt ? Date.now() - c.createdAt : null };
  }
}
