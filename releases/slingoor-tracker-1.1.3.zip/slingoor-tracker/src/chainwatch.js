import { EventEmitter } from 'node:events';
import { isCandidateLogs, parseWalletTx, tradesFromParsed, pumpTradeEvents, QUOTES } from './parse.js';

const QUOTE_MINTS = Object.keys(QUOTES);
import { sleep, redact, BoundedSet } from './util.js';
import { log } from './log.js';

// Real-time on-chain watcher.
//
// His wallet is "mentioned" in a flood of other people's transactions (spam token
// transfers, people tailing his callouts through pump.fun's router). Fetching all of those
// would burn RPC limits. So we combine two subscriptions:
//   - accountSubscribe(wallet): fires only in slots where HIS account was written
//     (he pays the fee on his own trades, so his SOL balance always changes)
//   - logsSubscribe(mentions wallet): gives the transaction signatures + logs
// and only fetch a transaction when it touched a real program AND his account changed in
// that slot. Anything this misses (rare edge cases) is still caught by the pump.fun poller.
export class ChainWatcher extends EventEmitter {
  constructor({ wsUrl, rpc, wallets }) {
    super();
    this.wsUrl = wsUrl;
    this.rpc = rpc;
    this.wallets = wallets;
    this.ws = null;
    this.subs = new Map(); // subscription id -> {type, wallet}
    this.pendingReq = new Map(); // request id -> {type, wallet}
    this.hot = new Map(); // `${wallet}:${slot}` -> time
    this.cands = new Map(); // `${wallet}:${slot}` -> [{sig, logs}]
    this.fetched = new Set();
    this.reqId = 1;
    this.connected = false;
    this.stopped = false;
    this.lastMsgAt = 0;
    this.connectedAt = 0;
    this.backoff = 1000;
    this.stats = { notifications: 0, candidates: 0, fetched: 0, his: 0, fast: 0, reconnects: 0 };
    this.fastSeen = new BoundedSet(2000);
    this.recentCatches = []; // timing of the last transactions of his we caught
  }

  start() {
    this._connect();
    this._keepalive = setInterval(() => this._tick(), 15000);
  }

  stop() {
    this.stopped = true;
    clearInterval(this._keepalive);
    try {
      this.ws?.close();
    } catch {}
  }

  _connect() {
    if (this.stopped) return;
    let ws;
    try {
      ws = new WebSocket(this.wsUrl);
    } catch (e) {
      log.error('WebSocket create failed:', e.message);
      return this._reconnectLater();
    }
    this.ws = ws;
    this.connectStartedAt = Date.now();
    this.subs.clear();
    this.pendingReq.clear();
    ws.onopen = () => {
      this.connected = true;
      this.connectedAt = Date.now();
      this.lastMsgAt = Date.now();
      if (this.stats.reconnects < 3 || this.stats.reconnects % 20 === 0) log.info(`Chain stream connected (${redact(this.wsUrl)})`);
      for (const w of this.wallets) {
        this._send('accountSubscribe', [w, { commitment: 'confirmed', encoding: 'base64' }], { type: 'account', wallet: w });
        // 'confirmed' (measured: on the public RPC, 'processed' notifications actually arrive ~1s later)
        this._send('logsSubscribe', [{ mentions: [w] }, { commitment: 'confirmed' }], { type: 'logs', wallet: w });
        this._watchQuoteAccounts(w, ws);
      }
      this.emit('status', 'connected');
    };
    ws.onmessage = (ev) => {
      this.lastMsgAt = Date.now();
      let m;
      try {
        m = JSON.parse(typeof ev.data === 'string' ? ev.data : Buffer.from(ev.data).toString());
      } catch {
        return;
      }
      this._onMessage(m);
    };
    ws.onerror = (e) => {
      log.debug('WebSocket error', e?.message || '');
    };
    ws.onclose = (e) => {
      const was = this.connected;
      this.connected = false;
      if (this.ws !== ws) return;
      // only reset the backoff if the connection had been healthy for a while
      if (was && Date.now() - this.connectedAt > 5000) this.backoff = 1000;
      if (was && (this.stats.reconnects < 3 || this.stats.reconnects % 20 === 0)) log.warn(`Chain stream closed (${e?.code ?? ''}), reconnecting… (${this.stats.reconnects} reconnects so far)`);
      this.emit('status', 'disconnected');
      this._reconnectLater();
    };
  }

  // Some of his buys are paid in USDC through a relayer that pays the fee, so his SOL balance
  // doesn't move. Watching his USDC/USDT/USD1/WSOL token accounts catches those slots too.
  async _watchQuoteAccounts(wallet, ws) {
    if (!this.quoteAccounts) this.quoteAccounts = new Map();
    let accts = this.quoteAccounts.get(wallet);
    if (!accts) {
      accts = [];
      for (const mint of QUOTE_MINTS) {
        try {
          const r = await this.rpc.call('getTokenAccountsByOwner', [wallet, { mint }, { encoding: 'jsonParsed', commitment: 'confirmed' }]);
          for (const a of r?.value || []) accts.push(a.pubkey);
        } catch (e) {
          log.debug('quote account lookup failed', e.message);
        }
      }
      this.quoteAccounts.set(wallet, accts);
    }
    if (this.ws !== ws || !this.connected) return;
    for (const a of accts) this._send('accountSubscribe', [a, { commitment: 'confirmed', encoding: 'base64' }], { type: 'account', wallet });
  }

  _reconnectLater() {
    if (this.stopped) return;
    this.stats.reconnects++;
    const wait = this.backoff;
    this.backoff = Math.min(this.backoff * 2, 15000);
    setTimeout(() => this._connect(), wait);
  }

  _send(method, params, meta) {
    const id = this.reqId++;
    if (meta) this.pendingReq.set(id, meta);
    try {
      this.ws.send(JSON.stringify({ jsonrpc: '2.0', id, method, params }));
    } catch {}
  }

  _forceReconnect(reason) {
    log.warn(`Chain stream ${reason}, reconnecting`);
    const old = this.ws;
    if (old) {
      old.onclose = null;
      old.onmessage = null;
      try {
        old.close();
      } catch {}
    }
    this.ws = null;
    this.connected = false;
    this.emit('status', 'disconnected');
    this._reconnectLater();
  }

  _tick() {
    if (!this.connected) {
      if (this.ws && this.ws.readyState === 0 && Date.now() - this.connectStartedAt > 20000) this._forceReconnect('stuck connecting');
      return;
    }
    // Keep the socket busy so proxies don't drop it, and detect silent dead sockets.
    this._send('slotUnsubscribe', [0]);
    if (Date.now() - this.lastMsgAt > 70000) this._forceReconnect('silent for 70s');
    // prune slot maps
    const cutoff = Date.now() - 120000;
    for (const [k, t] of this.hot) if (t < cutoff) this.hot.delete(k);
    for (const [k, v] of this.cands) if (v.t < cutoff) this.cands.delete(k);
    if (this.fetched.size > 5000) this.fetched = new Set([...this.fetched].slice(-2000));
  }

  _onMessage(m) {
    if (m.id != null && this.pendingReq.has(m.id)) {
      const meta = this.pendingReq.get(m.id);
      this.pendingReq.delete(m.id);
      if (m.error) {
        // A connection without its subscriptions is useless: start over.
        log.warn(`Subscribe ${meta.type} failed: ${m.error.message}`);
        setTimeout(() => this.connected && this._forceReconnect('lost its subscription'), 3000);
      } else this.subs.set(m.result, meta);
      return;
    }
    const method = m.method;
    if (method !== 'logsNotification' && method !== 'accountNotification') return;
    const sub = this.subs.get(m.params?.subscription);
    if (!sub) return;
    const slot = m.params.result?.context?.slot;
    const key = `${sub.wallet}:${slot}`;

    if (method === 'accountNotification') {
      this.hot.set(key, Date.now());
      const c = this.cands.get(key);
      if (c) for (const it of c.list) this._fetch(it.sig, sub.wallet, slot);
      return;
    }

    // logsNotification
    this.stats.notifications++;
    const v = m.params.result.value;
    if (!v || v.err) return;
    // fast path: his pump.fun buys AND sells, straight from the logs (no transaction download)
    for (const t of pumpTradeEvents(v.logs)) {
      if (t.user !== sub.wallet) continue;
      const fk = `${v.signature}:${t.mint}`;
      if (this.fastSeen.has(fk)) continue;
      this.fastSeen.add(fk);
      this.stats.fast++;
      if (!t.isBuy) this.stats.fastSells = (this.stats.fastSells || 0) + 1;
      this.emit('trade', {
        key: fk,
        sig: v.signature,
        wallet: sub.wallet,
        mint: t.mint,
        side: t.isBuy ? 'BUY' : 'SELL',
        amountUi: t.tokenAmount,
        preUi: null,
        postUi: null,
        quote: 'SOL',
        solAmount: t.solAmount,
        usdAmount: 0,
        time: null,
        detectedAt: Date.now(),
        source: 'chain',
        fast: true,
      });
    }
    if (!isCandidateLogs(v.logs)) return;
    this.stats.candidates++;
    const launchLike = v.logs.some((l) => /Instruction: (Create|CreateV2|InitializeMint)/.test(l));
    if (this.hot.has(key) || launchLike) return this._fetch(v.signature, sub.wallet, slot);
    const c = this.cands.get(key) || { t: Date.now(), list: [] };
    c.list.push({ sig: v.signature });
    this.cands.set(key, c);
  }

  async _fetch(sig, wallet, slot) {
    const k = `${sig}:${wallet}`;
    if (this.fetched.has(k)) return;
    this.fetched.add(k);
    this.stats.fetched++;
    const seenAt = Date.now();
    let tx = null;
    for (let i = 0; i < 6 && !tx; i++) {
      try {
        tx = await this.rpc.getTransaction(sig);
      } catch (e) {
        log.debug('getTransaction failed', sig.slice(0, 8), e.message);
      }
      if (!tx) await sleep(400 + i * 300);
    }
    if (!tx) {
      log.warn(`Could not load tx ${sig.slice(0, 10)}… (pump.fun poller will cover it)`);
      return;
    }
    const p = parseWalletTx(tx, wallet);
    if (!p) return; // not his transaction
    this.stats.his++;
    this.recentCatches.push({ sig, slot, lagMs: Date.now() - p.blockTime, fetchMs: Date.now() - seenAt, at: Date.now() });
    if (this.recentCatches.length > 20) this.recentCatches.shift();
    const events = tradesFromParsed(p);
    for (const ev of events) {
      ev.detectedAt = seenAt;
      this.emit('trade', ev);
    }
    for (const mint of p.newMints) {
      this.emit('launch', { mint, wallet, sig, time: p.blockTime, source: 'chain', devBuy: events.find((e) => e.mint === mint && e.side === 'BUY') || null });
    }
  }
}
