// The watchdog: restarts after crashes/freezes, installs tested updates, rolls back bad ones.
import test from 'node:test';
import assert from 'node:assert/strict';
import { spawn, spawnSync } from 'node:child_process';
import crypto from 'node:crypto';
import fs from 'node:fs';
import http from 'node:http';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const REAL = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const SUP_SRC = path.join(REAL, 'scripts', 'supervisor.js');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// A tiny fake bot. Its behaviour comes from the "mode" file so tests can change it between runs.
const FAKE_BOT = `
import fs from 'node:fs';
import path from 'node:path';
const root = path.dirname(new URL(import.meta.url).pathname);
const runs = path.join(root, 'data', 'runs.txt');
fs.mkdirSync(path.join(root, 'data'), { recursive: true });
fs.appendFileSync(runs, 'x');
const mode = (() => { try { return fs.readFileSync(path.join(root, 'mode'), 'utf8').trim(); } catch { return 'ok'; } })();
const beat = () => fs.writeFileSync(path.join(root, 'data', 'heartbeat.json'), JSON.stringify({ at: Date.now() }));
if (mode === 'crash') { console.error('boom'); setTimeout(() => process.exit(1), 50); }
else if (mode === 'freeze') { setInterval(() => {}, 1000); }
else if (mode === 'crash-once' && fs.readFileSync(runs, 'utf8').length === 1) { setTimeout(() => process.exit(1), 50); }
else { beat(); setInterval(beat, 100); }
process.on('SIGTERM', () => process.exit(0));
`;

function makeBot(dir, { version = '1.0.0', mode = 'ok', testOk = true } = {}) {
  fs.mkdirSync(path.join(dir, 'scripts'), { recursive: true });
  fs.mkdirSync(path.join(dir, 'test'), { recursive: true });
  fs.writeFileSync(path.join(dir, 'bot.js'), FAKE_BOT + `\n// v${version}\n`);
  fs.writeFileSync(path.join(dir, 'package.json'), JSON.stringify({ name: 'x', version, type: 'module' }));
  fs.copyFileSync(SUP_SRC, path.join(dir, 'scripts', 'supervisor.js'));
  fs.writeFileSync(path.join(dir, 'test', 'a.test.js'), `import test from 'node:test'; import assert from 'node:assert'; test('t', () => assert.ok(${testOk}));\n`);
  fs.writeFileSync(path.join(dir, 'mode'), mode);
  return dir;
}

function tmp() {
  return fs.mkdtempSync(path.join(os.tmpdir(), 'sup-'));
}

function zipOf(dir) {
  const out = path.join(tmp(), 'pkg.zip');
  const r = spawnSync('zip', ['-qr', out, 'slingoor-tracker'], { cwd: dir });
  assert.equal(r.status, 0, 'zip failed');
  return fs.readFileSync(out);
}

// Serves /owner/repo/main/update.json and the zip, like raw.githubusercontent.com
async function updateServer(zipBuf, version, { sha } = {}) {
  const sum = sha || crypto.createHash('sha256').update(zipBuf).digest('hex');
  const srv = http.createServer((req, res) => {
    const u = new URL(req.url, 'http://x');
    if (u.pathname === '/owner/repo/main/update.json') {
      res.setHeader('content-type', 'application/json');
      return res.end(JSON.stringify({ version, zip: `releases/bot-${version}.zip`, sha256: sum, notes: 'faster sells' }));
    }
    if (u.pathname === `/owner/repo/main/releases/bot-${version}.zip`) return res.end(zipBuf);
    res.statusCode = 404;
    res.end();
  });
  await new Promise((r) => srv.listen(0, '127.0.0.1', r));
  return { srv, url: `http://127.0.0.1:${srv.address().port}/owner/repo/main/update.json` };
}

function runSup(root, env = {}) {
  const p = spawn(process.execPath, [path.join(root, 'scripts', 'supervisor.js')], {
    cwd: root,
    env: {
      ...process.env,
      BOT_ROOT: root,
      SETTINGS_FILE: '',
      SUP_TICK_MS: '100',
      SUP_HEARTBEAT_STALE_MS: '1500',
      SUP_STARTUP_GRACE_MS: '1500',
      SUP_RESTART_MIN_MS: '100',
      SUP_UPDATE_DELAY_MS: '300',
      SUP_UPDATE_EVERY_MS: '600000',
      SUP_PROBATION_MS: '60000',
      SUP_PROBATION_CRASHES: '3',
      UPDATE_URL: 'http://127.0.0.1:1/none/none/update.json',
      ...env,
    },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  let out = '';
  p.stdout.on('data', (d) => (out += d));
  p.stderr.on('data', (d) => (out += d));
  p.done = new Promise((r) => p.on('exit', (code) => r(code)));
  p.out = () => out;
  p.stop = async () => {
    if (p.exitCode == null) p.kill('SIGTERM');
    return p.done;
  };
  return p;
}

const runs = (root) => {
  try {
    return fs.readFileSync(path.join(root, 'data', 'runs.txt'), 'utf8').length;
  } catch {
    return 0;
  }
};
const notices = (root) => {
  try {
    return JSON.parse(fs.readFileSync(path.join(root, 'data', 'notices.json'), 'utf8')).map((n) => n.text).join('\n');
  } catch {
    return '';
  }
};
async function waitFor(what, fn, ms = 15000) {
  const end = Date.now() + ms;
  while (Date.now() < end) {
    if (await fn()) return;
    await sleep(50);
  }
  throw new Error(`timed out waiting for ${what}`);
}

test('supervisor: restarts the bot after a crash and tells Telegram', async () => {
  const root = makeBot(path.join(tmp(), 'bot'), { mode: 'crash-once' });
  const p = runSup(root);
  try {
    await waitFor('second run', () => runs(root) >= 2);
    await waitFor('crash notice', () => /crashed and restarted itself/.test(notices(root)));
    await sleep(500);
    assert.equal(runs(root), 2, 'healthy after the restart, no more restarts');
  } finally {
    await p.stop();
  }
});

test('supervisor: a frozen bot (no heartbeat) gets killed and restarted', async () => {
  const root = makeBot(path.join(tmp(), 'bot'), { mode: 'freeze' });
  const p = runSup(root);
  try {
    await sleep(300);
    fs.writeFileSync(path.join(root, 'mode'), 'ok'); // next start is healthy
    await waitFor('restart after freeze', () => runs(root) >= 2, 10000);
    assert.match(notices(root), /froze and was restarted/);
  } finally {
    await p.stop();
  }
});

test('supervisor: installs a newer version only after its tests pass, keeps settings and wallet', async () => {
  const root = makeBot(path.join(tmp(), 'bot'), { version: '1.0.0' });
  fs.writeFileSync(path.join(root, 'settings.txt'), 'TELEGRAM_BOT_TOKEN=keepme\n');
  fs.writeFileSync(path.join(root, 'wallet-key.txt'), 'SECRET');
  const rel = tmp();
  makeBot(path.join(rel, 'slingoor-tracker'), { version: '1.1.0' });
  fs.writeFileSync(path.join(rel, 'slingoor-tracker', 'settings.txt'), 'TELEGRAM_BOT_TOKEN=\n'); // must NOT overwrite
  const { srv, url } = await updateServer(zipOf(rel), '1.1.0');
  const p = runSup(root, { UPDATE_URL: url });
  try {
    const code = await Promise.race([p.done, sleep(30000).then(() => 'timeout')]);
    assert.equal(code, 75, 'asks to be relaunched after installing\n' + p.out());
    assert.equal(JSON.parse(fs.readFileSync(path.join(root, 'package.json'))).version, '1.1.0');
    assert.match(fs.readFileSync(path.join(root, 'bot.js'), 'utf8'), /v1\.1\.0/);
    assert.equal(fs.readFileSync(path.join(root, 'settings.txt'), 'utf8'), 'TELEGRAM_BOT_TOKEN=keepme\n');
    assert.equal(fs.readFileSync(path.join(root, 'wallet-key.txt'), 'utf8'), 'SECRET');
    assert.match(notices(root), /Updated<\/b> v1\.0\.0 → v1\.1\.0/);
    assert.match(notices(root), /faster sells/);
    assert.ok(fs.existsSync(path.join(root, 'data', 'update', 'backup', 'bot.js')), 'old version backed up');
  } finally {
    await p.stop();
    srv.close();
  }
});

test('supervisor: an update whose tests fail on this machine is not installed', async () => {
  const root = makeBot(path.join(tmp(), 'bot'), { version: '1.0.0' });
  const rel = tmp();
  makeBot(path.join(rel, 'slingoor-tracker'), { version: '1.2.0', testOk: false });
  const { srv, url } = await updateServer(zipOf(rel), '1.2.0');
  const p = runSup(root, { UPDATE_URL: url });
  try {
    await waitFor('failed-test notice', () => /failed its tests/.test(notices(root)), 30000);
    assert.equal(JSON.parse(fs.readFileSync(path.join(root, 'package.json'))).version, '1.0.0');
    assert.equal(p.exitCode, null, 'keeps running the old version');
    const st = JSON.parse(fs.readFileSync(path.join(root, 'data', 'update', 'state.json')));
    assert.deepEqual(st.bad, ['1.2.0']);
  } finally {
    await p.stop();
    srv.close();
  }
});

test('supervisor: a corrupted download or a zip from another repo is refused', async () => {
  const root = makeBot(path.join(tmp(), 'bot'), { version: '1.0.0' });
  const rel = tmp();
  makeBot(path.join(rel, 'slingoor-tracker'), { version: '1.3.0' });
  const { srv, url } = await updateServer(zipOf(rel), '1.3.0', { sha: 'a'.repeat(64) });
  const p = runSup(root, { UPDATE_URL: url });
  try {
    await waitFor('checksum error', () => /checksum mismatch/.test(p.out()), 15000);
    assert.equal(JSON.parse(fs.readFileSync(path.join(root, 'package.json'))).version, '1.0.0');
  } finally {
    await p.stop();
    srv.close();
  }
  const { sameSource } = await import(SUP_SRC);
  const m = 'https://raw.githubusercontent.com/kabyt36-stack/slingoor-bot/main/update.json';
  assert.equal(sameSource(m, 'releases/x.zip'), true);
  assert.equal(sameSource(m, 'https://raw.githubusercontent.com/kabyt36-stack/slingoor-bot/main/releases/x.zip'), true);
  assert.equal(sameSource(m, 'https://raw.githubusercontent.com/evil/slingoor-bot/main/x.zip'), false);
  assert.equal(sameSource(m, 'https://evil.com/kabyt36-stack/slingoor-bot/x.zip'), false);
  assert.equal(sameSource(m, 'http://raw.githubusercontent.com/kabyt36-stack/slingoor-bot/main/x.zip'), false);
});

test('supervisor: a new version that keeps crashing is rolled back automatically', async () => {
  const root = makeBot(path.join(tmp(), 'bot'), { version: '1.0.0' });
  const rel = tmp();
  makeBot(path.join(rel, 'slingoor-tracker'), { version: '1.4.0' });
  // the new version passes its tests but crashes when it actually runs
  fs.writeFileSync(path.join(rel, 'slingoor-tracker', 'bot.js'), "console.error('new version boom'); process.exit(1);\n// v1.4.0\n");
  const { srv, url } = await updateServer(zipOf(rel), '1.4.0');
  let p = runSup(root, { UPDATE_URL: url });
  try {
    assert.equal(await Promise.race([p.done, sleep(30000).then(() => 'timeout')]), 75, p.out());
    assert.equal(JSON.parse(fs.readFileSync(path.join(root, 'package.json'))).version, '1.4.0');
    // relaunched (like launchd / the Start Bot window does): crashes 3x then rolls back
    p = runSup(root, { UPDATE_URL: url });
    const code = await Promise.race([p.done, sleep(20000).then(() => 'timeout')]);
    assert.equal(code, 75, p.out());
    assert.equal(JSON.parse(fs.readFileSync(path.join(root, 'package.json'))).version, '1.0.0');
    assert.match(notices(root), /Rolled back<\/b> v1\.4\.0 → v1\.0\.0/);
    // and it isn't installed again
    p = runSup(root, { UPDATE_URL: url });
    await waitFor('healthy old version', () => runs(root) >= 1 && fs.existsSync(path.join(root, 'data', 'heartbeat.json')));
    await sleep(1500);
    assert.equal(p.exitCode, null);
    assert.equal(JSON.parse(fs.readFileSync(path.join(root, 'package.json'))).version, '1.0.0');
  } finally {
    await p.stop();
    srv.close();
  }
});

test('supervisor: newer() compares versions', async () => {
  const { newer } = await import(SUP_SRC);
  assert.equal(newer('1.1.0', '1.0.9'), true);
  assert.equal(newer('1.10.0', '1.9.0'), true);
  assert.equal(newer('1.0.0', '1.0.0'), false);
  assert.equal(newer('0.9', '1.0.0'), false);
});
