import { accountKeysOf } from './parse.js';
import fs from 'node:fs';
import path from 'node:path';
import { log } from './log.js';
import { traderReport } from './paper.js';
import { signTx } from './solana.js';
import { sleep, escHtml as e, fmtSol, fmtNum, fmtPct, fmtAgo, fmtUsd, shortAddr, withTimeout } from './util.js';
import { linkButtons } from './format.js';
import { classify } from './narrative.js';
import { featureKeys, keyLabel } from './learn.js';

const LAMPORTS = 1e9;
const DUST_TOKENS = 1e-6;

const SOL_MINT = 'So11111111111111111111111111111111111111112';

// Builds swaps with Jupiter (free, routes pump.fun bonding-curve coins within seconds of launch,
// PumpSwap, Raydium, Meteora…) and falls back to PumpPortal if Jupiter has no route.
// Every transaction is signed with OUR key here on this computer and sent through our own RPC;
// the key never leaves this machine.
// a buy into a coin we already hold (an add): no dev check
const isAddLike = (c, mint) => c.positions?.[mint]?.tokens > 0;

export class Swapper {
  constructor({ rpc, kp, jupBase, jupKey, portalBase, slippage, priorityFee, pool = 'auto', confirmTimeoutMs = 60000, jitoUrls = [] }) {
    this.jitoUrls = jitoUrls;
    this.rpc = rpc;
    this.kp = kp;
    this.jupBase = jupBase;
    this.jupKey = jupKey;
    this.portalBase = portalBase;
    this.slippage = slippage;
    this.priorityFee = priorityFee;
    this.pool = pool;
    this.confirmTimeoutMs = confirmTimeoutMs;
    this.jupNextAt = 0;
    this.lastVenue = null;
  }

  // Jupiter rate-limit state. Extra wallets share the main wallet's (sw.jl = main.jl) so all wallets
  // together stay inside one API key's limit.
  get jl() {
    return (this._jl ||= { calls: [], blockedUntil: 0 });
  }
  set jl(v) {
    this._jl = v;
  }
  get jupCalls() {
    return this.jl.calls;
  }
  set jupCalls(v) {
    this.jl.calls = v;
  }
  get jupBlockedUntil() {
    return this.jl.blockedUntil;
  }
  set jupBlockedUntil(v) {
    this.jl.blockedUntil = v;
  }

  // background = a check that must never take a slot a trade might need right now
  async _jup(pathAndQuery, body, { background = false } = {}) {
    for (let attempt = 0; ; attempt++) {
      // free Jupiter API: 5 calls per 10s. Calls go out instantly while there's room in the window
      // (so a buy's quote + swap never wait), and only queue up when the window is full.
      if (background && this.jupBlockedUntil > Date.now()) throw Object.assign(new Error('busy: Jupiter is rate-limiting'), { busy: true });
      // calls allowed per ~10s window: keyless 5 (0.5/s); free key 10 (1/s); paid keys set JUPITER_RPS
      const max = this.jupWindowMax || (this.jupKey ? 10 : 5);
      if (background) {
        this.jupCalls = (this.jupCalls || []).filter((t) => Date.now() - t < 10500);
        // leave room for a full buy or sell (quote + swap) plus one retry
        if (this.jupCalls.length > max - 4) throw Object.assign(new Error('busy: Jupiter slots kept free for trades'), { busy: true });
      }
      for (;;) {
        this.jupCalls = (this.jupCalls || []).filter((t) => Date.now() - t < 10500);
        if (this.jupCalls.length < max) break;
        await sleep(Math.max(50, 10500 - (Date.now() - this.jupCalls[0])));
      }
      this.jupCalls.push(Date.now());
      const ctl = new AbortController();
      const t = setTimeout(() => ctl.abort(), 8000);
      let res;
      let text;
      try {
        res = await fetch(`${this.jupBase}${pathAndQuery}`, {
          method: body ? 'POST' : 'GET',
          headers: { 'content-type': 'application/json', ...(this.jupKey ? { 'x-api-key': this.jupKey } : {}) },
          body: body ? JSON.stringify(body) : undefined,
          signal: ctl.signal,
        });
        text = await res.text();
      } catch (err) {
        if (attempt < 2) continue;
        throw new Error(err.name === 'AbortError' ? 'Jupiter did not answer in 8s' : `Jupiter unreachable: ${err.message}`);
      } finally {
        clearTimeout(t);
      }
      if (res.status === 429 && attempt < 5) {
        // free tier: 5 calls per ~10s window. Wait until the window frees up.
        const reset = Number(res.headers.get('x-ratelimit-reset')) * 1000;
        const wait = reset > Date.now() ? Math.min(10000, reset - Date.now() + 150) : 2000;
        this.jupBlockedUntil = Date.now() + wait;
        log.debug(`Jupiter rate limit, waiting ${wait}ms`);
        await sleep(wait);
        continue;
      }
      if (res.status >= 500 && attempt < 2) {
        await sleep(800 * (attempt + 1));
        continue;
      }
      let j = null;
      try {
        j = JSON.parse(text);
      } catch {}
      if (res.status !== 200) throw Object.assign(new Error(`Jupiter ${res.status}: ${(j?.error || j?.message || text || '').toString().slice(0, 160)}`), { status: res.status, noRoute: /ROUTE|TRADABLE|not tradable|No route/i.test(text) });
      return j;
    }
  }

  async _jupBuild({ inputMint, outputMint, amount, slippage }, { allowSimError = false } = {}) {
    const q = await this._jup(`/quote?inputMint=${inputMint}&outputMint=${outputMint}&amount=${amount}&slippageBps=${Math.round((slippage || this.slippage) * 100)}&restrictIntermediateTokens=true`);
    if (!q?.outAmount) throw Object.assign(new Error('Jupiter found no route'), { noRoute: true });
    const s = await this._jup('/swap', {
      quoteResponse: q,
      userPublicKey: this.kp.publicKey,
      wrapAndUnwrapSol: true,
      dynamicComputeUnitLimit: true,
      prioritizationFeeLamports: { priorityLevelWithMaxLamports: { maxLamports: Math.round(this.priorityFee * LAMPORTS), priorityLevel: this.priorityLevel || 'veryHigh' } },
    });
    if (!s?.swapTransaction) throw new Error('Jupiter returned no transaction');
    if (s.simulationError && !allowSimError) throw new Error(`Jupiter's test run of the swap failed: ${explainSim(s.simulationError)}`);
    const tx = new Uint8Array(Buffer.from(s.swapTransaction, 'base64'));
    tx.quote = { inAmount: +q.inAmount || +amount, outAmount: +q.outAmount }; // V2.9.6: for the chase check
    return tx;
  }

  // What selling `raw` tokens would really pay right now (Jupiter quote, SOL). Used to double-check
  // profit sells: the outside price feed can be stale or wrong for some coins (e.g. coins traded against $PUMP).
  async quoteSellSol(mint, raw) {
    const q = await this._jup(`/quote?inputMint=${mint}&outputMint=${SOL_MINT}&amount=${raw}&slippageBps=100&restrictIntermediateTokens=true`);
    return q?.outAmount ? Number(q.outAmount) / LAMPORTS : null;
  }

  async _portalBuild({ action, mint, amount, denominatedInSol, slippage = null }) {
    const ctl = new AbortController();
    const t = setTimeout(() => ctl.abort(), 8000);
    try {
      const res = await fetch(`${this.portalBase}/trade-local`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          publicKey: this.kp.publicKey,
          action,
          mint,
          amount,
          denominatedInSol: denominatedInSol ? 'true' : 'false',
          slippage: slippage || this.slippage,
          priorityFee: this.priorityFee,
          pool: this.pool,
        }),
        signal: ctl.signal,
      });
      const buf = new Uint8Array(await res.arrayBuffer());
      if (res.status !== 200) {
        const msg = new TextDecoder().decode(buf).slice(0, 200);
        throw Object.assign(new Error(`PumpPortal ${res.status}: ${msg || 'no transaction'}`), { status: res.status });
      }
      if (buf.length < 100) throw new Error('PumpPortal returned an empty transaction');
      return buf;
    } catch (err) {
      if (err.name === 'AbortError') throw new Error('PumpPortal did not answer in 8s');
      throw err;
    } finally {
      clearTimeout(t);
    }
  }

  // Can Jupiter sell this coin right now? (some new pump.fun coin types can be bought but not sold yet)
  async canSell(mint) {
    const bal = await this.rpc.getTokenBalance(this.kp.publicKey, mint);
    if (!(bal.raw > 0n)) return null;
    try {
      const q = await this._jup(`/quote?inputMint=${mint}&outputMint=${SOL_MINT}&amount=${bal.raw}&slippageBps=${Math.round(this.slippage * 100)}`, null, { background: true });
      return !!q?.outAmount;
    } catch (err) {
      if (err.noRoute) return false;
      if (err.busy) return 'busy';
      return null; // unknown (rate limit / network)
    }
  }

  // buy: amount = SOL to spend. sell: amount = "40%" of what we hold.
  async build({ action, mint, amount, knownRaw = null, slippage = null }) {
    let jupReq;
    let portalReq;
    if (action === 'buy') {
      jupReq = { inputMint: SOL_MINT, outputMint: mint, amount: Math.round(amount * LAMPORTS), slippage };
      portalReq = { action, mint, amount, denominatedInSol: true };
    } else {
      const pct = Math.min(100, Math.max(0, parseFloat(amount)));
      // knownRaw = our exact token amount from our own last trade: saves a network round trip
      const bal = knownRaw != null ? { raw: BigInt(knownRaw) } : await this.rpc.getTokenBalance(this.kp.publicKey, mint);
      if (!(bal.raw > 0n)) throw Object.assign(new Error('wallet holds none of this coin'), { nothing: true });
      const raw = pct >= 100 ? bal.raw : (bal.raw * BigInt(Math.round(pct * 100))) / 10000n;
      if (raw <= 0n) throw Object.assign(new Error('amount to sell rounds to 0'), { nothing: true });
      jupReq = { inputMint: mint, outputMint: SOL_MINT, amount: raw.toString(), slippage };
      portalReq = { action, mint, amount: `${pct}%`, denominatedInSol: false };
    }
    try {
      const tx = await this._jupBuild(jupReq);
      this.lastVenue = 'Jupiter';
      return tx;
    } catch (err) {
      if (!this.portalBase) throw err;
      log.warn(`Jupiter couldn't build the ${action} (${err.message}), trying PumpPortal`);
      try {
        const tx = await this._portalBuild({ ...portalReq, slippage });
        // PumpPortal builds a SOL trade even for coins priced in another token (his $BTC / $PUMP pairs),
        // which then fails on-chain ("UnsupportedQuoteMint") and still costs the fee. Check it first.
        const sim = typeof this.rpc?.call !== 'function' ? null : await this.rpc
          .call('simulateTransaction', [Buffer.from(tx).toString('base64'), { encoding: 'base64', sigVerify: false, replaceRecentBlockhash: true, commitment: 'processed' }], { priority: true })
          .catch(() => null);
        const simErr = sim?.value?.err;
        if (simErr) {
          const why = (sim.value.logs || []).map((l) => l.match(/Error Message: (.+)$|Error Code: (\w+)/)).filter(Boolean).map((m) => m[1] || m[2])[0];
          throw Object.assign(new Error(`PumpPortal's ${action} would fail${why ? `: ${why}` : ''}`), { simFailed: true });
        }
        this.lastVenue = 'PumpPortal';
        return tx;
      } catch (err2) {
        // no route on Jupiter AND PumpPortal can't do it: a fresh pool Jupiter hasn't indexed yet -> worth waiting
        throw Object.assign(new Error(`${err.message} · ${err2.message}`), { noRoute: !!err.noRoute || !!err2.simFailed });
      }
    }
  }

  async send(bytes) {
    const { bytes: signed, sig } = signTx(bytes, this.kp);
    const b64 = Buffer.from(signed).toString('base64');
    const opts = { encoding: 'base64', skipPreflight: true, maxRetries: 0 };
    const t0 = Date.now();
    // Send to our RPC and Jito's relay at the same time (Jito validators make most blocks, so it
    // usually lands sooner). The same signed transaction can only ever execute once.
    const viaJito = this.jitoSend(b64);
    const viaRpc = this.rpc.call('sendTransaction', [b64, opts], { priority: true });
    try {
      await viaRpc;
    } catch (err) {
      if (!(await viaJito)) throw err; // only fail if neither route took it
    }
    const sentAt = this.jitoUrls?.length ? t0 : Date.now(); // Jito got it at t0
    let lastSend = Date.now();
    while (Date.now() - t0 < this.confirmTimeoutMs) {
      await sleep(400);
      const st = await this.rpc.call('getSignatureStatuses', [[sig], { searchTransactionHistory: false }], { priority: true }).catch(() => null);
      const s = st?.value?.[0];
      if (s?.err) throw Object.assign(new Error(`transaction failed on-chain: ${explainErr(s.err)}`), { sig, onChain: true });
      if (s && (s.confirmationStatus === 'confirmed' || s.confirmationStatus === 'finalized')) return { sig, ms: Date.now() - sentAt, sentAt };
      if (Date.now() - lastSend > 2000) {
        lastSend = Date.now();
        this.rpc.call('sendTransaction', [b64, opts], { priority: true }).catch(() => {});
        this.jitoSend(b64);
      }
    }
    throw Object.assign(new Error('not confirmed in 60s (network busy — it probably expired)'), { sig, expired: true });
  }

  // Fire-and-forget to Jito's relay(s). Resolves true if any relay accepted it.
  jitoSend(b64) {
    const urls = this.jitoUrls || [];
    if (!urls.length) return Object.assign(Promise.resolve(false), { firstAt: null });
    const started = Date.now();
    const p = Promise.all(
      urls.map(async (u) => {
        const ctl = new AbortController();
        const t = setTimeout(() => ctl.abort(), 3000);
        try {
          const r = await fetch(u, {
            method: 'POST',
            headers: { 'content-type': 'application/json' },
            body: JSON.stringify({ jsonrpc: '2.0', id: 1, method: 'sendTransaction', params: [b64, { encoding: 'base64' }] }),
            signal: ctl.signal,
          });
          const j = await r.json().catch(() => null);
          return r.ok && j?.result != null;
        } catch {
          return false;
        } finally {
          clearTimeout(t);
        }
      }),
    ).then((rs) => rs.some(Boolean));
    p.firstAt = started;
    return p;
  }

  // SOL and token change for our wallet in a confirmed transaction.
  async result(sig, mint) {
    for (let i = 0; i < 6; i++) {
      const tx = await this.rpc.getTransaction(sig).catch(() => null);
      if (tx?.meta) {
        const m = tx.meta;
        const sol = ((m.postBalances?.[0] ?? 0) - (m.preBalances?.[0] ?? 0)) / LAMPORTS;
        const tok = (list) =>
          (list || []).filter((b) => b.mint === mint && b.owner === this.kp.publicKey).reduce((a, b) => a + +(b.uiTokenAmount?.uiAmountString || 0), 0);
        const raw = (list) => (list || []).filter((b) => b.mint === mint && b.owner === this.kp.publicKey).reduce((a, b) => a + BigInt(b.uiTokenAmount?.amount || 0), 0n);
        // a coin account created by this trade: its ~0.002 SOL rent is a deposit (the bot gets it back
        // when it closes the empty account), not part of the price
        const had = new Set((m.preTokenBalances || []).filter((b) => b.mint === mint && b.owner === this.kp.publicKey).map((b) => b.accountIndex));
        let rent = 0;
        for (const b of m.postTokenBalances || []) {
          if (b.mint !== mint || b.owner !== this.kp.publicKey || had.has(b.accountIndex)) continue;
          const d = (m.postBalances?.[b.accountIndex] ?? 0) - (m.preBalances?.[b.accountIndex] ?? 0);
          if (d > 0 && d < 0.01 * LAMPORTS) rent += d;
        }
        return {
          rentSol: rent / LAMPORTS,
          solDelta: sol,
          tokenDelta: tok(m.postTokenBalances) - tok(m.preTokenBalances),
          tokenRawAfter: raw(m.postTokenBalances).toString(),
          feeSol: (m.fee || 0) / LAMPORTS,
        };
      }
      await sleep(800 * (i + 1));
    }
    return null;
  }

  async trade(req, prebuilt = null) {
    const bytes = prebuilt || (await this.build(req));
    chaseCheck(req, bytes.quote);
    const { sig, ms, sentAt } = await this.send(bytes);
    const r = await this.result(sig, req.mint);
    return { sig, ms, sentAt, venue: this.lastVenue, ...(r || {}) };
  }
}

// V2.9.6 don't chase the pump: a buy whose price is already more than maxPriceSol (his buy price + COPY_MAX_CHASE_PERCENT)
// is not sent. q = the quote the transaction was built from (pump.fun coins: 6 decimals).
export function chaseCheck(req, q) {
  if (req?.action !== 'buy' || !(req.maxPriceSol > 0) || !(q?.outAmount > 0) || !(q?.inAmount > 0)) return;
  const ours = q.inAmount / LAMPORTS / (q.outAmount / 1e6);
  if (ours > req.maxPriceSol) {
    const up = Math.round((ours / (req.maxPriceSol / (1 + (req.chasePct || 0) / 100)) - 1) * 100);
    throw Object.assign(new Error(`price already ${up}% above his buy — not chasing it`), { chased: true, upPct: up });
  }
}

function explainSim(e) {
  const s = typeof e === 'string' ? e : JSON.stringify(e);
  if (/insufficient|InsufficientFunds|no record of a prior credit|0x1\b|"Custom":1\b/i.test(s)) return 'not enough SOL in your wallet';
  if (/slippage|0x1771|6001|6002|TooLittle|TooMuch/i.test(s)) return 'price moved more than your slippage';
  return s.slice(0, 140);
}

function explainErr(err) {
  const s = JSON.stringify(err);
  if (/"Custom":6001|"Custom":6002|Slippage|TooMuchSol|TooLittle/i.test(s)) return 'price moved more than your slippage';
  if (/"Custom":1\b|InsufficientFunds|insufficient/i.test(s)) return 'not enough SOL';
  return s.slice(0, 120);
}

// Copies the target's trades with our own wallet: buys a fixed amount when he enters a coin,
// sells the same % of our bag when he sells, everything when he's out, and takes profit at Nx.
export class CopyTrader {
  constructor({ cfg, rpc, kp, swapper, pump, coins, broadcast, getSolPrice, file, targets = [], targetName = '', traderOf = null }) {
    this.targets = targets;
    this.targetName = targetName;
    // which trader a wallet belongs to (sling, cupsey...): each copied coin follows the sells of the one we copied
    this.traderOf = traderOf || (() => targetName);
    this.cfg = cfg; // cfg.copy
    this.rpc = rpc;
    this.kp = kp;
    this.swapper = swapper;
    this.pump = pump;
    this.coins = coins;
    this.broadcast = broadcast;
    this.getSolPrice = getSolPrice;
    this.file = file;
    this.positions = {}; // mint -> {symbol, tokens, costSol, proceedsSol, openedAt, tpDone, buySig}
    this.paused = false;
    this.spentToday = { day: '', sol: 0 };
    this.locks = new Map();
    this.retries = new Map();
    this.prebuilt = new Map(); // mint -> Promise<{bytes, at}>: a buy built while his entry is being confirmed
    this.inflight = new Set();
    this.traded = new Set();
    this.history = new Map(); // mint -> Promise: has he traded this coin before? // coins we've bought with him before (his re-buys of these are copied)
    this.stats = { buys: 0, sells: 0, failed: 0, skipped: 0 };
    this.lastSkip = null;
    this.lastBuy = null; // { sol, symbol, at } of the bot's last buy, shown in /copy
    this.day = null; // today's numbers for the 11:59pm daily recap (see dailyRecap)
    this.quickMode = !!cfg.quickMode; // /quick on|off (saved)
    this.quickFor = new Set(); // /quick <trader> on|off: quick profit only for that trader's coins (saved)
    this.now = () => Date.now();
    this.load();
  }

  load() {
    try {
      if (!fs.existsSync(this.file)) return;
      const j = JSON.parse(fs.readFileSync(this.file, 'utf8'));
      this.positions = j.positions || {};
      this.paused = !!j.paused;
      this.spentToday = j.spentToday || this.spentToday;
      this.lastBuy = j.lastBuy || null;
      this.day = j.day || null;
      if (typeof j.quickMode === 'boolean') this.quickMode = j.quickMode;
      if (Array.isArray(j.quickFor)) this.quickFor = new Set(j.quickFor);
      this.traded = new Set([...(j.traded || []), ...Object.keys(this.positions)]);
      this.tripLog = Array.isArray(j.tripLog) ? j.tripLog : [];
      this.lifeByLeader = j.lifeByLeader && typeof j.lifeByLeader === 'object' ? j.lifeByLeader : {};
    } catch (err) {
      log.warn('Could not read copy-trade file:', err.message);
    }
  }

  save() {
    try {
      fs.mkdirSync(path.dirname(this.file), { recursive: true });
      const tmp = this.file + '.tmp';
      fs.writeFileSync(tmp, JSON.stringify({ positions: this.positions, paused: this.paused, spentToday: this.spentToday, lastBuy: this.lastBuy, day: this.day, quickMode: this.quickMode, quickFor: [...(this.quickFor || [])], traded: [...this.traded].slice(-3000), tripLog: (this.tripLog || []).slice(-1000), lifeByLeader: this.lifeByLeader || {} }, null, 1));
      fs.renameSync(tmp, this.file);
    } catch (err) {
      log.error('Could not save copy-trade file:', err.message);
    }
  }

  setPaused(v) {
    this.paused = v;
    this.save();
  }

  // Runs jobs for the same coin one after another (a sell waits for our buy to land).
  _locked(mint, fn) {
    const prev = this.locks.get(mint) || Promise.resolve();
    const run = prev.then(fn).catch((err) => log.error('Copy trade error:', err.stack || err.message));
    this.locks.set(mint, run);
    run.finally(() => {
      if (this.locks.get(mint) === run) this.locks.delete(mint);
    });
    return run;
  }

  async _sym(mint) {
    const c = await withTimeout(this.coins.get(mint, { fresh: false, timeoutMs: 2000 }), 2500, null);
    return c?.symbol ? `$${c.symbol}` : shortAddr(mint);
  }

  // Every buy of his that the bot doesn't copy is told in Telegram with the reason (once per coin per 5 min).
  _skip(mint, why, { notify = true } = {}) {
    this.stats.skipped++;
    this.lastSkip = { mint, why, at: Date.now() };
    // /skips: the last skips with their reason (alerts for skips are off, this is where to look)
    (this.skips ||= []).push({ mint, why, at: Date.now(), sym: this.positions[mint]?.symbol || null });
    if (this.skips.length > 40) this.skips.shift();
    log.info(`Copy: skipped ${shortAddr(mint)} — ${why}`);
    if (!notify || this.cfg.skipAlerts === false) return;
    this.skipAlerted ||= new Map();
    const last = this.skipAlerted.get(mint);
    if (last && Date.now() - last < 300000) return;
    this.skipAlerted.set(mint, Date.now());
    if (this.skipAlerted.size > 500) this.skipAlerted.delete(this.skipAlerted.keys().next().value);
    this._sym(mint)
      .then((sym) => this._notify(`⏭ <b>BOT SKIPPED</b> <b>${e(sym)}</b>\n❓ Why: ${e(why)}\n<code>${mint}</code>`, mint))
      .catch(() => {});
  }

  async _notify(html, mint, sig) {
    try {
      await this.broadcast(html, linkButtons(mint, { sig }));
    } catch {}
  }

  // How much SOL to spend when he buys `hisSol`. Scales with his size (1 SOL -> 0.5, 1000 SOL -> 1 by
  // default), and never more than COPY_MAX_WALLET_PERCENT of the wallet or COPY_MAX_PER_COIN_SOL per coin.
  // Returns null if the buy would be too small to bother.
  sizeFor(hisSol, mint, { pending = 0 } = {}) {
    const c = this.cfg;
    let amt;
    if (c.sizeMode !== 'scale') amt = c.buySol;
    else if (!(hisSol > 0)) amt = c.scaleAt1; // his size unknown (some new coin types don't log it): size as if he bought 1 SOL
    else if (hisSol <= 1) amt = hisSol * c.scaleAt1;
    else amt = c.scaleAt1 + (c.maxBuySol - c.scaleAt1) * Math.min(1, Math.log10(hisSol) / Math.log10(Math.max(10, c.scaleMaxAt)));
    // his small buys: buy at least COPY_FLOOR_BUY_SOL (then the wallet/per-coin caps below still apply)
    if (c.floorBuySol > 0) amt = Math.max(amt, c.floorBuySol);
    if (c.maxBuySol > 0) amt = Math.min(amt, c.maxBuySol);
    if (c.maxWalletPct > 0 && this.balCache?.sol > 0) amt = Math.min(amt, (this.balCache.sol * c.maxWalletPct) / 100);
    if (c.maxPerCoinSol > 0) {
      const p = this.positions[mint];
      const already = (p?.tokens > 0 ? p.costSol || 0 : 0) + pending;
      amt = Math.min(amt, c.maxPerCoinSol - already);
    }
    amt = Math.floor(amt * 1e4) / 1e4;
    return amt >= (c.minBuySol || 0.005) ? amt : null;
  }

  // V2.11 bigger / smaller buy (2+ traders in the same coin, his big bets, his small test buys): x times the
  // normal size, still never more than COPY_MAX_WALLET_PERCENT of the wallet or COPY_MAX_PER_COIN_SOL per coin
  // V2.11.25 growth sizing (Khalil, Nov 13 11:39am: "start risking bigger and earn bigger and the more we earn the
  // bigger trades we go"): every buy is at least GROWTH_MIN_BUY_SOL (0.08), or GROWTH_PERCENT (25%) of this wallet's
  // SOL when that's more — so buys grow with the wallet. Then the tier / runner / big-bet multipliers, never under
  // the minimum and never over GROWTH_MAX_PERCENT (50%) of the wallet.
  growthAmount() {
    const c = this.cfg;
    const bal = this.balCache?.sol > 0 ? this.balCache.sol : 0;
    return Math.floor(Math.max(c.growthMinSol || 0.08, (bal * (c.growthPct || 25)) / 100) * 1e4) / 1e4;
  }

  growthScaled(amount, x, mint) {
    const c = this.cfg;
    let a = amount * (x > 0 ? x : 1);
    const bal = this.balCache?.sol > 0 ? this.balCache.sol : null;
    if (bal != null) a = Math.min(a, (bal * (c.growthMaxPct || 50)) / 100);
    a = Math.max(a, c.growthMinSol || 0.08);
    if (c.maxPerCoinSol > 0) {
      const p = this.positions[mint];
      a = Math.min(a, c.maxPerCoinSol - (p?.tokens > 0 ? p.costSol || 0 : 0));
    }
    a = Math.floor(a * 1e4) / 1e4;
    return a >= (c.minBuySol || 0.005) ? a : null;
  }

  scaled(amount, x, mint) {
    if (this.cfg.growthSize && amount) return this.growthScaled(amount, x, mint);
    if (!amount || !(x > 0) || x === 1) return amount;
    const c = this.cfg;
    let a = amount * x;
    if (c.maxWalletPct > 0 && this.balCache?.sol > 0) a = Math.min(a, (this.balCache.sol * c.maxWalletPct) / 100);
    if (c.maxPerCoinSol > 0) {
      const p = this.positions[mint];
      a = Math.min(a, c.maxPerCoinSol - (p?.tokens > 0 ? p.costSol || 0 : 0));
    }
    a = Math.floor(a * 1e4) / 1e4;
    const min = c.minBuySol || 0.005;
    if (a < min) return x < 1 ? Math.max(min, Math.min(amount, min)) : amount;
    return a;
  }

  // Has he traded this coin before this buy? Looks at the history of his token account for it:
  // anything older than a few minutes means it's an old coin of his, not a fresh entry.
  // 'new' | 'old' | null (couldn't tell).
  checkHistory(ev) {
    const mint = ev.mint;
    const cached = this.history.get(mint);
    if (cached && Date.now() - cached.at < 120000) return cached.p;
    const p = (async () => {
      const wallet = ev.wallet;
      if (!wallet) return null;
      const cutoff = (ev.time || ev.detectedAt || Date.now()) - (this.cfg.newCoinWindowMs ?? 10 * 60000);
      for (let attempt = 0; attempt < 2; attempt++) {
        try {
          const r = await this.rpc.call('getTokenAccountsByOwner', [wallet, { mint }, { encoding: 'jsonParsed', commitment: 'confirmed' }], { priority: true });
          const accts = (r?.value || []).map((a) => a.pubkey).filter(Boolean);
          if (!accts.length) return 'new';
          for (const a of accts) {
            const sigs = (await this.rpc.call('getSignaturesForAddress', [a, { limit: 25, commitment: 'confirmed' }], { priority: true })) || [];
            const older = sigs.find((s) => s.signature !== ev.sig && s.blockTime && s.blockTime * 1000 < cutoff);
            if (older) return { old: true, at: older.blockTime * 1000 };
          }
          return 'new';
        } catch (e) {
          log.debug('history check failed', e.message);
          await sleep(300);
        }
      }
      return null;
    })().then((v) => (v && v.old ? 'old:' + v.at : v));
    this.history.set(mint, { at: Date.now(), p });
    if (this.history.size > 500) this.history.delete(this.history.keys().next().value);
    return p;
  }

  // true while we hold, are buying or are selling this coin (its token account must not be closed)
  isBusy(mint) {
    return !!(this.positions[mint]?.tokens > 0 || this.inflight.has(mint) || this.locks.has(mint) || this.pendingBuy?.has(mint) || this.prebuilt.has(mint) || this.retries?.has?.(mint));
  }

  // He bought a coin we don't know he held: build our buy right away (it's only sent if this turns
  // out to be a new entry). Saves the time of the "did he already hold it?" check.
  onMaybeEntry(ev) {
    if (!this.cfg.enabled || this.paused) return;
    const mint = ev.mint;
    if (this.cfg.onlyNewCoins && !this.cfg.copyReentries && !this.traded.has(mint)) this.checkHistory(ev); // runs alongside the build
    if (!this.swapper.build) return;
    if (this.positions[mint]?.tokens > 0 || this.inflight.has(mint) || this.prebuilt.has(mint)) return;
    if (ev.time && Date.now() - ev.time > this.cfg.maxDelayMs) return;
    const amount = this.scaled(this.cfg.growthSize ? this.growthAmount() : this.sizeFor(ev.solAmount, mint), ev.sizeX, mint);
    if (!amount) return;
    const pr = this.swapper
      .build({ action: 'buy', mint, amount, denominatedInSol: true })
      .then((bytes) => ({ bytes, at: Date.now(), amount }))
      .catch(() => null);
    this.prebuilt.set(mint, pr);
    setTimeout(() => this.prebuilt.get(mint) === pr && this.prebuilt.delete(mint), 20000).unref?.();
  }

  // A booster trader (TRADER_BOOSTERS "decu>bot") bought a coin we copied from the leader: hold it for the
  // jump (no quick sell; wider dip before selling) and sell 100% when the booster sells.
  noteBooster({ ev, kind }) {
    if (kind !== 'ENTRY' && kind !== 'ADD') return false;
    const p = this.positions[ev.mint];
    const who = ev.wallet ? this.traderOf(ev.wallet) : null;
    if (!p || !(p.tokens > 0) || !who) return false;
    if (!(this.cfg.boosters || []).some(([b, l]) => b === who && l === p.leader)) return false;
    if (p.boostedBy) return true;
    p.boostedBy = who;
    p.tradersIn = true;
    log.info(`${p.symbol || ev.mint}: ${who} bought in after ${p.leader} — holding for the jump, selling all when ${who} sells`);
    this.save();
    return true;
  }

  // Called by the tracker for every trade of his it understands.
  onSignal({ ev, kind, pre, post, sol, devReady }) {
    if (!this.cfg.enabled) return;
    const mint = ev.mint;
    if (kind !== 'ENTRY') this.prebuilt.delete(mint); // it was an add: drop the prepared buy
    if (kind === 'ENTRY') this.hisOut?.delete(mint);
    // One buy per coin (default): while our buy of a coin is being decided or sent, more buys of his in the
    // same coin are ignored (no double buys), and once we've bought a coin we never buy it again
    // (no adds, no buying back in after selling) — sells and take-profit still work as normal.
    if ((kind === 'ENTRY' || kind === 'ADD') && this.cfg.oneBuyPerCoin !== false) {
      if (this.inflight.has(mint) || this.pendingBuy?.has(mint) || this.entryPending?.has(mint) || this.locks.has(mint)) return;
      if (this.traded.has(mint) || this.positions[mint]) {
        if (kind === 'ADD' && !(this.positions[mint]?.tokens > 0) && !this.traded.has(mint)) return;
        return this._skip(mint, this.positions[mint]?.tokens > 0 ? 'already holding it — one buy per coin, no adds' : 'already bought and sold this coin once — one buy per coin, no rebuys');
      }
    }
    if (kind === 'ENTRY' || (kind === 'ADD' && this.cfg.copyAdds)) {
      // V2.8.2 checks the buy will need (holder count, learned coin skips) start NOW, alongside the
      // new-coin check and the buy build, instead of one after another right before sending
      if (kind === 'ENTRY') this._earlyChecks(mint, ev, sol);
      // Adds are only followed in coins we bought with him. His old bags (held from before, or coins
      // we skipped) are never bought into; a fresh entry of his (or a re-buy after selling out) is.
      if (kind === 'ADD' && !(this.positions[mint]?.tokens > 0) && !this.inflight.has(mint)) return;
      if (this.paused) return this._skip(mint, 'copy trading is paused');
      // a dev coin the dev watcher decided to buy now (after its dip / holders): the launch is minutes old by design
      const age = devReady ? 0 : ev.time ? Date.now() - ev.time : 0;
      if (age > this.cfg.maxDelayMs) return this._skip(mint, `his buy was ${fmtAgo(age)} ago (older than ${this.cfg.maxDelayMs / 1000}s)`);
      if (this.cfg.minHisBuySol > 0 && sol > 0 && sol < this.cfg.minHisBuySol) return this._skip(mint, `his buy ${fmtSol(sol)} SOL is under COPY_MIN_HIS_BUY_SOL`);
      if (!this.cfg.copyAdds && (this.positions[mint]?.tokens > 0 || this.inflight.has(mint))) return;
      // Only his brand-new coins: a coin he traded before (and we never bought with him) is skipped.
      if (kind === 'ENTRY' && this.cfg.onlyNewCoins && !devReady && !this.traded.has(mint) && !(this.positions[mint]?.tokens > 0)) return this._entryIfNew(mint, ev, sol);
      return this._queueBuy(mint, ev, sol);
    }
    if (!this.cfg.mirrorSells) {
      if (kind !== 'EXIT' && !(kind === 'MOVED' && post <= 0)) return;
    }
    // a coin we copied from one trader only follows THAT trader's sells (another trader selling the same coin is ignored)
    // ...except a booster (e.g. decu on a coin copied from bot): his sell sells it all
    const lead = this.positions[mint]?.leader;
    const seller = ev?.wallet ? this.traderOf(ev.wallet) : null;
    if (lead && seller && seller !== lead) {
      if (this.positions[mint]?.boostedBy === seller && (kind === 'EXIT' || kind === 'PARTIAL' || kind === 'MOVED')) {
        this._locked(mint, () => this._sell(mint, 100, 'mirror', ev));
      }
      return;
    }
    if (kind === 'EXIT' || ((kind === 'MOVED' || kind === 'PARTIAL') && post <= 0)) {
      (this.hisOut ||= new Set()).add(mint);
      if (this.hisOut.size > 500) this.hisOut.delete(this.hisOut.values().next().value);
    }
    if (kind === 'PARTIAL' || kind === 'EXIT' || kind === 'MOVED') {
      const out = kind === 'EXIT' || post <= 0 || (pre > 0 && post / pre < 0.03);
      if (kind === 'MOVED' && !out) return; // he only moved part of his bag to another wallet
      if (!this.positions[mint] && !this.inflight.has(mint)) return;
      const pct = out ? 100 : Math.max(1, Math.min(100, Math.round(((pre - post) / pre) * 100)));
      // V2.8.10: his tiny partial sells (under COPY_MIN_MIRROR_PERCENT, default 10%) are not copied: a 1% sell
      // cost more in fees than it brought in, and made side wallets (which always sell 100%) dump at ~1.0x
      if (!out && pct < (this.cfg.minMirrorPct ?? 10)) {
        log.info(`Copy: ignored his ${pct}% sell of ${this.positions[mint]?.symbol || mint} (under ${this.cfg.minMirrorPct ?? 10}%)`);
        return;
      }
      return this._locked(mint, () => this._sell(mint, pct, out ? 'exit' : 'mirror', ev));
    }
  }

  // "New" = he held none of this coin right before this buy (a first buy, or buying back in after selling
  // out — even if he traded it days ago). Adds to a bag he's holding are never copied.
  async heldBefore(ev) {
    if (ev.preUi != null) return ev.preUi > 0; // read from his transaction itself
    for (let i = 0; i < 2; i++) {
      try {
        const b = await this.rpc.getTokenBalance(ev.wallet, ev.mint, this.cfg.chainCommitment || 'processed');
        return b.ui - (ev.amountUi || 0) > (ev.amountUi || 0) * 0.01;
      } catch {
        await sleep(200);
      }
    }
    return null;
  }

  // Old coins (launched more than COPY_MAX_COIN_AGE_HOURS ago) are never bought, whoever is buying.
  async _tooOld(mint) {
    const max = this.cfg.maxCoinAgeMs ?? 3 * 3600000;
    if (!(max > 0) || !this.coins?.ageMs) return null;
    const age = await withTimeout(this.coins.ageMs(mint), 2500, null).catch(() => null);
    return age != null && age > max ? age : null;
  }

  async _entryIfNew(mint, ev, sol) {
    const ageP = this._tooOld(mint); // runs alongside the other checks and the build
    // COPY_REENTRIES=on: "new" = he held none right before (buying back in after selling counts)
    // V2.8.2: always for quick-profit traders (bot, decu): they flip the same coin again and again, and
    // their buy back in after selling out is a new trade — it was being skipped as "not a new coin for him"
    const lead = ev?.wallet ? this.traderOf(ev.wallet) : null;
    if (this.cfg.copyReentries || (lead && this.cfg.toasters?.includes(lead))) {
      if (ev.preUi != null || ev.preChecked) {
        const old = await ageP;
        if (old) return this._skip(mint, `the coin was launched ${fmtAgo(old)} ago — only new coins are copied (COPY_MAX_COIN_AGE_HOURS)`);
        return this._queueBuy(mint, ev, sol);
      }
      if (!this.prebuilt.has(mint)) this.onMaybeEntry({ ...ev, solAmount: sol || ev.solAmount });
      this.inflight.add(mint);
      let held;
      try {
        held = await withTimeout(this.heldBefore(ev), 4000, null);
      } finally {
        this.inflight.delete(mint);
      }
      const old = await ageP;
      if (held === false && !old) return this._queueBuy(mint, ev, sol);
      if (old) {
        this.prebuilt.delete(mint);
        return this._skip(mint, `the coin was launched ${fmtAgo(old)} ago — only new coins are copied (COPY_MAX_COIN_AGE_HOURS)`);
      }
      this.prebuilt.delete(mint);
      if (held == null) return this._skip(mint, "couldn't check whether he already held it (Solana RPC didn't answer)");
      return this._skip(mint, 'he already holds this coin, so this is an add to his bag, not a new entry');
    }
    // default: only coins he has NEVER traded before (his token account has no history older than a few minutes)
    if (!this.prebuilt.has(mint)) this.onMaybeEntry({ ...ev, solAmount: sol || ev.solAmount });
    this.entryPending ||= new Set();
    this.entryPending.add(mint);
    setTimeout(() => this.entryPending.delete(mint), 6000).unref?.();
    this.inflight.add(mint);
    let h;
    try {
      h = await withTimeout(this.checkHistory(ev), 5000, null);
    } finally {
      this.inflight.delete(mint);
    }
    this.entryPending.delete(mint);
    const old = h === 'new' ? await ageP : null;
    if (old) {
      this.prebuilt.delete(mint);
      return this._skip(mint, `the coin was launched ${fmtAgo(old)} ago — only new coins are copied (COPY_MAX_COIN_AGE_HOURS)`);
    }
    if (h === 'new') return this._queueBuy(mint, ev, sol);
    this.prebuilt.delete(mint);
    if (h == null) return this._skip(mint, "couldn't confirm it's a new coin of his (Solana RPC didn't answer)");
    const at = +h.split(':')[1];
    return this._skip(mint, `not a new coin for him: he first traded it ${fmtAgo(Date.now() - at)} ago (only brand-new coins are copied; COPY_REENTRIES=on in settings.txt to also copy re-buys)`);
  }

  // His buys of the same coin that arrive while we're still buying are added up into one follow-up buy
  // (he often buys in quick bursts), so we don't fire a dozen small trades.
  _queueBuy(mint, ev, hisSol) {
    this.pendingBuy ||= new Map();
    const q = this.pendingBuy.get(mint) || { his: 0, ev, queued: false };
    q.his += hisSol > 0 ? hisSol : 0;
    q.ev = ev;
    this.pendingBuy.set(mint, q);
    if (q.queued) return;
    q.queued = true;
    this.inflight.add(mint);
    return this._locked(mint, async () => {
      const job = this.pendingBuy.get(mint);
      this.pendingBuy.delete(mint);
      try {
        await this._buy(mint, job.ev, job.his);
      } finally {
        if (!this.pendingBuy.has(mint)) this.inflight.delete(mint);
      }
    });
  }

  // V2.8.1 what a coin looks like right now: narrative, X account, market cap, age, his buy size,
  // and (full) holders + how many coins its dev launched. Slow lookups are rate-capped and cached.
  async coinFeatures(mint, hisSol, { full = true } = {}) {
    const c = (await withTimeout(this.coins.get(mint), 2500, null).catch(() => null)) || {};
    const f = { tags: c.name || c.symbol ? classify(c).tags : [], twitter: c.name ? !!c.twitter : null, mc: c.mc ?? null, ageMin: c.ageMs != null ? c.ageMs / 60000 : null, hisSol: hisSol > 0 ? hisSol : null };
    // V2.11.30 volume (last hour, when the price feed has it) and the dev check's answer (both already known, no calls)
    const act = this.coins.activity?.get?.(mint);
    if (act?.volH1 > 0) f.volH1 = act.volH1;
    else if (c.volH1 > 0) f.volH1 = c.volH1;
    const dk = this.devRisk?.known?.(mint)?.kind;
    if (dk) f.devKind = dk;
    if (!full) return f;
    const now = Date.now();
    this._fx ||= { h: 0, d: 0, dev: new Map() };
    if (now - this._fx.h >= 3000) {
      this._fx.h = now;
      f.holders = await withTimeout(this.countHolders(mint), 2000, null).catch(() => null);
    }
    if (c.creator) {
      const hit = this._fx.dev.get(c.creator);
      if (hit != null) f.devCoins = hit;
      else if (now - this._fx.d >= 5000 && this.pump?.getCreatedCoins) {
        this._fx.d = now;
        const r = await withTimeout(this.pump.getCreatedCoins(c.creator, 50), 3000, null).catch(() => null);
        if (r) {
          f.devCoins = Math.max(r.count || 0, r.coins?.length || 0);
          this._fx.dev.set(c.creator, f.devCoins);
          if (this._fx.dev.size > 2000) this._fx.dev.clear();
        }
      }
    }
    return f;
  }

  // a tracked wallet bought a coin (copied or not): the learner follows it (never slows a buy)
  learnSeen(mint, leader, hisSol) {
    if (!this.learner || !leader) return;
    setTimeout(() => this.coinFeatures(mint, hisSol).then((f) => this.learner.coinSeen(mint, leader, f)).catch(() => {}), 1500).unref?.();
  }

  // V2.9.4 holders needed before a buy: TRADER_MIN_HOLDERS for that trader if set, else COPY_MIN_HOLDERS_TO_BUY
  // (30) for everyone — except devs that buy at launch (instant / rug), when no coin has holders yet
  _minHoldersFor(lname) {
    if (!lname) return 0;
    const own = this.cfg.traderMinHolders?.[lname];
    if (own != null) return own;
    if (this.cfg.launchBuyers?.includes(lname)) return 0;
    return this.cfg.minHoldersToBuy || 0;
  }

  _earlyChecks(mint, ev, hisSol) {
    const lname = ev?.wallet ? this.traderOf(ev.wallet) : null;
    if (!lname || this.paused || this.traded.has(mint) || this.positions[mint]) return;
    this.early ||= new Map();
    if (this.early.get(mint)?.at > Date.now() - 15000) return;
    const skipKeys = this.learned?.[lname]?.skip;
    const mh = this._minHoldersFor(lname);
    const mkt = this._marketSkipFor(lname);
    if (!(mh > 0) && !skipKeys?.length && !mkt) return;
    const quiet = (p) => p.catch(() => null);
    const keys = [...(skipKeys || []), ...(mkt || [])];
    this.early.set(mint, {
      at: Date.now(),
      holders: mh > 0 || keys.some((k) => k.startsWith('holders:')) ? quiet(this.countHolders(mint)) : null,
      features: keys.length ? quiet(this.coinFeatures(mint, hisSol, { full: (skipKeys || []).some((k) => /^(holders|dev):/.test(k)) })) : null,
    });
    if (this.early.size > 300) this.early.delete(this.early.keys().next().value);
  }

  // V2.11.30 the market's losing coin kinds (a Set), or null (none / always-copied trader / dev's own launch)
  _marketSkipFor(lname) {
    const m = this.marketSkip;
    if (!m?.size || (lname && (this.cfg.alwaysCopy?.includes(lname) || this.cfg.devNames?.includes(lname)))) return null;
    return m;
  }

  async _buy(mint, ev, hisSol) {
    const lname = ev?.wallet ? this.traderOf(ev.wallet) : null;
    const early = this.early?.get(mint);
    const fresh = early && Date.now() - early.at < 15000 ? early : null;
    // V2.8.1 kinds of coins you chose to skip for this wallet (from /suggestions)
    const skipKeys = lname && this.learned?.[lname]?.skip;
    if (skipKeys?.length) {
      const fp = fresh?.features || this.coinFeatures(mint, hisSol, { full: skipKeys.some((k) => /^(holders|dev):/.test(k)) });
      const f = await withTimeout(fp, 2000, null).catch(() => null);
      const hit = f && featureKeys(f).find((k) => skipKeys.includes(k));
      if (hit) return this._skip(mint, `learned: ${lname}'s ${keyLabel(hit)} lose money`);
    }
    // V2.11.30 market adapt: kinds of coins losing across the market right now are skipped (always-copied excluded).
    // Never waits long: what isn't known within 0.8s doesn't block the buy.
    const mkt = this._marketSkipFor(lname);
    if (mkt) {
      const f = await withTimeout(fresh?.features || this.coinFeatures(mint, hisSol, { full: false }), 800, null).catch(() => null);
      if (f) {
        if (f.holders == null && fresh?.holders) f.holders = await withTimeout(fresh.holders, 50, null).catch(() => null);
        if (!f.devKind) f.devKind = this.devRisk?.known?.(mint)?.kind;
        const hit = featureKeys(f).find((k) => mkt.has(k));
        if (hit) return this._skip(mint, `market: ${keyLabel(hit)} are losing right now`);
      }
    }
    // V2.11.53 late chases and same-name copies (see versions.js). Always-copied traders and devs' launches aren't checked.
    if (this.book && !isAddLike(this, mint) && !(lname && (this.cfg.devNames?.includes(lname) || this.cfg.alwaysCopy?.includes(lname)))) {
      const why = await this.book.check(mint, lname, ev?.priceSol).catch(() => null);
      if (why) return this._skip(mint, why);
    }
    // V2.11.23 dev check: a coin from a fresh dev (no trades before it) — the main wallet skips it, side wallets buy
    // and get out fast. Tracked devs' own launches and always-copied traders (kimchi) are not checked.
    if (this.devRisk && !isAddLike(this, mint) && !(lname && (this.cfg.devNames?.includes(lname) || this.cfg.alwaysCopy?.includes(lname)))) {
      const dr = this.devRisk.known(mint) || (await withTimeout(this.devRisk.check(mint), this.cfg.devCheckWaitMs ?? 300, null).catch(() => null));
      if (dr && this.devRisk.risky(dr.kind)) {
        if (!this.quickMode || ev?.cautious) return this._skip(mint, `fresh dev (no trades before this coin): ${ev?.cautious ? 'cautious hour, no wallet buys it' : 'main wallet skips it'}`);
        ev.freshDev = true;
      }
    }
    // V2.10.1 TRADER_MAX_MC (cupsey:40000): his buys above that market cap are not copied
    const maxMc = lname && this.cfg.traderMaxMc?.[lname];
    if (maxMc > 0 && ev?.priceSol > 0) {
      const mc = ev.priceSol * 1e9 * (this.getSolPrice?.() || 0);
      if (mc > maxMc) return this._skip(mint, `${lname}: market cap $${Math.round(mc / 1000)}k is over his $${Math.round(maxMc / 1000)}k limit`);
    }
    // TRADER_MIN_HOLDERS (e.g. bot:20): no buy into a coin nobody holds yet
    const mh = this._minHoldersFor(lname);
    if (mh > 0) {
      const n = await withTimeout(fresh?.holders || this.countHolders(mint), 1500, null).catch(() => null);
      if (n != null && n < mh) return this._skip(mint, `only ${n} holders (under ${mh})`);
    }
    // limits are checked and a slot reserved before anything async, so a burst of entries can't overshoot them
    const day = new Date().toISOString().slice(0, 10);
    if (this.spentToday.day !== day) this.spentToday = { day, sol: 0 };
    this.reserved ||= 0;
    this.reservedAmt ||= 0;
    const isAdd = this.positions[mint]?.tokens > 0;
    // dev coins: fixed size (DEV_BUY_SOL main / DEV_QUICK_WALLET_BUY_SOL quick wallets)
    const devLeader = ev?.wallet && this.cfg.devNames?.includes(this.traderOf(ev.wallet));
    const leaderName = ev?.wallet ? this.traderOf(ev.wallet) : null;
    const amount = this.scaled(this.cfg.growthSize && !isAdd ? this.growthAmount() : devLeader ? this.cfg.devBuySol : this.cfg.traderBuySol?.[leaderName] && !this.cfg.sellAllAlways ? this.cfg.traderBuySol[leaderName] : this.sizeFor(hisSol, mint), isAdd ? 1 : ev?.sizeX, mint);
    if (!amount) {
      const p = this.positions[mint];
      return this._skip(mint, p && this.cfg.maxPerCoinSol > 0 && p.costSol >= this.cfg.maxPerCoinSol - 0.005 ? `already ${fmtSol(p.costSol)} SOL in this coin (COPY_MAX_PER_COIN_SOL)` : 'buy would be too small');
    }
    const open = Object.values(this.positions).filter((p) => p.tokens > 0).length + this.reserved;
    if (!isAdd && open >= this.cfg.maxOpen) return this._skipNotify(mint, await this._sym(mint), `you already have ${open} open copy positions (COPY_MAX_OPEN_POSITIONS=${this.cfg.maxOpen})`);
    // V2.11.2 neutral traders only buy while the last COPY_HOT_RESERVE slots are still free (kept for hot traders)
    if (!isAdd && ev?.tier === 'neutral' && this.cfg.hotReserve > 0 && open >= this.cfg.maxOpen - this.cfg.hotReserve)
      return this._skip(mint, `${lname || 'neutral trader'} is neutral: keeping the last ${this.cfg.hotReserve} open slots for hot traders`);
    if (this.cfg.dailyLimitSol > 0 && this.spentToday.sol + this.reservedAmt + amount > this.cfg.dailyLimitSol + 1e-9)
      return this._skipNotify(mint, await this._sym(mint), `daily limit reached (${fmtSol(this.spentToday.sol)} of ${fmtSol(this.cfg.dailyLimitSol)} SOL today)`);
    if (!isAdd) this.reserved++;
    this.reservedAmt += amount;
    try {
      return await this._doBuy(mint, ev, hisSol, amount, isAdd);
    } finally {
      if (!isAdd) this.reserved--;
      this.reservedAmt -= amount;
    }
  }

  async _doBuy(mint, ev, hisSol, amount = this.cfg.buySol, isAdd = false) {
    // nothing slow before the buy: the coin name is looked up in parallel, and the wallet balance
    // comes from a copy refreshed in the background
    const symP = this._sym(mint);
    const need = amount + this.cfg.keepSol + this.cfg.priorityFee + 0.003;
    const bal = this.balCache && Date.now() - this.balCache.at < 60000 ? this.balCache.sol - this.reservedSol(amount) : null;
    // V2.11.27 (Khalil, Nov 13 1:11pm): the main wallet (0.1 SOL) couldn't afford the 0.08 minimum plus fees, so it
    // never bought. Main now buys with what's left after fees and the reserve (down to 0.02) instead of skipping.
    if (bal != null && bal < need && this.cfg.growthSize && !this.quickMode && !isAdd) {
      const left = Math.floor((bal - (need - amount)) * 1e4) / 1e4;
      if (left >= 0.02) amount = left;
    }
    if (bal != null && bal < amount + this.cfg.keepSol + this.cfg.priorityFee + 0.003) return this._skipNotify(mint, await symP, `not enough SOL in your wallet (${fmtSol(bal)} SOL, need ${fmtSol(need)})`);
    let sym = mint.slice(0, 6);

    let lastErr;
    const t0 = Date.now();
    let waitedForRoute = false;
    let slipFails = 0;
    for (let attempt = 1; attempt <= 2 || (lastErr?.waitRoute && attempt <= 60) || (lastErr?.slipped && attempt <= 3); attempt++) {
      try {
        let ready = null;
        if (attempt === 1 && this.prebuilt.has(mint)) {
          const pb = await this.prebuilt.get(mint);
          this.prebuilt.delete(mint);
          if (pb && Date.now() - pb.at < 20000 && Math.abs(pb.amount - amount) < 1e-9) ready = pb.bytes; // fresh and the same size
        }
        // the price ran past our slippage (a launch pumping): try again at up to double the slippage
        const slip = slipFails ? Math.min(this.cfg.maxSlippage ?? 50, (this.cfg.slippage || 25) * 2) : null;
        // V2.9.6 his fill price + COPY_MAX_CHASE_PERCENT: above that, we'd be buying his pump (traders only, not devs, not adds)
        const lead = ev?.wallet ? this.traderOf(ev.wallet) : null;
        const chasePct = this.cfg.maxChasePct || 0;
        const chase = !isAdd && chasePct > 0 && ev?.priceSol > 0 && !this.cfg.devNames?.includes(lead) ? { maxPriceSol: ev.priceSol * (1 + chasePct / 100), chasePct } : {};
        const r = await this.swapper.trade({ action: 'buy', mint, amount, denominatedInSol: true, ...(slip ? { slippage: slip } : {}), ...chase }, slip ? null : ready);
        sym = await symP;
        this.refreshBalance();
        const spent = r.solDelta != null ? Math.max(0, -r.solDelta - (r.rentSol || 0)) : amount;
        let tokens = r.tokenDelta;
        if (!(tokens > 0)) tokens = Math.max(0, ((await this.tokenBalance(mint).catch(() => 0)) || 0) - (this.positions[mint]?.tokens || 0));
        const rawAfter = BigInt(r.tokenRawAfter || 0) > 0n ? r.tokenRawAfter : null;
        const old = this.positions[mint];
        const big = hisSol > this.cfg.quickTpHisMinSol;
        if (old && old.tokens > 0) {
          // add to the position (average cost)
          old.tokens += tokens;
          old.boughtTokens = (old.boughtTokens || old.tokens - tokens) + tokens;
          old.costSol += spent;
          old.raw = rawAfter;
          old.buys = (old.buys || 1) + 1;
          if (big && !old.quickDone) old.quickTp = true;
        } else {
          this.positions[mint] = { symbol: sym, tokens, boughtTokens: tokens, raw: rawAfter, costSol: spent, proceedsSol: 0, openedAt: Date.now(), tpDone: false, quickTp: big, quickDone: false, buys: 1, buySig: r.sig, leader: ev?.wallet ? this.traderOf(ev.wallet) : undefined, hisBuySol: hisSol > 0 && !this.cfg.devNames?.includes(ev?.wallet && this.traderOf(ev.wallet)) ? hisSol : null };
        }
        const pos = this.positions[mint];
        if (ev?.runnerHold && !isAdd) pos.runnerHold = true; // V2.11.19 likely runner: hold rules for this coin
        if (ev?.freshDev && !isAdd && this.quickMode) pos.freshDev = true; // V2.11.23 fresh dev: out fast
        if (ev?.confirmed && !isAdd) pos.confirmed = true; // V2.11.24 a fast trader's buy he was still holding
        // V2.9.8 the market cap we bought at (what we paid per token x 1B supply x SOL price)
        const solUsd = this.getSolPrice?.() || 0;
        if (!pos.buyMc && tokens > 0 && solUsd > 0) pos.buyMc = (spent / tokens) * 1e9 * solUsd;
        this.spentToday.sol += spent;
        this.traded.add(mint);
        this.stats.buys++;
        this.lastBuy = { sol: spent, symbol: sym, at: Date.now() };
        this._dayAdd({ buys: 1, spent });
        this.save();
        const lag = ev.time ? Date.now() - ev.time : null;
        const sinceSeen = ev.detectedAt && r.sentAt ? r.sentAt - ev.detectedAt : null;
        if (sinceSeen != null) log.info(`Copy speed: sent ${(sinceSeen / 1000).toFixed(2)}s after his buy was spotted${r.ms ? `, landed ${(r.ms / 1000).toFixed(1)}s later` : ''}`);
        log.info(`Copy: bought ${sym} for ${fmtSol(spent)} SOL (${r.sig})`);
        this._checkSellable(mint, sym);
        await this._notify(
          [
            // one line, on purpose: how much SOL went into which coin
            this.cfg.shortAlerts
              ? `🟢 Bought <b>${e(sym)}</b> — <b>${fmtSol(spent)} SOL</b>${pos.buyMc ? ` · MC ${fmtUsd(pos.buyMc)}` : ''}${!isAdd && ev?.sizeWhy ? ` · ${e(ev.sizeWhy)}` : ''}`
              : `🤖 <b>${isAdd ? 'COPY ADD' : 'COPY BUY'}</b> <b>${e(sym)}</b> — spent <b>${fmtSol(spent)} SOL</b>${!isAdd && ev?.sizeWhy ? `\n${e(ev.sizeWhy)}` : ''}`,
          ].filter(Boolean).join('\n'),
          mint,
          r.sig,
        );
        return;
      } catch (err) {
        lastErr = err;
        sym = await symP;
        if (err.chased) return this._skip(mint, err.message);
        this.refreshBalance();
        log.warn(`Copy buy ${sym} attempt ${attempt} failed: ${err.message}`);
        if (err.expired) {
          // it may still have landed late: never buy twice
          await sleep(3000);
          const have = await this.tokenBalance(mint).catch(() => 0);
          if (have > (isAdd ? (this.positions[mint]?.tokens || 0) * 1.001 : 0)) {
            this.traded.add(mint);
            if (!isAdd) this.positions[mint] = { symbol: sym, tokens: have, boughtTokens: have, costSol: amount, proceedsSol: 0, openedAt: Date.now(), tpDone: false, buys: 1, buySig: err.sig, leader: ev?.wallet ? this.traderOf(ev.wallet) : undefined };
            else Object.assign(this.positions[mint], { tokens: have, costSol: this.positions[mint].costSol + amount, raw: null });
            this.spentToday.sol += amount;
            this.stats.buys++;
            this.lastBuy = { sol: amount, symbol: sym, at: Date.now() };
            this._dayAdd({ buys: 1, spent: amount });
            this.save();
            await this._notify(`🤖 <b>COPY BUY</b> <b>${e(sym)}</b> ✅ (landed late)
💰 ~${fmtSol(amount)} SOL → ${fmtNum(have)} tokens
<code>${mint}</code>`, mint, err.sig);
            return;
          }
        }
        err.slipped = err.onChain && /slippage/i.test(err.message);
        if (err.slipped) slipFails++;
        // A brand-new pool (a fresh launch, or a coin paired with another token like his $BTC) can take
        // Jupiter a little while to find. Keep trying for COPY_ROUTE_WAIT_SECONDS unless he's already out.
        const noRoute = err.noRoute || /no routes|could_not_find|not tradable|route/i.test(err.message);
        err.waitRoute = false;
        if (noRoute && Date.now() - t0 < (this.cfg.routeWaitMs ?? 45000) && !this.hisOut?.has(mint)) {
          err.waitRoute = true;
          if (!waitedForRoute) {
            waitedForRoute = true;
            this._notify(`⏳ <b>COPY BUY WAITING</b> <b>${e(await symP)}</b>\nBrand-new pool, no route to buy it yet — retrying for up to ${Math.round((this.cfg.routeWaitMs ?? 45000) / 1000)}s.\n<code>${mint}</code>`, mint);
          }
          await sleep(1500);
          continue;
        }
        if (/not enough SOL|4\d\d/.test(err.message) && !/429/.test(err.message)) break;
      }
    }
    this.stats.failed++;
    await this._notify(`🤖 <b>COPY BUY FAILED</b> <b>${e(sym)}</b> ❌\n${e(lastErr.message)}\n<code>${mint}</code>`, mint, lastErr.sig);
  }

  // Right after buying (never before — that would slow the buy): warn if Jupiter can't sell it.
  _checkSellable(mint, sym, tries = 0) {
    if (!this.swapper.canSell) return;
    // Without a Jupiter key the free request limit is shared with everything else on your internet
    // connection, so every request is kept for trades. (A coin Jupiter can't sell is still handled
    // when he sells: retries + Padre button.)
    if (!this.swapper.jupKey && !this.cfg.forceSellCheck) return;
    setTimeout(async () => {
      if (!this.positions[mint] || this.locks.has(mint)) {
        if (this.positions[mint] && tries < 6) this._checkSellable(mint, sym, tries + 1);
        return;
      }
      const ok = await this.swapper.canSell(mint).catch(() => null);
      if (ok === 'busy' && tries < 6) return this._checkSellable(mint, sym, tries + 1); // trades first; try later
      if (ok !== false || !this.positions[mint]) return;
      this.positions[mint].noSellRoute = true;
      this.save();
      await this._notify(
        `⚠️ <b>HEADS UP</b> <b>${e(sym)}</b>: Jupiter can't sell this coin type yet (a newer pump.fun coin). When he sells, the bot will keep retrying, but you may need to sell it in Padre yourself.\n<code>${mint}</code>`,
        mint,
      );
    }, this.cfg.sellCheckDelayMs).unref?.();
  }

  async _skipNotify(mint, sym, why) {
    this._skip(mint, why, { notify: false });
    await this._notify(`🤖 <b>COPY BUY SKIPPED</b> <b>${e(sym)}</b>\n${e(why)}\n<code>${mint}</code>`, mint);
  }

  // reason: 'mirror' (he sold some) | 'exit' (he's out) | 'tp' (take profit) | 'manual'
  async _sell(mint, pct, reason, ev, retry = 0) {
    // quick-profit wallets always sell everything (no partial sells)
    if (this.cfg.sellAllAlways) pct = 100;
    const p = this.positions[mint];
    if (!p) return;
    // a newer sell signal replaces a pending retry of an older one
    if (retry === 0 && this.retries.has(mint)) {
      clearTimeout(this.retries.get(mint));
      this.retries.delete(mint);
    }
    const sym = p.symbol || (await this._sym(mint));
    // no balance check here: the swap reads our exact balance once, right before it builds the sell
    const before = p.tokens > 0 ? p.tokens : null;
    let lastErr;
    const attempts = reason === 'exit' || reason === 'manual' ? 3 : 2;
    let slipFails = 0;
    for (let attempt = 1; attempt <= attempts || (lastErr?.slipped && attempt <= attempts + 2); attempt++) {
      try {
        // V2.8.2: a coin dumping past the slippage: each retry allows more (10% -> 20% -> 35%, up to COPY_MAX_SLIPPAGE)
        const base = this.cfg.slippage || 10;
        const slip = slipFails ? Math.min(this.cfg.maxSlippage ?? 50, slipFails === 1 ? base * 2 : base * 3.5) : null;
        const r = await this.swapper.trade({ action: 'sell', mint, amount: `${pct}%`, denominatedInSol: false, knownRaw: attempt === 1 ? p.raw : null, ...(slip ? { slippage: slip } : {}) });
        const got = r.solDelta != null ? r.solDelta : 0;
        const tokensBefore = p.tokens || 0;
        p.proceedsSol += got;
        this._dayAdd({ sells: 1, got });
        const bal = await this.rpc.getTokenBalance(this.kp.publicKey, mint).catch(() => null);
        const left = bal ? bal.ui : null;
        p.tokens = left ?? Math.max(0, (p.tokens || 0) + (r.tokenDelta || 0));
        p.raw = bal && bal.raw != null ? String(bal.raw) : null;
        this.stats.sells++;
        if (pct >= 100 && left != null && left > DUST_TOKENS && !p.sweeping) {
          // tokens still showing after selling 100%: either the RPC is a moment behind, or our saved
          // amount was out of date. Look again shortly and sell whatever is really left.
          p.sweeping = true;
          this._locked(mint, async () => {
            await sleep(2500);
            const b = await this.tokenBalance(mint).catch(() => null);
            if (b != null && b > DUST_TOKENS && this.positions[mint]) {
              this.positions[mint].raw = null;
              this.positions[mint].sweepPass = true;
              return this._sell(mint, 100, reason, ev);
            }
            delete this.positions[mint];
            this.save();
          });
        }
        const closed = p.tokens <= DUST_TOKENS || (pct >= 100 && !p.sweeping);
        const head = { mirror: `🤖 <b>COPY SELL ${pct}%</b>`, exit: '🤖 <b>COPY SELL — ALL OUT</b>', tp: `🎯 <b>TAKE PROFIT ${this.cfg.tpX}x — SOLD ${pct}%</b>`, quick: `⚡ <b>QUICK PROFIT ${this.cfg.quickTpX}x — SOLD ${pct}%</b>`, manual: `🤖 <b>MANUAL SELL ${pct}%</b>`, ladder: `🎯 <b>TAKE PROFIT ${p.ladderX}x — SOLD ${pct}%</b>`, qprofit: `⚡ <b>QUICK PROFIT ${(p.miniX || 0).toFixed(2)}x — SOLD ALL</b>`, mini: `🍳 <b>MINI COOK ${(p.miniX || 0).toFixed(2)}x — SOLD ${pct}%</b>`, timeout: `⏰ <b>${this.cfg.maxHoldHours}H UP — SOLD ALL</b>`, crash: '📉 <b>DUMPING — SOLD ALL</b>', trail: '🛡 <b>PROFIT LOCK — SOLD ALL</b>', protect: '🛡 <b>PROFIT LOCK — SOLD ALL</b>', stoploss: '🛑 <b>STOP LOSS — SOLD ALL</b>', dead: '💀 <b>DEAD COIN — SOLD ALL</b>', holders: '👥 <b>TOO FEW HOLDERS — SOLD ALL</b>', losing: '📉 <b>LOSING — SOLD ALL</b>', weak: '🪫 <b>WEAK COIN — SOLD ALL</b>' }[reason];
        const who = e(p.leader || this.targetName || 'He');
        const why = { mirror: `👤 ${who} sold ~${pct}% of his bag`, exit: `👤 ${who} fully sold out`, tp: `📈 Your bag hit ${this.cfg.tpX}x`, quick: `📈 Up ${this.cfg.quickTpX}x on a big buy of his — locking some in, keeping the rest`, manual: '👤 You asked for it', qprofit: `⚡ Quick profit mode: up ${Math.round(((p.miniX || 1) - 1) * 100)}% — took it all`, mini: pct >= 100 ? `🛟 Up ${Math.round(((p.miniX || 1) - 1) * 100)}% — took the whole win (${e(p.leader || '')} new pair: no holding)` : `🛟 Safety net: up ${Math.round(((p.miniX || 1) - 1) * 100)}% — took ${pct}% off, the rest keeps riding`, crash: `📉 Dropped fast: ${p.protectX ? `${p.protectX.recent.toFixed(2)}x → ${p.protectX.now.toFixed(2)}x in a few minutes` : 'falling fast'} — getting out`, trail: `🛡 Gave back too much from the top (${p.protectX ? `${p.protectX.peak.toFixed(2)}x → ${p.protectX.now.toFixed(2)}x` : ''}) — locking in the rest`, protect: `🛡 It ran to ${p.protectX ? p.protectX.peak.toFixed(2) : '?'}x and is sliding back to your entry — selling before it goes red`, weak: `🪫 Small buy (${p.weakInfo ? fmtSol(p.weakInfo.his) : '?'} SOL) on a fading chart (volume dropping, not climbing) — out before it dies`, losing: `📉 Fell to ${p.protectX ? p.protectX.now.toFixed(2) : '?'}x of your buy — getting out`, holders: `👥 Only ${p.holdersInfo ?? '?'} holders (under ${this.cfg.minHolders}), not growing, and it's under your buy — getting out`, dead: `💀 Nobody's trading it (${p.deadInfo ? `${p.deadInfo.trades5m} trades, $${Math.round(p.deadInfo.vol5m)} volume in 5 min; ${p.deadInfo.sellsH1} sells vs ${p.deadInfo.buysH1} buys in the last hour` : 'no activity'}) and it's under your buy — getting out`, stoploss: `📉 Down to ${p.protectX ? p.protectX.now.toFixed(2) : '?'}x of your buy — cutting it before it rugs more`, timeout: null, ladder: (p.ladderOut || 0) >= 0.99 && !p.ladderFreeSaid ? `📈 Up ${p.ladderX}x — initial taken out, the rest rides for free` : `📈 Up ${p.ladderX}x — took ${p.ladderPct || ''}% profit, the rest keeps riding (stop loss still on)` }[reason];
        const lines = [`${head} <b>${e(sym)}</b> ✅`, ...(why ? [why] : []), `💸 Got <b>${fmtSol(got)} SOL</b>`];
        if (closed) {
          const pnl = p.proceedsSol - p.costSol;
          lines.push(`📊 Trip: in ${fmtSol(p.costSol)} → out ${fmtSol(p.proceedsSol)} SOL = <b>${pnl >= 0 ? '+' : ''}${fmtSol(pnl)} SOL</b> (${fmtPct(p.costSol ? (pnl / p.costSol) * 100 : 0)})${reason === 'timeout' ? '' : ` · held ${fmtAgo(Date.now() - p.openedAt)}`}`);
          const mult = p.costSol > 0 ? p.proceedsSol / p.costSol : 0;
          this._dayAdd({ trip: { sym, pnl, x: mult, leader: p.leader || null, mint, buyMc: p.buyMc, cost: p.costSol, ...(p.confirmed ? { confirmed: true } : {}) } });
          this.learner?.closed(mint, p);
          if (mult >= 2) lines.unshift(`🔥 <b>COOKED ${mult.toFixed(1)}x</b> on <b>${e(sym)}</b> — in ${fmtSol(p.costSol)} SOL, out ${fmtSol(p.proceedsSol)} SOL`);
          delete this.positions[mint];
        } else lines.push(`👜 Still holding ${fmtNum(p.tokens)} tokens`);
        // was this sale at a loss? (the whole trip if it closed, otherwise what the sold part cost)
        const soldCost = p.costSol * Math.min(1, Math.max(0, tokensBefore - (p.tokens || 0)) / (p.boughtTokens || tokensBefore || 1));
        const isLoss = closed ? p.proceedsSol < p.costSol : got < soldCost * 0.999;
        if (reason === 'tp') p.tpDone = true;
        this.save();
        log.info(`Copy: sold ${pct}% of ${sym} for ${fmtSol(got)} SOL (${reason}, ${r.sig})`);
        // when a sweep follows, only its final "all out" message is sent
        // losing sells make no alert (COPY_LOSS_ALERTS=off): they're listed in the 11:59pm daily recap instead
        if (isLoss && this.cfg.lossAlerts === false) return;
        let msg = lines.join('\n');
        if (this.cfg.shortAlerts) {
          // V2 short alerts: one line. Big cook (trip 2x+), mini cook, or a plain sell, plus the SOL you got.
          const mult = closed && p.costSol > 0 ? p.proceedsSol / p.costSol : null;
          const saleX = soldCost > 0 ? got / soldCost : null;
          const xs = (v) => (v != null ? `${v.toFixed(2)}x ` : '');
          // V2.11.22 (Khalil): only a cook when that coin made money after fees (the whole trip when it's closed,
          // this sale when part of it is still held); a big one (COOK_SHOW_TOTAL_SOL+ profit) also shows your total
          const profit = closed ? p.proceedsSol - p.costSol : got - soldCost;
          // V2.11.23 (Khalil: "I'm not up and it gave alert") ...and only while your total PnL today is up too
          const dayUp = this.totalPnl ? this.totalPnl() > 0 : true;
          const inProfit = profit > 0 && dayUp;
          const total = inProfit && this.cfg.cookShowTotalSol > 0 && profit >= this.cfg.cookShowTotalSol && this.totalPnl ? this.totalPnl() : null;
          const tail = total != null ? `\n💰 Your PnL today: <b>${total >= 0 ? '+' : '-'}${fmtSol(Math.abs(total))} SOL</b>` : '';
          if (inProfit && mult != null && mult >= 2) msg = `🔥 <b>${mult.toFixed(1)}x cook</b> on <b>${e(sym)}</b> — got <b>${fmtSol(got)} SOL</b> (+${fmtSol(profit)})${tail}`;
          else if (inProfit && (reason === 'mini' || reason === 'qprofit')) msg = `🍳 <b>${xs(saleX ?? p.miniX)}mini cook</b> on <b>${e(sym)}</b> — got <b>${fmtSol(got)} SOL</b> (+${fmtSol(profit)})${tail}`;
          else msg = `💸 Sold ${pct >= 100 || closed ? 'all' : `${pct}%`} <b>${e(sym)}</b>${saleX != null ? ` (${saleX.toFixed(2)}x)` : ''} — got <b>${fmtSol(got)} SOL</b>`;
        }
        if (!(pct >= 100 && !closed && p.sweeping && !p.sweepPass)) await this._notify(msg, mint, r.sig);
        return;
      } catch (err) {
        lastErr = err;
        if (err.nothing) {
          delete this.positions[mint];
          this.save();
          return;
        }
        log.warn(`Copy sell ${sym} attempt ${attempt} failed: ${err.message}`);
        err.slipped = err.onChain && /slippage/i.test(err.message);
        if (err.slipped) slipFails++;
        if (err.expired && before != null) {
          await sleep(3000);
          const now = await this.tokenBalance(mint).catch(() => null);
          if (now != null && now < before * 0.99) {
            // it landed late — don't sell again
            p.tokens = now;
            if (now <= DUST_TOKENS) delete this.positions[mint];
            this.save();
            await this._notify(`🤖 <b>COPY SELL ${pct}%</b> <b>${e(sym)}</b> ✅ (landed late)\n<code>${mint}</code>`, mint, err.sig);
            return;
          }
        }
        if (err.noRoute) break; // retrying right away won't help; handled below
        if (err.slipped) continue; // right away, with more slippage: the price is running away
        if (attempt < attempts) await sleep(1000);
      }
    }
    // No route yet (e.g. a new pump.fun coin type Jupiter can't sell): keep trying instead of giving up
    if (lastErr.noRoute && reason !== 'manual' && retry < this.cfg.sellRetryMax) {
      if (retry === 0) {
        await this._notify(
          `🤖 <b>COPY SELL DELAYED</b> <b>${e(sym)}</b> ⏳ (${pct}%)\nJupiter can't sell this coin right now. The bot retries every ${fmtAgo(this.cfg.sellRetryMs)} for ${fmtAgo(this.cfg.sellRetryMs * this.cfg.sellRetryMax)}.\n👉 To get out now, sell it in Padre (button below).\n<code>${mint}</code>`,
          mint,
        );
      }
      const t = setTimeout(() => {
        this.retries.delete(mint);
        this._locked(mint, () => this._sell(mint, pct, reason, ev, retry + 1));
      }, this.cfg.sellRetryMs);
      t.unref?.();
      this.retries.set(mint, t);
      return;
    }
    this.stats.failed++;
    await this._notify(
      `🤖 <b>COPY SELL FAILED</b> <b>${e(sym)}</b> ❌ (${pct}%)\n${e(lastErr.message)}\n⚠️ You still hold it — sell it yourself (Padre button), or send /sell ${mint} ${pct}\n<code>${mint}</code>`,
      mint,
      lastErr.sig,
    );
  }

  manualSell(mint, pct) {
    if (!this.positions[mint]) this.positions[mint] = { symbol: null, tokens: 1, costSol: 0, proceedsSol: 0, openedAt: Date.now(), tpDone: true };
    return this._locked(mint, () => this._sell(mint, pct, 'manual'));
  }

  reservedSol(own = 0) {
    return Math.max(0, (this.reservedAmt || 0) - own); // SOL other buys in flight are about to spend
  }

  refreshBalance() {
    return this.solBalance()
      .then((sol) => (this.balCache = { sol, at: Date.now() }))
      .catch(() => {});
  }

  async solBalance() {
    const r = await this.rpc.call('getBalance', [this.kp.publicKey, { commitment: 'confirmed' }], { priority: true });
    return (r?.value ?? 0) / LAMPORTS;
  }

  async tokenBalance(mint) {
    return (await this.rpc.getTokenBalance(this.kp.publicKey, mint)).ui;
  }

  // Current SOL value of our bag from pump.fun's price.
  async valueSol(mint, tokens) {
    const px = this.pxCache?.[mint];
    if (px > 0) return tokens * px;
    const c = await this.pump.getCoin(mint).catch(() => null);
    if (!c) return null;
    const supply = c.total_supply ? +c.total_supply / 1e6 : 1e9;
    if (+c.market_cap > 0) return (tokens * +c.market_cap) / supply;
    const sp = this.getSolPrice();
    if (+c.usd_market_cap > 0 && sp) return (tokens * +c.usd_market_cap) / supply / sp;
    return null;
  }

  async checkTakeProfit() {
    if (!this.cfg.enabled) return;
    const ladder = this.cfg.tpLadder || [];
    // the ladder replaces the single take-profit and the quick profit
    const doTp = !ladder.length && this.cfg.tpX > 0 && this.cfg.tpPercent > 0;
    const doQuick = !ladder.length && this.cfg.quickTpX > 0 && this.cfg.quickTpPercent > 0;
    // nothing to watch at all -> skip (quick mode, mini cook and the protection rules count too)
    if (!doTp && !doQuick && !ladder.length && !(this.cfg.maxHoldHours > 0) && !this.quickMode && !this.cfg.miniCook && this.cfg.protect === false && !Object.keys(this.exitPick || {}).length && !Object.keys(this.cfg.styleRules || {}).length) return;
    // one price lookup for every open position
    const open = Object.entries(this.positions).filter(([, p]) => p.tokens > 0).map(([m]) => m);
    this.pxCache = open.length && this.coins.pricesSol ? await this.coins.pricesSol(open, this.getSolPrice()).catch(() => ({})) : {};
    this._npQuotes = 0;
    for (const [mint, p] of Object.entries(this.positions)) {
      if (!(p.tokens > 0) || !(p.costSol > 0) || this.locks.has(mint)) continue;
      // /hold: this coin only sells when he sells (no take-profit, no dying-coin sells, no 8h limit)
      if (p.keep) continue;
      // held too long: sell everything (whatever profit it took along the way is already banked)
      const limitAt = p.openedAt + this.cfg.maxHoldHours * 3600000;
      if (this.cfg.maxHoldHours > 0 && p.openedAt && !p.keep && !p.holdWarned && !(!this.quickMode && ((p.leader && this.cfg.holdRules?.[p.leader]) || p.runnerHold)) && limitAt - Date.now() < 30 * 60000 && limitAt > Date.now()) {
        p.holdWarned = true;
        this.save();
        const sym = await this._sym(mint);
        // what the sale would bring in at today's price, and the trip's profit/loss
        let money = '';
        const v = await withTimeout(this.valueSol(mint, p.tokens), 2500, null).catch(() => null);
        if (v != null && v >= 0) {
          const out = v + (p.proceedsSol || 0);
          const pnl = out - p.costSol;
          money =
            `\n💰 At today's price you'd get <b>~${fmtSol(v)} SOL</b> for it` +
            `\n📊 Trip: in ${fmtSol(p.costSol)} SOL${p.proceedsSol > 0 ? ` (already took out ${fmtSol(p.proceedsSol)})` : ''} → ${pnl >= 0 ? `🟢 <b>+${fmtSol(pnl)} SOL</b> profit (${(out / p.costSol).toFixed(2)}x)` : `🔴 <b>-${fmtSol(-pnl)} SOL</b> loss (-${(-pnl / p.costSol).toFixed(2)}x)`}`;
        } else money = `\n💰 Couldn't get its price right now (in ${fmtSol(p.costSol)} SOL)`;
        this._notify(`⏰ <b>${e(sym)}</b> gets sold in ~${Math.max(1, Math.round((limitAt - Date.now()) / 60000))} min (${this.cfg.maxHoldHours}h limit).${money}\nTo hold it until ${e(p.leader || this.targetName || 'he')} sells instead: <code>/hold ${mint}</code>`, mint);
      }
      // V2.11.18 hold traders (kimchi): every wallet holds his coins — 25% off at 2x, the rest goes when he sells,
      // only a -75% stop loss before that (no 8h limit, no quick / dying-coin / protect sells)
      // (V2.11.20 Khalil: side wallets keep their quick profit — they build profit slowly; the main wallet holds for the big win)
      // V2.11.37 (Khalil, Nov 13 8:30pm: "make my bot replicate his style when it copy trades him"): a style trader's
      // coins (henry: quick in-and-out) are sold his way in every wallet: all out at his usual take, a tight stop,
      // and out by his usual hold time (or when he sells). Never held as a runner.
      // V2.11.44 main: another tracked trader in the coin, or a likely runner -> held (not his style). Side wallets keep
      // their quick band: his take, but inside SIDE_TAKE_FROM_X..TO_X.
      const hold0 = this.quickMode ? null : (p.leader ? this.cfg.holdRules?.[p.leader] : null) || (p.runnerHold ? this.cfg.runnerHoldRule : null);
      const raw = p.leader && !hold0 && !(p.tradersIn && !this.quickMode) ? this.cfg.styleRules?.[p.leader] : null;
      const style = raw && raw.miniToX > 0 ? (this.quickMode && this.cfg.quickFromX > 1 && raw.miniToX > (this.cfg.quickToX || 0) ? { ...raw, miniFromX: this.cfg.quickFromX, miniToX: this.cfg.quickToX, miniPullbackPct: this.cfg.quickPullbackPct ?? raw.miniPullbackPct } : raw) : null;
      const hold = style ? null : hold0;
      if (this.cfg.maxHoldHours > 0 && p.openedAt && !p.keep && !hold && Date.now() > limitAt && !p.timeoutSent) {
        p.timeoutSent = true;
        this.save();
        this._locked(mint, () => this._sell(mint, 100, 'timeout'));
        continue;
      }
      const wantQuick = doQuick && p.quickTp && !p.quickDone && !hold;
      const wantTp = doTp && !p.tpDone && !hold;
      const step = hold ? null : ladder[p.ladderDone || 0];
      const protect = this.cfg.protect !== false && !hold;
      // mini cook: only on buys of 0.1 SOL+ (the 0.01 SOL slack covers fees/rounding), once per coin
      // quick profit mode (/quick on): every coin sells 100% between +25% and +75%, any buy size
      const quickHere = this.quickMode || this.quickFor?.has(p.leader);
      const ownMini = !!hold || !!style || (p.leader && !p.tradersIn && (this.cfg.leaderRules?.[p.leader]?.miniToX > 0 || this.learned?.[p.leader]?.miniToX > 0 || this.exitPick?.[p.leader]?.miniToX > 0));
      const wantMini = (quickHere || ownMini || (this.cfg.miniCook && p.costSol >= (this.cfg.miniMinSol ?? 0.1) - 0.01)) && !p.miniDone;
      if (!wantQuick && !wantTp && !step && !protect && !wantMini && !(hold?.stopLossX > 0)) continue;
      let v = await this.valueSol(mint, p.tokens);
      // V2.9.7 no price from the price sites (brand-new or thin coins): ask Jupiter what selling it would pay
      // (every 20s per coin), so the stop loss and the other sell rules still work on it. Before, a coin
      // without a price was never checked at all and rode to zero.
      // at most 2 such quotes per check, so they never crowd out Jupiter for buys
      if (v == null && this.swapper.quoteSellSol && (this._npQuotes || 0) < 2 && Date.now() - (p.quoteTriedAt || 0) >= 20000) {
        this._npQuotes = (this._npQuotes || 0) + 1;
        p.quoteTriedAt = Date.now();
        const raw = p.raw && BigInt(p.raw) > 0n ? String(p.raw) : String(Math.floor(p.tokens * 1e6));
        v = await withTimeout(this.swapper.quoteSellSol(mint, raw), 4000, null).catch(() => null);
        if (v != null) p.quotedValueSol = v;
      } else if (v == null && p.quotedValueSol != null && Date.now() - (p.quoteTriedAt || 0) < 20000) v = p.quotedValueSol;
      p.lastValueSol = v;
      if (v == null) continue;
      // what the tokens we still hold cost us (average price), so earlier sells don't move the target
      const cost = p.costSol * Math.min(1, p.tokens / (p.boughtTokens || p.tokens));
      let x = v / cost;
      // a fresh real quote (taken when a profit sell was double-checked) wins over a higher feed price
      if (p.quoteAt && Date.now() - p.quoteAt < 30000 && p.quoteX < x) x = p.quoteX;
      p.lastX = x;
      this.learner?.sample(mint, p, x);
      // coins copied from a fast trader (cupsey: new pairs that often rug) use tighter sell rules
      // a dev coin that one of the tracked traders also holds may run further: normal rules (hold longer)
      this._checkSmart(mint, p);
      // V2.8: sell settings you approved from /suggestions go on top of that wallet's rules
      // V2.11 the exit his pretend wallets showed works best for him (/ghosts); settings you approved win over it
      const pick = p.leader && !p.tradersIn ? this.exitPick?.[p.leader] : null;
      const R = { ...this.cfg, ...((p.leader && !p.tradersIn && { ...(this.cfg.leaderRules?.[p.leader] || {}), ...(pick || {}), ...(this.learned?.[p.leader] || {}) }) || {}), ...(hold || {}) };
      if (p.tradersIn) R.miniPullbackPct = Math.max(R.miniPullbackPct ?? 10, 20); // smart money in: ride a wider dip
      if (style) Object.assign(R, style);
      // per-trader max hold (rug-dev experiment: out within minutes, no holding)
      if (R.maxHoldMinutes > 0 && (!p.tradersIn || style) && Date.now() - (p.openedAt || 0) > R.maxHoldMinutes * 60000 && !p.shortHoldSent) {
        p.shortHoldSent = true;
        this.save();
        this._locked(mint, () => this._sell(mint, 100, 'timeout'));
        continue;
      }
      // V2.11.23 side wallet in a fresh dev's coin: armed at +10%, all out at +25% or a 5% pullback
      if (this.quickMode && p.freshDev) Object.assign(R, { miniFromX: this.cfg.freshFromX ?? 1.1, miniToX: this.cfg.freshToX ?? 1.25, miniPullbackPct: this.cfg.freshPullbackPct ?? 5, miniPct: 100 });
      else if ((this.quickMode || this.quickFor?.has(p.leader)) && !pick && !hold) Object.assign(R, { miniFromX: this.cfg.quickFromX ?? 1.25, miniToX: this.cfg.quickToX ?? 1.75, miniPullbackPct: this.cfg.quickPullbackPct ?? 7, miniPct: 100 });
      if (style) Object.assign(R, style); // his style wins over the side wallets' quick rule too
      // V2.12.6 a side wallet's stop is never looser than SIDE_STOP_LOSS_X (-15%), whatever a trader's rule says
      if (this.quickMode && this.cfg.sideStopX > 0 && !hold) R.stopLossX = Math.max(R.stopLossX || 0, this.cfg.sideStopX);
      // Stop loss (fast traders): sold all once it's down to COPY stop-loss x of what we paid. Needs the price
      // to be low on two checks in a row, and the coin held 60s+, so a late price feed right after our buy can't trigger it.
      if (R.stopLossX > 0 && x <= R.stopLossX && Date.now() - (p.openedAt || 0) > 60000) {
        if (p.slowCount >= 1) {
          p.protectX = { peak: p.peakX || x, recent: x, now: x };
          this.save();
          this._locked(mint, () => this._sell(mint, 100, 'stoploss'));
          continue;
        }
        p.slowCount = (p.slowCount || 0) + 1;
      } else p.slowCount = 0;
      // Weak buy (V2): the trader bought small (under COPY_WEAK_BUY_SOL, default 3 SOL ≈ $300) and the coin is
      // fading: 5-min volume below its hourly pace and the market cap not climbing -> sell all. Small buys on
      // quiet charts usually die within ~10 minutes. Needs two checks in a row; held 3+ min first.
      if (!hold && this.cfg.weakBuySol > 0 && p.hisBuySol != null && p.hisBuySol < this.cfg.weakBuySol && x < (this.cfg.weakMaxX ?? 1.1) && Date.now() - (p.openedAt || 0) >= (this.cfg.weakMinMs ?? 180000)) {
        const a = this.coins?.activity?.get(mint);
        // don't sell a coin people are still piling into: holders going up, or more buyers than sellers in 5 min
        const hc = this._holders(mint);
        const holdersUp = hc?.n != null && p.weakHolders != null && hc.n > p.weakHolders;
        if (hc?.n != null) p.weakHolders = hc.n;
        const buyersWin = a && a.buysM5 > a.sellsM5;
        const fading = a && Date.now() - a.at < 60000 && a.volH1 > 0 && a.volM5 * 12 < a.volH1 && !holdersUp && !buyersWin;
        if (fading) {
          if (p.weakCount >= 1) {
            p.weakInfo = { x, his: p.hisBuySol };
            this.save();
            this._locked(mint, () => this._sell(mint, 100, 'weak'));
            continue;
          }
          p.weakCount = (p.weakCount || 0) + 1;
        } else p.weakCount = 0;
      }
      // Too few holders (sling's coins only): under COPY_MIN_HOLDERS wallets holding it after the first
      // COPY_MIN_HOLDERS_AFTER_MINUTES, while it's losing and not picking up holders -> sell all.
      // A coin that's gaining (in profit, or holders going up) is kept. Counted with one Helius call per coin per minute,
      // in the background; needs two low counts in a row.
      if (!hold && this.cfg.minHolders > 0 && !(p.leader && this.cfg.leaderRules?.[p.leader]) && Date.now() - (p.openedAt || 0) >= (this.cfg.minHoldersAfterMs ?? 600000)) {
        const hc = this._holders(mint);
        if (hc && hc.n != null && hc.at !== p.holdersSeenAt) {
          p.holdersSeenAt = hc.at;
          // only while it's NOT gaining: under your buy price and holders not growing since the last count
          const growing = p.lastHolders != null && hc.n > p.lastHolders;
          p.lastHolders = hc.n;
          if (hc.n < this.cfg.minHolders && x < 1 && !growing) {
            if (p.fewHolders >= 1) {
              p.holdersInfo = hc.n;
              this.save();
              this._locked(mint, () => this._sell(mint, 100, 'holders'));
              continue;
            }
            p.fewHolders = (p.fewHolders || 0) + 1;
          } else p.fewHolders = 0;
        }
      }
      // Dead coin: losing money, nobody trading it any more (few trades / tiny volume in the last 5 min) and
      // more people selling than buying over the last hour -> sell all. Needs two checks in a row.
      if (!hold && this.cfg.deadCoin && x < 1 && Date.now() - (p.openedAt || 0) >= (this.cfg.deadMinMs ?? 1200000)) {
        const a = this.coins?.activity?.get(mint);
        const fresh = a && Date.now() - a.at < 60000;
        const quiet = fresh && (a.buysM5 + a.sellsM5 < (this.cfg.deadMaxTrades5m ?? 10) || a.volM5 < (this.cfg.deadMaxVol5m ?? 300));
        const leaving = fresh && a.sellsH1 > a.buysH1;
        if (quiet && leaving) {
          if (p.deadCount >= 1) {
            p.deadInfo = { x, trades5m: a.buysM5 + a.sellsM5, vol5m: a.volM5, buysH1: a.buysH1, sellsH1: a.sellsH1 };
            this.save();
            this._locked(mint, () => this._sell(mint, 100, 'dead'));
            continue;
          }
          p.deadCount = (p.deadCount || 0) + 1;
        } else p.deadCount = 0;
      }
      // Dying coin: sell everything that's left while there's still profit to take.
      if (protect) {
        const now = Date.now();
        p.peakX = Math.max(p.peakX || 0, x);
        p.hist = (p.hist || []).filter((h) => now - h.t < (R.crashWindowMs ?? 300000));
        p.hist.push({ t: now, x });
        const recentHigh = Math.max(...p.hist.map((h) => h.x));
        const armX = R.trailArmX ?? 1.5;
        let why = null;
        // 1) falling fast: down 35% from its high of the last 5 minutes (e.g. $1.3M -> $800K)
        if (x <= recentHigh * (1 - (R.crashDropPct ?? 35) / 100)) why = 'crash';
        // 2) once it ran (1.5x+), never give more than 40% of the top back
        else if (p.peakX >= armX && x <= p.peakX * (1 - (R.trailDropPct ?? 40) / 100)) why = 'trail';
        // 3) once it ran, never let it slide back toward what we paid
        else if (p.peakX >= armX && x <= (R.floorX ?? 1.15)) why = 'protect';
        // honest label: if it's already under what we paid, it's not a profit lock
        if ((why === 'trail' || why === 'protect') && x < 1) why = 'losing';
        if (why) {
          p.protectX = { peak: p.peakX, recent: recentHigh, now: x };
          this.save();
          this._locked(mint, () => this._sell(mint, 100, why));
          continue;
        }
      }
      // Mini cook: armed at 1.75x; sells once it pulls back 10% from its top (still in profit) or hits 2.5x.
      if (wantMini) {
        if (x >= R.miniFromX) p.miniArmed = true;
        if (p.miniArmed) {
          p.miniPeak = Math.max(p.miniPeak || 0, x);
          const pulledBack = x <= p.miniPeak * (1 - R.miniPullbackPct / 100) && x > 1.05;
          if (x >= R.miniToX || pulledBack) {
            const before = { ladderDone: p.ladderDone };
            p.miniDone = true;
            p.miniX = x;
            // ladder rungs inside the mini-cook range are covered by it (no second 50% right after)
            while (ladder[p.ladderDone || 0] && ladder[p.ladderDone || 0].x <= R.miniToX) p.ladderDone = (p.ladderDone || 0) + 1;
            this.save();
            this._locked(mint, () =>
              this._cookSell(mint, R.miniPct, (this.quickMode || this.quickFor?.has(p.leader)) && !hold ? 'qprofit' : 'mini', () => Object.assign(p, { miniDone: false, miniArmed: false, miniPeak: 0, ladderDone: before.ladderDone })),
            );
            continue;
          }
        }
        // while it's deciding, the ladder waits for rungs inside the mini-cook range
        if (p.miniArmed && step && step.x <= R.miniToX) continue;
      }
      if (step && x >= step.x) {
        p.ladderDone = (p.ladderDone || 0) + 1; // one rung per check; the next rung is checked 10s later
        p.ladderX = step.x;
        p.ladderPct = step.pct;
        // V2.11.60 how much of the initial the ladder has taken out so far (x of the bag sold at each rung)
        p.ladderFreeSaid = (p.ladderOut || 0) >= 0.99;
        p.ladderOut = (p.ladderOut || 0) + (p.ladderLeft ?? 1) * (step.pct / 100) * step.x;
        p.ladderLeft = (p.ladderLeft ?? 1) * (1 - step.pct / 100);
        this.save();
        this._locked(mint, () => this._cookSell(mint, step.pct, 'ladder', () => (p.ladderDone = Math.max(0, (p.ladderDone || 1) - 1))));
      } else if (wantTp && x >= this.cfg.tpX) {
        p.tpDone = true; // only once per position
        if (wantQuick) p.quickDone = true; // the bigger take-profit covers it
        this.save();
        this._locked(mint, () => this._cookSell(mint, this.cfg.tpPercent, 'tp', () => Object.assign(p, { tpDone: false, quickDone: false })));
      } else if (wantQuick && x >= this.cfg.quickTpX) {
        p.quickDone = true;
        this.save();
        this._locked(mint, () => this._cookSell(mint, this.cfg.quickTpPercent, 'quick', () => (p.quickDone = false)));
      }
    }
  }


  // V2.8.2 the learner's coins (sold in the last 30 min, and every coin the wallets bought) are priced
  // in their own background pass, so they never slow down the price check of the coins we hold.
  async learnPrices() {
    if (!this.learner || this._learnBusy || !this.coins.pricesSol) return;
    this._learnBusy = true;
    try {
      const open = new Set(Object.keys(this.positions));
      const watch = this.learner.watching().filter((m) => !open.has(m));
      const px = watch.length ? await this.coins.pricesSol(watch, this.getSolPrice()).catch(() => ({})) : {};
      for (const m of watch) this.learner.postPrice(m, px[m]);
      this.learner.tick();
    } finally {
      this._learnBusy = false;
    }
  }

  // After a restart: forget positions that were sold by hand in the wallet app.
  async resync() {
    for (const [mint, p] of Object.entries(this.positions)) {
      const bal = await this.tokenBalance(mint).catch(() => null);
      if (bal == null) continue;
      if (bal <= DUST_TOKENS) delete this.positions[mint];
      else {
        p.tokens = bal;
        p.raw = null; // re-read on the next sell
      }
    }
    this.save();
  }

  // Coins sitting in our wallet that the bot doesn't know about (bought by hand, or a buy that landed
  // after the bot gave up) are taken over as if the bot had bought them: they then sell when he sells
  // and follow the take-profit ladder. Only coins HE currently holds (so airdropped spam is ignored).
  async adoptStrays() {
    if (!this.targets?.length || this._adopting) return;
    this._adopting = true;
    try {
      for (const programId of ['TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA', 'TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb']) {
        const r = await this.rpc.call('getTokenAccountsByOwner', [this.kp.publicKey, { programId }, { encoding: 'jsonParsed', commitment: 'confirmed' }]).catch(() => null);
        for (const a of r?.value || []) {
          const info = a.account?.data?.parsed?.info;
          const mint = info?.mint;
          const ui = +info?.tokenAmount?.uiAmount || 0;
          if (!mint || ui <= DUST_TOKENS || this.positions[mint] || this.isBusy(mint)) continue;
          if (/^(So11111111111111111111111111111111111111112|EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v|Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB)$/.test(mint)) continue;
          if ((this.adoptChecked?.get(mint) || 0) > Date.now() - 600000) continue;
          (this.adoptChecked ||= new Map()).set(mint, Date.now());
          let his = 0;
          for (const w of this.targets) his += (await this.rpc.getTokenBalance(w, mint).catch(() => ({ ui: 0 }))).ui || 0;
          if (!(his > 0)) continue;
          // what we paid: SOL spent on the transactions that added this coin to our account
          let cost = 0;
          let got = 0;
          const sigs = (await this.rpc.call('getSignaturesForAddress', [a.pubkey, { limit: 40 }]).catch(() => [])) || [];
          for (const s of sigs.filter((x) => !x.err)) {
            const tx = await this.rpc.getTransaction(s.signature).catch(() => null);
            if (!tx?.meta) continue;
            const keys = accountKeysOf(tx);
            const i = keys.indexOf(this.kp.publicKey);
            if (i < 0) continue;
            const solD = ((tx.meta.postBalances[i] ?? 0) - (tx.meta.preBalances[i] ?? 0)) / LAMPORTS;
            const amt = (bs) => (bs || []).filter((b) => b.owner === this.kp.publicKey && b.mint === mint).reduce((x, b) => x + (+b.uiTokenAmount.uiAmountString || 0), 0);
            const tokD = amt(tx.meta.postTokenBalances) - amt(tx.meta.preTokenBalances);
            if (tokD > 0 && solD < 0) cost += -solD;
            if (tokD < 0 && solD > 0) got += solD;
          }
          const sym = await this._sym(mint);
          this.positions[mint] = { symbol: sym, tokens: ui, boughtTokens: ui, costSol: Math.max(0, cost - got) || cost, proceedsSol: 0, openedAt: Date.now(), tpDone: false, buys: 1, adopted: true };
          this.traded.add(mint);
          this.save();
          log.info(`Copy: adopted ${sym} (${ui} tokens, cost ~${fmtSol(cost)} SOL) found in the wallet`);
          await this._notify(`👜 <b>TAKING OVER</b> <b>${e(sym)}</b>\nFound ${fmtNum(ui)} tokens in your bot wallet (cost ~${fmtSol(cost)} SOL). The bot now manages them like its own buy: sells when ${e(this.targetName || 'he')} sells, take-profit ladder from your cost.\n<code>${mint}</code>`, mint);
        }
      }
    } finally {
      this._adopting = false;
    }
  }

  // Profit sells (mini cook, take-profit ladder): first get a real Jupiter quote for the bag. If the real
  // price says we're NOT in profit (the price feed was stale/wrong), don't sell it as a cook: undo and let
  // the loss rules judge it on the real price. If the quote can't be had, sell as before.
  async _cookSell(mint, pct, reason, undo) {
    const p = this.positions[mint];
    if (!p) return;
    const realX = await this._quoteX(mint, p).catch(() => null);
    if (realX != null) {
      p.quoteX = realX;
      p.quoteAt = Date.now();
      const tooLow = realX < 1.02 || (reason === 'ladder' && realX < (p.ladderX || 1) * 0.7);
      if (tooLow) {
        undo?.();
        this.save();
        log.warn(`Not selling ${p.symbol || mint} as a ${reason}: price feed said profit, real quote is ${realX.toFixed(2)}x`);
        return;
      }
      if (reason === 'mini' || reason === 'qprofit') p.miniX = realX;
    }
    return this._sell(mint, pct, reason);
  }

  async _quoteX(mint, p) {
    if (!this.swapper?.quoteSellSol) return null;
    let raw = p.raw ? BigInt(p.raw) : null;
    if (!raw) {
      const b = await withTimeout(this.rpc.getTokenBalance(this.kp.publicKey, mint), 2500, null).catch(() => null);
      raw = b?.raw != null ? BigInt(b.raw) : null;
    }
    if (!raw || raw <= 0n) return null;
    const out = await withTimeout(this.swapper.quoteSellSol(mint, raw.toString()), 3000, null);
    if (!(out > 0)) return null;
    const cost = p.costSol * Math.min(1, p.tokens / (p.boughtTokens || p.tokens));
    return cost > 0 ? out / cost : null;
  }

  // V2.11.53 a held coin whose newer same-name version has passed its market cap: sold (once per coin)
  sellOutdated() {
    if (!this.book?.cfg?.versionCheck) return [];
    const sold = [];
    for (const [mint, p] of Object.entries(this.positions)) {
      if (!(p.tokens > 0) || p.outdatedSold || this.locks.has(mint)) continue;
      const by = this.book.overtakenBy(mint);
      if (!by) continue;
      p.outdatedSold = true;
      log.info(`Copy: ${p.symbol || mint} — a newer coin with the same name (${by.slice(0, 6)}) passed it: selling`);
      sold.push(mint);
      this._locked(mint, () => this._sell(mint, 100, 'outdated')).catch(() => {});
    }
    return sold;
  }

  // Smart-money check, in the background at most once a minute per coin:
  //  - dev coins: is one of the tracked traders also holding it?
  //  - every coin: did one of the watch-only wallets (WATCH_WALLETS) buy in AFTER the bot did?
  // Either one -> p.tradersIn: the coin is held longer (normal rules instead of the quick dev rules, and a
  // wider dip before the mini cook sells). The volume/dump/stop-loss sells still protect it.
  _checkSmart(mint, p) {
    const isDev = p.leader && this.cfg.devNames?.includes(p.leader);
    const traders = isDev ? this.cfg.traderWallets || [] : [];
    const watch = this.cfg.watchWallets || [];
    if ((!traders.length && !watch.length) || p.tradersIn || (p.smartCheckAt && Date.now() - p.smartCheckAt < 60000)) return;
    const first = p.smartCheckAt == null;
    p.smartCheckAt = Date.now();
    const has = (w) => this.rpc.getTokenBalance(w, mint).then((b) => !!(b && b.ui > 0)).catch(() => false);
    Promise.all([Promise.all(traders.map(has)), Promise.all(watch.map((x) => has(x.wallet)))])
      .then(([tIn, wIn]) => {
        const watchIn = watch.filter((_, i) => wIn[i]).map((x) => x.name);
        if (first) p.watchAtBuy = watchIn; // already in before us: doesn't count
        const newcomers = watchIn.filter((n) => !(p.watchAtBuy || []).includes(n));
        if (tIn.some(Boolean) || newcomers.length) {
          p.tradersIn = true;
          p.smartNames = newcomers;
          log.info(`${p.symbol || mint}: ${newcomers.length ? `${newcomers.join(', ')} bought in after us` : 'a tracked trader is in this dev coin'} — holding it longer`);
          this.save();
        }
      })
      .catch(() => {});
  }

  // Holder count of a coin (wallets with a balance), refreshed in the background at most once a minute.
  // Returns the last known { n, at } right away so the take-profit loop never waits on it.
  _holders(mint) {
    this.holderCache ||= new Map();
    const c = this.holderCache.get(mint);
    if ((!c || Date.now() - c.at > 60000) && !c?.busy) {
      const entry = { ...(c || {}), busy: true };
      this.holderCache.set(mint, entry);
      this.countHolders(mint)
        .then((n) => this.holderCache.set(mint, { n, at: Date.now() }))
        .catch(() => this.holderCache.set(mint, { n: c?.n ?? null, at: Date.now() }));
    }
    return c && !c.busy ? c : c?.n != null ? c : null;
  }

  // Helius DAS: up to 1000 non-empty token accounts; unique owners = holders
  async countHolders(mint) {
    const r = await this.rpc.call('getTokenAccounts', { mint, limit: 1000, options: { showZeroBalance: false } });
    const accts = r?.token_accounts;
    if (!Array.isArray(accts)) throw new Error('no holder data');
    return new Set(accts.filter((a) => +a.amount > 0).map((a) => a.owner)).size;
  }

  // ---- daily recap ----
  _dayKey(t) {
    const d = new Date(t);
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  }

  // today's record; a new day starts from the wallet balance at that moment
  _today() {
    const key = this._dayKey(this.now());
    if (!this.day || this.day.date !== key) {
      this.day = { date: key, startSol: this.balCache?.sol ?? null, buys: 0, spent: 0, sells: 0, got: 0, trips: [], recapSent: false };
    }
    if (this.day.startSol == null && this.balCache?.sol != null) this.day.startSol = this.balCache.sol;
    return this.day;
  }

  _dayAdd({ buys = 0, spent = 0, sells = 0, got = 0, trip = null }) {
    const d = this._today();
    d.buys += buys;
    d.spent += spent || 0;
    d.sells += sells;
    d.got += got || 0;
    if (trip) {
      const t = { sym: trip.sym, pnl: +trip.pnl.toFixed(6), x: +trip.x.toFixed(3), leader: trip.leader, at: this.now(), ...(trip.confirmed ? { confirmed: true } : {}), ...(trip.mint ? { mint: trip.mint } : {}), ...(trip.buyMc ? { buyMc: Math.round(trip.buyMc) } : {}), ...(trip.cost ? { cost: +trip.cost.toFixed(4) } : {}) };
      d.trips.push(t);
      if (d.trips.length > 300) d.trips.shift();
      // V2.9.8 every closed coin, kept across days (for /wins)
      (this.tripLog ||= []).push(t);
      if (this.tripLog.length > 1000) this.tripLog.splice(0, this.tripLog.length - 1000);
      // V2.11.6 all-time profit per trader copied (never trimmed)
      if (t.leader) (this.lifeByLeader ||= {})[t.leader] = Math.round(((this.lifeByLeader[t.leader] || 0) + t.pnl) * 1e6) / 1e6;
    }
  }

  // V2.9.8 /wins: the coins that made the most, and the market caps the bot bought at (winners vs losers)
  winsText({ leader = null, n = 10, trips = null } = {}) {
    const all = (trips || this.tripLog || []).filter((t) => !leader || (t.leader || '').toLowerCase() === leader.toLowerCase());
    if (!all.length) return `🏆 No closed coins${leader ? ` from ${e(leader)}` : ''} yet.`;
    const won = all.filter((t) => t.pnl > 0).sort((a, b) => b.pnl - a.pnl);
    const lost = all.filter((t) => t.pnl <= 0);
    const mcs = (a) => a.map((t) => t.buyMc).filter((m) => m > 0).sort((x, y) => x - y);
    const med = (a) => (a.length ? a[Math.floor(a.length / 2)] : null);
    const ago = (t) => {
      const h = (Date.now() - t) / 3600000;
      return h < 1 ? `${Math.max(1, Math.round(h * 60))}m` : h < 48 ? `${Math.round(h)}h` : `${Math.round(h / 24)}d`;
    };
    const sum = (a) => a.reduce((x, t) => x + t.pnl, 0);
    const lines = [`🏆 <b>Biggest wins</b>${leader ? ` from ${e(leader)}` : ''} (${won.length} of ${all.length} coins won · total ${sum(all) >= 0 ? '+' : '-'}${fmtSol(Math.abs(sum(all)))} SOL)`];
    for (const t of won.slice(0, n)) lines.push(`• <b>${e(t.sym || '?')}</b> +${fmtSol(t.pnl)} SOL (${t.x.toFixed(2)}x)${t.buyMc ? ` · bought at ${fmtUsd(t.buyMc)}` : ''}${leader ? '' : ` · ${e(t.leader || '?')}`}${t.wallet ? ` · ${e(t.wallet)}` : ''} · ${ago(t.at)} ago`);
    if (!won.length) lines.push('• none yet');
    const mw = med(mcs(won));
    const ml = med(mcs(lost));
    const ma = mcs(all);
    if (ma.length) lines.push('', `📊 <b>Market cap at our buy</b> (middle value): winners ${mw ? fmtUsd(mw) : '?'} · losers ${ml ? fmtUsd(ml) : '?'} · range ${fmtUsd(ma[0])}–${fmtUsd(ma.at(-1))}`);
    else lines.push('', '📊 Market cap at buy: recorded from v2.9.8 on (older coins don\'t have it).');
    return lines.join('\n');
  }

  // PnL lines for the hourly summary: the last hour and today so far (coins closed), totals only
  pnlLines(sinceMs = 3600000) {
    const d = this._today();
    const sign = (n) => `${n >= 0 ? '+' : '-'}${fmtSol(Math.abs(n))}`;
    const from = this.now() - sinceMs;
    const hour = d.trips.filter((t) => (t.at || 0) >= from);
    const sum = (a) => a.reduce((x, t) => x + t.pnl, 0);
    const gains = (a) => sum(a.filter((t) => t.pnl > 0));
    const losses = (a) => sum(a.filter((t) => t.pnl < 0));
    const devTrips = d.trips.filter((t) => t.leader && this.cfg.devNames?.includes(t.leader));
    const rug = (t) => t.leader && this.cfg.rugNames?.includes(t.leader);
    const devLine = this.cfg.devNames?.length ? [`👨‍💻 Devs: <b>${sign(sum(devTrips.filter((t) => !rug(t))))} SOL</b>`] : [];
    if (this.cfg.rugNames?.length) {
      const rt = d.trips.filter(rug);
      devLine.push(`🧪 Rug test: <b>${sign(sum(rt))} SOL</b> (${rt.length} coin${rt.length === 1 ? '' : 's'}, ${rt.filter((t) => t.pnl > 0).length} won)`);
    }
    return [
      ...devLine,
      `💰 PnL this hour: <b>${sign(sum(hour))} SOL</b> (gains ${sign(gains(hour))} · losses ${sign(losses(hour))})`,
      `📅 PnL today: <b>${sign(sum(d.trips))} SOL</b> (gains ${sign(gains(d.trips))} · losses ${sign(losses(d.trips))})`,
    ];
  }

  async dailyRecapText() {
    const d = this._today();
    const sol = await this.solBalance().catch(() => this.balCache?.sol ?? null);
    const open = Object.entries(this.positions).filter(([, p]) => p.tokens > 0);
    let openVal = 0;
    let openCost = 0;
    let priced = true;
    for (const [mint, p] of open) {
      const v = await withTimeout(this.valueSol(mint, p.tokens), 2500, null).catch(() => null);
      if (v == null) priced = false;
      openVal += v || 0;
      openCost += Math.max(0, p.costSol - (p.proceedsSol || 0));
    }
    const realized = d.trips.reduce((a, t) => a + t.pnl, 0);
    const wins = d.trips.filter((t) => t.pnl > 0).length;
    const sign = (n) => `${n >= 0 ? '+' : '-'}${fmtSol(Math.abs(n))}`;
    const [y, m, dd] = d.date.split('-').map(Number);
    const day = new Date(y, m - 1, dd).toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
    const lines = [`${this.isPaper ? '🧪 <b>PAPER recap' : '📅 <b>Daily recap'} — ${day}</b>`, ''];
    // totals only, no coin names
    const gains = d.trips.filter((t) => t.pnl > 0).reduce((a, t) => a + t.pnl, 0);
    const losses = d.trips.filter((t) => t.pnl < 0).reduce((a, t) => a + t.pnl, 0);
    lines.push(`🟢 Total gains: <b>${sign(gains)} SOL</b>`);
    lines.push(`🔴 Total losses: <b>${sign(losses)} SOL</b>`);
    lines.push(`${realized >= 0 ? '💰' : '📉'} Total PnL: <b>${sign(realized)} SOL</b>`);
    // V2.7 trader report card: rating per trader (A best .. F worst) and who to think about replacing
    const rep = traderReport(d.trips.map((t) => ({ ...t, leader: t.leader ? e(t.leader) : null })), { sign });
    if (rep.lines.length) lines.push('', '📋 <b>Traders today</b>', ...rep.lines);
    // V2.5 rug-dev experiment: its own line
    if (this.cfg.rugNames?.length) {
      const rt = d.trips.filter((t) => t.leader && this.cfg.rugNames.includes(t.leader));
      lines.push(`🧪 Rug test: <b>${sign(rt.reduce((a2, t) => a2 + t.pnl, 0))} SOL</b> (${rt.length} coin${rt.length === 1 ? '' : 's'}, ${rt.filter((t) => t.pnl > 0).length} won)`);
    }
    // MPT = most profitable trader: whose copies made the most SOL today
    const byTrader = {};
    for (const t of d.trips) {
      const who = t.leader || this.targetName || 'he';
      byTrader[who] = (byTrader[who] || 0) + t.pnl;
    }
    const ranked = Object.entries(byTrader).sort((a, b) => b[1] - a[1]);
    if (ranked.length) {
      const [top, pnl] = ranked[0];
      lines.push('');
      lines.push(pnl > 0 ? `🏆 <b>MPT</b> (most profitable trader): <b>${e(top)}</b> ${sign(pnl)} SOL` : `🏆 <b>MPT</b>: nobody made you SOL today (closest: <b>${e(top)}</b> ${sign(pnl)} SOL)`);
      if (ranked.length > 1) lines.push(`   ${ranked.map(([n, v]) => `${e(n)} ${sign(v)}`).join(' · ')}`);
      lines.push('');
    }
    lines.push(`🤖 ${d.trips.length} coin${d.trips.length === 1 ? '' : 's'} closed (${wins} won, ${d.trips.length - wins} lost) · ${d.buys} buy${d.buys === 1 ? '' : 's'} · ${d.sells} sell${d.sells === 1 ? '' : 's'}`);
    lines.push('');
    if (sol != null) lines.push(`👛 Wallet: <b>${fmtSol(sol)} SOL</b>${d.startSol != null ? ` (started the day at ${fmtSol(d.startSol)} SOL → ${sign(sol - d.startSol)} SOL)` : ''}`);
    if (open.length) lines.push(`👜 Still holding ${open.length} coin${open.length > 1 ? 's' : ''}: worth ~${fmtSol(openVal)} SOL${priced ? '' : ' (some unpriced)'}, ${fmtSol(openCost)} SOL still in them`);
    if (sol != null) lines.push(`💼 Total: <b>~${fmtSol(sol + openVal)} SOL</b>`);
    return lines.join('\n');
  }

  // sends the recap once a day at 23:59 (Mac's local time)
  async checkDailyRecap(send) {
    const t = new Date(this.now());
    if (t.getHours() !== 23 || t.getMinutes() < 59) return false;
    const d = this._today();
    if (d.recapSent) return false;
    d.recapSent = true;
    this.save();
    try {
      await send(await this.dailyRecapText());
    } catch (err) {
      log.warn('Daily recap failed:', err.message);
    }
    return true;
  }

  start() {
    this.resync().catch(() => {});
    setTimeout(() => this.adoptStrays().catch((err) => log.warn('adopt check failed', err.message)), 5000).unref?.();
    this._adopt = setInterval(() => this.adoptStrays().catch(() => {}), 120000);
    this.refreshBalance();
    this._bal = setInterval(() => this.refreshBalance(), 15000);
    this._tp = setInterval(() => this.checkTakeProfit().catch((err) => log.warn('take-profit check failed', err.message)), this.cfg.tpCheckMs);
    this._lp = setInterval(() => this.learnPrices().catch(() => {}), 10000);
    this._lp.unref?.();
  }

  stop() {
    clearInterval(this._tp);
    clearInterval(this._lp);
    clearInterval(this._adopt);
    for (const t of this.retries.values()) clearTimeout(t);
    clearInterval(this._bal);
  }

  // /hold <CA>: this coin only sells when he sells (no take-profit, no dying-coin sells, no 8h limit). /unhold undoes it.
  setKeep(mint, keep) {
    const p = this.positions[mint];
    if (!p) return false;
    p.keep = !!keep;
    if (!keep) p.holdWarned = false;
    this.save();
    return true;
  }

  async statusText() {
    const bal = await this.solBalance().catch(() => null);
    const c = this.cfg;
    const lines = [
      `🤖 <b>Copy trading: ${!c.enabled ? 'OFF' : this.paused ? '⏸ PAUSED' : '🟢 LIVE'}</b>`,
      `👛 Wallet: ${bal != null ? `<b>${fmtSol(bal)} SOL</b>` : '?'}`,
      `💰 Last buy: ${this.lastBuy ? `<b>${fmtSol(this.lastBuy.sol)} SOL</b> on ${e(this.lastBuy.symbol || '?')} (${fmtAgo(Date.now() - this.lastBuy.at)} ago)` : 'none yet'}`,
      `📈 Since start: ${this.stats.buys} buys · ${this.stats.sells} sells · ${this.stats.failed} failed · ${this.stats.skipped} skipped`,
    ];
    if (c.dailyLimitSol > 0) lines.push(`📅 Spent today: ${fmtSol(this.spentToday.sol)} / ${fmtSol(c.dailyLimitSol)} SOL`);
    const open = Object.entries(this.positions).filter(([, p]) => p.tokens > 0);
    if (open.length) {
      lines.push('', '<b>Open copy positions</b>');
      for (const [mint, p] of open) {
        const v = p.lastValueSol ?? (await this.valueSol(mint, p.tokens).catch(() => null));
        const x = v != null && p.costSol > 0 ? (v + p.proceedsSol) / p.costSol : null;
        lines.push(`• <b>${e(p.symbol || shortAddr(mint))}</b> in ${fmtSol(p.costSol)} SOL${p.buys > 1 ? ` (${p.buys} buys)` : ''}${v != null ? ` · now ~${fmtSol(v)} SOL` : ''}${p.proceedsSol > 0 ? ` · took out ${fmtSol(p.proceedsSol)}` : ''}${x != null ? ` (${x.toFixed(2)}x)` : ''}${p.keep ? ' · 🔒 holding till he sells' : ''}\n   <code>${mint}</code>`); // coin address kept: needed for /sell and /hold
      }
    } else lines.push('', 'No open copy positions.');
    lines.push('', '/pause · /resume · /sell &lt;CA&gt; [percent]');
    return lines.join('\n');
  }
}
