// V2.11.53 same-name versions + late chases, replaying Khalil's Nov 14 "Gregory McCarthy" coins:
// ORIG launched 1:28pm (ran to $254k, the bot made money), COPY launched 2:12pm while ORIG ran (random tweet, no
// website: $3k -> $89k -> $3k in 15 min), REAL launched 2:23pm with the story's source as its website (held ~$90k+).
import test from 'node:test';
import assert from 'node:assert/strict';
import { CoinBook, nameKey } from '../src/versions.js';

const SOL = 100; // $ per SOL
const px = (mcUsd) => mcUsd / SOL / 1e9; // SOL per token at that market cap
function world() {
  let t = Date.parse('2026-11-14T19:00:00Z');
  const info = {
    ORIG: { name: 'Gregory McCarthy', symbol: 'GREGORY', createdAt: Date.parse('2026-11-14T18:28:21Z'), website: null },
    COPY: { name: 'Gregory McCarthy', symbol: 'GREGORY', createdAt: Date.parse('2026-11-14T19:12:56Z'), website: null },
    REAL: { name: 'Gregory  McCarthy!', symbol: 'GREG', createdAt: Date.parse('2026-11-14T19:23:59Z'), website: 'https://www.facebook.com/pinalcountyanimalcontrol' },
    NEWB: { name: 'Fresh Launch', symbol: 'NEW', createdAt: null, website: null },
  };
  const coins = { get: async (m) => info[m] || null, peek: () => null };
  const book = new CoinBook({ coins, getSolPrice: () => SOL, cfg: { lateChaseX: 10, lateChaseMinutes: 5, lateChaseOkTraders: 2, versionCheck: true }, now: () => t });
  return { book, info, at: (iso) => (t = Date.parse(iso)), tick: (ms) => (t += ms) };
}
const tick = () => new Promise((r) => setImmediate(r));

test('names match loosely (case, spaces, punctuation)', () => {
  assert.equal(nameKey('Gregory McCarthy'), nameKey('gregory  mccarthy!'));
  assert.equal(nameKey('ab'), null);
});

test('copycat with no website is skipped, the one linking the real source is bought, the original is never sold for a copy', async () => {
  const w = world();
  w.at('2026-11-14T19:07:48Z');
  w.book.note('ORIG', 't58', px(30000));
  w.at('2026-11-14T19:12:57Z');
  w.book.note('ORIG', 't18', px(50000));
  await tick();
  assert.equal(await w.book.check('ORIG', 't18', px(50000)), null, 'the original (39 min old, 1.7x in 5 min): bought');
  w.at('2026-11-14T19:18:13Z');
  w.book.note('ORIG', 't17', px(200000), false); // the original still trading up high
  w.book.note('COPY', 'bot', px(3000));
  await tick();
  assert.match(await w.book.check('COPY', 'bot', px(3000)), /copycat: an older coin has the same name/);
  assert.equal(w.book.overtakenBy('ORIG'), null, 'a smaller, newer copy never sells the original');
  w.at('2026-11-14T19:25:10Z');
  w.book.note('REAL', 'bot', px(13000));
  await tick();
  assert.equal(await w.book.check('REAL', 'bot', px(13000)), null, 'same name but links the real source: bought');
});

test('a newer same-name coin that passes the old one: the old one is "old version" (not bought, held one sold)', async () => {
  const w = world();
  w.at('2026-11-14T19:30:00Z');
  w.book.note('ORIG', 't17', px(43000), false);
  w.book.note('REAL', 't3', px(98000));
  await w.book.info('ORIG');
  await tick();
  assert.equal(w.book.overtakenBy('ORIG'), 'REAL');
  assert.match(await w.book.check('ORIG', 't3', px(43000)), /old version: a newer coin with the same name \(REAL\)/);
  assert.equal(w.book.overtakenBy('REAL'), null);
  // an old price (over 5 min) isn't trusted: no sell on a stale number
  w.tick(6 * 60000);
  assert.equal(w.book.overtakenBy('ORIG'), null);
});

test('late chase: up 10x+ in under 5 min is skipped unless 2 other traders buy up there too', async () => {
  const w = world();
  w.at('2026-11-14T19:18:19Z');
  w.book.note('COPY', 't3', px(4000));
  w.at('2026-11-14T19:21:01Z');
  w.book.note('COPY', 't17', px(42000));
  w.book.cfg.versionCheck = false; // late chase only
  assert.match(await w.book.check('COPY', 't17', px(42000)), /late chase: up \d+x from the lowest a tracked trader paid in under 5 min \(only 0 other traders/);
  // two other traders bought at ~this price in the last minute: smart money up here too -> copied
  w.book.note('COPY', 't42', px(39000));
  w.book.note('COPY', 'decu', px(35000));
  assert.equal(await w.book.check('COPY', 't17', px(42000)), null);
  // 6 min later the cheap buy is out of the window: the 1.3x move since isn't a chase
  w.tick(6 * 60000);
  w.book.note('COPY', 't58', px(45000));
  assert.equal(await w.book.check('COPY', 't58', px(58000)), null);
});

test('late chase from launch: a coin 2 min old already at 12x its launch market cap', async () => {
  const w = world();
  w.at('2026-11-14T19:00:00Z');
  w.info.NEWB.createdAt = Date.parse('2026-11-14T18:58:00Z');
  w.book.note('NEWB', 'bot', 12 * 28 / 1e9);
  assert.match(await w.book.check('NEWB', 'bot', 12 * 28 / 1e9), /late chase: up 12x from launch/);
  assert.equal(await w.book.check('NEWB', 'bot', 5 * 28 / 1e9), null, '5x from launch is fine');
});

test('V2.11.61 the coin book stays bounded: old coins leave the name index too', async () => {
  const coins = { get: async (m) => ({ name: `Coin ${m}`, createdAt: 1 }), peek: () => null };
  const book = new CoinBook({ coins, cfg: { versionCheck: true } });
  for (let i = 0; i < 1600; i++) await book.info(`M${i}`);
  assert.ok(book.infos.size <= 1500);
  assert.ok(book.byName.size <= 1500, `name index ${book.byName.size}`);
  assert.equal(book.known('M0'), null);
  assert.ok(book.known('M1599'));
});
