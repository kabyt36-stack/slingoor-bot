// Builders for leaderboard tests: real-shaped Solana transactions and pump.fun trade records.
import crypto from 'node:crypto';
import { b58encode, b58decode } from '../src/solana.js';

export const PUMP = '6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P';
export const addr = () => b58encode(crypto.randomBytes(32));

// a pump.fun TradeEvent "Program data:" log line, as the program writes it
export function tradeLogs(user, mint, sol, tok, isBuy) {
  const b = Buffer.alloc(401);
  Buffer.from([189, 219, 127, 211, 78, 230, 97, 238]).copy(b, 0);
  Buffer.from(b58decode(mint)).copy(b, 8);
  b.writeBigUInt64LE(BigInt(Math.round(sol * 1e9)), 40);
  b.writeBigUInt64LE(BigInt(Math.round(tok * 1e6)), 48);
  b[56] = isBuy ? 1 : 0;
  Buffer.from(b58decode(user)).copy(b, 57);
  return [
    `Program ${PUMP} invoke [1]`,
    `Program log: Instruction: ${isBuy ? 'Buy' : 'Sell'}`,
    `Program data: ${b.toString('base64')}`,
    `Program ${PUMP} success`,
  ];
}

// getTransaction(encoding=json) result for one swap by `wallet`: solDelta SOL (negative = spent),
// token balance tokPre -> tokPost of `mint` (6 decimals)
export function swapTx({ wallet, sig, time, mint, solDelta, tokPre, tokPost, fee = 5000 }) {
  const pre = 10_000_000_000;
  const post = pre + Math.round(solDelta * 1e9) - fee;
  const tb = (amt) => [{ accountIndex: 2, mint, owner: wallet, programId: 'TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA', uiTokenAmount: { amount: String(Math.round(amt * 1e6)), decimals: 6, uiAmount: amt, uiAmountString: String(amt) } }];
  return {
    slot: 1000 + Math.floor(time / 400),
    blockTime: Math.floor(time / 1000),
    version: 0,
    transaction: {
      signatures: [sig],
      message: { accountKeys: [wallet, 'pAMMBay6oceH9fJKBRHGP5D4bD4sWpmSwMn52FMfXEA', 'TokAcct1111111111111111111111111111111111111'], header: { numRequiredSignatures: 1, numReadonlySignedAccounts: 0, numReadonlyUnsignedAccounts: 1 }, instructions: [], recentBlockhash: 'x' },
    },
    meta: {
      err: null,
      fee,
      preBalances: [pre, 1, 2039280],
      postBalances: [post, 1, 2039280],
      preTokenBalances: tb(tokPre),
      postTokenBalances: tb(tokPost),
      logMessages: ['Program pAMMBay6oceH9fJKBRHGP5D4bD4sWpmSwMn52FMfXEA invoke [1]', 'Program pAMMBay6oceH9fJKBRHGP5D4bD4sWpmSwMn52FMfXEA success'],
      loadedAddresses: { writable: [], readonly: [] },
    },
  };
}

// A fake chain: wallets' transactions, served the way getSignaturesForAddress / getTransaction do.
export class FakeChain {
  constructor() {
    this.sigs = {}; // wallet -> [{signature, blockTime, err}] oldest first
    this.txs = {};
    this.calls = { getSignaturesForAddress: 0, getTransaction: 0 };
    this.failTx = new Set();
    this.n = 0;
  }
  // a round trip: buy `cost` SOL at time t, sell for `got` SOL `holdMin` minutes later
  trip(wallet, t, cost, got, { holdMin = 30, mint = addr(), tok = 1000 } = {}) {
    this.add(wallet, t, mint, -cost, 0, tok);
    if (got != null) this.add(wallet, t + holdMin * 60000, mint, got, tok, 0);
    return mint;
  }
  add(wallet, time, mint, solDelta, tokPre, tokPost) {
    const sig = `sig${++this.n}x${wallet.slice(0, 6)}`;
    this.txs[sig] = swapTx({ wallet, sig, time, mint, solDelta, tokPre, tokPost });
    (this.sigs[wallet] ||= []).push({ signature: sig, blockTime: Math.floor(time / 1000), err: null, slot: this.txs[sig].slot });
    this.sigs[wallet].sort((a, b) => a.blockTime - b.blockTime);
    return sig;
  }
  // a failed transaction (err) and spam that mentions the wallet but it didn't sign
  noise(wallet, time) {
    const sig = `bad${++this.n}`;
    (this.sigs[wallet] ||= []).push({ signature: sig, blockTime: Math.floor(time / 1000), err: { InstructionError: [0, 'x'] } });
    const spam = `spam${++this.n}`;
    const tx = swapTx({ wallet: 'Someone1111111111111111111111111111111111111', sig: spam, time, mint: addr(), solDelta: -1, tokPre: 0, tokPost: 5 });
    this.txs[spam] = tx;
    this.sigs[wallet].push({ signature: spam, blockTime: Math.floor(time / 1000), err: null });
    this.sigs[wallet].sort((a, b) => a.blockTime - b.blockTime);
  }
  handle(method, params) {
    this.calls[method] = (this.calls[method] || 0) + 1;
    if (method === 'getSignaturesForAddress') {
      const [wallet, o = {}] = params;
      let list = [...(this.sigs[wallet] || [])].reverse(); // newest first
      if (o.before) list = list.slice(list.findIndex((s) => s.signature === o.before) + 1);
      if (o.until) {
        const i = list.findIndex((s) => s.signature === o.until);
        if (i >= 0) list = list.slice(0, i);
      }
      return list.slice(0, o.limit || 1000);
    }
    if (method === 'getTransaction') {
      if (this.failTx.has(params[0])) throw Object.assign(new Error('getTransaction: boom'), { rpcCode: -32000 });
      return this.txs[params[0]] || null;
    }
    return null;
  }
  // an Rpc-like object
  rpc() {
    return {
      call: async (m, p) => this.handle(m, p),
      getTransaction: async (sig) => this.handle('getTransaction', [sig]),
    };
  }
}
