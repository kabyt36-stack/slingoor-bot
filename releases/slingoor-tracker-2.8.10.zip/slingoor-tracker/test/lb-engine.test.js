import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { EventEmitter } from 'node:events';
import { Discovery, TradeStream } from '../src/leaderboard/discover.js';
import { Scanner } from '../src/leaderboard/scanner.js';
import { rows, boards, boardMessages, autoPicks, coinsMessage, periodOf } from '../src/leaderboard/board.js';
import { TopCoins } from '../src/leaderboard/topcoins.js';
import { LeaderboardService } from '../src/leaderboard/service.js';
import { createEngine } from '../src/leaderboard/worker.js';
import { greenStreak, windowStats, dayBefore } from '../src/leaderboard/score.js';
import { loadConfig } from '../src/config.js';
import { FakeChain, tradeLogs, addr } from './lb-fixtures.js';

const tmpdir = () => fs.mkdtempSync(path.join(os.tmpdir(), 'lb-'));
const H = 3600000;
const NOW = new Date(2026, 10, 11, 21, 0, 0).getTime();
const noonDaysAgo = (n, h = 12) => {
  const d = new Date(NOW);
  d.setHours(h, 0, 0, 0);
  d.setDate(d.getDate() - n);
  return d.getTime();
};

// ---------------- discovery ----------------
test('discovery: finds the profitable human, ignores losers, tiny wallets and spam bots', () => {
  let t = NOW;
  const d = new Discovery({ minTrades: 4, maxTradesPerDay: 400, minVolSol: 1, now: () => t });
  const human = addr();
  const loser = addr();
  const bot = addr();
  const tiny = addr();
  for (let i = 0; i < 3; i++) {
    const m = addr();
    d.addLogs(tradeLogs(human, m, 1, 1000, true));
    d.addLogs(tradeLogs(human, m, 1.8, 1000, false));
    const m2 = addr();
    d.addLogs(tradeLogs(loser, m2, 1, 1000, true));
    d.addLogs(tradeLogs(loser, m2, 0.3, 1000, false));
  }
  for (let i = 0; i < 900; i++) {
    const m = addr();
    d.add({ user: bot, mint: m, solAmount: 0.5, tokenAmount: 10, isBuy: true });
    d.add({ user: bot, mint: m, solAmount: 0.51, tokenAmount: 10, isBuy: false });
  }
  const m = addr();
  d.addLogs(tradeLogs(tiny, m, 0.01, 5, true));
  d.addLogs(tradeLogs(tiny, m, 0.03, 5, false));
  const c = d.candidates(10);
  assert.deepEqual(c.map((x) => x.wallet), [human]);
  assert.ok(Math.abs(c[0].pnl - 2.4) < 1e-6);
  assert.equal(c[0].wins, 3);
  // handed out once only
  assert.deepEqual(d.candidates(10), []);
  // tiny wallet forgotten after 30 idle minutes, the others kept
  t += 31 * 60000;
  d.prune();
  assert.ok(!d.w.has(tiny));
  assert.ok(d.w.has(human) && d.w.has(loser));
  // a sell with no buy seen (bought before we listened) is not profit
  const late = addr();
  d.add({ user: late, mint: addr(), solAmount: 50, tokenAmount: 10, isBuy: false });
  assert.equal(d.w.get(late).pnl, 0);
});

test('stream: subscribes to pump.fun, feeds trades, honours the daily data cap, reconnects', async () => {
  const socks = [];
  class FakeWS {
    constructor(url) {
      this.url = url;
      this.sent = [];
      socks.push(this);
      setTimeout(() => this.onopen?.(), 1);
    }
    send(s) {
      this.sent.push(JSON.parse(s));
    }
    close() {
      this.closed = true;
      setTimeout(() => this.onclose?.(), 1);
    }
    push(logs) {
      this.onmessage({ data: JSON.stringify({ jsonrpc: '2.0', method: 'logsNotification', params: { result: { value: { signature: 's', err: null, logs } } } }) });
    }
  }
  const d = new Discovery();
  const s = new TradeStream({ url: 'wss://x', discovery: d, maxMbPerDay: 0.003, WebSocketImpl: FakeWS });
  s.backoff = 5;
  s.start();
  await new Promise((r) => setTimeout(r, 10));
  assert.equal(socks[0].sent[0].method, 'logsSubscribe');
  assert.deepEqual(socks[0].sent[0].params[0], { mentions: ['6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P'] });
  const u = addr();
  socks[0].push(tradeLogs(u, addr(), 1, 100, true));
  assert.equal(s.stats.trades, 1);
  assert.ok(d.w.has(u));
  // 3 KB cap -> paused, no reconnect
  for (let i = 0; i < 10; i++) socks[0].push(tradeLogs(u, addr(), 1, 100, true));
  assert.ok(s.stats.capped);
  await new Promise((r) => setTimeout(r, 30));
  assert.equal(socks.length, 1);
  s.stop();
  // a dropped connection reconnects
  const s2 = new TradeStream({ url: 'wss://y', discovery: d, WebSocketImpl: FakeWS });
  s2.backoff = 5;
  s2.start();
  await new Promise((r) => setTimeout(r, 10));
  socks.at(-1).close();
  await new Promise((r) => setTimeout(r, 40));
  assert.equal(socks.length, 3);
  s2.stop();
});

// ---------------- scanner ----------------
function sixGreenDays(chain, w) {
  // day 6..1: a win each day, plus a loss on day 3 (still a green day overall)
  for (let n = 6; n >= 1; n--) {
    chain.trip(w, noonDaysAgo(n, 10), 1, 1.6);
    chain.trip(w, noonDaysAgo(n, 14), 0.5, 0.8);
  }
  chain.trip(w, noonDaysAgo(3, 16), 1, 0.7);
  chain.noise(w, noonDaysAgo(2, 9));
}

test('scanner: reads a wallet\'s history once, scores it, then only reads new transactions', async () => {
  const chain = new FakeChain();
  const w = addr();
  sixGreenDays(chain, w);
  const dir = tmpdir();
  let t = NOW;
  const sc = new Scanner({ rpc: chain.rpc(), file: path.join(dir, 'lb.json'), historyDays: 7, dailyCredits: 0, now: () => t, rescanMinutes: 60 });
  sc.enqueue([w]);
  const r1 = await sc.cycle();
  assert.equal(r1.added, 1);
  const rec = sc.d.wallets[w];
  const firstTx = chain.calls.getTransaction;
  assert.equal(firstTx, 27); // 26 swaps + 1 spam (the failed one is never downloaded)
  const s = windowStats(rec, t, 7);
  assert.equal(s.wins, 12);
  assert.equal(s.losses, 1);
  assert.ok(Math.abs(s.pnl - (6 * 0.9 - 0.3)) < 1e-6, `pnl ${s.pnl}`);
  assert.equal(greenStreak(rec, t), 6);
  // spam token sent to the wallet by someone else is not a trade
  assert.equal(Object.keys(rec.pos).length, 0);

  // new trades today -> the next scan downloads only those
  t += H;
  chain.trip(w, t - 30 * 60000, 2, 3, { holdMin: 10 });
  await sc.cycle();
  assert.equal(chain.calls.getTransaction - firstTx, 2);
  assert.ok(Math.abs(windowStats(sc.d.wallets[w], t, 7).pnl - (6 * 0.9 - 0.3 + 1)) < 1e-6);
  // nothing new -> nothing downloaded
  t += H;
  const before = chain.calls.getTransaction;
  await sc.cycle();
  assert.equal(chain.calls.getTransaction, before);
  // saved and reloaded the same
  const sc2 = new Scanner({ rpc: chain.rpc(), file: path.join(dir, 'lb.json'), now: () => t });
  assert.equal(greenStreak(sc2.d.wallets[w], t), 6);
  // after midnight today's green day joins the streak
  assert.equal(greenStreak(sc2.d.wallets[w], t + 3 * H), 7);
});

test('scanner: daily credit budget is never overspent; wallets wait for tomorrow', async () => {
  const chain = new FakeChain();
  const a = addr();
  const b = addr();
  sixGreenDays(chain, a);
  sixGreenDays(chain, b);
  let t = NOW;
  const sc = new Scanner({ rpc: chain.rpc(), file: path.join(tmpdir(), 'lb.json'), dailyCredits: 40, now: () => t });
  sc.enqueue([a, b]);
  const r = await sc.cycle();
  assert.equal(r.added, 1);
  assert.ok(r.budget);
  assert.ok(sc._budget().used <= 40, `used ${sc._budget().used}`);
  assert.ok(!sc.d.wallets[b]);
  assert.deepEqual(sc.d.queue, [b]);
  // next day: the budget resets and b gets scanned
  t += 24 * H;
  const r2 = await sc.cycle();
  assert.equal(r2.added, 1);
  assert.ok(sc.d.wallets[b].coverFrom);
});

test('scanner: wallets with thousands of transactions are flagged as bots without downloading them', async () => {
  const chain = new FakeChain();
  const w = addr();
  for (let i = 0; i < 60; i++) chain.trip(w, NOW - 3 * H + i * 60000, 0.1, 0.11, { holdMin: 0.05 });
  const sc = new Scanner({ rpc: chain.rpc(), file: path.join(tmpdir(), 'lb.json'), maxTxPerWallet: 50, now: () => NOW });
  sc.enqueue([w]);
  const r = await sc.cycle();
  assert.equal(r.bots, 1);
  assert.equal(chain.calls.getTransaction, 0);
  assert.match(sc.d.wallets[w].flags.why, /50\+ transactions/);
});

test('scanner: a download that fails part-way loses nothing and counts nothing twice', async () => {
  const chain = new FakeChain();
  const w = addr();
  sixGreenDays(chain, w);
  const all = chain.sigs[w].filter((s) => !s.err).map((s) => s.signature);
  chain.failTx.add(all[13]);
  let t = NOW;
  const sc = new Scanner({ rpc: chain.rpc(), file: path.join(tmpdir(), 'lb.json'), now: () => t, rescanMinutes: 1 });
  sc.enqueue([w]);
  await sc.cycle();
  chain.failTx.clear();
  t += 5 * 60000;
  await sc.cycle();
  const s = windowStats(sc.d.wallets[w], t, 7);
  assert.equal(s.wins + s.losses, 13);
  assert.ok(Math.abs(s.pnl - (6 * 0.9 - 0.3)) < 1e-6, `pnl ${s.pnl}`);
});

test('scanner: seeds (tracked traders) are always scanned and never evicted; pool stays at its size', async () => {
  const chain = new FakeChain();
  const seed = addr();
  sixGreenDays(chain, seed);
  const others = Array.from({ length: 6 }, () => addr());
  others.forEach((w, i) => chain.trip(w, noonDaysAgo(1), 1, i % 2 ? 0.5 : 2));
  const sc = new Scanner({ rpc: chain.rpc(), file: path.join(tmpdir(), 'lb.json'), poolSize: 4, seeds: [{ wallet: seed, name: 'schoen' }], now: () => NOW });
  sc.enqueue(others);
  await sc.cycle({ newPerCycle: 10 });
  const left = Object.keys(sc.d.wallets);
  assert.equal(left.length, 4);
  assert.ok(left.includes(seed));
  assert.equal(sc.d.wallets[seed].name, 'schoen');
});

// ---------------- boards ----------------
test('boards: ranking, filters, message size, auto-copy picks', () => {
  const recs = [];
  const mk = (name, streak, pnlPerDay, { wr = 1, active = true, bot = false } = {}) => {
    const r = { wallet: addr(), name, coverFrom: noonDaysAgo(20), lastTradeAt: active ? NOW - H : NOW - 5 * 24 * H, days: {}, curWin: Math.round(streak * 2 * wr), bestWin: 9, holds: [600], flags: bot ? { bot: true } : null, pos: {} };
    for (let n = 1; n <= 7; n++) {
      const green = n <= streak;
      r.days[dayBefore(NOW, n)] = { pnl: green ? pnlPerDay : -0.5, wins: green ? Math.round(4 * wr) : 0, losses: green ? 4 - Math.round(4 * wr) : 2, buySol: 5, trades: 10 };
    }
    recs.push(r);
    return r;
  };
  const a = mk('a', 7, 1);
  const b = mk('b', 3, 5);
  const c = mk('c', 5, 0.5, { wr: 0.25 });
  mk('gone', 7, 9, { active: false });
  mk('bot', 7, 9, { bot: true });
  const list = rows(recs, NOW, { minTrips: 5 });
  assert.deepEqual(list.map((x) => x.name).sort(), ['a', 'b', 'c']);
  const bd = boards(list, { minWinRate: 0.5 });
  assert.deepEqual(bd.byStreak.map((x) => x.name), ['a', 'c', 'b']);
  assert.deepEqual(bd.byPnl.map((x) => x.name), ['b', 'a']); // c's win rate is too low
  const picks = autoPicks(list, { count: 3, minStreak: 3, minWinRate: 0.55, minPnl: 2, exclude: new Set([b.wallet]) });
  assert.deepEqual(picks.map((x) => x.name), ['a']);
  // 25 wallets with long names still fit Telegram's limit, and every message is valid-looking HTML
  for (let i = 0; i < 25; i++) mk(`trader_${i}_with_a_long_name`, 6, 2);
  const msgs = boardMessages(rows(recs, NOW), { top: 25, followed: new Set([a.wallet]), stats: 'x', picks, autoOn: false, dateLabel: 'Wed, Nov 11' });
  assert.equal(msgs.length, 3);
  for (const m of msgs) {
    assert.ok(m.length <= 4096, `length ${m.length}`);
    assert.equal((m.match(/<a /g) || []).length, (m.match(/<\/a>/g) || []).length);
    assert.equal((m.match(/<code>/g) || []).length, (m.match(/<\/code>/g) || []).length);
  }
  assert.match(msgs[0], /Longest green-day streaks/);
  assert.match(msgs[0], /⭐/);
  assert.match(msgs[2], /Auto-copy is <b>off<\/b> — it would copy/);
  assert.ok(msgs[0].includes(`<code>${a.wallet}</code>`));
});

// ---------------- whole engine: live trades in, leaderboard out ----------------
test('engine: a wallet trading on pump.fun is found by the stream, its history scored, and it tops the board', async () => {
  const chain = new FakeChain();
  const star = addr();
  sixGreenDays(chain, star);
  const socks = [];
  class FakeWS {
    constructor() {
      socks.push(this);
      setTimeout(() => this.onopen?.(), 1);
    }
    send() {}
    close() {}
  }
  const dir = tmpdir();
  const lb = loadConfig('/nonexistent').leaderboard;
  const dexCalls = [];
  const dex = async (url) => {
    dexCalls.push(url);
    const mints = url.split('/').pop().split(',');
    return { pairs: mints.map((m, i) => ({ baseToken: { address: m, symbol: `C${i}`, name: `Coin ${i}` }, marketCap: 100000 * (i + 1), pairCreatedAt: NOW - 3 * H, liquidity: { usd: 1 } })) };
  };
  Object.assign(lb, { file: path.join(dir, 'lb.json'), postFile: path.join(dir, 'post.json'), coinsFile: path.join(dir, 'coins.json'), coinsOpts: { fetch: dex, gapMs: 0, minVolSol: 1 }, seeds: [], stream: 'public', publicWs: 'wss://x' });
  const eng = createEngine(lb, { rpc: chain.rpc(), now: () => NOW, WebSocketImpl: FakeWS });
  eng.start();
  await new Promise((r) => setTimeout(r, 10));
  // today on pump.fun: two winning trips and one loss
  const push = (logs) => socks[0].onmessage({ data: JSON.stringify({ params: { result: { value: { err: null, logs } } } }) });
  for (const [cost, got] of [[1, 2], [1, 1.5], [1, 0.8]]) {
    const m = addr();
    push(tradeLogs(star, m, cost, 1000, true));
    push(tradeLogs(star, m, got, 1000, false));
  }
  const r = await eng.cycle();
  assert.equal(r.added, 1);
  const b = eng.board();
  eng.stop();
  assert.match(b.msgs[0], /🥇 <a href="https:\/\/gmgn.ai\/sol\/address\//);
  assert.ok(b.msgs[0].includes(star), 'star wallet on the streak board');
  assert.match(b.msgs[0], /🔥 6d green/);
  assert.match(b.msgs[0], /1 wallets tracked/);
  assert.equal(b.picks[0].wallet, star); // would be auto-copied (but auto-copy is off)
  assert.match(eng.status(), /Leaderboard scanner/);
  // the coins it saw trading got a market cap and are on the coins board
  assert.ok(dexCalls.length >= 1 && dexCalls[0].includes('/latest/dex/tokens/'));
  const cm = eng.coinsBoard({ period: 'day' })[0];
  assert.match(cm, /Biggest coins — today/);
  assert.match(cm, /peak <b>\$\d+K<\/b>/);
  // other periods
  assert.match(eng.board({ period: 'yesterday' }).msgs[1], /Top PnL — yesterday/);
  assert.match(eng.board({ period: 'month' }).msgs[1], /Top PnL — 30 days/);
  assert.ok(eng.board({ period: 'yesterday' }).msgs[1].includes(star));
  assert.match(eng.board({ period: 'yesterday' }).msgs[1], /\+0\.90 SOL<\/b> yesterday/);
  // morning post (NOW is a Wednesday): wallets (3) + coins of the day
  const dly = eng.daily();
  assert.equal(dly.msgs.length, 4);
  assert.match(dly.msgs[3], /Biggest coins — today/);
  assert.equal(dly.picks[0].wallet, star);
});

// ---------------- daily post + phase 2 ----------------
function fakeWorker(answers) {
  const w = new EventEmitter();
  w.postMessage = (m) => setImmediate(() => w.emit('message', { id: m.id, result: answers[m.cmd] }));
  w.terminate = () => {};
  return w;
}

test('daily post: not on the very first day, then once a day at the set time', async () => {
  const dir = tmpdir();
  const lb = { postHour: 9, postMinute: 0, postFile: path.join(dir, 'post.json'), autoCopy: false, autoTradersFile: path.join(dir, 'lbt.json') };
  let t = new Date(2026, 10, 11, 22, 5).getTime();
  const sent = [];
  const svc = new LeaderboardService({ lb, workerData: {}, send: async (h) => sent.push(h), now: () => t, makeWorker: () => fakeWorker({ daily: { msgs: ['B1', 'B2', 'B3'], picks: [] } }) });
  svc._spawn();
  assert.equal(await svc.tick(), false); // first run: tomorrow
  t = new Date(2026, 10, 12, 8, 59).getTime();
  assert.equal(await svc.tick(), false);
  t = new Date(2026, 10, 12, 9, 0).getTime();
  assert.equal(await svc.tick(), true);
  assert.deepEqual(sent, ['B1', 'B2', 'B3']);
  t = new Date(2026, 10, 12, 15, 0).getTime();
  assert.equal(await svc.tick(), false);
  // survives a restart without posting twice
  const svc2 = new LeaderboardService({ lb, workerData: {}, send: async (h) => sent.push(h), now: () => t, makeWorker: () => fakeWorker({}) });
  assert.equal(await svc2.tick(), false);
  assert.equal(sent.length, 3);
  assert.ok(!fs.existsSync(lb.autoTradersFile)); // auto-copy off: nothing written
});

test('phase 2 auto-copy (when switched on): writes the picks, restarts once, the config then copies them', async () => {
  const dir = tmpdir();
  const lbt = path.join(dir, 'lbt.json');
  const lb = { postHour: 9, postMinute: 0, postFile: path.join(dir, 'post.json'), autoCopy: true, autoTradersFile: lbt };
  const w1 = addr();
  let relaunches = 0;
  const sent = [];
  const svc = new LeaderboardService({ lb, workerData: {}, send: async (h) => sent.push(h), relaunch: () => relaunches++, makeWorker: () => fakeWorker({}) });
  assert.equal(await svc.applyAutoCopy([{ wallet: w1, streak: 5, pnl7: 9 }]), true);
  assert.equal(relaunches, 1);
  assert.match(sent[0], /Auto-copy/);
  assert.equal(await svc.applyAutoCopy([{ wallet: w1, streak: 6, pnl7: 10 }]), false); // same wallets: no restart
  assert.equal(relaunches, 1);
  // config picks them up only with LB_AUTO_COPY=on
  const settings = path.join(dir, 'settings.txt');
  fs.writeFileSync(settings, `TELEGRAM_BOT_TOKEN=1:x\nLB_AUTO_TRADERS_FILE=${lbt}\nLB_AUTO_COPY_BUY_SOL=0.03\n`);
  const off = loadConfig(settings);
  assert.ok(!off.traders.some((t) => t.name === 'lb1'));
  fs.appendFileSync(settings, 'LB_AUTO_COPY=on\n');
  const onCfg = loadConfig(settings);
  const t = onCfg.traders.find((x) => x.name === 'lb1');
  assert.deepEqual(t.wallets, [w1]);
  assert.ok(onCfg.wallets.includes(w1));
  assert.equal(onCfg.copy.traderBuySol.lb1, 0.03);
  // auto-copied wallets are not "seeds" on the board
  assert.ok(!onCfg.leaderboard.seeds.some((s) => s.wallet === w1));
});

test('settings: post time formats, seeds from traders + watch wallets, off switch', () => {
  const dir = tmpdir();
  const f = path.join(dir, 's.txt');
  const w = addr();
  fs.writeFileSync(f, `TELEGRAM_BOT_TOKEN=1:x\nLB_POST_TIME=9:30pm\nLB_SEED_WALLETS=whale:${w}\nLB_MIN_WIN_RATE=60\n`);
  const c = loadConfig(f).leaderboard;
  assert.equal(c.postHour, 21);
  assert.equal(c.postMinute, 30);
  assert.equal(c.minWinRate, 0.6);
  assert.ok(c.seeds.some((s) => s.name === 'whale' && s.wallet === w));
  assert.ok(c.seeds.some((s) => s.name === 'schoen'));
  assert.ok(c.seeds.some((s) => s.name === 'cyberleek'));
  fs.writeFileSync(f, 'TELEGRAM_BOT_TOKEN=1:x\nLEADERBOARD=off\nLB_POST_TIME=7\n');
  const c2 = loadConfig(f).leaderboard;
  assert.equal(c2.enabled, false);
  assert.equal(c2.postHour, 7);
});

test('the scanner thread really starts, answers, and comes back if it dies', { timeout: 30000 }, async () => {
  const dir = tmpdir();
  const lb = { ...loadConfig('/nonexistent').leaderboard, file: path.join(dir, 'lb.json'), postFile: path.join(dir, 'post.json'), stream: 'off', seeds: [], coinsFile: path.join(dir, 'coins.json') };
  const svc = new LeaderboardService({ lb, workerData: { lb, rpcUrl: 'http://127.0.0.1:9/', heliusKeys: [], heliusWs: null, logFile: path.join(dir, 'bot.log'), isPublicRpc: false }, send: async () => {} });
  svc._spawn();
  const msgs = await svc.command('');
  assert.match(msgs[0], /Wallet leaderboard/);
  assert.match((await svc.command('status'))[0], /Stream: off/);
  // kill the thread: it's restarted
  svc.deaths = -1; // first restart after ~2.5s
  await svc.w.terminate();
  const t0 = Date.now();
  while (Date.now() - t0 < 15000) {
    try {
      if ((await svc.command(''))[0]) break;
    } catch {}
    await new Promise((r) => setTimeout(r, 300));
  }
  assert.match((await svc.command(''))[0], /Wallet leaderboard/);
  svc.stop();
});

// ---------------- day / week / month + coins ----------------
test('periods: day, yesterday, week and month rank on their own PnL', () => {
  const mkRec = (name, per) => {
    const r = { wallet: addr(), name, coverFrom: noonDaysAgo(40), lastTradeAt: NOW - H, days: {}, curWin: 3, bestWin: 3, holds: [600], flags: null, pos: {} };
    for (const [n, pnl] of Object.entries(per)) r.days[dayBefore(NOW, +n)] = { pnl, wins: pnl > 0 ? 3 : 0, losses: pnl > 0 ? 0 : 3, buySol: 5, trades: 6 };
    return r;
  };
  const recs = [mkRec('todayKing', { 0: 9, 1: -1, 5: -1 }), mkRec('ydayKing', { 0: 1, 1: 8 }), mkRec('weekKing', { 0: 2, 1: 2, 3: 20 }), mkRec('monthKing', { 0: 1, 1: 1, 20: 90 })];
  const topOf = (days, offset, minTrips) => boards(rows(recs, NOW, { days, offset, minTrips }), {}).byPnl[0].name;
  assert.equal(topOf(1, 0, 2), 'todayKing');
  assert.equal(topOf(1, 1, 2), 'ydayKing');
  assert.equal(topOf(7, 0, 5), 'weekKing');
  assert.equal(topOf(30, 0, 5), 'monthKing');
  assert.equal(periodOf('daily'), 'today');
  assert.equal(periodOf('Monthly'), 'month');
  assert.equal(periodOf('7d'), 'week');
  assert.equal(periodOf('status'), null);
  const m = boardMessages(rows(recs, NOW, { days: 30 }), { label: '30 days', only: 'pnl' });
  assert.equal(m.length, 1);
  assert.match(m[0], /Top PnL — 30 days/);
  assert.match(m[0], /\+92\.0 SOL<\/b> 30 days/);
});

test('morning post adds the weekly boards on Monday and the monthly boards on the 1st', async () => {
  const mk = (t) => {
    const dir = tmpdir();
    const lb = { ...loadConfig('/nonexistent').leaderboard, file: path.join(dir, 'lb.json'), coinsFile: path.join(dir, 'c.json'), seeds: [], stream: 'off' };
    return createEngine(lb, { rpc: new FakeChain().rpc(), now: () => t }).daily().msgs;
  };
  const wed = mk(new Date(2026, 10, 11, 9, 0).getTime());
  assert.equal(wed.length, 4);
  const mon = mk(new Date(2026, 10, 16, 9, 0).getTime());
  assert.equal(mon.length, 6);
  assert.match(mon[4], /Weekly leaderboard[\s\S]*Top PnL — last 7 days/);
  assert.match(mon[5], /Biggest coins — this week/);
  const first = mk(new Date(2026, 11, 1, 9, 0).getTime()); // Tuesday Dec 1
  assert.equal(first.length, 6);
  assert.match(first[4], /Monthly leaderboard[\s\S]*Top PnL — last 30 days/);
  assert.match(first[5], /Biggest coins — this month/);
  for (const m of [...mon, ...first]) assert.ok(m.length <= 4096);
});

test('biggest coins: volume picks what to price, peaks are kept, periods go by launch time, junk is dropped', async () => {
  let t = NOW;
  const mc = {};
  const created = {};
  const calls = [];
  const fetch = async (url) => {
    const mints = url.split('/').pop().split(',');
    calls.push(mints.length);
    return { pairs: mints.filter((m) => mc[m]).flatMap((m) => [
      { baseToken: { address: m, symbol: `S${m.slice(0, 3)}`, name: 'N' }, marketCap: mc[m], pairCreatedAt: created[m] + 3600000, liquidity: { usd: 5 } },
      { baseToken: { address: m, symbol: `S${m.slice(0, 3)}`, name: 'N' }, marketCap: mc[m] * 0.99, pairCreatedAt: created[m], liquidity: { usd: 1 } },
    ]) };
  };
  const file = path.join(tmpdir(), 'coins.json');
  const tc = new TopCoins({ file, dexApi: 'http://dex', now: () => t, fetch, gapMs: 0, minVolSol: 25 });
  const big = addr(), mid = addr(), tiny = addr(), old = addr();
  Object.assign(created, { [big]: t - 2 * H, [mid]: t - 3 * H, [tiny]: t - H, [old]: t - 10 * 24 * H });
  Object.assign(mc, { [big]: 2_400_000, [mid]: 300_000, [tiny]: 9000, [old]: 5_000_000 });
  for (let i = 0; i < 40; i++) for (const m of [big, mid, old]) tc.track({ mint: m, solAmount: 1 });
  tc.track({ mint: tiny, solAmount: 0.5 }); // under the volume bar: never priced
  let r = await tc.refresh();
  assert.equal(r.seen, 3);
  assert.ok(calls.every((n) => n <= 5));
  assert.ok(!tc.coins[tiny]);
  assert.equal(tc.coins[big].created, created[big]); // earliest pool = launch
  // it dumps: the peak stays, "now" follows
  t += H;
  mc[big] = 600_000;
  mc[mid] = 900_000;
  await tc.refresh();
  assert.equal(tc.coins[big].peak, 2_400_000);
  assert.equal(tc.coins[big].mc, 600_000);
  assert.equal(tc.coins[mid].peak, 900_000);
  const day = coinsMessage(tc.list(), t, { days: 1, label: 'today' });
  assert.ok(day.indexOf(big) < day.indexOf(mid) && day.indexOf(big) > 0);
  assert.ok(!day.includes(old)); // launched 10 days ago: not a coin of the day
  assert.match(day, /peak <b>\$2\.40M<\/b> · now \$600K \(-75%\)/);
  const month = coinsMessage(tc.list(), t, { days: 30, label: 'this month' });
  assert.ok(month.indexOf(old) > 0 && month.indexOf(old) < month.indexOf(big));
  assert.ok(!coinsMessage(tc.list(), t, { days: 7, label: 'this week' }).includes(old));
  // saved and reloaded; a dead small coin is dropped after a day, the old ones after 31 days
  const tc2 = new TopCoins({ file, dexApi: 'http://dex', now: () => t, fetch, gapMs: 0 });
  assert.equal(tc2.coins[big].peak, 2_400_000);
  tc2.coins[tiny] = { mint: tiny, created: t - 2 * 24 * H, peak: 9000, mc: 9000 };
  t += 22 * 24 * H;
  await tc2.refresh();
  assert.ok(!tc2.coins[tiny] && !tc2.coins[old] && tc2.coins[big]);
  // DexScreener down: nothing lost
  const tc3 = new TopCoins({ file, dexApi: 'http://dex', now: () => t, fetch: async () => { throw new Error('down'); }, gapMs: 0 });
  await tc3.refresh();
  assert.equal(tc3.coins[big].peak, 2_400_000);
  assert.match(coinsMessage([], t, {}), /Nothing yet/);
});

test('/lb arguments reach the right board', async () => {
  const asked = [];
  const w = new EventEmitter();
  w.postMessage = (m) => (asked.push([m.cmd, m.opts?.period]), setImmediate(() => w.emit('message', { id: m.id, result: m.cmd === 'board' ? { msgs: ['x'] } : ['c'] })));
  w.terminate = () => {};
  const dir = tmpdir();
  const svc = new LeaderboardService({ lb: { postFile: path.join(dir, 'p.json') }, workerData: {}, send: async () => {}, makeWorker: () => w });
  svc._spawn();
  for (const a of [[], ['day'], ['yesterday'], ['weekly'], ['month'], ['coins'], ['coins', 'week'], ['coins', 'monthly']]) await svc.command(...a);
  assert.deepEqual(asked, [['board', 'week'], ['board', 'today'], ['board', 'yesterday'], ['board', 'week'], ['board', 'month'], ['coins', 'day'], ['coins', 'week'], ['coins', 'month']]);
});
