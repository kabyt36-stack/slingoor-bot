import { test } from 'node:test';
import assert from 'node:assert/strict';
import { newRecord, applyTrades, writeOffStale, greenStreak, windowStats, botReason, dayKey, dayBefore, medianHoldSec, pruneDays } from '../src/leaderboard/score.js';

const H = 3600000;
// noon local time, `n` days ago
const at = (now, n, h = 12) => {
  const d = new Date(now);
  d.setHours(h, 0, 0, 0);
  d.setDate(d.getDate() - n);
  return d.getTime();
};
const buy = (mint, sol, tok, time) => ({ side: 'BUY', mint, quote: 'SOL', solAmount: sol, amountUi: tok, time });
const sell = (mint, sol, tok, time) => ({ side: 'SELL', mint, quote: 'SOL', solAmount: sol, amountUi: tok, time });
const NOW = new Date(2026, 10, 11, 21, 0, 0).getTime();

test('a round trip: realized PnL, win and the day it lands on', () => {
  const r = newRecord('W');
  applyTrades(r, [buy('A', 1, 1000, at(NOW, 1, 10)), sell('A', 0.9, 500, at(NOW, 1, 11)), sell('A', 1.6, 500, at(NOW, 1, 12))]);
  const d = r.days[dayBefore(NOW, 1)];
  assert.ok(Math.abs(d.pnl - 1.5) < 1e-9);
  assert.equal(d.wins, 1);
  assert.equal(d.losses, 0);
  assert.equal(r.curWin, 1);
  assert.deepEqual(r.pos, {});
  assert.equal(r.holds[0], 7200);
});

test('average cost over several buys; partial sells only realize their share', () => {
  const r = newRecord('W');
  applyTrades(r, [buy('A', 1, 1000, at(NOW, 0, 9)), buy('A', 3, 1000, at(NOW, 0, 9) + 1), sell('A', 3, 1000, at(NOW, 0, 10))]);
  // avg cost 2 SOL per 1000 tokens -> sold 1000 for 3 = +1, bag still open
  const d = r.days[dayKey(at(NOW, 0, 10))];
  assert.ok(Math.abs(d.pnl - 1) < 1e-9);
  assert.equal(d.wins + d.losses, 0);
  assert.ok(Math.abs(r.pos.A.cost - 2) < 1e-9);
});

test('sells of tokens bought before we were watching are not counted as free profit', () => {
  const r = newRecord('W');
  applyTrades(r, [sell('OLD', 5, 1000, at(NOW, 1))]);
  assert.deepEqual(r.days, {});
  // and selling MORE than we saw bought only counts the seen part
  applyTrades(r, [buy('B', 1, 100, at(NOW, 1, 9)), sell('B', 10, 1000, at(NOW, 1, 10))]);
  assert.ok(Math.abs(r.days[dayBefore(NOW, 1)].pnl - 0) < 1e-9); // got 1 SOL for the 100 seen -> break even
});

test('losing trip resets the win streak; best streak kept', () => {
  const r = newRecord('W');
  const ev = [];
  for (let i = 0; i < 4; i++) ev.push(buy(`W${i}`, 1, 100, at(NOW, 1, 8) + i * 60000), sell(`W${i}`, 1.5, 100, at(NOW, 1, 9) + i * 60000));
  ev.push(buy('L', 1, 100, at(NOW, 1, 10)), sell('L', 0.4, 100, at(NOW, 1, 11)));
  ev.push(buy('Z', 1, 100, at(NOW, 1, 12)), sell('Z', 2, 100, at(NOW, 1, 13)));
  applyTrades(r, ev);
  assert.equal(r.bestWin, 4);
  assert.equal(r.curWin, 1);
  assert.equal(r.days[dayBefore(NOW, 1)].wins, 5);
  assert.equal(r.days[dayBefore(NOW, 1)].losses, 1);
});

test('green-day streak counts back from yesterday, skips idle days, stops at the first red day', () => {
  const r = newRecord('W', { coverFrom: at(NOW, 9, 1) });
  const trip = (n, pnl, m) => [buy(m, 1, 100, at(NOW, n, 10)), sell(m, 1 + pnl, 100, at(NOW, n, 11))];
  applyTrades(r, [...trip(8, -0.5, 'a'), ...trip(7, 1, 'b'), ...trip(6, 1, 'c'), ...trip(4, 2, 'd'), ...trip(2, 0.3, 'e'), ...trip(1, 0.1, 'f'), ...trip(0, -0.9, 'g')]);
  // yesterday(1) green, 2 green, 3 idle, 4 green, 5 idle, 6 green, 7 green, 8 red -> 5
  assert.equal(greenStreak(r, NOW), 5);
  assert.equal(greenStreak(r, NOW, { idleBreaks: true }), 2);
  // today's red day doesn't count yet (day not finished)
  const w = windowStats(r, NOW, 7);
  assert.ok(Math.abs(w.pnl - (2 + 0.3 + 0.1 - 0.9 + 1)) < 1e-9); // days 0..6
  assert.equal(w.wins, 4);
  assert.equal(w.losses, 1);
});

test('the partly-known first day never counts toward a streak', () => {
  const r = newRecord('W', { coverFrom: at(NOW, 2, 15) });
  applyTrades(r, [buy('a', 1, 1, at(NOW, 2, 16)), sell('a', 2, 1, at(NOW, 2, 17)), buy('b', 1, 1, at(NOW, 1, 16)), sell('b', 2, 1, at(NOW, 1, 17))]);
  assert.equal(greenStreak(r, NOW), 1);
});

test('stale bags are written off as a loss (bag holders do not look perfect), later sells count as profit', () => {
  const r = newRecord('W');
  applyTrades(r, [buy('R', 2, 100, at(NOW, 3, 10))]);
  writeOffStale(r, NOW, 24);
  const k = dayKey(at(NOW, 3, 10) + 24 * H);
  assert.ok(Math.abs(r.days[k].pnl + 2) < 1e-9);
  assert.equal(r.days[k].losses, 1);
  assert.equal(r.curWin, 0);
  assert.ok(r.pos.R.wroteOff);
  applyTrades(r, [sell('R', 0.5, 100, at(NOW, 0, 9))]);
  assert.ok(Math.abs(r.days[dayKey(at(NOW, 0, 9))].pnl - 0.5) < 1e-9);
  assert.equal(r.pos.R, undefined);
  // fresh bags are left alone
  const r2 = newRecord('W');
  applyTrades(r2, [buy('X', 1, 1, NOW - 2 * H)]);
  writeOffStale(r2, NOW, 24);
  assert.ok(!r2.pos.X.wroteOff);
});

test('moving a bag to another wallet is neither a win nor a loss', () => {
  const r = newRecord('W');
  applyTrades(r, [buy('M', 1, 100, at(NOW, 1, 9)), { side: 'XFER_OUT', mint: 'M', amountUi: 100, time: at(NOW, 1, 10) }]);
  assert.deepEqual(r.pos, {});
  assert.equal(r.days[dayBefore(NOW, 1)].wins + r.days[dayBefore(NOW, 1)].losses, 0);
});

test('USD / token-priced trades are skipped safely', () => {
  const r = newRecord('W');
  applyTrades(r, [{ side: 'BUY', mint: 'U', quote: 'USD', usdAmount: 100, amountUi: 10, time: NOW - H }, { side: 'BUY', mint: 'T', quote: 'TOKEN', amountUi: 10, time: NOW - H }]);
  assert.deepEqual(r.pos, {});
});

test('bot detection: too many trades a day, or holds of a few seconds', () => {
  const r = newRecord('W');
  const ev = [];
  for (let i = 0; i < 12; i++) ev.push(buy(`s${i}`, 0.1, 10, at(NOW, 1, 9) + i * 60000), sell(`s${i}`, 0.12, 10, at(NOW, 1, 9) + i * 60000 + 3000));
  applyTrades(r, ev);
  assert.equal(medianHoldSec(r), 3);
  assert.match(botReason(r, NOW), /holds coins ~3s/);
  const r2 = newRecord('W');
  r2.days[dayBefore(NOW, 1)] = { pnl: 1, wins: 300, losses: 0, buySol: 10, trades: 900 };
  assert.match(botReason(r2, NOW), /900 trades a day/);
  const human = newRecord('W');
  applyTrades(human, [buy('h', 1, 1, at(NOW, 1, 9)), sell('h', 2, 1, at(NOW, 1, 11))]);
  assert.equal(botReason(human, NOW), null);
});

test('old days are pruned', () => {
  const r = newRecord('W');
  r.days[dayBefore(NOW, 90)] = { pnl: 1, wins: 1, losses: 0, buySol: 1, trades: 2 };
  r.days[dayBefore(NOW, 3)] = { pnl: 1, wins: 1, losses: 0, buySol: 1, trades: 2 };
  pruneDays(r, NOW, 60);
  assert.deepEqual(Object.keys(r.days), [dayBefore(NOW, 3)]);
});
