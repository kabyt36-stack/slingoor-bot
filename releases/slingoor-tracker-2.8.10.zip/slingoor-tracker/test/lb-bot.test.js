// The real bot.js with the leaderboard switched on, against the mock world (needs WS_LIB, like the other e2e tests).
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { startWorld, W } from './mock.js';

const WS_LIB = process.env.WS_LIB;

test('bot: leaderboard thread runs next to the tracker, /lb answers, /lb status shows the scanner', { skip: !WS_LIB, timeout: 90000 }, async () => {
  const w = await startWorld(WS_LIB);
  const sigCalls = [];
  w.M.rpcHook = async (r) => {
    if (r.method === 'getSignaturesForAddress') {
      sigCalls.push(r.params[0]);
      return [];
    }
    return undefined;
  };
  try {
    w.startBot({ LEADERBOARD: 'on', LB_STREAM: 'public', LB_PUBLIC_WS: w.wsUrl, QUIET_MODE: 'on' });
    w.tgPush('/start');
    await w.waitFor('registered', () => w.sent(/You're set/).length);
    w.tgPush('/lb');
    await w.waitFor('leaderboard reply', () => w.sent(/Wallet leaderboard/).length);
    const lb = w.sent(/Wallet leaderboard/)[0].text;
    assert.match(lb, /Longest green-day streaks/);
    assert.match(lb, /No wallet on a green streak yet/);
    await w.waitFor('all three boards', () => w.sent(/Top PnL/).length && w.sent(/Most wins in a row/).length);
    w.tgPush('/lb status');
    await w.waitFor('status reply', () => w.sent(/Leaderboard scanner/).length);
    assert.match(w.sent(/Leaderboard scanner/)[0].text, /Stream: public · live/);
    // the scanner subscribed to pump.fun's program on its own connection
    await w.waitFor('pump.fun subscription', () => w.WS.subscribeCount >= 2);
    // the rest of the bot keeps answering while it runs
    w.tgPush('/help');
    await w.waitFor('help', () => w.sent(/\/lb — wallet leaderboard/).length);
    // a manual scan reads the tracked trader's history (he's a seed)
    w.tgPush('/lb scan');
    await w.waitFor('scan done', () => w.sent(/Scan done/).length, 30000);
    assert.ok(sigCalls.includes(W));
    assert.ok(!/Unhandled|Crashed|Fatal/.test(w.out), w.out.slice(-1500));
  } finally {
    await w.close();
  }
});
