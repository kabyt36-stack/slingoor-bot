import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import http from 'node:http';
import { EventEmitter } from 'node:events';
import { LbChat } from '../src/leaderboard/chat.js';
import { LeaderboardService } from '../src/leaderboard/service.js';
import { loadConfig } from '../src/config.js';

const tmpdir = () => fs.mkdtempSync(path.join(os.tmpdir(), 'lbc-'));
const until = async (fn, ms = 8000) => {
  const t0 = Date.now();
  while (!fn()) {
    if (Date.now() - t0 > ms) throw new Error('timed out');
    await new Promise((r) => setTimeout(r, 20));
  }
};

// a tiny Telegram Bot API, one inbox per bot token
async function fakeTelegram() {
  const bots = {}; // token -> { updates: [], sent: [] }
  let uid = 1;
  const srv = http.createServer((req, res) => {
    let body = '';
    req.on('data', (c) => (body += c));
    req.on('end', () => {
      const m = /^\/bot([^/]+)\/(\w+)/.exec(req.url);
      const b = (bots[m[1]] ||= { updates: [], sent: [] });
      const p = body ? JSON.parse(body) : {};
      const ok = (result) => res.end(JSON.stringify({ ok: true, result }));
      if (m[2] === 'getMe') return ok({ id: 1, username: 'lb_test_bot' });
      if (m[2] === 'sendMessage') {
        b.sent.push({ chat: String(p.chat_id), text: p.text });
        return ok({ message_id: b.sent.length });
      }
      if (m[2] === 'getUpdates') {
        const send = () => ok(b.updates.splice(0).filter((u) => u.update_id >= (p.offset || 0)));
        return b.updates.length ? send() : setTimeout(send, 50);
      }
      ok(true);
    });
  });
  await new Promise((r) => srv.listen(0, '127.0.0.1', r));
  return {
    base: `http://127.0.0.1:${srv.address().port}`,
    bots,
    push: (token, chat, text) => (bots[token] ||= { updates: [], sent: [] }).updates.push({ update_id: uid++, message: { chat: { id: chat }, text, date: Math.floor(Date.now() / 1000) } }),
    close: () => new Promise((r) => (srv.closeAllConnections?.(), srv.close(r))),
  };
}

test('leaderboard bot: its own chat registers on Start, answers /lb, gets the posts; strangers are ignored', { timeout: 30000 }, async () => {
  const t = await fakeTelegram();
  const dir = tmpdir();
  const TOKEN = '222:lbtokenlbtokenlbtokenlbtoken';
  const asked = [];
  const chat = new LbChat({ token: TOKEN, apiBase: t.base, file: path.join(dir, 'chat.json'), command: async (a) => (asked.push(a), ['BOARD1', 'BOARD2']) });
  try {
    await chat.start();
    assert.equal(chat.name, 'lb_test_bot');
    assert.equal(await chat.broadcast('nobody yet'), 0);
    t.push(TOKEN, 555, '/start');
    const sent = () => t.bots[TOKEN].sent;
    await until(() => sent().length >= 3);
    assert.match(sent()[0].text, /leaderboards post here every morning/);
    assert.deepEqual(sent().slice(1, 3).map((x) => x.text), ['BOARD1', 'BOARD2']);
    assert.deepEqual(chat.chats(), ['555']);
    // someone else finding the bot gets nothing
    t.push(TOKEN, 999, '/start');
    t.push(TOKEN, 999, '/lb');
    t.push(TOKEN, 555, '/lb status');
    await until(() => asked.includes('status'));
    await until(() => sent().length >= 5);
    assert.ok(sent().every((x) => x.chat === '555'));
    // daily post goes to this chat
    assert.equal(await chat.broadcast('DAILY'), 1);
    assert.equal(sent().at(-1).text, 'DAILY');
    // remembered after a restart
    const again = new LbChat({ token: TOKEN, apiBase: t.base, file: path.join(dir, 'chat.json'), command: async () => [] });
    assert.deepEqual(again.chats(), ['555']);
  } finally {
    chat.stop();
    await t.close();
  }
});

function fakeWorker(answers) {
  const w = new EventEmitter();
  w.postMessage = (m) => setImmediate(() => w.emit('message', { id: m.id, result: answers[m.cmd] }));
  w.terminate = () => {};
  return w;
}

test('daily post never goes to the copy chat: waits for the leaderboard chat, with one setup note', async () => {
  const dir = tmpdir();
  const lb = { postHour: 9, postMinute: 0, postFile: path.join(dir, 'post.json'), autoCopy: false, autoTradersFile: path.join(dir, 'x.json') };
  let t = new Date(2026, 10, 12, 10, 0).getTime();
  const lbSent = [];
  const mainSent = [];
  let dest = false;
  const mk = () =>
    new LeaderboardService({
      lb, workerData: {}, now: () => t,
      send: async (h) => lbSent.push(h),
      hasDest: () => dest,
      nudge: async (done) => (done === 'token' ? 'token' : (mainSent.push('setup note'), 'token')),
      makeWorker: () => fakeWorker({ daily: { msgs: ['B1', 'B2', 'B3'], picks: [] } }),
    });
  const svc = mk();
  svc._spawn();
  for (let i = 0; i < 5; i++) assert.equal(await svc.tick(), false);
  assert.deepEqual(lbSent, []);
  assert.deepEqual(mainSent, ['setup note']); // once, not every tick
  const svc2 = mk(); // nor again after a restart
  svc2._spawn();
  await svc2.tick();
  assert.equal(mainSent.length, 1);
  // chat set up: first day is skipped (scanner warming up), next morning it posts there
  dest = true;
  assert.equal(await svc2.tick(), false);
  t += 24 * 3600000;
  assert.equal(await svc2.tick(), true);
  assert.deepEqual(lbSent, ['B1', 'B2', 'B3']);
  assert.equal(mainSent.length, 1);
});

test('settings: LB_BOT_TOKEN / LB_CHAT_ID; the copy bot\'s own token is refused', () => {
  const f = path.join(tmpdir(), 's.txt');
  fs.writeFileSync(f, 'TELEGRAM_BOT_TOKEN=111:maintokenmaintokenmaintoken\nLB_BOT_TOKEN=222:lbtokenlbtokenlbtokenlbtoken\nLB_CHAT_ID=-100123, 77\n');
  const c = loadConfig(f).leaderboard;
  assert.equal(c.botToken, '222:lbtokenlbtokenlbtokenlbtoken');
  assert.deepEqual(c.chatIds, ['-100123', '77']);
  fs.writeFileSync(f, 'TELEGRAM_BOT_TOKEN=111:maintokenmaintokenmaintoken\nLB_BOT_TOKEN=111:maintokenmaintokenmaintoken\n');
  assert.equal(loadConfig(f).leaderboard.botToken, '');
  assert.equal(loadConfig('/nonexistent').leaderboard.botToken, '');
});
