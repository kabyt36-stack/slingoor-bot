// Main-thread side of the leaderboard: starts the scanner thread (and restarts it if it dies),
// posts the leaderboards once a day, answers /lb, and runs phase 2 (auto-copy) when it's switched on.
import fs from 'node:fs';
import path from 'node:path';
import { Worker } from 'node:worker_threads';
import { fileURLToPath } from 'node:url';
import { log } from '../log.js';
import { dayKey } from './score.js';
import { periodOf } from './board.js';

const WORKER = path.join(path.dirname(fileURLToPath(import.meta.url)), 'worker.js');

export class LeaderboardService {
  constructor({ lb, workerData, send, hasDest = () => true, nudge = null, relaunch = () => {}, now = () => Date.now(), makeWorker = (data) => new Worker(WORKER, { workerData: data, resourceLimits: { maxOldGenerationSizeMb: 768 } }) }) {
    this.lb = lb;
    this.workerData = workerData;
    this.send = send; // async (html) => void, to the leaderboard chat
    this.hasDest = hasDest; // is there a chat to post to yet?
    this.nudge = nudge; // async () => key|null: tells the user (once) how to set the chat up
    this.relaunch = relaunch; // restart the bot (phase 2: new wallets to copy)
    this.now = now;
    this.makeWorker = makeWorker;
    this.pending = new Map();
    this.seq = 1;
    this.deaths = 0;
    this.post = this._loadPost();
  }

  _loadPost() {
    try {
      return JSON.parse(fs.readFileSync(this.lb.postFile, 'utf8')) || {};
    } catch {
      return {};
    }
  }
  _savePost() {
    try {
      fs.mkdirSync(path.dirname(this.lb.postFile), { recursive: true });
      fs.writeFileSync(this.lb.postFile, JSON.stringify(this.post));
    } catch {}
  }

  start() {
    this._spawn();
    this._nudge().catch(() => {});
    this._t = setInterval(() => this.tick().catch((e) => log.warn('Leaderboard post failed:', e.message)), 30000);
    this._t.unref?.();
  }

  stop() {
    clearInterval(this._t);
    this.stopped = true;
    this.w?.terminate?.();
  }

  _spawn() {
    if (this.stopped) return;
    let w;
    try {
      w = this.makeWorker(this.workerData);
    } catch (e) {
      log.error('Leaderboard thread could not start:', e.message);
      return;
    }
    this.w = w;
    w.on('message', (m) => {
      const p = this.pending.get(m?.id);
      if (!p) return;
      this.pending.delete(m.id);
      clearTimeout(p.timer);
      m.error ? p.reject(new Error(m.error)) : p.resolve(m.result);
    });
    w.on('error', (e) => log.error('Leaderboard thread error:', e?.stack || e?.message || e));
    w.on('exit', (code) => {
      if (this.w !== w || this.stopped) return;
      for (const p of this.pending.values()) p.reject(new Error('leaderboard thread stopped'));
      this.pending.clear();
      this.deaths++;
      const wait = Math.min(10 * 60000, 5000 * 2 ** Math.min(this.deaths, 7));
      log.warn(`Leaderboard thread stopped (code ${code}); restarting in ${Math.round(wait / 1000)}s`);
      setTimeout(() => this._spawn(), wait).unref?.();
    });
  }

  // one short setup note (once per step), when the leaderboard has no chat of its own yet
  async _nudge() {
    if (!this.nudge || this.hasDest()) return;
    const key = await this.nudge(this.post.nudged || null);
    if (key && key !== this.post.nudged) {
      this.post.nudged = key;
      this._savePost();
    }
  }

  ask(cmd, opts, timeoutMs = 20000) {
    if (!this.w) return Promise.reject(new Error('leaderboard not running'));
    const id = this.seq++;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(id);
        reject(new Error('leaderboard thread did not answer'));
      }, timeoutMs);
      this.pending.set(id, { resolve, reject, timer });
      this.w.postMessage({ id, cmd, opts });
    });
  }

  // once a day at LB_POST_TIME (Mac's local time)
  async tick() {
    if (!this.hasDest()) await this._nudge().catch(() => {});
    const t = this.now();
    const d = new Date(t);
    if (d.getHours() * 60 + d.getMinutes() < this.lb.postHour * 60 + this.lb.postMinute) return false;
    const k = dayKey(t);
    if (this.post.lastDay === k) return false;
    if (!this.hasDest()) {
      await this._nudge().catch(() => {});
      return false; // no leaderboard chat yet: posts as soon as there is one
    }
    if (!this.post.lastDay) {
      // first run ever: the scanner has nothing yet, so the first post is tomorrow (/lb shows it anytime)
      this.post.lastDay = k;
      this._savePost();
      return false;
    }
    this.post.lastDay = k; // mark first: a failed send is not retried every 30s all day
    this._savePost();
    const b = await this.ask('daily');
    for (const html of b.msgs) await this.send(html);
    await this.applyAutoCopy(b.picks);
    return true;
  }

  // Phase 2: write today's picks for the copy bot and restart it on them (only with LB_AUTO_COPY=on)
  async applyAutoCopy(picks) {
    if (!this.lb.autoCopy) return false;
    const next = (picks || []).map((p, i) => ({ name: `lb${i + 1}`, wallet: p.wallet, streak: p.streak, pnl7: p.pnl7, since: this.now() }));
    let prev = [];
    try {
      prev = JSON.parse(fs.readFileSync(this.lb.autoTradersFile, 'utf8')) || [];
    } catch {}
    const same = prev.length === next.length && prev.every((p, i) => p.wallet === next[i].wallet);
    if (same) return false;
    fs.mkdirSync(path.dirname(this.lb.autoTradersFile), { recursive: true });
    fs.writeFileSync(this.lb.autoTradersFile, JSON.stringify(next, null, 1));
    log.info(`Leaderboard auto-copy: now copying ${next.map((x) => x.wallet).join(', ') || 'nobody'}; restarting`);
    await this.send(`🤖 <b>Auto-copy</b> updated: ${next.length ? next.map((x) => `${x.name} <code>${x.wallet}</code>`).join(', ') : 'nobody qualifies today'} — restarting the bot to follow them.`);
    this.relaunch();
    return true;
  }

  // /lb · /lb day|yesterday|week|month · /lb coins [day|week|month] · /lb status · /lb scan
  async command(arg, arg2) {
    const a = String(arg || '').toLowerCase();
    const b2 = String(arg2 || '').toLowerCase();
    if (a === 'status') return [await this.ask('status')];
    if (a === 'scan') {
      const r = await this.ask('cycle', null, 30 * 60000);
      return [r?.skipped ? '⏳ A scan is already running.' : `✅ Scan done: +${r.added} wallets, ${r.rescanned} updated, ${r.bots} bots skipped${r.budget ? ' (daily credit budget used up)' : ''}.`];
    }
    // /lb coins [day|week|month]
    if (a === 'coins' || a === 'coin') {
      const p = /^(week|weekly|7d)$/.test(b2) ? 'week' : /^(month|monthly|30d)$/.test(b2) ? 'month' : 'day';
      return this.ask('coins', { period: p });
    }
    // /lb [day|yesterday|week|month]
    const b = await this.ask('board', { period: periodOf(a) || 'week' });
    return b.msgs;
  }
}
