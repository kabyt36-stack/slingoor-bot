// The leaderboard's own Telegram bot, so its posts stay out of the copy-trading chat.
// Create a bot with @BotFather, put its token in LB_BOT_TOKEN, open it and press Start: that chat gets
// the daily leaderboards and answers /lb, /lb status, /lb scan.
import fs from 'node:fs';
import path from 'node:path';
import { Telegram } from '../telegram.js';
import { log } from '../log.js';

export class LbChat {
  constructor({ token, apiBase, chatIds = [], file, command }) {
    this.tg = new Telegram({ token, apiBase });
    this.fixed = chatIds.map(String);
    this.file = file;
    this.command = command; // async (arg) => [html...]
    this.saved = [];
    try {
      const j = JSON.parse(fs.readFileSync(file, 'utf8'));
      if (Array.isArray(j?.chats)) this.saved = j.chats.map(String);
    } catch {}
    this.name = null;
  }

  chats() {
    return this.fixed.length ? this.fixed : this.saved;
  }

  _save() {
    try {
      fs.mkdirSync(path.dirname(this.file), { recursive: true });
      fs.writeFileSync(this.file, JSON.stringify({ chats: this.saved }));
    } catch (e) {
      log.warn('Leaderboard chat: could not save:', e.message);
    }
  }

  async start() {
    try {
      this.name = (await this.tg.getMe()).username;
      log.info(`Leaderboard bot: @${this.name}${this.chats().length ? '' : ' — open it in Telegram and press Start'}`);
    } catch (e) {
      log.warn(`Leaderboard bot token not accepted by Telegram (${e.message}); check LB_BOT_TOKEN`);
    }
    this.tg.poll((m) => this.onMessage(m));
  }

  stop() {
    this.tg.stop();
  }

  // -> number of chats it reached
  async broadcast(html) {
    let n = 0;
    for (const id of this.chats()) {
      try {
        await this.tg.send(id, html);
        n++;
      } catch (e) {
        if (e.migrateTo) {
          const list = this.fixed.length ? this.fixed : this.saved;
          list[list.indexOf(id)] = String(e.migrateTo);
          this._save();
          await this.tg.send(e.migrateTo, html).then(() => n++).catch(() => {});
        } else log.warn(`Leaderboard chat ${id}: ${e.message}`);
      }
    }
    return n;
  }

  async onMessage(msg) {
    const chatId = String(msg.chat.id);
    const [cmdRaw, ...args] = msg.text.trim().split(/\s+/);
    const cmd = cmdRaw.toLowerCase().replace(/@.*$/, '');
    const known = this.chats().includes(chatId);
    if (!known) {
      // the first chat to press Start owns the bot; nobody else can use it
      if (this.fixed.length || this.saved.length || cmd !== '/start') return;
      this.saved.push(chatId);
      this._save();
    }
    const say = (html) => this.tg.send(chatId, html).catch((e) => log.warn('Leaderboard chat send failed:', e.message));
    try {
      if (cmd === '/start' || cmd === '/help') {
        await say('🏆 <b>Wallet leaderboard</b>\nThe leaderboards post here every morning.\n/lb — wallets, 7 days · /lb day · /lb yesterday · /lb month\n/lb coins — biggest coins today · /lb coins week · /lb coins month\n/lb status — the scanner · /lb scan — scan now\nEvery morning: yesterday\'s wallets + the day\'s coins. Mondays add the week, the 1st adds the month.');
        if (cmd === '/help') return;
      }
      if (cmd === '/start' || cmd === '/lb' || cmd === '/leaderboard') for (const html of await this.command(cmd === '/start' ? '' : args[0], args[1])) await say(html);
    } catch (e) {
      await say(`🏆 Leaderboard not ready yet: ${String(e.message).replace(/[<>&]/g, '')}`);
    }
  }
}
