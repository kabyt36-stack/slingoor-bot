// Runs the leaderboard scanner in its own thread, so reading thousands of pump.fun trades a second
// never slows down the copy bot's buys and sells (they run on the main thread).
import { parentPort, workerData } from 'node:worker_threads';
import { Rpc } from '../rpc.js';
import { KeyPool } from '../keys.js';
import { setLogFile, log } from '../log.js';
import { Discovery, TradeStream } from './discover.js';
import { Scanner } from './scanner.js';
import { rows, boardMessages, autoPicks, coinsMessage, PERIODS } from './board.js';
import { TopCoins } from './topcoins.js';
import { dayKey } from './score.js';

export function createEngine(lb, { rpc, now = () => Date.now(), WebSocketImpl = globalThis.WebSocket, heliusWs = null }) {
  const botOpts = { maxTradesPerDay: lb.maxTradesPerDay, minHoldSec: lb.minHoldSec };
  const discovery = new Discovery({ maxTradesPerDay: lb.maxTradesPerDay, now });
  const scanner = new Scanner({
    rpc,
    file: lb.file,
    historyDays: lb.historyDays,
    maxTxPerWallet: Math.max(2500, lb.historyDays * 200),
    dailyCredits: lb.dailyCredits,
    poolSize: lb.poolSize,
    bagholdHours: lb.bagholdHours,
    maxTradesPerDay: lb.maxTradesPerDay,
    minHoldSec: lb.minHoldSec,
    seeds: lb.seeds,
    now,
  });
  const coins = new TopCoins({ file: lb.coinsFile, dexApi: lb.dexApi, now, ...(lb.coinsOpts || {}) });
  discovery.onTrade = (ev) => coins.track(ev);
  const followed = new Set(lb.excludeWallets);
  let stream = null;
  let streamKind = null;
  const startStream = (kind) => {
    stream?.stop();
    streamKind = kind;
    const url = kind === 'helius' ? heliusWs : lb.publicWs;
    stream = new TradeStream({ url, discovery, maxMbPerDay: kind === 'helius' ? lb.streamMaxMb : 0, now, WebSocketImpl });
    stream.startedAt = now();
    stream.start();
    log.info(`Leaderboard: listening to pump.fun trades (${kind === 'helius' ? `Helius, max ${lb.streamMaxMb} MB a day` : 'public Solana server'})`);
  };

  // auto: the free public server first; if it gives nothing for 5 minutes and there's a Helius key, use Helius (capped)
  const checkStream = () => {
    if (lb.stream !== 'auto' || streamKind !== 'public' || !heliusWs) return;
    if (stream.stats.trades === 0 && now() - stream.startedAt > 5 * 60000) {
      log.warn(`Leaderboard: public Solana server sent no pump.fun trades in 5 min (${stream.stats.lastError || 'no data'}), switching to Helius`);
      startStream('helius');
    }
  };

  const state = (period = 'week') => {
    const P = PERIODS[period] || PERIODS.week;
    const recs = scanner.records();
    const list = rows(recs, now(), { minTrips: P.minTrips || lb.minTrips, idleBreaks: lb.idleBreaks, botOpts, days: P.days, offset: P.offset });
    return { recs, list, P };
  };
  const COIN_P = { day: [1, 'today'], week: [7, 'this week'], month: [30, 'this month'] };
  const coinsMsg = (period = 'day') => {
    const [days, label] = COIN_P[period] || COIN_P.day;
    return coinsMessage(coins.list(), now(), { days, label, top: lb.top });
  };

  const picksFor = (list) =>
    autoPicks(list, { count: lb.autoCount, minStreak: lb.autoMinStreak, minWinRate: lb.autoMinWinRate, minPnl: lb.autoMinPnl, exclude: followed });

  return {
    discovery,
    scanner,
    get stream() {
      return stream;
    },
    start() {
      if (lb.stream !== 'off') startStream(lb.stream === 'helius' && heliusWs ? 'helius' : 'public');
      this._timers = [
        setInterval(() => (discovery.prune(), coins.prune()), 2 * 60000),
        setInterval(checkStream, 30000),
        setInterval(() => this.cycle().catch((e) => log.warn('Leaderboard cycle failed:', e.message)), 30 * 60000),
      ];
      for (const t of this._timers) t.unref?.();
      // first pass shortly after start (seeds + whatever the stream found)
      setTimeout(() => this.cycle().catch((e) => log.warn('Leaderboard cycle failed:', e.message)), 3 * 60000).unref?.();
    },
    stop() {
      stream?.stop();
      for (const t of this._timers || []) clearInterval(t);
    },
    async cycle() {
      const perCycle = Math.ceil(lb.newPerHour / 2); // a cycle every 30 min
      scanner.enqueue(discovery.candidates(perCycle * 2, new Set([...Object.keys(scanner.d.wallets), ...followed])).map((c) => c.wallet));
      const r = await scanner.cycle({ newPerCycle: perCycle });
      if (!r.skipped) {
        const c = await coins.refresh().catch((e) => (log.warn('Leaderboard coins refresh failed:', e.message), null));
        if (c) log.info(`Leaderboard coins: ${c.seen}/${c.checked} market caps read · ${coins.list().length} coins kept`);
      }
      if (!r.skipped) log.info(`Leaderboard: +${r.added} new wallets, ${r.rescanned} updated, ${r.bots} bots skipped${r.budget ? ', daily credit budget used up' : ''} · ${scanner.records().length} in the pool · credits today ${scanner._budget().used}`);
      return r;
    },
    coins,
    coinsBoard: ({ period = 'day' } = {}) => [coinsMsg(period)],
    // the morning post: yesterday's wallets + today's coins; Mondays add the week, the 1st adds the month
    daily() {
      const d = new Date(now());
      const y = this.board({ period: 'yesterday' });
      const msgs = [...y.msgs, coinsMsg('day')];
      const pnlOnly = (period) => {
        const { list, P } = state(period);
        return boardMessages(list, { top: lb.top, minWinRate: lb.minWinRate, followed, label: P.label, only: 'pnl' })[0];
      };
      if (d.getDay() === 1) msgs.push('📅 <b>Weekly leaderboard</b>\n' + pnlOnly('lastweek'), coinsMsg('week'));
      if (d.getDate() === 1) msgs.push('🗓 <b>Monthly leaderboard</b>\n' + pnlOnly('lastmonth'), coinsMsg('month'));
      // auto-copy picks are always judged on the full week
      return { msgs, picks: this.board({ period: 'week' }).picks, day: dayKey(now()) };
    },
    board({ autoOn = lb.autoCopy, period = 'week' } = {}) {
      const { recs, list, P } = state(period);
      const st = stream?.stats;
      const stats = `${recs.length} wallets tracked · ${list.length} active humans scored · ${discovery.w.size} wallets seen on pump.fun today · Helius credits used today ${scanner._budget().used}/${lb.dailyCredits || '∞'}${st ? ` · stream ${stream.connected ? 'live' : st.capped ? 'paused (data cap)' : 'reconnecting'}` : ''}`;
      const picks = picksFor(list);
      const d = new Date(now());
      return {
        msgs: boardMessages(list, { top: lb.top, minWinRate: lb.minWinRate, followed, stats, picks: period === 'week' ? picks : null, autoOn, label: P.label, dateLabel: d.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' }) }),
        picks: picks.map((p) => ({ wallet: p.wallet, streak: p.streak, pnl7: p.pnl7 })),
        day: dayKey(now()),
      };
    },
    status() {
      const st = stream?.stats || {};
      return [
        `🏆 <b>Leaderboard scanner</b>`,
        `Stream: ${lb.stream === 'off' ? 'off' : `${streamKind} · ${stream?.connected ? 'live' : st.capped ? 'paused (daily data cap)' : 'reconnecting'} · ${st.trades || 0} trades read · ${Math.round((st.bytesToday || 0) / 1e6)} MB today`}`,
        `Coins: ${coins.list().length} kept · ${coins.live.size} trading now`,
        `Wallets: ${scanner.records().length} tracked · ${scanner.d.queue.length} queued · ${discovery.w.size} seen today`,
        `Helius credits today: ${scanner._budget().used} of ${lb.dailyCredits || 'no limit'}`,
      ].join('\n');
    },
  };
}

// ---- thread entry ----
if (parentPort && workerData?.lb) {
  const { lb, rpcUrl, heliusKeys, heliusWs, logFile, isPublicRpc } = workerData;
  if (logFile) setLogFile(logFile);
  const pool = heliusKeys?.length > 1 ? new KeyPool(heliusKeys) : null;
  // its own slow lane: at most ~8 requests a second, so the copy bot's requests always have room
  const rpc = new Rpc(rpcUrl, isPublicRpc ? { minGapMs: 400, concurrency: 1 } : { minGapMs: 120, concurrency: 3, pool });
  const engine = createEngine(lb, { rpc, heliusWs });
  engine.start();
  parentPort.on('message', async (m) => {
    try {
      let result;
      if (m.cmd === 'board') result = engine.board(m.opts || {});
      else if (m.cmd === 'coins') result = engine.coinsBoard(m.opts || {});
      else if (m.cmd === 'daily') result = engine.daily();
      else if (m.cmd === 'status') result = engine.status();
      else if (m.cmd === 'cycle') result = await engine.cycle();
      parentPort.postMessage({ id: m.id, result });
    } catch (e) {
      parentPort.postMessage({ id: m.id, error: e.message });
    }
  });
}
