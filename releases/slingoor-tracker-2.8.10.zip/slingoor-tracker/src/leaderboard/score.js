// Leaderboard scoring: turns a wallet's trades (BUY/SELL events from parse.js) into realized PnL per day,
// winning/losing coin round trips, a green-day streak and a win streak.
//
// How PnL is counted (realized only, in SOL):
//   - every BUY adds to that coin's cost; every SELL realizes  SOL received - average cost of what was sold
//   - sells of tokens we never saw being bought (bought before we started watching, or sent in from another
//     wallet) don't count: no cost known, so no fake "free" profit
//   - a coin is a finished trip once 99% of the biggest bag is gone: a win if the trip made money
//   - a bag nobody sold for BAGHOLD hours counts as a loss of what's left in it (memecoin bags that old are
//     almost always dead; without this, a wallet that never sells its losers would look perfect).
//     If it gets sold later anyway, that SOL is counted as profit on that day.
// Days are the Mac's local calendar days.

export const DAY_MS = 86400000;

export function dayKey(t) {
  const d = new Date(t);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

// the local day `n` days before the day of t (n can be 0)
export function dayBefore(t, n) {
  const d = new Date(t);
  d.setHours(12, 0, 0, 0); // noon: DST changes never skip or repeat a day
  d.setDate(d.getDate() - n);
  return dayKey(d.getTime());
}

export function newRecord(wallet, extra = {}) {
  return {
    wallet,
    addedAt: Date.now(),
    lastSig: null, // newest signature already processed
    lastTxAt: 0, // time of that signature
    coverFrom: null, // trades are known from this time on (history scan start)
    lastTradeAt: 0,
    pos: {}, // mint -> { cost, tok, max, pnl, openedAt, lastAt, wroteOff }
    days: {}, // 'YYYY-MM-DD' -> { pnl, wins, losses, buySol, trades }
    curWin: 0,
    bestWin: 0,
    holds: [], // seconds held, last 50 finished trips (bot detection)
    flags: null, // { bot: true, why } when it looks like a bot
    ...extra,
  };
}

const day = (rec, t) => (rec.days[dayKey(t)] ||= { pnl: 0, wins: 0, losses: 0, buySol: 0, trades: 0 });

function closeTrip(rec, mint, p, t) {
  const d = day(rec, t);
  const win = p.pnl > 0;
  if (win) {
    d.wins++;
    rec.curWin++;
    rec.bestWin = Math.max(rec.bestWin, rec.curWin);
  } else {
    d.losses++;
    rec.curWin = 0;
  }
  rec.holds.push(Math.max(0, Math.round((t - p.openedAt) / 1000)));
  if (rec.holds.length > 50) rec.holds.splice(0, rec.holds.length - 50);
  delete rec.pos[mint];
}

// Applies trade events (any order; sorted here) to the record. Only SOL-priced trades are scored.
export function applyTrades(rec, events, { dustPct = 1 } = {}) {
  const evs = [...events].filter((e) => e && e.mint && e.time).sort((a, b) => a.time - b.time || (a.side === 'BUY' ? -1 : 1));
  for (const ev of evs) {
    const t = ev.time;
    if (ev.side === 'BUY') {
      if (ev.quote !== 'SOL' || !(ev.solAmount > 0) || !(ev.amountUi > 0)) continue;
      let p = rec.pos[ev.mint];
      if (!p || p.wroteOff) p = rec.pos[ev.mint] = { cost: 0, tok: 0, max: 0, pnl: 0, openedAt: t, lastAt: t };
      p.cost += ev.solAmount;
      p.tok += ev.amountUi;
      p.max = Math.max(p.max, p.tok);
      p.lastAt = t;
      const d = day(rec, t);
      d.buySol += ev.solAmount;
      d.trades++;
      rec.lastTradeAt = Math.max(rec.lastTradeAt, t);
    } else if (ev.side === 'SELL') {
      const p = rec.pos[ev.mint];
      if (!p || !(ev.amountUi > 0)) continue; // no cost known: not scored
      rec.lastTradeAt = Math.max(rec.lastTradeAt, t);
      const d = day(rec, t);
      d.trades++;
      if (p.wroteOff) {
        // a written-off bag sold after all: whatever it brought in is profit that day
        if (ev.quote === 'SOL' && ev.solAmount > 0) d.pnl += ev.solAmount;
        p.tok = Math.max(0, p.tok - ev.amountUi);
        if (p.tok <= p.max * (dustPct / 100)) delete rec.pos[ev.mint];
        continue;
      }
      if (ev.quote !== 'SOL' || !(ev.solAmount >= 0)) {
        // sold for another token: we can't price it; treat it like a transfer (cost leaves with the tokens)
        const frac = Math.min(1, ev.amountUi / (p.tok || ev.amountUi));
        p.cost -= p.cost * frac;
        p.tok -= p.tok * frac;
      } else {
        const sold = Math.min(ev.amountUi, p.tok);
        const frac = p.tok > 0 ? sold / p.tok : 0;
        const basis = p.cost * frac;
        // only the part of the sell that came from tokens we saw bought counts
        const got = ev.solAmount * (sold / ev.amountUi);
        const pnl = got - basis;
        p.cost -= basis;
        p.tok -= sold;
        p.pnl += pnl;
        d.pnl += pnl;
      }
      p.lastAt = t;
      if (p.tok <= p.max * (dustPct / 100)) closeTrip(rec, ev.mint, p, t);
    } else if (ev.side === 'XFER_OUT') {
      const p = rec.pos[ev.mint];
      if (!p || !(ev.amountUi > 0)) continue;
      // bag moved to another wallet: its cost goes with it, no profit or loss here
      const frac = Math.min(1, ev.amountUi / (p.tok || ev.amountUi));
      p.cost -= p.cost * frac;
      p.tok -= p.tok * frac;
      if (p.tok <= p.max * (dustPct / 100)) {
        if (p.pnl !== 0) closeTrip(rec, ev.mint, p, t);
        else delete rec.pos[ev.mint];
      }
    }
    // XFER_IN: tokens with no known cost are ignored
  }
  return rec;
}

// Bags held longer than bagholdHours without being sold: count what's left in them as lost.
export function writeOffStale(rec, now, bagholdHours = 24) {
  if (!(bagholdHours > 0)) return rec;
  for (const [mint, p] of Object.entries(rec.pos)) {
    if (p.wroteOff || now - p.lastAt < bagholdHours * 3600000) continue;
    const t = p.lastAt + bagholdHours * 3600000;
    const d = day(rec, t);
    d.pnl -= p.cost;
    p.pnl -= p.cost;
    p.cost = 0;
    const tok = p.tok;
    closeTrip(rec, mint, p, t);
    rec.pos[mint] = { cost: 0, tok, max: tok, pnl: 0, openedAt: p.openedAt, lastAt: t, wroteOff: true };
  }
  return rec;
}

// Consecutive green days, counted back from the last finished day (yesterday).
// A day with no finished trades doesn't break the streak (idleBreaks=false) — it's skipped.
// Only days we have full history for count.
export function greenStreak(rec, now, { idleBreaks = false, minPnl = 0 } = {}) {
  const coverDay = rec.coverFrom ? dayKey(rec.coverFrom) : null;
  let streak = 0;
  for (let n = 1; n <= 400; n++) {
    const k = dayBefore(now, n);
    if (coverDay && k <= coverDay) break; // the first day is only partly known
    const d = rec.days[k];
    const traded = d && (d.wins + d.losses > 0 || Math.abs(d.pnl) > 1e-9);
    if (!traded) {
      if (idleBreaks) break;
      continue;
    }
    if (d.pnl > minPnl) streak++;
    else break;
  }
  return streak;
}

// Totals over the last `days` days (today included).
// offset 1 = finished days only (ends yesterday).
export function windowStats(rec, now, days = 7, offset = 0) {
  const s = { pnl: 0, wins: 0, losses: 0, buySol: 0, trades: 0, greenDays: 0, redDays: 0, activeDays: 0 };
  for (let n = offset; n < days + offset; n++) {
    const d = rec.days[dayBefore(now, n)];
    if (!d) continue;
    s.pnl += d.pnl;
    s.wins += d.wins;
    s.losses += d.losses;
    s.buySol += d.buySol;
    s.trades += d.trades;
    if (d.wins + d.losses > 0 || d.trades) {
      s.activeDays++;
      if (d.pnl > 0) s.greenDays++;
      else if (d.pnl < 0) s.redDays++;
    }
  }
  const n = s.wins + s.losses;
  s.winRate = n ? s.wins / n : 0;
  s.closed = n;
  return s;
}

export function medianHoldSec(rec) {
  const h = [...(rec.holds || [])].sort((a, b) => a - b);
  if (!h.length) return null;
  return h[Math.floor(h.length / 2)];
}

// Looks like a bot (not someone you can follow)? -> reason string, else null
export function botReason(rec, now, { maxTradesPerDay = 400, minHoldSec = 15 } = {}) {
  if (rec.flags?.bot) return rec.flags.why || 'bot';
  const w = windowStats(rec, now, 7);
  if (w.activeDays && w.trades / w.activeDays > maxTradesPerDay) return `${Math.round(w.trades / w.activeDays)} trades a day`;
  const med = medianHoldSec(rec);
  if (med != null && (rec.holds?.length || 0) >= 10 && med < minHoldSec) return `holds coins ~${med}s`;
  return null;
}

// Drops day entries older than keepDays (keeps the file small)
export function pruneDays(rec, now, keepDays = 60) {
  const cut = dayBefore(now, keepDays);
  for (const k of Object.keys(rec.days)) if (k < cut) delete rec.days[k];
  return rec;
}
