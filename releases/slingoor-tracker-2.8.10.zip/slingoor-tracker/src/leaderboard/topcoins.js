// Biggest new coins of the day / week / month.
// The trade stream shows which new pump.fun coins are getting real volume; for those the market cap is
// read from DexScreener every scan (it follows the coin after it leaves the bonding curve too), and the
// highest value seen is kept as the coin's peak.
import fs from 'node:fs';
import path from 'node:path';
import { fetchJson, sleep } from '../util.js';
import { log } from '../log.js';
import { DAY_MS } from './score.js';

export class TopCoins {
  constructor({ file, dexApi, minVolSol = 25, keepDays = 31, maxStored = 1200, now = () => Date.now(), fetch = fetchJson, gapMs = 250 }) {
    this.file = file;
    this.dexApi = dexApi;
    this.minVol = minVolSol;
    this.keepDays = keepDays;
    this.maxStored = maxStored;
    this.now = now;
    this.fetch = fetch;
    this.gapMs = gapMs;
    this.live = new Map(); // mint -> { first, last, vol, n } from the stream
    this.coins = {}; // mint -> { mint, symbol, name, created, firstSeen, peak, peakAt, mc, mcAt, vol }
    try {
      const j = JSON.parse(fs.readFileSync(file, 'utf8'));
      if (j?.coins) this.coins = j.coins;
    } catch {}
  }

  // one pump.fun trade from the stream
  track(ev) {
    if (!ev?.mint) return;
    const t = this.now();
    let m = this.live.get(ev.mint);
    if (!m) {
      if (this.live.size >= 20000) return;
      m = { first: t, last: t, vol: 0, n: 0 };
      this.live.set(ev.mint, m);
    }
    m.last = t;
    m.n++;
    if (ev.solAmount > 0) m.vol += ev.solAmount;
  }

  prune() {
    const t = this.now();
    for (const [k, m] of this.live) if (t - m.last > 2 * 3600000 || (t - m.last > 20 * 60000 && m.vol < this.minVol)) this.live.delete(k);
  }

  save() {
    try {
      fs.mkdirSync(path.dirname(this.file), { recursive: true });
      fs.writeFileSync(this.file + '.tmp', JSON.stringify({ coins: this.coins }));
      fs.renameSync(this.file + '.tmp', this.file);
    } catch (e) {
      log.warn('Leaderboard: could not save coins:', e.message);
    }
  }

  // which coins get a market-cap check this scan
  _targets() {
    const t = this.now();
    const fresh = [...this.live].filter(([k, m]) => m.vol >= this.minVol && !this.coins[k]).sort((a, b) => b[1].vol - a[1].vol).slice(0, 60).map(([k]) => k);
    // known coins: everything from the last day, and older ones that are still worth something
    const known = Object.values(this.coins)
      .filter((c) => t - c.created <= DAY_MS || c.mc >= 50000 || this.live.has(c.mint))
      .sort((a, b) => (b.mc || 0) - (a.mc || 0))
      .slice(0, 150)
      .map((c) => c.mint);
    return [...new Set([...fresh, ...known])];
  }

  // reads market caps (5 coins per DexScreener call) and updates peaks
  async refresh() {
    const t = this.now();
    const mints = this._targets();
    let seen = 0;
    for (let i = 0; i < mints.length; i += 5) {
      const chunk = mints.slice(i, i + 5);
      const j = await this.fetch(`${this.dexApi}/latest/dex/tokens/${chunk.join(',')}`, { timeout: 6000 }).catch(() => null);
      for (const mint of chunk) {
        const pairs = (j?.pairs || []).filter((p) => p.baseToken?.address === mint);
        if (!pairs.length) continue;
        pairs.sort((a, b) => (b.liquidity?.usd || 0) - (a.liquidity?.usd || 0));
        const mc = +pairs[0].marketCap || +pairs[0].fdv || 0;
        if (!(mc > 0)) continue;
        const createdTs = pairs.map((p) => +p.pairCreatedAt).filter((x) => x > 0);
        const live = this.live.get(mint);
        const c = (this.coins[mint] ||= { mint, created: createdTs.length ? Math.min(...createdTs) : live?.first || t, firstSeen: live?.first || t, peak: 0, peakAt: 0, mc: 0, mcAt: 0, vol: 0 });
        if (createdTs.length) c.created = Math.min(c.created, ...createdTs);
        c.symbol = pairs[0].baseToken.symbol || c.symbol;
        c.name = pairs[0].baseToken.name || c.name;
        c.mc = mc;
        c.mcAt = t;
        if (live) c.vol = Math.max(c.vol || 0, live.vol);
        if (mc > c.peak) {
          c.peak = mc;
          c.peakAt = t;
        }
        seen++;
      }
      if (this.gapMs && i + 5 < mints.length) await sleep(this.gapMs);
    }
    this._evict();
    this.save();
    return { checked: mints.length, seen };
  }

  _evict() {
    const t = this.now();
    for (const c of Object.values(this.coins)) {
      const old = t - c.created;
      if (old > this.keepDays * DAY_MS || (old > DAY_MS && c.peak < 30000)) delete this.coins[c.mint];
    }
    const all = Object.values(this.coins);
    if (all.length > this.maxStored) for (const c of all.sort((a, b) => a.peak - b.peak).slice(0, all.length - this.maxStored)) delete this.coins[c.mint];
  }

  list() {
    return Object.values(this.coins);
  }
}
