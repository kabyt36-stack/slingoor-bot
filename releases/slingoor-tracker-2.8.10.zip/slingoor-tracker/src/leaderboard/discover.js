// Finds wallets worth scoring, from ANY wallet trading on pump.fun.
//
// The stream listens to pump.fun's program on the Solana log stream and decodes its trade record
// (the same decoder the copy bot uses), so every bonding-curve buy/sell of every wallet comes in for free
// (no transaction downloads). From that it keeps a rough running score per wallet — SOL in/out per coin —
// and hands the best ones to the scanner, which then reads each wallet's real history (all venues).
//
// Memory is kept small: wallets that only did a few tiny trades are forgotten after a while.
import { pumpTradeEvents, PUMP_PROGRAM } from '../parse.js';
import { log } from '../log.js';

export class Discovery {
  constructor({ minTrades = 4, maxTradesPerDay = 400, minVolSol = 1, maxWallets = 50000, now = () => Date.now() } = {}) {
    this.minTrades = minTrades;
    this.maxTrades = maxTradesPerDay;
    this.minVol = minVolSol;
    this.maxWallets = maxWallets;
    this.now = now;
    this.w = new Map(); // wallet -> { b, s, n, pnl, wins, losses, last, m: Map(mint -> [cost, tok]) }
    this.events = 0;
    this.handedOut = new Set();
    this.dayStart = this.now();
  }

  // ev: { user, mint, solAmount, tokenAmount, isBuy }
  add(ev) {
    if (!ev?.user || !ev.mint || !(ev.tokenAmount > 0)) return;
    this.events++;
    const t = this.now();
    let x = this.w.get(ev.user);
    if (!x) {
      x = { b: 0, s: 0, n: 0, pnl: 0, wins: 0, losses: 0, last: t, m: new Map() };
      this.w.set(ev.user, x);
    }
    x.n++;
    x.last = t;
    const sol = ev.solAmount > 0 ? ev.solAmount : 0;
    if (ev.isBuy) {
      x.b += sol;
      const p = x.m.get(ev.mint) || [0, 0, 0];
      if (!x.m.has(ev.mint) && x.m.size >= 30) x.m.delete(x.m.keys().next().value); // keep memory small
      p[0] += sol;
      p[1] += ev.tokenAmount;
      p[2] = Math.max(p[2], p[1]);
      x.m.set(ev.mint, p);
    } else {
      x.s += sol;
      const p = x.m.get(ev.mint);
      if (!p || !(p[1] > 0)) return; // bought before we were listening
      const sold = Math.min(ev.tokenAmount, p[1]);
      const basis = p[0] * (sold / p[1]);
      const pnl = sol * (sold / ev.tokenAmount) - basis;
      p[0] -= basis;
      p[1] -= sold;
      p[3] = (p[3] || 0) + pnl;
      x.pnl += pnl;
      if (p[1] <= p[2] * 0.01) {
        if (p[3] > 0) x.wins++;
        else x.losses++;
        x.m.delete(ev.mint);
      }
    }
  }

  // from one websocket log notification
  addLogs(logs) {
    let n = 0;
    for (const ev of pumpTradeEvents(logs)) {
      this.add(ev);
      this.onTrade?.(ev); // biggest-coins tracker
      n++;
    }
    return n;
  }

  // forget small fry and keep the map under maxWallets; called every few minutes
  prune() {
    const t = this.now();
    for (const [k, x] of this.w) {
      const idle = t - x.last;
      if ((idle > 30 * 60000 && x.b + x.s < this.minVol) || idle > 6 * 3600000) this.w.delete(k);
      else for (const [mint, p] of x.m) if (t - x.last > 3 * 3600000 || p[1] <= 0) x.m.delete(mint);
    }
    if (this.w.size > this.maxWallets) {
      const sorted = [...this.w].sort((a, b) => a[1].b + a[1].s - (b[1].b + b[1].s));
      for (const [k] of sorted.slice(0, this.w.size - this.maxWallets)) this.w.delete(k);
    }
    // a new day: start counting again (wallets handed out stay known to the scanner)
    if (t - this.dayStart > 24 * 3600000) {
      this.dayStart = t;
      this.handedOut.clear();
      for (const x of this.w.values()) Object.assign(x, { b: 0, s: 0, n: 0, pnl: 0, wins: 0, losses: 0 });
    }
  }

  // best wallets not handed out yet: made money, enough trades to judge, not bot-like volume
  candidates(k, skip = new Set()) {
    const days = Math.max(1, (this.now() - this.dayStart) / 86400000);
    const out = [];
    for (const [wallet, x] of this.w) {
      if (skip.has(wallet) || this.handedOut.has(wallet)) continue;
      if (x.n < this.minTrades || x.n / days > this.maxTrades) continue;
      if (x.b + x.s < this.minVol || !(x.pnl > 0)) continue;
      if (x.wins + x.losses < 2) continue;
      out.push({ wallet, pnl: x.pnl, wins: x.wins, losses: x.losses, n: x.n });
    }
    out.sort((a, b) => b.pnl - a.pnl);
    const pick = out.slice(0, k);
    for (const p of pick) this.handedOut.add(p.wallet);
    return pick;
  }
}

// Live websocket on pump.fun's program. maxMbPerDay: stop for the day after this much data (paid
// RPCs like Helius bill websocket data by size), 0 = no cap.
export class TradeStream {
  constructor({ url, discovery, maxMbPerDay = 0, commitment = 'confirmed', now = () => Date.now(), WebSocketImpl = globalThis.WebSocket }) {
    this.url = url;
    this.d = discovery;
    this.maxBytes = maxMbPerDay > 0 ? maxMbPerDay * 1e6 : 0;
    this.commitment = commitment;
    this.now = now;
    this.WS = WebSocketImpl;
    this.connected = false;
    this.stopped = false;
    this.backoff = 2000;
    this.stats = { msgs: 0, trades: 0, bytesToday: 0, reconnects: 0, lastMsgAt: 0, capped: false, lastError: null };
    this.day = new Date(this.now()).getDate();
  }

  start() {
    this._connect();
    this._t = setInterval(() => this._tick(), 20000);
    this._t.unref?.();
  }

  stop() {
    this.stopped = true;
    clearInterval(this._t);
    try {
      this.ws?.close();
    } catch {}
  }

  _tick() {
    const d = new Date(this.now()).getDate();
    if (d !== this.day) {
      this.day = d;
      this.stats.bytesToday = 0;
      if (this.stats.capped) {
        this.stats.capped = false;
        this._connect();
      }
    }
    // silent socket for 2 minutes -> reconnect
    if (this.connected && this.now() - this.stats.lastMsgAt > 120000) {
      try {
        this.ws.close();
      } catch {}
    }
  }

  _connect() {
    if (this.stopped || this.stats.capped || !this.url) return;
    let ws;
    try {
      ws = new this.WS(this.url);
    } catch (e) {
      this.stats.lastError = e.message;
      return this._later();
    }
    this.ws = ws;
    ws.onopen = () => {
      this.connected = true;
      this.stats.lastMsgAt = this.now();
      ws.send(JSON.stringify({ jsonrpc: '2.0', id: 1, method: 'logsSubscribe', params: [{ mentions: [PUMP_PROGRAM] }, { commitment: this.commitment }] }));
    };
    ws.onmessage = (ev) => {
      if (this.stats.capped) return;
      const raw = typeof ev.data === 'string' ? ev.data : Buffer.from(ev.data).toString();
      this.stats.lastMsgAt = this.now();
      this.stats.bytesToday += raw.length;
      let m;
      try {
        m = JSON.parse(raw);
      } catch {
        return;
      }
      if (m.error) this.stats.lastError = m.error.message;
      const v = m.params?.result?.value;
      if (v && !v.err && Array.isArray(v.logs)) {
        this.stats.msgs++;
        this.stats.trades += this.d.addLogs(v.logs);
        if (this.backoff > 2000 && this.stats.msgs % 500 === 0) this.backoff = 2000;
      }
      if (this.maxBytes && this.stats.bytesToday > this.maxBytes) {
        this.stats.capped = true;
        log.info(`Leaderboard stream: daily data cap reached (${Math.round(this.maxBytes / 1e6)} MB), paused until tomorrow`);
        try {
          ws.close();
        } catch {}
      }
    };
    ws.onerror = (e) => {
      this.stats.lastError = e?.message || 'stream error';
    };
    ws.onclose = () => {
      if (this.ws !== ws) return;
      this.connected = false;
      this._later();
    };
  }

  _later() {
    if (this.stopped || this.stats.capped) return;
    this.stats.reconnects++;
    const wait = this.backoff;
    this.backoff = Math.min(this.backoff * 2, 60000);
    setTimeout(() => this._connect(), wait).unref?.();
  }
}
