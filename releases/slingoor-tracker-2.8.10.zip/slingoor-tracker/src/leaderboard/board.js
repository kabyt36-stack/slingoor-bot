// Turns scored wallets into the leaderboards and the Telegram messages.
import { greenStreak, windowStats, dayKey, DAY_MS, botReason } from './score.js';
import { escHtml as e, shortAddr } from '../util.js';

// The periods a board can cover. offset 1 = finished days only (used by the morning post).
export const PERIODS = {
  today: { days: 1, offset: 0, label: 'today so far', minTrips: 2 },
  yesterday: { days: 1, offset: 1, label: 'yesterday', minTrips: 2 },
  week: { days: 7, offset: 0, label: '7 days' },
  month: { days: 30, offset: 0, label: '30 days' },
  lastweek: { days: 7, offset: 1, label: 'last 7 days' },
  lastmonth: { days: 30, offset: 1, label: 'last 30 days' },
};
export function periodOf(arg) {
  const a = String(arg || '').toLowerCase();
  if (/^(day|daily|today|1d|24h)$/.test(a)) return 'today';
  if (/^(yesterday|yday)$/.test(a)) return 'yesterday';
  if (/^(month|monthly|30d)$/.test(a)) return 'month';
  if (/^(week|weekly|7d)$/.test(a)) return 'week';
  return null;
}

export function rows(records, now, { minTrips = 5, activeDays = 2, idleBreaks = false, botOpts = {}, days = 7, offset = 0 } = {}) {
  const out = [];
  for (const r of records) {
    if (!r.coverFrom || r.flags?.bot || botReason(r, now, botOpts)) continue;
    if (now - (r.lastTradeAt || 0) > (activeDays + offset) * DAY_MS) continue;
    const w = windowStats(r, now, days, offset);
    if (w.closed < minTrips) continue;
    const w7 = days === 7 && !offset ? w : windowStats(r, now, 7);
    const today = r.days[dayKey(now)];
    out.push({
      wallet: r.wallet,
      name: r.name || null,
      streak: greenStreak(r, now, { idleBreaks }),
      pnl: w.pnl, // the board's period
      pnl7: w7.pnl,
      pnlToday: today ? today.pnl : 0,
      winRate: w.winRate,
      wins: w.wins,
      losses: w.losses,
      greenDays: w.greenDays,
      redDays: w.redDays,
      curWin: r.curWin || 0,
      bestWin: r.bestWin || 0,
      trades: w.trades,
      volume: w.buySol,
      roi: w.buySol > 0 ? w.pnl / w.buySol : 0,
    });
  }
  return out;
}

export function boards(list, { top = 10, minWinRate = 0.5 } = {}) {
  const byStreak = list
    .filter((x) => x.streak >= 1 && x.pnl7 > 0)
    .sort((a, b) => b.streak - a.streak || b.pnl7 - a.pnl7)
    .slice(0, top);
  const byPnl = list
    .filter((x) => x.pnl > 0 && x.winRate >= minWinRate)
    .sort((a, b) => b.pnl - a.pnl)
    .slice(0, top);
  const byWins = list
    .filter((x) => x.curWin >= 2 && x.pnl7 > 0)
    .sort((a, b) => b.curWin - a.curWin || b.winRate - a.winRate || b.pnl7 - a.pnl7)
    .slice(0, top);
  return { byStreak, byPnl, byWins };
}

// Phase 2 (off unless LB_AUTO_COPY=on): which wallets the bot would copy
export function autoPicks(list, { count = 3, minStreak = 3, minWinRate = 0.55, minPnl = 2, minTrips = 10, exclude = new Set() } = {}) {
  return list
    .filter((x) => !exclude.has(x.wallet) && x.streak >= minStreak && x.winRate >= minWinRate && x.pnl7 >= minPnl && x.wins + x.losses >= minTrips)
    .sort((a, b) => b.streak - a.streak || b.pnl7 - a.pnl7)
    .slice(0, count);
}

const sol = (n) => `${n >= 0 ? '+' : '−'}${Math.abs(n) >= 100 ? Math.abs(n).toFixed(0) : Math.abs(n) >= 10 ? Math.abs(n).toFixed(1) : Math.abs(n).toFixed(2)}`;
const pct = (x) => `${Math.round(x * 100)}%`;
const medal = (i) => ['🥇', '🥈', '🥉'][i] || `${i + 1}.`;

function line(x, i, followed, per = '7d') {
  const label = x.name ? `${e(x.name)} (${shortAddr(x.wallet)})` : shortAddr(x.wallet);
  const star = followed?.has(x.wallet) ? ' ⭐' : '';
  return (
    `${medal(i)} <a href="https://gmgn.ai/sol/address/${x.wallet}">${label}</a>${star}\n` +
    `    🔥 ${x.streak}d green · 💰 <b>${sol(x.pnl)} SOL</b> ${e(per)} · 🎯 ${pct(x.winRate)} (${x.wins}W/${x.losses}L) · ${x.curWin} wins in a row\n` +
    `    <code>${x.wallet}</code>`
  );
}

// -> array of HTML messages (one per board, so each stays under Telegram's 4096 characters)
export function boardMessages(list, { top = 10, minWinRate = 0.5, followed = new Set(), dateLabel = '', stats = null, picks = null, autoOn = false, label = '7 days', only = null } = {}) {
  const b = boards(list, { top, minWinRate });
  const head = [`🏆 <b>Wallet leaderboard</b>${dateLabel ? ` — ${e(dateLabel)}` : ''}`];
  if (stats) head.push(`<i>${e(stats)}</i>`);
  head.push(`<i>PnL = realized SOL, ${e(label)}. Green streak = days in a row in profit (days off don't break it). ⭐ = already followed.</i>`);
  const auto = picks
    ? autoOn
      ? `🤖 <b>Auto-copy</b> is copying: ${picks.length ? picks.map((p) => `<code>${shortAddr(p.wallet)}</code>`).join(', ') : 'nobody qualifies today'}`
      : `🤖 Auto-copy is <b>off</b>${picks.length ? ` — it would copy: ${picks.map((p) => `<code>${shortAddr(p.wallet)}</code>`).join(', ')}` : ' (nobody would qualify today)'}`
    : '';
  // whole entries only, so a message never gets cut in the middle of a link (Telegram max 4096)
  const block = (pre, title, arr, empty, post = '') => {
    let out = [...pre, title].join('\n');
    if (!arr.length) out += '\n' + empty;
    for (let i = 0; i < arr.length; i++) {
      const l = '\n' + line(arr[i], i, followed, label);
      if (out.length + l.length + post.length + 2 > 4000) break;
      out += l;
    }
    return post ? `${out}\n\n${post}` : out;
  };
  if (only === 'pnl') return [block([], `💰 <b>Top PnL — ${e(label)} (win rate ≥ ${pct(minWinRate)})</b>`, b.byPnl, 'Nothing yet.')];
  return [
    block([...head, ''], '🔥 <b>Longest green-day streaks</b>', b.byStreak, 'No wallet on a green streak yet — streaks build up as days pass.'),
    block([], `💰 <b>Top PnL — ${e(label)} (win rate ≥ ${pct(minWinRate)})</b>`, b.byPnl, 'Nothing yet.'),
    block([], '🎯 <b>Most wins in a row (right now)</b>', b.byWins, 'Nothing yet.', auto),
  ];
}

// ---------- biggest coins ----------
export const usd = (n) => (n >= 1e9 ? `$${(n / 1e9).toFixed(2)}B` : n >= 1e6 ? `$${(n / 1e6).toFixed(n >= 1e7 ? 1 : 2)}M` : n >= 1e3 ? `$${(n / 1e3).toFixed(n >= 1e5 ? 0 : 1)}K` : `$${Math.round(n)}`);
const age = (ms) => (ms < 3600000 ? `${Math.max(1, Math.round(ms / 60000))}m` : ms < 2 * DAY_MS ? `${Math.round(ms / 3600000)}h` : `${Math.round(ms / DAY_MS)}d`);

// coins: [{ mint, symbol, name, created, peak, mc }] -> one HTML message
export function coinsMessage(coins, now, { days = 1, top = 10, label = 'today' } = {}) {
  const list = coins
    .filter((c) => c.peak > 0 && now - c.created <= days * DAY_MS)
    .sort((a, b) => b.peak - a.peak)
    .slice(0, top);
  let out = `🪙 <b>Biggest coins — ${e(label)}</b>\n<i>New pump.fun coins launched in the last ${days === 1 ? '24 hours' : `${days} days`}, by the highest market cap seen.</i>`;
  if (!list.length) return out + '\nNothing yet — it fills in as the scanner watches new coins.';
  list.forEach((c, i) => {
    const l =
      `\n${medal(i)} <a href="https://dexscreener.com/solana/${c.mint}">$${e(c.symbol || c.mint.slice(0, 5))}</a>${c.name && c.name !== c.symbol ? ` ${e(String(c.name).slice(0, 28))}` : ''}\n` +
      `    📈 peak <b>${usd(c.peak)}</b> · now ${c.mc > 0 ? usd(c.mc) : '?'}${c.mc > 0 && c.peak > 0 && c.mc < c.peak * 0.98 ? ` (${Math.round((c.mc / c.peak - 1) * 100)}%)` : ''} · ${age(now - c.created)} old\n` +
      `    <code>${c.mint}</code>`;
    if (out.length + l.length <= 4000) out += l;
  });
  return out;
}
