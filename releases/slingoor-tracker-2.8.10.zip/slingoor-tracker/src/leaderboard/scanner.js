// Reads candidate wallets' real trade history and keeps their scores up to date.
//
// For each wallet: its signatures (getSignaturesForAddress, 1 credit per 1000) and each transaction
// (getTransaction, 1 credit each on Helius) are read once; after that only new transactions are read.
// Trades are taken from the wallet's own balance changes (parse.js), so every venue counts
// (pump.fun, PumpSwap, Raydium, Meteora, Jupiter, Axiom/Padre routers...).
//
// A daily credit budget keeps this from eating the Helius plan the copy bot needs. When it's spent,
// scanning waits for tomorrow; the board still works with what's known.
import fs from 'node:fs';
import path from 'node:path';
import { parseWalletTx, tradesFromParsed } from '../parse.js';
import { newRecord, applyTrades, writeOffStale, pruneDays, botReason, windowStats, dayKey, DAY_MS } from './score.js';
import { log } from '../log.js';

export class Scanner {
  constructor({
    rpc,
    file,
    historyDays = 7,
    maxTxPerWallet = 2500,
    dailyCredits = 100000,
    poolSize = 300,
    bagholdHours = 24,
    maxTradesPerDay = 400,
    minHoldSec = 15,
    rescanMinutes = 180,
    seeds = [], // [{ wallet, name }] always scored
    now = () => Date.now(),
  }) {
    this.rpc = rpc;
    this.file = file;
    this.historyDays = historyDays;
    this.maxTx = maxTxPerWallet;
    this.dailyCredits = dailyCredits;
    this.poolSize = poolSize;
    this.bagholdHours = bagholdHours;
    this.botOpts = { maxTradesPerDay, minHoldSec };
    this.rescanMs = rescanMinutes * 60000;
    this.seeds = seeds;
    this.now = now;
    this.busy = false;
    this.d = this._load();
    for (const s of seeds) {
      const r = (this.d.wallets[s.wallet] ||= newRecord(s.wallet, { addedAt: this.now() }));
      r.name = s.name;
      r.seed = true;
    }
  }

  _load() {
    try {
      const d = JSON.parse(fs.readFileSync(this.file, 'utf8'));
      if (d && d.wallets) return { budget: { day: null, used: 0 }, queue: [], ...d };
    } catch {}
    return { wallets: {}, budget: { day: null, used: 0 }, queue: [] };
  }

  save() {
    try {
      fs.mkdirSync(path.dirname(this.file), { recursive: true });
      fs.writeFileSync(this.file + '.tmp', JSON.stringify(this.d));
      fs.renameSync(this.file + '.tmp', this.file);
    } catch (e) {
      log.warn('Leaderboard: could not save wallets:', e.message);
    }
  }

  // ---- credit budget (per local day) ----
  _budget() {
    const k = dayKey(this.now());
    if (this.d.budget.day !== k) this.d.budget = { day: k, used: 0 };
    return this.d.budget;
  }
  creditsLeft() {
    return this.dailyCredits > 0 ? Math.max(0, this.dailyCredits - this._budget().used) : Infinity;
  }
  _spend(n) {
    this._budget().used += n;
  }

  // queue wallets found by the stream (most promising first)
  enqueue(wallets) {
    const known = new Set([...Object.keys(this.d.wallets), ...this.d.queue]);
    for (const w of wallets) if (!known.has(w)) this.d.queue.push(w);
    if (this.d.queue.length > 500) this.d.queue.length = 500;
  }

  // all signatures newer than `until` (or within the history window), newest first
  async _signatures(wallet, { until = null, since = 0, cap }) {
    const out = [];
    let before;
    for (let page = 0; page < 50; page++) {
      const opts = { limit: 1000, commitment: 'confirmed' };
      if (before) opts.before = before;
      if (until) opts.until = until;
      this._spend(1);
      const list = (await this.rpc.call('getSignaturesForAddress', [wallet, opts])) || [];
      let done = list.length < 1000;
      for (const s of list) {
        if (since && s.blockTime && s.blockTime * 1000 < since) {
          done = true;
          break;
        }
        out.push(s);
        if (out.length > cap) return { sigs: out, over: true };
      }
      if (done || !list.length) break;
      before = list.at(-1).signature;
    }
    return { sigs: out, over: false };
  }

  // Reads new history for one wallet. Returns 'ok' | 'budget' | 'bot' | 'error'
  async scan(wallet) {
    const r = (this.d.wallets[wallet] ||= newRecord(wallet, { addedAt: this.now() }));
    const first = !r.coverFrom;
    // first scan: the history window; later: everything after the last transaction read
    // (a wallet with no transactions yet has no lastSig: then everything since its window started)
    const since = first ? this.now() - this.historyDays * DAY_MS : r.lastSig ? 0 : r.coverFrom;
    let sigs;
    try {
      // the signature list is cheap; check it fits the budget before downloading transactions
      if (this.creditsLeft() < 2) return 'budget';
      const res = await this._signatures(wallet, { until: first ? null : r.lastSig, since, cap: this.maxTx });
      if (res.over) {
        r.flags = { bot: true, why: `${this.maxTx}+ transactions in ${first ? `${this.historyDays} days` : 'one scan'}` };
        r.scannedAt = this.now();
        return 'bot';
      }
      sigs = res.sigs.filter((s) => !s.err);
    } catch (e) {
      log.warn(`Leaderboard: signatures for ${wallet.slice(0, 6)} failed: ${e.message}`);
      return 'error';
    }
    if (sigs.length > this.creditsLeft()) return 'budget';
    const events = [];
    let newest = null;
    let failed = false;
    // oldest first, a few at a time (the RPC client paces the requests)
    const ordered = [...sigs].reverse();
    for (let i = 0; i < ordered.length; i += 8) {
      const chunk = ordered.slice(i, i + 8);
      const txs = await Promise.all(
        chunk.map(async (s) => {
          this._spend(1);
          try {
            return await this.rpc.getTransaction(s.signature, { priority: false });
          } catch (e) {
            return { failed: e.message };
          }
        }),
      );
      if (txs.some((t) => t?.failed)) {
        // stop at the first gap so no trade is skipped; the rest is read next time
        const firstFail = txs.findIndex((t) => t?.failed);
        for (const tx of txs.slice(0, firstFail)) events.push(...tradesFromParsed(parseWalletTx(tx, wallet)));
        if (firstFail > 0) newest = chunk[firstFail - 1];
        log.warn(`Leaderboard: tx download failed for ${wallet.slice(0, 6)}: ${txs[firstFail].failed}`);
        failed = true;
        break;
      }
      for (const tx of txs) events.push(...tradesFromParsed(parseWalletTx(tx, wallet)));
      newest = chunk.at(-1);
    }
    if (failed && first && !newest) {
      // nothing read: try this wallet again from scratch next time
      delete this.d.wallets[wallet];
      return 'error';
    }
    applyTrades(r, events);
    if (first) r.coverFrom = since;
    if (newest) {
      r.lastSig = newest.signature;
      r.lastTxAt = (newest.blockTime || 0) * 1000;
    }
    r.scannedAt = this.now();
    writeOffStale(r, this.now(), this.bagholdHours);
    pruneDays(r, this.now(), 60);
    return failed ? 'error' : 'ok';
  }

  // which known wallets are worth a rescan now (best first)
  _due() {
    const t = this.now();
    return Object.values(this.d.wallets)
      .filter((r) => r.coverFrom && !r.flags?.bot && t - (r.scannedAt || 0) >= this.rescanMs)
      .sort((a, b) => windowStats(b, t, 7).pnl - windowStats(a, t, 7).pnl)
      .map((r) => r.wallet);
  }

  // drop the weakest wallets when the pool is over size (never seeds)
  _evict() {
    const t = this.now();
    const all = Object.values(this.d.wallets);
    if (all.length <= this.poolSize) return;
    const score = (r) => (r.flags?.bot ? -1e9 : 0) + (t - (r.lastTradeAt || 0) > 3 * DAY_MS ? -1e6 : 0) + windowStats(r, t, 7).pnl;
    const drop = all.filter((r) => !r.seed).sort((a, b) => score(a) - score(b)).slice(0, all.length - this.poolSize);
    for (const r of drop) delete this.d.wallets[r.wallet];
  }

  // One pass: new wallets from the queue (up to `newPerCycle`), then rescans of known wallets.
  async cycle({ newPerCycle = 15, maxRescans = 100 } = {}) {
    if (this.busy) return { skipped: true };
    this.busy = true;
    const res = { added: 0, rescanned: 0, bots: 0, budget: false, errors: 0 };
    try {
      const work = [];
      // seeds without history first
      for (const s of this.seeds) if (!this.d.wallets[s.wallet]?.coverFrom) work.push(s.wallet);
      while (work.length < newPerCycle && this.d.queue.length) work.push(this.d.queue.shift());
      const fresh = new Set(work);
      for (const w of this._due().slice(0, maxRescans)) if (!fresh.has(w)) work.push(w);
      for (const w of work) {
        if (this.creditsLeft() < 2) {
          res.budget = true;
          // keep new wallets queued for tomorrow
          if (fresh.has(w) && !this.d.wallets[w]?.coverFrom) this.d.queue.unshift(w);
          continue;
        }
        const out = await this.scan(w);
        if (out === 'budget') {
          res.budget = true;
          if (fresh.has(w) && !this.d.wallets[w]?.coverFrom) {
            delete this.d.wallets[w];
            this.d.queue.unshift(w);
          }
        } else if (out === 'bot') res.bots++;
        else if (out === 'error') res.errors++;
        else if (fresh.has(w)) res.added++;
        else res.rescanned++;
        if (out !== 'budget') {
          const r = this.d.wallets[w];
          if (r && !r.flags?.bot) {
            const why = botReason(r, this.now(), this.botOpts);
            if (why) r.flags = { bot: true, why };
          }
        }
      }
      for (const r of Object.values(this.d.wallets)) writeOffStale(r, this.now(), this.bagholdHours);
      this._evict();
      this.save();
    } finally {
      this.busy = false;
    }
    return res;
  }

  records() {
    return Object.values(this.d.wallets);
  }
}
