// V2.4 dev mode: copy coins that tracked devs launch.
//   instant  (e.g. Pattersin): buy right away, sell fast at the best quick profit (+25% to +40%)
//   dip      (Dev nig, Dev ya): after the launch, wait until the price falls DEV_DIP_PERCENT from its
//            high, then buy
//   momentum (Claudia): wait until the coin has DEV_MOMENTUM_HOLDERS holders AND the price is up
//            DEV_MOMENTUM_UP_PERCENT from the launch, then buy (she tends to rug right away)
// The price is read straight from the coin's own latest trade on chain (pump.fun TradeEvent), so it
// works seconds after launch, before price sites list the coin.
import { pumpTradeEvents } from './parse.js';
import { log } from './log.js';

export const DEV_MODES = new Set(['instant', 'dip', 'momentum']);

// DEVS setting: name:wallet:mode, comma separated
export function parseDevs(text, isAddress) {
  const out = [];
  for (const part of String(text || '').split(',').map((x) => x.trim()).filter(Boolean)) {
    const [name, wallet, mode = 'instant'] = part.split(':').map((x) => (x || '').trim());
    if (!name || !wallet) continue;
    if (!isAddress(wallet)) throw new Error(`DEVS: ${name} has an invalid wallet: ${wallet}`);
    if (!DEV_MODES.has(mode)) throw new Error(`DEVS: ${name} has an unknown mode "${mode}" (instant, dip or momentum)`);
    out.push({ name, wallet, mode });
  }
  return out;
}

export class DevWatcher {
  constructor({ rpc, countHolders, onReady, cfg = {}, now = () => Date.now(), everyMs = 3000 }) {
    this.rpc = rpc;
    this.countHolders = countHolders; // async mint -> holders
    this.onReady = onReady; // (sig) => buy now
    this.cfg = { dipPct: 20, upPct: 30, minHolders: 40, watchMs: 20 * 60000, ...cfg };
    this.now = now;
    this.everyMs = everyMs;
    this.w = new Map(); // mint -> { sig, dev, start, first, high, last }
    this.busy = false;
  }

  watch(sig, dev) {
    const mint = sig.ev.mint;
    if (this.w.has(mint)) return;
    this.w.set(mint, { sig, dev, start: this.now(), first: null, high: null, last: null });
    log.info(`Dev ${dev.name} launched ${mint}: watching (${dev.mode === 'dip' ? `buy after a ${this.cfg.dipPct}% dip` : `buy at ${this.cfg.minHolders}+ holders and +${this.cfg.upPct}%`})`);
    if (!this._t) {
      this._t = setInterval(() => this.tick().catch(() => {}), this.everyMs);
      this._t.unref?.();
    }
  }

  // SOL per token from the coin's newest pump.fun trade
  async priceOf(mint) {
    const sigs = await this.rpc.call('getSignaturesForAddress', [mint, { limit: 4 }]);
    for (const s of sigs || []) {
      if (s.err) continue;
      const tx = await this.rpc.call('getTransaction', [s.signature, { maxSupportedTransactionVersion: 1, encoding: 'json', commitment: 'confirmed' }]);
      const evs = pumpTradeEvents(tx?.meta?.logMessages || []).filter((e) => e.mint === mint && e.priceSol > 0);
      if (evs.length) return evs.at(-1).priceSol;
    }
    return null;
  }

  async tick() {
    if (this.busy) return;
    this.busy = true;
    try {
      for (const [mint, x] of [...this.w]) {
        if (this.now() - x.start > this.cfg.watchMs) {
          this.w.delete(mint);
          log.info(`Dev ${x.dev.name}: ${mint} never hit the buy condition in ${Math.round(this.cfg.watchMs / 60000)} min — not bought`);
          continue;
        }
        const px = await this.priceOf(mint).catch(() => null);
        if (!(px > 0)) continue;
        x.first ??= px;
        x.high = Math.max(x.high || 0, px);
        x.last = px;
        let ready = false;
        if (x.dev.mode === 'dip') ready = px <= x.high * (1 - this.cfg.dipPct / 100);
        else if (x.dev.mode === 'momentum' && px >= x.first * (1 + this.cfg.upPct / 100)) {
          const n = await this.countHolders(mint).catch(() => null);
          x.holders = n;
          ready = n != null && n >= this.cfg.minHolders;
        }
        if (ready) {
          this.w.delete(mint);
          log.info(`Dev ${x.dev.name}: ${mint} hit the buy condition — buying`);
          this.onReady({ ...x.sig, devReady: true });
        }
      }
      if (!this.w.size && this._t) {
        clearInterval(this._t);
        this._t = null;
      }
    } finally {
      this.busy = false;
    }
  }

  stop() {
    clearInterval(this._t);
    this._t = null;
  }
}
