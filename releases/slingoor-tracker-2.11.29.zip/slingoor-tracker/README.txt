SLINGOOR TRACKER — Telegram alerts for slingoor (5YRgrP3mjGzrzirYYN5HAQH19cTYREYwGxW6XRJQUzij)
=================================================================================================

WHAT IT SENDS YOU
  🟢 NEW ENTRY        the second he buys a coin he didn't hold (about 1 second after his transaction)
  ➕ ADDED MORE       he buys more of a coin he already holds
  🟠 SOLD xx%         partial sell, with how much of his bag is left
  🔴 FULLY SOLD OUT   his bag hits 0 — includes the trip result (SOL in vs out) and pump.fun's PnL
  📤 MOVED TOKENS     he sent the bag to another wallet without selling
  📣 CALLOUT          he posts a callout on pump.fun — his text, MC at the call, and whether he's holding it
  📝 CALLOUT UPDATE   he posts an update on one of his callouts
  🚀 LAUNCHED A COIN  he creates a new coin (with his dev buy)

  Every buy/callout/launch is tagged with its narrative and how well it fits HIS META:
    🔥🔥 BIG TITTY COIN FORMULA  a real ticker spelled out dirty ($BTC Big Titty Coin, $ETH Extra Thick Hoe,
                                 $CPU Cum Processing Unit…) — what most of his biggest bags are
    🔥 META MATCH              same type of narrative he usually plays, same series as coins he played
                               ("Cute Crypto ___"), or a coin about him ($SLINGHOUSE, $SLINGTOSHI…)
    🟡 partial / ⚪ off-meta
  plus the coins of his it's most similar to. The bot learns his meta from his current bags, his last 100
  callouts, his recent trades and coins he launched, and keeps learning from every new entry.

  Quick repeat buys/sells of the same coin are merged into one message (he often buys in bursts).
  Each alert has buttons: pump.fun · Padre · GMGN · DexScreener · Tx.

COPY TRADING (optional — buys and sells for you)
  Double-click "3 - Copy Trade Setup", paste the private key of the wallet the bot should trade with,
  and pick how much SOL to spend per coin. Then restart the bot. What it does:
    🤖 he BUYS (new coin, re-entry or add) → you buy, scaled to his size: he buys 1 SOL → 0.5 SOL,
                                            10 → ~0.67, 100 → ~0.83, 1000+ → 1 SOL (max). Quick bursts merge.
    🛡 never full port                     → one buy ≤ 20% of your wallet's SOL, one coin ≤ 2 SOL total
    🤖 he sells part                       → sells the same % of your bag
    🤖 he's fully out                      → sells everything
    ⚡ his big buys (> 1 SOL) hit 1.5x     → sells 35%, keeps the rest riding
    🎯 your bag hits 2x                    → sells 25%. Take-profits never sell out; no stop loss.
  A buy we only see 30s+ late (e.g. right after a restart) is skipped.
  Telegram: /copy (wallet, open positions, PnL) · /pause (no new buys; sells still follow him) ·
            /resume · /sell <CA> [percent]
  ⚠️ Use a SEPARATE wallet with only the SOL you're OK losing — memecoins can go to zero in minutes,
     and copying is always a little behind him. The key is saved only in wallet-key.txt in this folder,
     trades are signed on your Mac, and the key is never sent anywhere.
  SPEED: the bot reads his pump.fun buys straight off the live Solana log stream (it decodes
  pump.fun's own trade record, so it doesn't have to download his transaction first) and fires your
  buy right away, with no waiting on pump.fun's site. With a free
  Helius key ("1 - Setup") that stream is fast and steady; on the free public server it drops often and
  the bot falls back to pump.fun's feed (~2-3s slower). For copy trading, the Helius key matters a lot.
  Every trade is sent to the normal Solana server and Jito's relay at the same time, so it lands sooner.
  Trades are routed by Jupiter (no extra fee); coins Jupiter can't route yet go through PumpPortal
  (0.5% fee). All limits (buy size, slippage, take profit, max open positions, daily SOL limit…) are
  in settings.txt under COPY TRADING.

FIRST-TIME SETUP (Mac)
  1. In Telegram, message @BotFather → /newbot → choose a name → copy the token.
  2. Double-click "1 - Setup". If macOS says it can't verify the file: open System Settings →
     Privacy & Security, scroll down, click "Open Anyway" (older macOS: right-click the file → Open).
     If it asks to let Terminal access your Downloads/Desktop folder, click Allow.
     It installs Node.js inside this folder, asks for the token, optionally a free Helius key,
     and tests every connection. You want to see ✅ on each line.
  3. Double-click "2 - Start Bot". Keep that window open (minimize it is fine).
  4. Open your new bot in Telegram and send /start. That chat now gets the alerts.

  Want it always on? Double-click "Auto-start ON" instead of step 3: it runs in the background and
  starts by itself whenever you log in. "Auto-start OFF" stops it. (Use one or the other, not both.)
  If the folder is in Downloads/Desktop/Documents, Auto-start copies it to your home folder
  (slingoor-tracker) because macOS doesn't let background programs read those folders. After that,
  edit settings.txt in the home-folder copy.
  The Mac must be awake and online for alerts — closing the lid on battery puts it to sleep.

FASTER + MORE RELIABLE (recommended)
  The free public Solana server works but drops the connection now and then. A free Helius key
  (https://dashboard.helius.dev) fixes that: run "1 - Setup" again and paste it, or put it in
  settings.txt as HELIUS_API_KEY=...  The pump.fun feed also watches his trades as a backup, so a
  dropped connection doesn't mean a missed alert — just a few seconds slower.

KEEPS ITSELF RUNNING + UPDATES ITSELF
- Start it with “2 - Start Bot” or “Auto-start ON” (if you used Auto-start before, click Auto-start ON
  again once from this version so the watchdog takes over).
- Crash or freeze → it restarts on its own within seconds and tells you in Telegram.
- Every 10 minutes it checks for a new version (github.com/kabyt36-stack/slingoor-bot). A new version is
  downloaded, checksum-checked, and must pass the full test suite on your Mac before it's installed.
  If it then crashes right after updating, the old version is put back automatically.
- Updates never touch settings.txt, wallet-key.txt or your data.
- /version shows the version, /update checks right now. To turn updates off: AUTO_UPDATE=off in settings.txt.
- Logs: logs/bot.log and logs/supervisor.log

TELEGRAM COMMANDS
  /status     is everything connected
  /meta       the narratives he plays, with examples
  /bags       his biggest current bags
  /recent     the last alerts
  /callouts   his latest callouts and how they're doing
  /check CA   does a coin fit his meta? (or just paste a contract address)
  /test       sample alert
  /id         this chat's id (to add a group: put ids in TELEGRAM_CHAT_ID, comma separated)

SETTINGS (settings.txt — open with TextEdit, restart the bot after changes)
  Turn any alert type on/off, only get entries that match his meta (META_ONLY_ENTRIES=on),
  ignore small buys (MIN_ALERT_SOL), add more of his wallets (TARGET_WALLETS=a,b).
  If the bot is off for a while, trades from the last 10 minutes and callouts from the last 30
  minutes are still sent when it comes back; older ones are skipped so you don't get flooded.

HOW IT WORKS (short)
  - On-chain: listens to the Solana network for transactions that mention his wallet. His wallet gets
    flooded by other people's transactions (spam and people tailing his callouts), so the bot only
    opens a transaction when his own account changed in that block, then reads his exact balance
    change: new entry = he had 0 before, full exit = 0 after. Works for any venue (pump.fun, PumpSwap,
    Jupiter, Axiom/Padre routers).
  - pump.fun: polls his trade feed, callouts, and created coins from pump.fun's own API.
    pump.fun limits how often its callout list can be read, so the bot reads it every 20s and in
    between checks his positions (each one shows his latest callout on that coin). Callouts on coins
    he holds show up within ~5s; on a coin he doesn't hold, within ~20s. If pump.fun blocks the
    list for a while, /status says so and the positions check keeps working.
  SOL amounts are what actually left/entered his wallet, including platform fees, so they can differ
  ~1% from the number pump.fun shows.

FILES
  bot.js, src/        the bot
  settings.txt        your settings
  data/state.json     what it has already alerted (safe to delete to reset)
  data/copytrade.json your open copy-trade positions
  wallet-key.txt      your copy-trading wallet key (only if you ran 3 - Copy Trade Setup) — never share it
  logs/bot.log        log file if something looks off
  test/               automated tests (developer use)
