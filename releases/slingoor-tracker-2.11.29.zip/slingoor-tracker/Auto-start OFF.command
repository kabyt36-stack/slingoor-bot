#!/bin/bash
# Stops the background tracker and turns off auto-start.
LABEL=com.slingoor.tracker
PLIST="$HOME/Library/LaunchAgents/$LABEL.plist"
launchctl bootout "gui/$(id -u)/$LABEL" 2>/dev/null || launchctl unload -w "$PLIST" 2>/dev/null
rm -f "$PLIST"
echo "✅ Auto-start is OFF and the background tracker is stopped."
read -r -p "Press Enter to close"
