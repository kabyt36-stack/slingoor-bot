#!/bin/bash
# Double-click me once. Installs Node.js (into this folder only), asks for your Telegram bot token,
# then tests every connection.
cd "$(dirname "$0")" || exit 1
clear
echo "=========================================="
echo "   slingoor tracker — setup"
echo "=========================================="
echo

# ---------- 1) Node.js ----------
. ./scripts/find-node.sh
if [ -z "$NODE" ]; then
  echo "Getting Node.js 22 (one time, about 50 MB, stays inside this folder)…"
  case "$(uname -m)" in arm64) ARCH=darwin-arm64 ;; *) ARCH=darwin-x64 ;; esac
  BASE="https://nodejs.org/dist/latest-v22.x"
  SUMS="$(curl -fsSL "$BASE/SHASUMS256.txt")" || { echo "❌ Could not reach nodejs.org. Check your internet and try again."; read -r -p "Press Enter to close"; exit 1; }
  FILE="$(echo "$SUMS" | grep -E " node-v[0-9.]+-$ARCH\.tar\.gz$" | awk '{print $2}' | head -1)"
  SUM="$(echo "$SUMS" | grep -E " $FILE$" | awk '{print $1}')"
  mkdir -p runtime
  curl -fL --progress-bar -o runtime/node.tar.gz "$BASE/$FILE" || { echo "❌ Download failed."; read -r -p "Press Enter to close"; exit 1; }
  echo "$SUM  runtime/node.tar.gz" | shasum -a 256 -c - >/dev/null || { echo "❌ Download was corrupted, run setup again."; rm -f runtime/node.tar.gz; read -r -p "Press Enter to close"; exit 1; }
  tar -xzf runtime/node.tar.gz -C runtime && rm -f runtime/node.tar.gz
  rm -rf runtime/node && mv runtime/node-v*-"$ARCH" runtime/node
  NODE="$(pwd)/runtime/node/bin/node"
fi
echo "✅ Node.js $("$NODE" --version)"
echo

# ---------- 2) Telegram bot token ----------
CUR="$("$NODE" scripts/setting.js TELEGRAM_BOT_TOKEN)"
if [ -n "$CUR" ]; then
  echo "A Telegram bot token is already saved (…${CUR: -6})."
  read -r -p "Paste a new token to replace it, or just press Enter to keep it: " TOKEN
else
  echo "In Telegram, open @BotFather → /newbot → pick a name → copy the token it gives you."
  read -r -p "Paste your bot token here: " TOKEN
fi
TOKEN="$(echo "$TOKEN" | tr -d '[:space:]')"
if [ -n "$TOKEN" ]; then
  if [[ "$TOKEN" =~ ^[0-9]{5,}:[A-Za-z0-9_-]{30,}$ ]]; then
    "$NODE" scripts/setting.js TELEGRAM_BOT_TOKEN "$TOKEN"
    echo "✅ Token saved"
  else
    echo "⚠️  That doesn't look like a bot token (it should look like 123456789:AAH...). Not saved."
  fi
fi
echo

# ---------- 3) Optional Helius key ----------
CURH="$("$NODE" scripts/setting.js HELIUS_API_KEY)"
if [ -z "$CURH" ]; then
  echo "Optional: a free Helius key makes alerts faster and more reliable."
  echo "Get one at https://dashboard.helius.dev (sign up → copy the API key)."
  read -r -p "Paste it here, or press Enter to skip: " HK
  HK="$(echo "$HK" | tr -d '[:space:]')"
  if [ -n "$HK" ]; then "$NODE" scripts/setting.js HELIUS_API_KEY "$HK"; echo "✅ Helius key saved"; fi
  echo
fi

# ---------- 4) Test everything ----------
chmod +x ./*.command 2>/dev/null
"$NODE" bot.js --check
echo
echo "Next: double-click “2 - Start Bot”, then open your bot in Telegram and send /start"
echo
read -r -p "Press Enter to close this window"
