#!/bin/bash
# Double-click to run the tracker. Keep this window open (minimize it); close it to stop the bot.
cd "$(dirname "$0")" || exit 1
. ./scripts/find-node.sh
if [ -z "$NODE" ]; then
  echo "Node.js isn't set up yet — double-click “1 - Setup” first."
  read -r -p "Press Enter to close"
  exit 1
fi
if launchctl list 2>/dev/null | grep -q com.slingoor.tracker; then
  echo "The tracker is already running in the background (auto-start is ON)."
  echo "Use “Auto-start OFF” first if you want to run it in this window instead."
  read -r -p "Press Enter to close"
  exit 0
fi
echo "slingoor tracker is running. Keep this window open (you can minimize it)."
echo "Your Mac won't idle-sleep while it runs. Close this window to stop the bot."
echo "If the bot crashes or freezes it restarts by itself, and new versions install themselves"
echo "(each one is tested on this Mac first, and rolled back if it misbehaves)."
echo
while true; do
  caffeinate -is "$NODE" scripts/supervisor.js
  code=$?
  if [ $code -eq 0 ]; then break; fi
  if [ $code -eq 75 ]; then continue; fi   # restart after an update / rollback
  echo "Watchdog stopped unexpectedly (code $code). Restarting in 5 seconds…"
  sleep 5
done
