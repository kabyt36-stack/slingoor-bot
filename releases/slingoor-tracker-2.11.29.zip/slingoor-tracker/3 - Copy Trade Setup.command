#!/bin/bash
# Double-click to turn on copy trading: saves your wallet key on this Mac and sets the buy size.
cd "$(dirname "$0")" || exit 1
clear
echo "=========================================="
echo "   slingoor tracker — copy trading setup"
echo "=========================================="
echo
. ./scripts/find-node.sh
if [ -z "$NODE" ]; then
  echo "Run “1 - Setup” first."
  read -r -p "Press Enter to close"
  exit 1
fi
echo "The bot will trade with the wallet whose private key you paste here."
echo "⚠️  Use a SEPARATE wallet (e.g. make a new one in Phantom) with only the SOL you're OK risking."
echo "    The key is saved only in this folder (wallet-key.txt) and is never sent anywhere —"
echo "    trades are signed right here on your Mac."
echo
echo "Phantom: Settings → your account → Show Private Key → copy."
if [ -f wallet-key.txt ]; then
  read -r -s -p "A key is already saved. Paste a new one to replace it, or press Enter to keep it: " KEY
else
  read -r -s -p "Paste the private key (it stays hidden while you paste), then press Enter: " KEY
fi
echo
KEY="$(echo "$KEY" | tr -d '[:space:]')"
if [ -n "$KEY" ]; then
  if ADDR="$(KEY="$KEY" "$NODE" --input-type=module -e "import { loadKeypair } from './src/solana.js'; console.log(loadKeypair(process.env.KEY).publicKey)" 2>&1)"; then
    (umask 077; printf '%s\n' "$KEY" > wallet-key.txt)
    chmod 600 wallet-key.txt
    echo "✅ Key saved. Wallet: $ADDR"
  else
    echo "❌ That key didn't work: ${ADDR##*Error: }"
    read -r -p "Press Enter to close"
    exit 1
  fi
fi
unset KEY
echo
CUR="$("$NODE" scripts/setting.js COPY_MAX_BUY_SOL)"
echo "Buys scale with his: he buys 1 SOL -> you buy 0.5, he buys 1000 -> you buy the max."
read -r -p "Most SOL to spend on one buy [${CUR:-1}]: " AMT
AMT="$(echo "$AMT" | tr -d '[:space:]')"
if [ -n "$AMT" ]; then
  if [[ "$AMT" =~ ^[0-9]*\.?[0-9]+$ ]]; then "$NODE" scripts/setting.js COPY_MAX_BUY_SOL "$AMT"; else echo "⚠️  Not a number, keeping ${CUR:-1}"; fi
fi
"$NODE" scripts/setting.js COPY_TRADE on
echo
echo "Copy trading is ON: buys when he buys (scaled to his size, max 20% of your wallet per buy),"
echo "sells when he sells, quick profit on his big buys, 25% at 2x — never sells out on profit."
echo "(Change any of this in settings.txt under COPY TRADING.)"
"$NODE" bot.js --check
echo
echo "Restart the bot (close the “2 - Start Bot” window and open it again, or Auto-start OFF then ON)."
echo "In Telegram: /copy shows your positions, /pause stops new buys."
echo
read -r -p "Press Enter to close this window"
