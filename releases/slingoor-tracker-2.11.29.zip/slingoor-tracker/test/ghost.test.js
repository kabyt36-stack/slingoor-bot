import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { GhostBook } from '../src/ghost.js';

const file = () => path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'gh-')), 'g.json');
const near = (a, b, e = 1e-6) => assert.ok(Math.abs(a - b) < e, `${a} vs ${b}`);

test('ghosts: side style sells all at +25%; main style rides; fees and our delay are counted', () => {
  let now = 1_000_000;
  const g = new GhostBook({ file: file(), now: () => now, fee: 0.0005, entryPenaltyPct: 5, rulesFor: () => ({}) });
  assert.equal(g.open('dilly', 'M1', 1e-7), true);
  assert.equal(g.open('dilly', 'M1', 1e-7), false, 'one buy per coin');
  const entry = 1.05e-7;
  now += 30000;
  g.price('M1', entry * 1.3); // +30% vs our (late) entry
  const sides = g.d.closed.filter((c) => c.style !== 'main');
  assert.deepEqual(sides.map((c) => c.style).sort(), ['W2', 'W3', 'W4'], 'three side wallets');
  for (const side of sides) {
    near(side.pnl, 0.05 * (1.3 / 1.02) - 0.0005 - (0.05 + 0.0005)); // they bought 2% later than the main
    assert.equal(side.why, '+25%');
  }
  assert.ok(Object.values(g.d.open).some((x) => x.style === 'main'), 'main still holding');
  // he sells everything: main sells at the last price
  g.hisSell('dilly', 'M1', 100, true);
  const main = g.d.closed.find((c) => c.style === 'main');
  near(main.pnl, 0.1 * 1.3 - 0.0005 - (0.1 + 0.0005));
  assert.equal(main.why, 'his exit');
  assert.equal(g.open('dilly', 'M1', 1e-7), false, 'no second buy after closing');
});

test('ghosts: stop loss -20% (two low prices in a row, after 60s), his partial sells, report ranks traders', () => {
  let now = 2_000_000;
  const g = new GhostBook({ file: file(), now: () => now, fee: 0, entryPenaltyPct: 0 });
  g.open('bot', 'L1', 1);
  now += 10000;
  g.price('L1', 0.7);
  g.price('L1', 0.7);
  assert.equal(g.d.closed.length, 0, 'not in the first 60s');
  now += 60000;
  g.price('L1', 0.7);
  assert.equal(g.d.closed.length, 0, 'first low check waits');
  g.price('L1', 0.7);
  assert.equal(g.d.closed.filter((c) => !['t15', 't2', 'trail', 'xb'].includes(c.style)).length, 4, 'all four wallets stopped out');
  assert.ok(g.d.closed.every((c) => c.why === 'stop loss'));
  // schoen: he sells half -> main sells half, side sells all
  g.open('schoen', 'W1', 1);
  now += 5000;
  g.price('W1', 1.2);
  g.hisSell('schoen', 'W1', 50, false);
  assert.equal(g.d.closed.filter((c) => c.trader === 'schoen' && c.style !== 'main' && c.why === 'he sold').length, 3);
  const m = Object.values(g.d.open).find((x) => x.trader === 'schoen');
  near(m.left, 0.5);
  g.hisSell('schoen', 'W1', 5, false); // tiny sells are ignored, like the real bot
  near(m.left, 0.5);
  g.price('W1', 2);
  g.hisSell('schoen', 'W1', 100, true);
  const r = g.report();
  // sides bought at 1.02: 0.05 x 1.2/1.02 = 0.0588 each -> +0.0088 x 3 = +0.026
  assert.match(r, /🟢 <b>schoen<\/b>: set \+0\.086 · main \+0\.060 \(1\/1\) · 3 sides \+0\.026 \(3\/3\) → best: main/);
  assert.match(r, /🔴 <b>bot<\/b>: set -0\.07\d · main -0\.030 \(0\/1\) · 3 sides -0\.04\d \(0\/3\)/);
  assert.ok(r.indexOf('schoen') < r.indexOf('bot'), 'best trader first');
  // survives a restart, reset clears
  g.save(true);
  assert.equal(new GhostBook({ file: g.file }).d.closed.length, 16, '8 + their 8 test exits');
  g.reset();
  assert.match(g.report(), /nothing yet/);
});

test('V2.9.11 a buy without a price (coins already on PumpSwap / Raydium) still opens the ghosts: they buy at the first price seen', () => {
  let now = 3_000_000;
  const g = new GhostBook({ file: file(), now: () => now, fee: 0, entryPenaltyPct: 5 });
  assert.equal(g.open('dilly', 'AMM1', null), true);
  assert.equal(Object.values(g.d.open).filter((x) => !['t15', 't2', 'trail', 'xb'].includes(x.style)).length, 4);
  g.hisSell('dilly', 'AMM1', 50, false); // no price yet: nothing happens
  assert.equal(g.d.closed.length, 0);
  now += 15000;
  g.price('AMM1', 2); // first price: the buy
  const m = Object.values(g.d.open).find((x) => x.style === 'main');
  near(m.entry, 2);
  near(Object.values(g.d.open).find((x) => x.style === 'W2').entry, 2.04, 1e-9);
  g.price('AMM1', 2.6); // sides: +27% -> sold
  assert.equal(g.d.closed.filter((c) => c.style !== 'main').length, 3);
  assert.match(g.report(), /<b>dilly<\/b>: set \+/);
});

test('V2.9.12 market-cap ranges: each trader\'s pretend wallets by market cap; sweet spot skips a range only after 8+ coins lost there', async () => {
  const { bandOf } = await import('../src/ghost.js');
  assert.equal(bandOf(8000), '<$10k');
  assert.equal(bandOf(45000), '$30-100k');
  assert.equal(bandOf(null), null);
  let now = 4_000_000;
  const g = new GhostBook({ file: file(), now: () => now, fee: 0, entryPenaltyPct: 0, solUsd: () => 100 });
  // price 1e-7 SOL x 1B x $100 = $10k... use 5e-8 -> $5k (under $10k) and 4e-7 -> $40k
  for (let i = 0; i < 9; i++) {
    g.open('dilly', `LOW${i}`, 5e-8);
    now += 61000;
    g.price(`LOW${i}`, 3e-8);
    g.price(`LOW${i}`, 3e-8); // -40%: stopped out
    g.open('dilly', `MID${i}`, 4e-7);
    g.price(`MID${i}`, 4e-7 * 1.5);
    g.hisSell('dilly', `MID${i}`, 100, true);
  }
  const bs = g.bandStats('dilly');
  assert.equal(bs['<$10k'].coins, 9);
  assert.ok(bs['<$10k'].pnl < 0);
  assert.equal(bs['$30-100k'].coins, 9);
  assert.equal(bs['$30-100k'].won, 9);
  assert.equal(g.allowed('dilly', 6000), false, 'low caps lost money: skipped');
  assert.equal(g.allowed('dilly', 50000), true, 'his good range: copied');
  assert.equal(g.allowed('dilly', 200000), true, 'no data there yet: copied');
  assert.equal(g.allowed('schoen', 6000), true, 'another trader: his own ranges');
  assert.equal(g.allowed('dilly', null), true, 'no market cap: copied');
  const t = g.sweetSpotText(['dilly', 'schoen']);
  assert.match(t, /<b>dilly<\/b>: ⛔ <\$10k -[\d.]+ \(0\/9\) · ✅ \$30-100k \+[\d.]+ \(9\/9\)/);
  assert.doesNotMatch(t, /schoen/, 'no data, no line');
  assert.match(g.report(), /📊 MC: \$30-100k \+[\d.]+ \(9\/9\) · <\$10k -/);
});

test('V2.11 test exits: same coins sold other ways (1.5x, 2x, ride the top, before him), not in the 4-wallet totals', () => {
  let now = 1_000_000;
  const g = new GhostBook({ file: file(), now: () => now, fee: 0, entryPenaltyPct: 0, stopLossX: 0.5 });
  g.open('dilly', 'A', 1);
  assert.equal(Object.keys(g.d.open).length, 8, '4 wallets + 4 test exits');
  const tick = (px) => {
    now += 1000;
    g.price('A', px);
  };
  tick(1.6); // t15 sells all, sides sell (+25%)
  tick(1.2); // trail (armed at 1.3, top 1.6, 20% off = 1.28) sells
  g.hisSell('dilly', 'A', 100, true); // he's out at 1.2: main + t2 + xb sell
  const by = Object.fromEntries(g.d.closed.map((c) => [c.style, c]));
  assert.ok(Math.abs(by.t15.pnl - 0.05 * 0.6) < 1e-6);
  assert.ok(Math.abs(by.trail.pnl - 0.05 * 0.2) < 1e-6);
  assert.ok(Math.abs(by.t2.pnl - 0.05 * 0.2) < 1e-6);
  const lt = g.lastTrades('dilly', 30);
  const fourWallets = by.main.pnl + by.W2.pnl + by.W3.pnl + by.W4.pnl;
  assert.ok(Math.abs(lt.pnl - fourWallets) < 1e-6, 'rotation only counts your 4 wallets');
  assert.equal(g.stats().dilly.side.n, 3);
});

test('V2.11 sell before him: learns where he usually sells his winners; test exit sells half just before it', () => {
  let now = 1_000_000;
  const g = new GhostBook({ file: file(), now: () => now, fee: 0, entryPenaltyPct: 5 });
  assert.equal(g.beforeX('dilly'), null, 'no data yet');
  for (let i = 0; i < 8; i++) {
    g.open('dilly', `M${i}`, 1);
    now += 1000;
    g.price(`M${i}`, 2);
    g.hisSell('dilly', `M${i}`, 100, true);
  }
  assert.equal(g.typicalExit('dilly'), 2);
  assert.equal(g.beforeX('dilly'), 1.71, '90% of the way to 2x, from our buy (5% above his)');
  g.open('dilly', 'N', 1);
  const xb = g.d.open['dilly|xb|N'];
  assert.equal(xb.beforeX, 1.71);
  now += 1000;
  g.price('N', 1.05 * 1.75);
  assert.equal(g.d.open['dilly|xb|N'].left, 0.5, 'half sold just before his usual exit');
});

test('V2.11 exit pick: picks the exit that made the most on his last coins (15+), only when it clearly beats yours', () => {
  let now = 1_000_000;
  const g = new GhostBook({ file: file(), now: () => now, fee: 0, entryPenaltyPct: 0, stopLossX: 0.5 });
  // he lets his winners run to 1.6x and round-trip: he sells at 0.9x
  for (let i = 0; i < 16; i++) {
    g.open('dilly', `C${i}`, 1);
    now += 1000;
    g.price(`C${i}`, 1.6);
    now += 1000;
    g.price(`C${i}`, 0.9);
    g.hisSell('dilly', `C${i}`, 100, true);
  }
  const m = g.exitPick('dilly', 'main');
  assert.equal(m.best, 't15');
  assert.deepEqual(m.rule, { miniFromX: 1.5, miniToX: 1.5, miniPullbackPct: 1, miniPct: 100, exitStyle: 't15' });
  assert.ok(m.rets.t15.ret > 0.4 && m.rets.t15.vs < 0);
  const s = g.exitPick('dilly', 'side');
  assert.equal(s.best, 't15', 'sides: 1.5x beats +25%');
  assert.equal(g.exitPick('dilly', 'main', { minCoins: 20 }).rule, null, 'not enough coins: keep the normal sells');
  assert.match(g.report(), /🎯 best exit: sell all at 1\.5x/);
});

test('V2.11 his big bets / small test buys, and his best hours', () => {
  let now = new Date(2026, 10, 12, 3, 10).getTime();
  const g = new GhostBook({ file: file(), now: () => now, fee: 0, entryPenaltyPct: 0, stopLossX: 0.5 });
  for (let i = 0; i < 9; i++) g.noteSize('dilly', 1);
  assert.equal(g.betKind('dilly', 5), null, 'under 10 buys: no idea yet');
  g.noteSize('dilly', 1);
  assert.equal(g.betKind('dilly', 2.5), 'big');
  assert.equal(g.betKind('dilly', 0.3), 'small');
  assert.equal(g.betKind('dilly', 1.2), null);
  // 8 losing coins bought at 3am
  for (let i = 0; i < 8; i++) {
    g.open('dilly', `L${i}`, 1);
    now += 1000;
    g.price(`L${i}`, 0.9);
    g.hisSell('dilly', `L${i}`, 100, true);
  }
  assert.equal(g.hourAllowed('dilly', now), false, '3am lost money');
  assert.equal(g.hourAllowed('dilly', new Date(2026, 10, 12, 14).getTime()), true, 'other hours: copied');
  assert.equal(g.hourAllowed('schoen', now), true);
  assert.match(g.report(), /⏰ not copied at: 3am/);
});

test('V2.11.6 all-time PnL per trader (your 4 pretend wallets; test exits not counted; never trimmed)', () => {
  let now = 1_000_000;
  const g = new GhostBook({ file: file(), now: () => now, fee: 0, entryPenaltyPct: 0 });
  g.open('t5', 'A', 1);
  now += 1000;
  g.price('A', 2);
  g.hisSell('t5', 'A', 100, true);
  // main 0.1 -> +0.1, sides sold at +25%: entry 1.02, sold at 2 -> 0.05 x (2/1.02 - 1) each
  const want = 0.1 + 3 * 0.05 * (2 / 1.02 - 1);
  assert.ok(Math.abs(g.lifePnl('t5') - want) < 1e-5, `${g.lifePnl('t5')}`);
  g.d.closed = [];
  assert.ok(Math.abs(g.lifePnl('t5') - want) < 1e-5, 'kept when old coins are trimmed');
  assert.equal(g.lifePnl('t6'), 0);
});

test('V2.11.8 sweet spot adapts: judged on his last 30 coins in a range, so a range that starts winning is copied again', () => {
  let now = 1_000_000;
  const g = new GhostBook({ file: file(), now: () => now, fee: 0, entryPenaltyPct: 0, solUsd: () => 100, stopLossX: 0.5 });
  const px = 2e-7; // x 1e9 x $100 = $20k: the $10-30k range
  const coin = (i, exit) => {
    g.open('dilly', `K${i}`, px);
    now += 1000;
    g.price(`K${i}`, px * exit);
    g.hisSell('dilly', `K${i}`, 100, true);
  };
  for (let i = 0; i < 30; i++) coin(i, 0.9);
  assert.equal(g.allowed('dilly', 20000), false, 'losing range: skipped');
  assert.equal(g.allowed('dilly', 200000), true, 'no data in that range: copied');
  for (let i = 30; i < 60; i++) coin(i, 1.2);
  assert.equal(g.allowed('dilly', 20000), true, 'his last 30 there won: copied again');
  assert.ok(g.bandStats('dilly')['$10-30k'].coins === 60 && g.recentBandStats('dilly')['$10-30k'].coins === 30);
});

test('V2.11.16 runners: each wallet\'s share of coins that ran 2x+; chance for a coin from every wallet in it; learns from what happened', () => {
  let now = 1_000_000;
  const g = new GhostBook({ file: file(), now: () => now, fee: 0, entryPenaltyPct: 0, stopLossX: 0.3, afterMs: 0 }); // judged right when he sells (the 6h after-window is tested below)
  const coin = (trader, mint, peak) => {
    g.open(trader, mint, 1);
    now += 1000;
    g.price(mint, peak);
    now += 1000;
    g.price(mint, 1);
    g.hisSell(trader, mint, 100, true);
  };
  // ace: 6 of 10 coins ran; dud: 0 of 40; mid: 4 of 20
  for (let i = 0; i < 10; i++) coin('ace', `A${i}`, i < 6 ? 3 : 1.2);
  for (let i = 0; i < 40; i++) coin('dud', `D${i}`, 1.1);
  for (let i = 0; i < 20; i++) coin('mid', `M${i}`, i < 4 ? 2.5 : 1.3);
  assert.deepEqual(g.runnerStats('ace'), { coins: 10, runners: 6 });
  const b = g.baseRate();
  assert.equal(b.coins, 70);
  assert.ok(Math.abs(b.rate - 10 / 70) < 1e-9);
  // ace's rate is pulled a little toward the average (he has only 10 coins)
  assert.ok(Math.abs(g.walletRate('ace') - (6 + 5 * b.rate) / 15) < 1e-9);
  // dud buys a coin ace already holds: ace makes it likely to run
  g.open('ace', 'NEW', 1);
  const rc = g.runnerChance('NEW', 'dud');
  assert.deepEqual(rc.traders.sort(), ['ace', 'dud']);
  assert.equal(rc.k, 2);
  assert.ok(rc.ready && !rc.calibrated);
  const ra = g.walletRate('ace');
  const rd = g.walletRate('dud');
  assert.ok(Math.abs(rc.raw - (1 - (1 - ra) * (1 - rd))) < 1e-9);
  assert.ok(rc.pct >= 2 * rc.base, 'ace in the coin: well above the usual');
  assert.ok(g.runnerChance('X', 'dud').pct <= 0.5 * rc.base, 'dud alone: well below');
  // calibration: 15 coins where the bot predicted ~40% with 2 wallets in, and none ran -> now it says 0%
  for (let i = 0; i < 15; i++) {
    g.notePred(`C${i}`, 0.42, 2);
    coin('mid', `C${i}`, 1.1);
  }
  assert.equal(g.d.calib.length, 15);
  assert.ok(g.d.calib.every((c) => c.k === 2 && !c.r));
  const fake = g.runnerChance('Y', 'mid');
  assert.equal(fake.k, 1, 'one wallet: other bucket, not calibrated yet');
  // past coins like NEW (2 wallets, same raw chance): 3 of 15 ran -> it says 20%, not the raw guess
  for (let i = 0; i < 15; i++) g.d.calib.push({ s: rc.raw, k: 2, r: i < 3 });
  const again = g.runnerChance('NEW', 'dud');
  assert.ok(again.calibrated);
  const same = g.d.calib.filter((c) => c.k === 2 && Math.floor(c.s * 10) === Math.floor(rc.raw * 10));
  assert.equal(again.pct, same.filter((c) => c.r).length / same.length, 'what really happened to coins like it');
  assert.ok(again.pct < rc.raw, 'lower than the raw guess');
});

test('V2.11.18 runner chance you set (kimchi 99%): any coin he is in counts as a runner, even with no data yet', () => {
  const g = new GhostBook({ file: file(), fee: 0, entryPenaltyPct: 0, runnerForce: { kimchi: 0.99 } });
  assert.equal(g.walletRate('kimchi'), 0.99);
  const alone = g.runnerChance('C1', 'kimchi');
  assert.ok(alone.ready && alone.forced.length === 1 && alone.pct >= 0.99);
  g.open('kimchi', 'C2', 1);
  const withHim = g.runnerChance('C2', 'dilly');
  assert.ok(withHim.pct >= 0.99, 'dilly buys a coin kimchi holds');
  assert.equal(g.runnerChance('C3', 'dilly').forced.length, 0);
});

test('V2.11.19 a coin that runs after he sold still counts as his runner (6h from his buy); the bot learns it then', () => {
  let now = 1_000_000;
  const g = new GhostBook({ file: file(), now: () => now, fee: 0, entryPenaltyPct: 0, stopLossX: 0.3 });
  g.notePred('UWU', 0.1, 1);
  g.open('t25', 'UWU', 1);
  now += 60000;
  g.price('UWU', 0.9);
  g.hisSell('t25', 'UWU', 100, true); // he sold at a loss
  assert.deepEqual(g.runnerStats('t25'), { coins: 1, runners: 0 });
  assert.ok(g.watching().includes('UWU'), 'still watched after he sold');
  assert.equal(g.d.calib?.length || 0, 0, 'not judged yet');
  now += 3600000;
  g.price('UWU', 40); // the coin ran
  assert.deepEqual(g.runnerStats('t25'), { coins: 1, runners: 1 }, 'he picked a runner');
  now += 6 * 3600000;
  assert.ok(!g.watching().includes('UWU'), 'window over');
  assert.deepEqual(g.d.calib, [{ s: 0.1, k: 1, r: true }], 'learned: that coin ran');
});

test('V2.11.21 pretend side wallets sell like the real ones: armed at +50%, all out at 2x or a 10% pullback', () => {
  let now = 1_000_000;
  const g = new GhostBook({ file: file(), now: () => now, fee: 0, entryPenaltyPct: 0, stopLossX: 0.3, sideRule: { from: 1.5, to: 2, pull: 10 } });
  g.open('t3', 'A', 1);
  const tick = (px) => {
    now += 1000;
    g.price('A', px);
  };
  tick(1.3); // the old +25%: no sell now
  assert.equal(g.d.closed.filter((c) => ['W2', 'W3', 'W4'].includes(c.style)).length, 0);
  tick(1.8); // armed (side entry 1.02 -> 1.76x)
  tick(1.55); // 12% off the top: sold
  const sides = g.d.closed.filter((c) => ['W2', 'W3', 'W4'].includes(c.style));
  assert.equal(sides.length, 3);
  assert.ok(sides.every((c) => c.why === 'side profit' && c.pnl > 0));
});

test('V2.11.22 median hold: how long he usually keeps a coin (his own sells, 10+)', () => {
  let now = 1_000_000;
  const g = new GhostBook({ file: file(), now: () => now, fee: 0, entryPenaltyPct: 0, afterMs: 0 });
  for (let i = 0; i < 11; i++) {
    g.open('dilly', `S${i}`, 1);
    now += 8000;
    g.price(`S${i}`, 1.01);
    g.hisSell('dilly', `S${i}`, 100, true);
  }
  assert.equal(g.medianHoldMs('dilly'), 8000);
  assert.equal(g.medianHoldMs('t3'), null, 'no data');
});
