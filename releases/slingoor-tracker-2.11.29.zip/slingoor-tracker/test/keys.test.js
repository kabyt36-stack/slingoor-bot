import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import { KeyPool, isOutOfCredits } from '../src/keys.js';
import { Rpc } from '../src/rpc.js';

test('key pool: main key first, backup when it runs out, back to main after it rests', () => {
  let t = 0;
  const p = new KeyPool(['MAIN', 'B1', 'B2'], { deadMs: 1000, now: () => t });
  assert.equal(p.current(), 'MAIN');
  p.markDead('MAIN');
  assert.equal(p.current(), 'B1');
  p.markDead('B1');
  assert.equal(p.current(), 'B2');
  t = 1500;
  assert.equal(p.current(), 'MAIN', 'main key is tried again after resting');
  assert.match(p.wsUrl(), /^wss:\/\/mainnet\.helius-rpc\.com\/\?api-key=MAIN$/);
});

test('out-of-credits errors are told apart from normal rate limits', () => {
  assert.ok(isOutOfCredits({ status: 429, message: 'HTTP 429: max usage reached' }));
  assert.ok(isOutOfCredits({ status: 401, message: 'unauthorized' }));
  assert.ok(!isOutOfCredits({ status: 429, message: 'rate limited' }), 'plain per-second rate limit: keep the key');
});

test('Rpc switches to a backup key when the main key is out of credits, and the call still succeeds', async () => {
  const seen = [];
  const srv = http.createServer((req, res) => {
    const key = new URL(req.url, 'http://x').searchParams.get('api-key');
    seen.push(key);
    if (key === 'MAIN') {
      res.statusCode = 429;
      return res.end('{"jsonrpc":"2.0","error":{"code":-32429,"message":"max usage reached"}}');
    }
    res.end('{"jsonrpc":"2.0","id":1,"result":123}');
  });
  await new Promise((r) => srv.listen(0, '127.0.0.1', r));
  const port = srv.address().port;
  try {
    const pool = new KeyPool(['MAIN', 'BACKUP1']);
    pool.rpcUrl = () => `http://127.0.0.1:${port}/?api-key=${pool.current()}`;
    const rpc = new Rpc('unused', { minGapMs: 0, pool });
    assert.equal(await rpc.call('getSlot', []), 123);
    assert.deepEqual(seen, ['MAIN', 'BACKUP1']);
    assert.equal(pool.current(), 'BACKUP1');
  } finally {
    srv.close();
  }
});
