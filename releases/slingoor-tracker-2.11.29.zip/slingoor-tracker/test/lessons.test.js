import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { Lessons } from '../src/lessons.js';

const tmp = () => path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'lessons-')), 'l.json');

test('V2.11.29 lessons: finds who lost the paper money and why; benches them 24h, then twice as long', () => {
  let t = 1e12;
  const trips = [
    { leader: 'dilly', pnl: -0.09, x: 0.1 },
    { leader: 'dilly', pnl: -0.095, x: 0.05 },
    { leader: 'dilly', pnl: 0.02, x: 1.2 },
    { leader: 'late', pnl: -0.02, x: 0.8, buyMc: 90000 },
    { leader: 'late', pnl: -0.025, x: 0.75, buyMc: 120000 },
    { leader: 'good', pnl: 0.1, x: 2 },
    { leader: 'good', pnl: -0.01, x: 0.9 },
    { leader: 'once', pnl: -0.08, x: 0.2 },
  ];
  const losers = Lessons.losers(trips);
  assert.deepEqual(losers.map((r) => r.name), ['dilly', 'late'], 'red, 2+ coins, 0.02+ lost; worst first');
  assert.match(losers[0].why, /2 of 3 went to zero/);
  assert.match(losers[1].why, /bought late \(around \$\d+k/);
  const f = tmp();
  const l = new Lessons({ file: f, now: () => t });
  const b = l.bench(losers, { exempt: ['late'] });
  assert.deepEqual(b.map((r) => [r.name, r.hours]), [['dilly', 24]], 'exempt (always copied) is not benched');
  assert.match(l.benched('dilly'), /benched 24h more: paper lost 0\.165 SOL on him \(2 of 3 went to zero/);
  assert.equal(l.benched('good'), null);
  t += 25 * 3600000;
  assert.equal(l.benched('dilly'), null, 'free again after 24h');
  const l2 = new Lessons({ file: f, now: () => t });
  assert.equal(l2.bench(losers.slice(0, 1))[0].hours, 48, 'benched again -> twice as long (kept across restarts)');
  assert.match(l2.benched('dilly'), /48h more/);
});
