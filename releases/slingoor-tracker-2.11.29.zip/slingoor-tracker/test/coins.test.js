// Coin name lookups when pump.fun and DexScreener don't know the coin: Helius getAsset.
import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import { Coins } from '../src/coins.js';

test('coins: falls back to Helius getAsset for a brand-new coin, keeps a curve market cap hint', async () => {
  const calls = [];
  const srv = http.createServer(async (req, res) => {
    let body = '';
    for await (const c of req) body += c;
    calls.push(req.url);
    res.setHeader('content-type', 'application/json');
    if (req.url.startsWith('/dex/')) return res.end(JSON.stringify({ pairs: [] }));
    const r = JSON.parse(body);
    assert.equal(r.method, 'getAsset');
    res.end(JSON.stringify({ jsonrpc: '2.0', id: r.id, result: { content: { metadata: { name: 'Fresh Coin', symbol: 'FRSH' }, links: { image: 'https://img/x.png' } }, token_info: { supply: 1e15, decimals: 6 } } }));
  });
  await new Promise((r) => srv.listen(0, '127.0.0.1', r));
  const base = `http://127.0.0.1:${srv.address().port}`;
  try {
    const pump = { getCoin: async () => { const e = new Error('HTTP 403 Just a moment'); e.status = 403; throw e; } };
    const coins = new Coins({ pump, dexApi: `${base}/dex`, rpcUrl: 'https://mainnet.helius-rpc.com/?api-key=x' });
    coins.dasUrl = `${base}/rpc`; // point the Helius lookup at the local server
    const c = await coins.get('Fresh1111111111111111111111111111111111pump', { hint: { mc: 7500, mcAt: Date.now() } });
    assert.equal(c.name, 'Fresh Coin');
    assert.equal(c.symbol, 'FRSH');
    assert.equal(c.image, 'https://img/x.png');
    assert.equal(c.mc, 7500, 'curve market cap from his trade is kept');
    assert.ok(calls.some((u) => u === '/rpc'));
    // not a Helius RPC -> no getAsset calls
    const c2 = new Coins({ pump, dexApi: `${base}/dex`, rpcUrl: 'https://api.mainnet-beta.solana.com' });
    assert.equal(c2.dasUrl, '');
  } finally {
    srv.close();
  }
});

test('coins: price batch also records trading activity (trades, volume, buys vs sells) for dead-coin checks', async () => {
  const srv = http.createServer((req, res) => {
    res.setHeader('content-type', 'application/json');
    res.end(JSON.stringify({ pairs: [
      { baseToken: { address: 'AAA' }, quoteToken: { address: 'So11111111111111111111111111111111111111112' }, priceNative: '0.000001', liquidity: { usd: 5000 }, txns: { m5: { buys: 2, sells: 5 }, h1: { buys: 30, sells: 70 } }, volume: { m5: 120, h1: 9000 } },
      { baseToken: { address: 'AAA' }, quoteToken: { address: 'So11111111111111111111111111111111111111112' }, priceNative: '0.000002', liquidity: { usd: 10 }, txns: { m5: { buys: 99, sells: 0 } }, volume: { m5: 99999 } },
    ] }));
  });
  await new Promise((r) => srv.listen(0, '127.0.0.1', r));
  try {
    const coins = new Coins({ pump: {}, dexApi: `http://127.0.0.1:${srv.address().port}` });
    const px = await coins.pricesSol(['AAA'], 100);
    assert.equal(px.AAA, 0.000001, 'deepest pool wins');
    const a = coins.activity.get('AAA');
    assert.deepEqual({ ...a, at: 0 }, { at: 0, buysM5: 2, sellsM5: 5, buysH1: 30, sellsH1: 70, volM5: 120, volH1: 9000, liq: 5000 });
  } finally {
    srv.close();
  }
});
