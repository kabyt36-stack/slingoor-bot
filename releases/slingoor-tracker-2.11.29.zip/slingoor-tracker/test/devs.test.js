import test from 'node:test';
import assert from 'node:assert/strict';
import { DevWatcher, parseDevs } from '../src/devs.js';
import { isAddress } from '../src/util.js';

const W = '5hAgYC8TJCcEZV7LTXAzkTrm7YL29YXyQQJPCNrG84zM';

test('DEVS setting: name:wallet:mode', () => {
  assert.deepEqual(parseDevs(`pat:${W}:instant, nig:${W}:dip`, isAddress), [
    { name: 'pat', wallet: W, mode: 'instant' },
    { name: 'nig', wallet: W, mode: 'dip' },
  ]);
  assert.throws(() => parseDevs(`x:${W}:yolo`, isAddress), /unknown mode/);
  assert.equal(parseDevs(`r:${W}:rug`, isAddress)[0].mode, 'rug');
  assert.throws(() => parseDevs('x:notawallet:dip', isAddress), /invalid wallet/);
});

function watcher(prices, holders = () => 0, cfg = {}) {
  let now = 0;
  const ready = [];
  const w = new DevWatcher({ rpc: {}, countHolders: async () => holders(), onReady: (s) => ready.push(s), cfg, now: () => now, everyMs: 1e9 });
  let i = 0;
  w.priceOf = async () => prices[Math.min(i++, prices.length - 1)];
  return { w, ready, setNow: (t) => (now = t) };
}
const sig = { ev: { mint: 'M1', wallet: W }, kind: 'ENTRY' };

test('dip dev (nig / ya): buys only after the price falls 20% from its high', async () => {
  const { w, ready } = watcher([1, 1.2, 1.0, 0.95]);
  w.watch(sig, { name: 'nig', mode: 'dip' });
  for (let k = 0; k < 3; k++) await w.tick();
  assert.equal(ready.length, 0, '1.0 is only 17% under the 1.2 high');
  await w.tick();
  assert.equal(ready.length, 1, '0.95 is 21% under -> buy');
  assert.equal(ready[0].devReady, true);
  w.stop();
});

test('momentum dev (claudia): buys at 40+ holders AND price up 30% from launch', async () => {
  let h = 10;
  const { w, ready } = watcher([1, 1.35, 1.4, 1.45], () => h);
  w.watch(sig, { name: 'claudia', mode: 'momentum' });
  await w.tick();
  await w.tick();
  assert.equal(ready.length, 0, 'up 35% but only 10 holders');
  h = 45;
  await w.tick();
  assert.equal(ready.length, 1);
  w.stop();
});

test('dev watcher gives up after the watch window', async () => {
  const { w, ready, setNow } = watcher([1, 1, 1]);
  w.watch(sig, { name: 'nig', mode: 'dip' });
  await w.tick();
  setNow(21 * 60000);
  await w.tick();
  assert.equal(ready.length, 0);
  assert.equal(w.w.size, 0);
});
