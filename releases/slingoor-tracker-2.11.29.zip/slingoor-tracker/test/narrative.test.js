import test from 'node:test';
import assert from 'node:assert/strict';
import { classify, isBackronym, MetaProfile } from '../src/narrative.js';
import { realCoins } from './helpers.js';

const d = realCoins();

test('his real "Big Titty Coin" style bags are recognised', () => {
  const formula = [
    ['BTC', 'Big Titty Coin'], ['LTC', 'Little Titty Coin'], ['ETH', 'Extra Thick Hoe'], ['XRP', 'Xtra Ripe Peaches'],
    ['BNB', 'Big Natural Boobs'], ['XBT', 'Xtremely Big Titties'], ['SOL', 'Sweet Onchain Lady'], ['XMR', 'Extra Massive Rear'],
    ['TAO', 'Tight and Orgasmic'], ['AMD', 'Always Moist Downstairs'], ['ETF', 'Enormous Titty Faucet'], ['CPU', 'Cum Processing Unit'],
    ['GLD', 'Giant Love Dumplings'], ['NVDA', 'Nut Vigorously In Dat Ass'], ['MON', 'Milkers or Nothing'], ['AAPL', 'Ass And Pussy Lovers'],
  ];
  for (const [s, n] of formula) assert.equal(classify({ name: n, symbol: s }).bigTittyMeta, true, `${s} ${n}`);
});

test('normal coin names are not flagged', () => {
  for (const [s, n] of [['PB', 'Peanut Butter'], ['PLUMBER', 'Plumber'], ['CHATCAT', 'Chat Cat'], ['ABTC', 'Anime Bitcoin'], ['WIF', 'dogwifhat']]) {
    assert.equal(classify({ name: n, symbol: s }).bigTittyMeta, false, `${s} ${n}`);
  }
  assert.equal(isBackronym('Plumber', 'PLUMBER'), false);
  assert.equal(isBackronym('Big Titty Coin', 'BTCX'), false);
});

test('meta profile built from his real coins ranks the ticker-backronym meta first', () => {
  const p = new MetaProfile();
  let i = 0;
  for (const [s, n, v] of d.holdings) p.add({ mint: 'H' + i++, name: n, symbol: s, valueUsd: v }, 1 + Math.log10(1 + v / 1000), 'bag');
  for (const [s, n] of d.callouts) p.add({ mint: 'C' + i++, name: n, symbol: s }, 1, 'callout');
  const top = p.topTags(4).map((t) => t.tag);
  assert.deepEqual(top.slice(0, 2).sort(), ['backronym', 'ticker']);
  assert.ok(top.includes('nsfw'));

  const hit = p.match({ name: 'Massive Sweaty Titties Rising', symbol: 'MSTR' });
  assert.equal(hit.level, 3);
  assert.ok(hit.similar.some((c) => /Titt/.test(c.name)), 'should point at his titty coins');

  const miss = p.match({ name: 'Space Laser', symbol: 'SPLZ' });
  assert.ok(miss.level <= 1, `level ${miss.level}`);
  assert.equal(p.match({ name: 'Peanut Butter', symbol: 'PB' }).level, 0);
  // a copy of a coin he already called counts as his meta
  assert.equal(p.match({ name: 'Chat Cat', symbol: 'MEOW', mint: 'copy' }).level, 2);
});

test('a coin from the same series as his past plays is a meta match ("Cute Crypto ___")', () => {
  const p = new MetaProfile();
  p.add({ mint: 'a', name: 'Cute Crypto Carrot', symbol: 'CCC' }, 2, 'bag');
  p.add({ mint: 'b', name: 'Cute Crypto Bottom', symbol: 'CCB' }, 1, 'callout');
  p.add({ mint: 'c', name: 'Big Titty Coin', symbol: 'BTC' }, 5, 'bag');
  p.add({ mint: 'd', name: 'Little Titty Coin', symbol: 'LTC' }, 3, 'bag');
  const m = p.match({ mint: 'new', name: 'Cute Crypto Faucet', symbol: 'CCF' });
  assert.equal(m.level, 2);
  assert.deepEqual(m.series.map((c) => c.symbol).sort(), ['CCB', 'CCC']);
  // sharing only the generic word "coin" is not a series
  assert.equal(p.match({ mint: 'x', name: 'Money Laundering Coin', symbol: 'MLC' }).series.length, 0);
});

test('a coin about him (e.g. $SLINGHOUSE) is a meta match and points at his own name coins', () => {
  const p = new MetaProfile({ selfWords: ['sling'] });
  p.add({ mint: 'a', name: 'Slingtoshi Nakamoto', symbol: 'SLINGTOSHI' }, 3, 'bag');
  p.add({ mint: 'b', name: 'Big Titty Coin', symbol: 'BTC' }, 9, 'bag');
  p.add({ mint: 'c', name: 'Little Titty Coin', symbol: 'LTC' }, 5, 'bag');
  const m = p.match({ mint: 'new', name: 'SLINGHOUSE', symbol: 'SLINGHOUSE' });
  assert.equal(m.level, 2);
  assert.ok(m.tags.includes('self'));
  assert.deepEqual(m.series.map((c) => c.symbol), ['SLINGTOSHI']);
});
