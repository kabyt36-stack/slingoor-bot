import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { DevRisk } from '../src/devrisk.js';

const file = () => path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'dr-')), 'd.json');

test('V2.11.23 dev check: a dev wallet with no trades before this coin is "fresh" (risky); any prior trade = ok', async () => {
  const coins = { get: async (m) => ({ creator: { NEW1: 'DEVA', OLD1: 'DEVB' }[m] }) };
  const calls = [];
  const pump = {
    getCreatedCoins: async (w) => (calls.push(w), { count: 1, coins: [{ mint: w === 'DEVA' ? 'NEW1' : 'OLD1', complete: false }] }),
    getUserTrades: async (w) => ({ trades: w === 'DEVA' ? [{ mint: 'NEW1', isBuy: true }] : [{ mint: 'NEW1', isBuy: true }, { mint: 'SOMETHING', isBuy: true, timestamp: '2026-11-01T00:00:00Z' }] }),
  };
  const d = new DevRisk({ file: file(), coins, pump });
  const a = await d.check('NEW1');
  assert.equal(a.kind, 'fresh');
  assert.equal(a.trades, 0);
  assert.equal(d.risky('fresh'), true);
  const b = await d.check('OLD1');
  assert.equal(b.kind, 'ok', 'one small prior trade is enough');
  assert.equal(d.risky('ok'), false);
  assert.equal(d.known('NEW1').kind, 'fresh', 'cached');
  await d.check('NEW1');
  assert.equal(calls.length, 2, 'no second lookup');
  // unknown (pump.fun down): no verdict
  const z = new DevRisk({ file: file(), coins, pump: { getCreatedCoins: async () => null, getUserTrades: async () => null } });
  assert.equal(await z.check('NEW1'), null);
});

test('V2.11.23 dev check learns: fresh devs stop counting as risky only if their coins rug no more than the others', () => {
  const d = new DevRisk({ file: file() });
  const add = (kind, rug, n) => {
    for (let i = 0; i < n; i++) d.d.outcomes.push({ kind, rug });
  };
  assert.equal(d.risky('fresh'), true, 'no data yet: risky');
  add('ok', true, 4);
  add('ok', false, 16); // ok devs: 20% rug
  add('fresh', true, 3);
  add('fresh', false, 17); // fresh devs: 15% rug
  assert.equal(d.risky('fresh'), false, 'learned: not worse');
  add('fresh', true, 20); // now 23/40 = 58%
  assert.equal(d.risky('fresh'), true);
  assert.match(d.text(), /Rugs by dev: fresh dev 58% \(40\) · dev with history 20% \(20\)/);
  // a coin's outcome is recorded from the pretend wallets
  d.d.kinds.X = { kind: 'fresh', at: Date.now() };
  d.outcome('X', 0.1);
  assert.deepEqual(d.d.outcomes.at(-1), { kind: 'fresh', rug: true });
});
