// Strict checker for Telegram Bot API "HTML" parse mode. Telegram rejects the whole
// message (400 "can't parse entities") on any unsupported tag, unbalanced tag or bare '&' / '<'.
const ALLOWED = new Set(['b', 'strong', 'i', 'em', 'u', 'ins', 's', 'strike', 'del', 'a', 'code', 'pre', 'tg-spoiler', 'blockquote', 'tg-emoji', 'span']);

export function checkTelegramHtml(html) {
  const errors = [];
  const stack = [];
  let visible = 0;
  let i = 0;
  while (i < html.length) {
    const ch = html[i];
    if (ch === '<') {
      const m = /^<(\/?)([a-z-]+)((?:\s+[a-z-]+="[^"<>]*")*)\s*>/.exec(html.slice(i));
      if (!m) {
        errors.push(`bare "<" at ${i}: ${JSON.stringify(html.slice(i, i + 20))}`);
        i++;
        continue;
      }
      const [all, close, tag] = m;
      if (!ALLOWED.has(tag)) errors.push(`unsupported tag <${tag}>`);
      if (close) {
        if (stack.pop() !== tag) errors.push(`unbalanced </${tag}>`);
      } else stack.push(tag);
      i += all.length;
      continue;
    }
    if (ch === '>') errors.push(`bare ">" at ${i}`);
    if (ch === '&') {
      const m = /^&(lt|gt|amp|quot|#\d+|#x[0-9a-f]+);/i.exec(html.slice(i));
      if (!m) errors.push(`bare "&" at ${i}: ${JSON.stringify(html.slice(i, i + 12))}`);
      else {
        i += m[0].length;
        visible++;
        continue;
      }
    }
    visible++;
    i++;
  }
  if (stack.length) errors.push(`unclosed tags: ${stack.join(',')}`);
  if (visible > 4096) errors.push(`too long: ${visible} chars`);
  return errors;
}

export function checkButtons(markup) {
  const errors = [];
  for (const row of markup?.inline_keyboard || []) {
    if (row.length > 8) errors.push('more than 8 buttons in a row');
    for (const b of row) {
      if (!b.text) errors.push('button without text');
      if (!/^https:\/\/[^\s]+$/.test(b.url || '')) errors.push(`bad button url ${b.url}`);
    }
  }
  return errors;
}
