import { fileURLToPath } from 'node:url';
import fs from 'node:fs';
import path from 'node:path';

export const FIX = path.join(path.dirname(fileURLToPath(import.meta.url)), 'fixtures');
export const realTxs = () => JSON.parse(fs.readFileSync(path.join(FIX, 'real-txs.json'), 'utf8'));
export const realCoins = () => JSON.parse(fs.readFileSync(path.join(FIX, 'real-coins.json'), 'utf8'));

const PROGRAM = { Token: 'TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA', Token2: 'TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb' };

// Rebuild a getTransaction(encoding=json) result from the compact fixture.
export function buildTx(c, wallet, sig, { extraLogs = [] } = {}) {
  const keys = Array.from({ length: c.n }, (_, i) => (i === c.wi ? wallet : `Other${String(i).padStart(2, '0')}1111111111111111111111111111`));
  const pre = Array(c.n).fill(1000000);
  const post = Array(c.n).fill(1000000);
  pre[c.wi] = c.pre;
  post[c.wi] = c.post;
  const tb = (arr) =>
    arr.map(([accountIndex, mint, prog, amount, decimals]) => ({
      accountIndex,
      mint,
      owner: wallet,
      programId: PROGRAM[prog] || prog,
      uiTokenAmount: { amount, decimals, uiAmount: Number(amount) / 10 ** decimals, uiAmountString: String(Number(amount) / 10 ** decimals) },
    }));
  // other people's token accounts in the same tx (must be ignored)
  const others = Array.from({ length: Math.min(c.other, 3) }, (_, i) => ({
    accountIndex: 40 + i,
    mint: c.ptb[0]?.[1] || 'So11111111111111111111111111111111111111112',
    owner: `SomeoneElse${i}11111111111111111111111111111`,
    programId: PROGRAM.Token,
    uiTokenAmount: { amount: String(5000 * (i + 1)), decimals: 6, uiAmount: 0, uiAmountString: '0' },
  }));
  const othersPost = others.map((o) => ({ ...o, uiTokenAmount: { ...o.uiTokenAmount, amount: String(Number(o.uiTokenAmount.amount) + 777) } }));
  const logs = [];
  for (const p of c.inv) logs.push(`Program ${p} invoke [1]`, `Program ${p} success`);
  logs.push(...extraLogs);
  return {
    slot: c.slot,
    blockTime: c.bt,
    version: 1,
    transaction: {
      signatures: [sig],
      message: {
        accountKeys: keys,
        header: { numRequiredSignatures: c.h[0], numReadonlySignedAccounts: c.h[1], numReadonlyUnsignedAccounts: c.h[2] },
        instructions: [],
        recentBlockhash: 'x',
      },
    },
    meta: {
      err: null,
      fee: c.fee,
      preBalances: pre,
      postBalances: post,
      preTokenBalances: [...tb(c.ptb), ...others],
      postTokenBalances: [...tb(c.qtb), ...othersPost],
      logMessages: logs,
      loadedAddresses: { writable: [], readonly: [] },
    },
  };
}
