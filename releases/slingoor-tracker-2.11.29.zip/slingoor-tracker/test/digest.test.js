import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { Digest, URGENT_RE, oneLine, isPlainSell, summaryKeeps } from '../src/digest.js';

const tmp = () => path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'dg-')), 'summary.json');
const at = (h, m) => new Date(2026, 10, 7, h, m, 5).getTime();

test('instant alerts: bot enters a coin, every sell it makes, failed sell, 8h warning, cooks; routine ones wait for the summary', () => {
  for (const s of ['🤖 <b>COPY SELL FAILED</b> <b>$X</b> ❌', '🤖 <b>COPY SELL DELAYED</b>', '⏰ <b>$X</b> gets sold in ~30 min (8h limit).', '🔥 <b>COOKED 3.1x</b> on', '🍳 <b>MINI COOK 1.95x — SOLD 50%</b>', '🤖 <b>COPY BUY</b> <b>$X</b> ✅\n💰 Spent', '🤖 <b>COPY BUY</b> <b>$X</b> ✅ (landed late)', '⏰ <b>8H UP — SOLD ALL</b> <b>$X</b> ✅\n💸 Got 0.07 SOL\n📊 Trip: in 0.09 → out 0.07', '🤖 <b>COPY SELL — ALL OUT</b> <b>$X</b> ✅\n📊 Trip: in', '🤖 <b>COPY SELL 50%</b> <b>$X</b> ✅\n👤 He sold ~50%\n💸 Got <b>0.05 SOL</b>\n👜 Still holding', '🎯 <b>TAKE PROFIT 4x — SOLD 25%</b> <b>$X</b> ✅\n📈 Up 4x\n💸 Got <b>0.1 SOL</b>', '🤖 <b>COPY SELL 40%</b> <b>$X</b> ✅ (landed late)'])
    assert.match(s, URGENT_RE, s);
  for (const s of ['⏳ <b>COPY BUY WAITING</b> <b>$X</b>', '🤖 <b>COPY BUY SKIPPED</b> <b>$X</b>', '⏭ <b>BOT SKIPPED</b>', '♻️ Got back <b>0.004 SOL</b>', '🤖 <b>COPY BUY FAILED</b>'])
    assert.doesNotMatch(s, URGENT_RE, s);
});

test('oneLine keeps the header and the money line, drops the address', () => {
  assert.equal(oneLine('🤖 <b>COPY BUY</b> <b>$X</b> ✅\n💰 Spent <b>0.1 SOL</b> → 1K tokens\n<code>MINT</code>'), '🤖 <b>COPY BUY</b> <b>$X</b> · 💰 Spent <b>0.1 SOL</b> → 1K tokens');
  assert.equal(oneLine('⏭ <b>BOT SKIPPED</b> <b>$Y</b>\n❓ Why: old coin\n<code>M</code>'), '⏭ <b>BOT SKIPPED</b> <b>$Y</b> · ❓ Why: old coin');
});

test('hourly summary: collects his trades per coin + bot actions, sends once at the start of the hour, survives a restart', async () => {
  const file = tmp();
  let now = at(9, 20);
  const sent = [];
  const mk = () => new Digest({ file, name: 'slingoor', send: async (h) => sent.push(h), status: async () => ['👛 Bot wallet: <b>0.66 SOL</b>'], now: () => now });
  let d = mk();
  assert.equal(await d.tick(), false, 'first run only starts collecting');
  d.trade({ kind: 'ENTRY', mint: 'A', sym: '$AAA', sol: 5, side: 'BUY' });
  d.trade({ kind: 'ADD', mint: 'A', sym: '$AAA', sol: 2, side: 'BUY' });
  d.trade({ kind: 'EXIT', mint: 'B', sym: '$B<b>', sol: 12, side: 'SELL' });
  d.note('🤖 <b>COPY BUY</b> <b>$AAA</b> ✅\n💰 Spent <b>0.1 SOL</b>\n<code>A</code>');
  d.launch('$NEW');
  now = at(9, 59);
  assert.equal(await d.tick(), false, 'not yet');
  d = mk(); // restart (auto-update) keeps what was collected
  now = at(10, 0);
  assert.equal(await d.tick(), true);
  assert.equal(await d.tick(), false, 'once per hour');
  assert.equal(sent.length, 1);
  const s = sent[0];
  assert.match(s, /Hourly summary/);
  assert.match(s, /\$AAA<\/b> new buy 7\.00 SOL \(2×\)/);
  assert.match(s, /\$B&lt;b&gt;<\/b> sold all \(12\.0 SOL\)/, 'symbols are escaped');
  assert.match(s, /Launched <b>\$NEW<\/b>/);
  assert.doesNotMatch(s, /COPY BUY/, 'V2.8.5: buys are not listed in the summary');
  assert.match(s, /Bot wallet: <b>0\.66 SOL/);
  now = at(11, 0);
  await d.tick();
  assert.match(sent[1], /no trades this hour/);
  assert.match(sent[1], /nothing to do this hour/);
});

test('hourly summary lists each trader separately (sling + cupsey)', async () => {
  const file = tmp();
  let now = at(9, 20);
  const sent = [];
  const d = new Digest({ file, name: 'slingoor', others: ['cupsey'], send: async (h) => sent.push(h), now: () => now });
  await d.tick();
  d.trade({ kind: 'ENTRY', mint: 'A', trader: 'cupsey', sym: '$CUP', sol: 3, side: 'BUY' });
  d.trade({ kind: 'ENTRY', mint: 'A', trader: 'slingoor', sym: '$CUP', sol: 1, side: 'BUY' });
  now = at(10, 0);
  await d.tick();
  const s = sent[0];
  assert.match(s, /👤 <b>slingoor<\/b>:\n• <b>\$CUP<\/b> new buy 1\.00 SOL/);
  assert.match(s, /👤 <b>cupsey<\/b>:\n• <b>\$CUP<\/b> new buy 3\.00 SOL/);
  now = at(11, 0);
  await d.tick();
  assert.match(sent[1], /slingoor: no trades this hour/);
  assert.match(sent[1], /cupsey: no trades this hour/);
});

test('V2: traders\' coins are left out of the hourly summary and listed by /traded instead', async () => {
  const file = tmp();
  let now = at(9, 20);
  const sent = [];
  const d = new Digest({ file, name: 'slingoor', others: ['cupsey'], send: async (h) => sent.push(h), now: () => now });
  d.hideTraders = true;
  await d.tick();
  d.trade({ kind: 'ENTRY', mint: 'A', trader: 'cupsey', sym: '$CUP', sol: 3, side: 'BUY' });
  now = at(10, 0);
  await d.tick();
  assert.doesNotMatch(sent[0], /CUP|cupsey|slingoor/);
  const t = d.tradedText();
  assert.match(t, /cupsey: <b>\$CUP<\/b> 3\.00 SOL · 40m ago/);
});

test('V2.7.5: only cook sells ping; plain sells are quiet, failures still ping', () => {
  for (const s of ['💸 Sold all <b>$X</b> (0.92x) — got <b>0.09 SOL</b>', '💸 Sold 50% <b>$X</b> — got <b>0.05 SOL</b> · <i>W2</i>', '🪫 <b>WEAK COIN — SOLD ALL</b> <b>$X</b> ✅\n💸 Got 0.05 SOL', '🤖 <b>COPY SELL — ALL OUT</b> <b>$X</b> ✅\n📊 Trip: in 0.1 → out 0.08'])
    assert.ok(isPlainSell(s), s);
  for (const s of ['🔥 <b>2.4x cook</b> on <b>$X</b> — got <b>0.24 SOL</b>', '🍳 <b>1.3x mini cook</b> on <b>$X</b> — got <b>0.13 SOL</b>', '🔥 <b>COOKED 3.1x</b> on <b>$X</b>', '🍳 <b>MINI COOK 1.95x — SOLD 50%</b> <b>$X</b> ✅\n💸 Got 0.1', '🤖 <b>COPY SELL FAILED</b> <b>$X</b> ❌', '🟢 Bought <b>$X</b> — <b>0.1 SOL</b>', '⏰ <b>$X</b> gets sold in ~30 min (8h limit).'])
    assert.ok(!isPlainSell(s), s);
});

test('V2.8.5 the summary only lists coins that made money (no buys, no losing sells)', () => {
  for (const h of ['💸 Sold all <b>$X</b> (1.34x) — got <b>0.13 SOL</b>', '🍳 <b>1.3x mini cook</b> on <b>$X</b> — got <b>0.13 SOL</b> · 🧪 paper', '🤖 <b>COPY SELL — ALL OUT</b> <b>$X</b> ✅\n💸 Got 0.2\n📊 Trip: in 0.1 → out 0.2 SOL = <b>+0.1 SOL</b>', '♻️ Got back <b>0.004 SOL</b> from 2 empty coin accounts', '🤖 <b>COPY SELL FAILED</b> <b>$X</b> ❌'])
    assert.ok(summaryKeeps(h), h);
  for (const h of ['🟢 Bought <b>$X</b> — <b>0.1 SOL</b> · 🧪 paper', '🤖 <b>COPY BUY FAILED</b> <b>$X</b>', '💸 Sold all <b>$X</b> (0.82x) — got <b>0.08 SOL</b>', '💸 Sold all <b>$X</b> (1.00x) — got <b>0.1 SOL</b>', '🪫 <b>WEAK COIN — SOLD ALL</b> <b>$X</b> ✅\n💸 Got 0.05\n📊 Trip: in 0.1 → out 0.05 SOL = <b>-0.05 SOL</b>', '💸 Sold 50% <b>$X</b> — got <b>0.05 SOL</b>'])
    assert.ok(!summaryKeeps(h), h);
});

test('V2.8.10 the summary never lists coins one by one: profitable sells become one count line', async () => {
  const file = tmp();
  let now = at(9, 20);
  const sent = [];
  const d = new Digest({ file, send: async (h) => sent.push(h), now: () => now });
  await d.tick();
  for (let i = 0; i < 40; i++) d.note(`💸 Sold all <b>$C${i}</b> (1.2${i % 10}x) — got <b>0.05 SOL</b> · W2 · 🧪 paper`);
  d.note('🍳 <b>2.19x mini cook</b> on <b>$G</b> — got <b>0.2 SOL</b>');
  d.note('💸 Sold all <b>$L</b> (0.80x) — got <b>0.04 SOL</b>');
  for (let i = 0; i < 5; i++) d.note(`🔄 Updated v1.${i} → v1.${i + 1}`);
  now = at(10, 0);
  await d.tick();
  const s = sent[0];
  assert.match(s, /• 41 sells in profit \(1 cook\) · best 2\.19x/);
  assert.doesNotMatch(s, /\$C\d|\$G|\$L|earlier/, 'no coin names, no "…earlier"');
  assert.equal((s.match(/Updated/g) || []).length, 3, 'only the last 3 other notes');
  now = at(11, 0);
  await d.tick();
  assert.match(sent[1], /nothing to do this hour/, 'counts reset every hour');
});
