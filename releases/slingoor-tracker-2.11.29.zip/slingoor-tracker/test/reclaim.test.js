// Closing empty token accounts of coins the bot sold out of (gets the rent back).
import test from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { buildCloseTx, RentReclaimer, TOKEN_PROGRAM, TOKEN_2022 } from '../src/reclaim.js';
import { b58encode, loadKeypair, parseTx, signTx, verifyTxSignature } from '../src/solana.js';

const key = () => b58encode(crypto.randomBytes(32));
function newKp() {
  const { privateKey, publicKey } = crypto.generateKeyPairSync('ed25519');
  const seed = privateKey.export({ format: 'der', type: 'pkcs8' }).subarray(-32);
  const pub = publicKey.export({ format: 'der', type: 'spki' }).subarray(-32);
  return loadKeypair(b58encode(Buffer.concat([seed, pub])));
}

test('close transaction: right layout, one close instruction per account, signs and verifies', () => {
  const kp = newKp();
  const a1 = { pubkey: key(), programId: TOKEN_PROGRAM };
  const a2 = { pubkey: key(), programId: TOKEN_2022 };
  const bh = key();
  const tx = buildCloseTx(kp.publicKey, [a1, a2], bh);
  const t = parseTx(tx);
  assert.equal(t.versioned, false);
  assert.equal(t.numRequired, 1);
  assert.deepEqual(t.keys, [kp.publicKey, a1.pubkey, a2.pubkey, TOKEN_PROGRAM, TOKEN_2022]);
  const msg = t.buf.subarray(t.msgStart);
  assert.deepEqual([...msg.subarray(0, 3)], [1, 0, 2], 'header: 1 signer, 2 read-only programs');
  const after = 3 + 1 + 5 * 32;
  assert.equal(b58encode(msg.subarray(after, after + 32)), bh);
  const ix = [...msg.subarray(after + 32)];
  // 2 instructions: [program, 3 accounts (account, destination=owner, owner), 1 byte data = 9]
  assert.deepEqual(ix, [2, 3, 3, 1, 0, 0, 1, 9, 4, 3, 2, 0, 0, 1, 9]);
  const { bytes } = signTx(tx, kp);
  assert.ok(verifyTxSignature(bytes, kp.publicKey));
  assert.throws(() => buildCloseTx(kp.publicKey, [], bh));
  assert.throws(() => buildCloseTx(kp.publicKey, [a1, a1], bh), /duplicate/);
});

test('reclaimer: closes only empty accounts of coins we traded, not busy ones, after they sat empty a while', async () => {
  const owner = newKp().publicKey;
  const names = {};
  const acct = (mint, amount, programId = TOKEN_PROGRAM, extra = {}) => ({
    pubkey: (names[mint] = key()),
    account: { lamports: 2039280, data: { parsed: { info: { mint, owner, state: 'initialized', tokenAmount: { amount }, ...extra } } } },
    programId,
  });
  const accounts = [acct('SOLD1', '0'), acct('SOLD2', '0', TOKEN_2022), acct('HELD', '500'), acct('BUSY', '0'), acct('NOTOURS', '0'), acct('So11111111111111111111111111111111111111112', '0'), acct('FROZEN', '0', TOKEN_PROGRAM, { state: 'frozen' })];
  const sent = [];
  let failNext = false;
  const rpc = {
    call: async (m, p) => {
      if (m === 'getTokenAccountsByOwner') return { value: accounts.filter((a) => a.programId === p[1].programId) };
      if (m === 'getLatestBlockhash') return { value: { blockhash: key() } };
      throw new Error('unexpected ' + m);
    },
  };
  const swapper = {
    send: async (tx) => {
      if (failNext) {
        failNext = false;
        throw new Error('transaction failed on-chain');
      }
      sent.push(parseTx(tx).keys);
      return { sig: 'S' + sent.length };
    },
  };
  const notes = [];
  const r = new RentReclaimer({ rpc, swapper, owner, isBusy: (m) => m === 'BUSY', isOurs: (m) => m !== 'NOTOURS', notify: async (t) => notes.push(t), minAgeMs: 50 });
  assert.equal(await r.run(), 0, 'first sight: wait until it has been empty a while');
  await new Promise((res) => setTimeout(res, 60));
  failNext = true;
  assert.equal(await r.run(), 0, 'send failed: nothing reclaimed');
  const got = await r.run(); // after a failure, each account goes in its own transaction
  assert.ok(Math.abs(got - 0.00407856) < 1e-9, String(got));
  assert.equal(sent.length, 2);
  const closed = sent.map((k) => k[1]).sort();
  assert.deepEqual(closed, [names.SOLD1, names.SOLD2].sort());
  assert.match(notes[0], /0\.0041 SOL<\/b> from 2 empty coin accounts/);
});
