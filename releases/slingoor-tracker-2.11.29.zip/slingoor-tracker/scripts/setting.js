// Usage: node scripts/setting.js KEY            -> prints the current value
//        node scripts/setting.js KEY VALUE      -> sets it in settings.txt
// (If a key appears more than once, the last one counts — same rule as the bot.)
import { fileURLToPath } from 'node:url';
import fs from 'node:fs';
import path from 'node:path';

const file = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'settings.txt');
const [key, value] = process.argv.slice(2);
const text = fs.existsSync(file) ? fs.readFileSync(file, 'utf8') : '';
const lines = text.split(/\r?\n/);
const isKey = (l) => l.trim().startsWith(`${key}=`);

if (value === undefined) {
  const hit = lines.filter(isKey).pop();
  process.stdout.write(hit ? hit.slice(hit.indexOf('=') + 1).replace(/\s+#.*$/, '').trim() : '');
} else {
  let done = false;
  const out = [];
  for (const l of lines) {
    if (!isKey(l)) out.push(l);
    else if (!done) {
      out.push(`${key}=${value}`);
      done = true;
    }
  }
  if (!done) {
    if (out.length && out[out.length - 1] === '') out.splice(out.length - 1, 0, `${key}=${value}`);
    else out.push(`${key}=${value}`);
  }
  fs.writeFileSync(file, out.join('\n'));
}
