# Sourced by the .command files. Sets NODE to a Node.js 22+ binary, or empty.
NODE=""
if [ -x "./runtime/node/bin/node" ]; then
  NODE="$(pwd)/runtime/node/bin/node"
else
  for cand in "$(command -v node 2>/dev/null)" /opt/homebrew/bin/node /usr/local/bin/node; do
    if [ -n "$cand" ] && [ -x "$cand" ]; then
      major=$("$cand" -p 'process.versions.node.split(".")[0]' 2>/dev/null)
      if [ "${major:-0}" -ge 22 ] 2>/dev/null; then NODE="$cand"; break; fi
    fi
  done
fi
