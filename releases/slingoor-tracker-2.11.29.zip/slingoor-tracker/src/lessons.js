// V2.11.29 paper auto-restart lessons (Khalil, Nov 13 3:05pm: "If the paper trade wallet starts going like low just
// restart it, have the bot figure out why it was losing so much off a trader then adapt").
// When the paper wallets fall to PAPER_AUTO_RESTART_AT of what they started with, the bot looks at every coin closed
// since the start, finds the traders whose copies lost the money and why (rugs / bought late / small bleeds), benches
// them (not copied) and restarts paper. Benched again later -> benched twice as long. Kept across restarts.
import fs from 'node:fs';
import path from 'node:path';

const HOUR = 3600000;

export class Lessons {
  constructor({ file, now = () => Date.now(), benchHours = 24 } = {}) {
    this.file = file;
    this.now = now;
    this.benchHours = benchHours;
    this.d = { bench: {}, restarts: [] };
    try {
      this.d = { ...this.d, ...JSON.parse(fs.readFileSync(file, 'utf8')) };
    } catch {}
  }

  save() {
    if (!this.file) return;
    try {
      fs.mkdirSync(path.dirname(this.file), { recursive: true });
      fs.writeFileSync(this.file + '.tmp', JSON.stringify(this.d));
      fs.renameSync(this.file + '.tmp', this.file);
    } catch {}
  }

  // per trader: coins, won, pnl, rugs (got back under half), and the why
  static analyze(trips) {
    const by = {};
    for (const t of trips || []) {
      if (!t?.leader) continue;
      const r = (by[t.leader] ||= { name: t.leader, coins: 0, won: 0, pnl: 0, rugs: 0, rugLoss: 0, mcs: [] });
      r.coins++;
      r.pnl += t.pnl || 0;
      if ((t.pnl || 0) > 0) r.won++;
      if (t.x != null && t.x < 0.5) {
        r.rugs++;
        r.rugLoss += -(t.pnl || 0);
      }
      if (t.buyMc > 0) r.mcs.push(t.buyMc);
    }
    for (const r of Object.values(by)) {
      r.pnl = Math.round(r.pnl * 1e6) / 1e6;
      const lost = -r.pnl;
      const med = r.mcs.length ? r.mcs.sort((a, b) => a - b)[Math.floor(r.mcs.length / 2)] : 0;
      r.why =
        r.rugs && r.rugLoss >= lost * 0.5
          ? `${r.rugs} of ${r.coins} went to zero (rugs)`
          : med >= 60000
            ? `bought late (around $${Math.round(med / 1000)}k market cap) and sold for less`
            : `small losses add up: won ${r.won} of ${r.coins}`;
      delete r.mcs;
    }
    return Object.values(by).sort((a, b) => a.pnl - b.pnl);
  }

  // the traders who lost the money: red, 2+ coins, lost 0.02+ SOL (worst first, up to 5)
  static losers(trips) {
    return Lessons.analyze(trips)
      .filter((r) => r.pnl <= -0.02 && r.coins >= 2)
      .slice(0, 5);
  }

  // bench them: 24h the first time, twice as long each time after
  bench(losers, { exempt = [] } = {}) {
    const out = [];
    for (const r of losers) {
      if (exempt.includes(r.name)) continue;
      const old = this.d.bench[r.name];
      const times = (old?.times || 0) + 1;
      const hours = this.benchHours * 2 ** (times - 1);
      this.d.bench[r.name] = { until: this.now() + hours * HOUR, times, lost: r.pnl, why: r.why };
      out.push({ ...r, hours });
    }
    this.save();
    return out;
  }

  noteRestart(total, start) {
    this.d.restarts.push({ at: this.now(), total: Math.round(total * 1e4) / 1e4, start: Math.round(start * 1e4) / 1e4 });
    if (this.d.restarts.length > 50) this.d.restarts.splice(0, this.d.restarts.length - 50);
    this.save();
  }

  // why he isn't copied right now (null = free to copy)
  benched(name) {
    const b = this.d.bench[name];
    if (!b || this.now() >= b.until) return null;
    return `benched ${Math.ceil((b.until - this.now()) / HOUR)}h more: paper lost ${Math.abs(b.lost).toFixed(3)} SOL on him (${b.why})`;
  }
}
