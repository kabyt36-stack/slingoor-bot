// Small shared helpers. No external dependencies.

export const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const B58 = /^[1-9A-HJ-NP-Za-km-z]{32,44}$/;
export const isAddress = (s) => typeof s === 'string' && B58.test(s);

export function shortAddr(a, n = 4) {
  if (!a || a.length <= n * 2 + 1) return a || '';
  return `${a.slice(0, n)}…${a.slice(-n)}`;
}

export function escHtml(s) {
  return String(s ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

export function fmtUsd(v) {
  if (v == null || !Number.isFinite(+v)) return '?';
  v = +v;
  const a = Math.abs(v);
  const sign = v < 0 ? '-' : '';
  if (a >= 1e9) return `${sign}$${(a / 1e9).toFixed(2)}B`;
  if (a >= 1e6) return `${sign}$${(a / 1e6).toFixed(2)}M`;
  if (a >= 1e4) return `${sign}$${(a / 1e3).toFixed(1)}K`;
  if (a >= 1e3) return `${sign}$${(a / 1e3).toFixed(2)}K`;
  if (a >= 1) return `${sign}$${a.toFixed(0)}`;
  return `${sign}$${a.toFixed(2)}`;
}

export function fmtSol(v) {
  if (v == null || !Number.isFinite(+v)) return '?';
  v = +v;
  const a = Math.abs(v);
  if (a >= 100) return v.toFixed(1);
  if (a >= 1) return v.toFixed(2);
  if (a >= 0.01) return v.toFixed(3);
  return v.toFixed(4);
}

export function fmtNum(v) {
  if (v == null || !Number.isFinite(+v)) return '?';
  v = +v;
  const a = Math.abs(v);
  if (a >= 1e9) return `${(v / 1e9).toFixed(2)}B`;
  if (a >= 1e6) return `${(v / 1e6).toFixed(2)}M`;
  if (a >= 1e3) return `${(v / 1e3).toFixed(1)}K`;
  if (Number.isInteger(v)) return String(v);
  return v.toFixed(a >= 1 ? 0 : 4);
}

export function fmtPct(v) {
  if (v == null || !Number.isFinite(+v)) return '?';
  const s = +v >= 0 ? '+' : '';
  return `${s}${(+v).toFixed(Math.abs(v) >= 100 ? 0 : 1)}%`;
}

export function fmtAgo(ms) {
  if (!Number.isFinite(ms) || ms < 0) return '';
  const s = ms / 1000;
  if (s < 60) return `${s.toFixed(s < 10 ? 1 : 0)}s`;
  if (s < 3600) return `${Math.round(s / 60)}m`;
  if (s < 86400) return `${(s / 3600).toFixed(1)}h`;
  return `${(s / 86400).toFixed(1)}d`;
}

// fetch JSON with timeout. Throws an Error carrying .status for HTTP errors.
export async function fetchJson(url, { method = 'GET', headers = {}, body, timeout = 10000 } = {}) {
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), timeout);
  try {
    const res = await fetch(url, {
      method,
      headers,
      body: body == null ? undefined : typeof body === 'string' ? body : JSON.stringify(body),
      signal: ctl.signal,
    });
    const text = await res.text();
    if (!res.ok) {
      const err = new Error(`HTTP ${res.status} for ${redact(url)}: ${text.slice(0, 160)}`);
      err.status = res.status;
      err.retryAfter = Number(res.headers.get('retry-after')) || 0;
      throw err;
    }
    try {
      return text ? JSON.parse(text) : null;
    } catch {
      const err = new Error(`Bad JSON from ${redact(url)}`);
      err.status = res.status;
      throw err;
    }
  } catch (e) {
    if (e.name === 'AbortError') {
      const err = new Error(`Timeout after ${timeout}ms for ${redact(url)}`);
      err.timeout = true;
      throw err;
    }
    throw e;
  } finally {
    clearTimeout(timer);
  }
}

// Hide API keys / bot tokens in logs.
export function redact(s) {
  return String(s)
    .replace(/api-key=[^&\s]+/gi, 'api-key=***')
    .replace(/bot\d+:[A-Za-z0-9_-]+/g, 'bot***');
}

export function withTimeout(promise, ms, fallback = null) {
  let t;
  return Promise.race([
    promise.catch(() => fallback),
    new Promise((r) => {
      t = setTimeout(() => r(fallback), ms);
    }),
  ]).finally(() => clearTimeout(t));
}

// Keeps insertion order, drops oldest beyond max.
export class BoundedSet {
  constructor(max = 5000, items = []) {
    this.max = max;
    this.set = new Set(items);
  }
  has(k) {
    return this.set.has(k);
  }
  add(k) {
    if (this.set.has(k)) return false;
    this.set.add(k);
    if (this.set.size > this.max) {
      const first = this.set.values().next().value;
      this.set.delete(first);
    }
    return true;
  }
  toJSON() {
    return [...this.set];
  }
  get size() {
    return this.set.size;
  }
}
