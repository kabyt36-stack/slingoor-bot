import { escHtml as e, fmtUsd, fmtSol, fmtPct, fmtAgo, fmtNum, shortAddr } from './util.js';
import { TAGS, tagText } from './narrative.js';

export function linkButtons(mint, { sig, calloutId } = {}) {
  const rows = [
    [
      { text: 'pump.fun', url: calloutId ? `https://pump.fun/coin/${mint}?highlight_callout=${calloutId}` : `https://pump.fun/coin/${mint}` },
      { text: 'Padre', url: `https://trade.padre.gg/trade/solana/${mint}` },
    ],
    [
      { text: 'GMGN', url: `https://gmgn.ai/sol/token/${mint}` },
      { text: 'DexScreener', url: `https://dexscreener.com/solana/${mint}` },
    ],
  ];
  if (sig) rows[1].push({ text: 'Tx', url: `https://solscan.io/tx/${sig}` });
  return rows;
}

export function coinLine(coin, mint) {
  const sym = coin?.symbol ? `$${e(coin.symbol)}` : shortAddr(mint);
  const name = coin?.name && coin.name !== coin.symbol ? ` — ${e(coin.name)}` : '';
  return `<b>${sym}</b>${name}`;
}

export function mcLine(coin) {
  if (!coin) return null;
  const parts = [];
  if (coin.mc) parts.push(`📊 MC ${fmtUsd(coin.mc)}`);
  if (coin.isPump) parts.push(coin.complete ? '🎓 graduated' : '🌱 on bonding curve');
  if (coin.ageMs != null) parts.push(`🕐 coin age ${fmtAgo(coin.ageMs)}`);
  return parts.length ? parts.join(' · ') : null;
}

export function metaBlock(m) {
  if (!m) return [];
  const lines = [];
  const norm = (s) => String(s || '').trim().toLowerCase();
  const isCopy = (c) => norm(c.name) === norm(m.name) && norm(c.symbol) === norm(m.symbol);
  const copies = (m.series || []).filter(isCopy);
  const series = (m.series || []).filter((c) => !isCopy(c));
  const fmt = (list) => list.map((c) => `$${e(c.symbol)} (${e(c.name)})`).join(', ');
  const shown = new Set();
  const bySeries = m.level === 2 && m.score < 50 && (m.coreHits?.length || 0) < 2 && (series.length || copies.length);
  const selfSeries = series.filter((c) => c.cls?.tags?.includes('self'));
  if (m.level === 3) lines.push('🔥🔥 <b>BIG TITTY COIN FORMULA</b> — real ticker spelled out, his #1 meta');
  else if (m.tags.includes('self')) {
    lines.push(`🔥 <b>META MATCH</b> — a coin about him${selfSeries.length ? `, like his ${fmt(selfSeries)}` : ''}`);
    selfSeries.forEach((c) => shown.add(c.mint));
  } else if (bySeries && series.length) {
    lines.push(`🔥 <b>META MATCH</b> — same series as coins he played: ${fmt(series)}`);
    series.forEach((c) => shown.add(c.mint));
  } else if (bySeries) lines.push('🔥 <b>META MATCH</b> — he already played a coin with this exact name');
  else if (m.level === 2) lines.push(`🔥 <b>META MATCH ${m.score}%</b> — same type of narrative he plays`);
  else if (m.level === 1) lines.push(`🟡 Partial meta match (${m.score}%)`);
  else lines.push('⚪ Off his usual meta');
  lines.push(`🏷 ${m.tags.length ? tagText(m.tags) : 'narrative unclear'}`);
  if (copies.length && !(bySeries && !series.length)) lines.push('♻️ He played another coin with this exact name before');
  const like = [...series, ...(m.similar || [])]
    .filter((c) => !shown.has(c.mint) && !isCopy(c))
    .filter((c, i, a) => a.findIndex((x) => x.mint === c.mint) === i)
    .slice(0, 3);
  if (like.length) lines.push(`🧬 Like his: ${fmt(like)}`);
  return lines;
}

const KIND_HEAD = {
  ENTRY: (n) => `🟢 <b>${n} NEW ENTRY</b>`,
  ADD: (n) => `➕ <b>${n} ADDED MORE</b>`,
  PARTIAL: (n, g) => `🟠 <b>${n} SOLD ${g.pctSold != null ? Math.round(g.pctSold) + '%' : 'SOME'}</b>`,
  EXIT: (n) => `🔴 <b>${n} FULLY SOLD OUT</b>`,
  MOVED: (n) => `📤 <b>${n} MOVED TOKENS OUT</b>`,
};

function amountText(g, solPrice) {
  if (g.sol > 0) {
    const usd = g.usd > 0 ? g.usd : solPrice ? g.sol * solPrice : null;
    return `<b>${fmtSol(g.sol)} SOL</b>${usd ? ` (~${fmtUsd(usd)})` : ''}`;
  }
  if (g.usd > 0) return `<b>${fmtUsd(g.usd)}</b>`;
  if (g.paidWith) return `swapped ${g.side === 'BUY' ? 'from' : 'into'} another token`;
  return null;
}

// g = merged trade group (see tracker.js)
export function tradeMessage(g, { name, solPrice, multiWallet }) {
  const n = e(name.toUpperCase());
  const lines = [`${KIND_HEAD[g.kind](n, g)} ${coinLine(g.coin, g.mint)}`];
  const amt = amountText(g, solPrice);
  const many = g.count > 1 ? ` · ${g.count} ${g.side === 'BUY' ? 'buys' : 'sells'} in ${fmtAgo(g.lastTime - g.firstTime) || '0s'}` : '';
  if (g.kind === 'ENTRY' || g.kind === 'ADD') {
    if (amt) lines.push(`💰 Bought ${amt}${many}`);
  } else if (g.kind === 'MOVED') {
    lines.push(`📦 Sent ${fmtNum(g.tokens)} tokens to another wallet (no SOL back)${g.postUi != null ? ` · left in wallet: ${fmtNum(g.postUi)}` : ''}`);
  } else {
    if (amt) lines.push(`💸 Sold for ${amt}${many}`);
    if (g.kind === 'PARTIAL' && g.pctLeft != null) lines.push(`👜 Still holding ~${Math.round(g.pctLeft)}% of his bag`);
    if (g.kind === 'EXIT') lines.push('👜 Bag is now <b>0</b> — he is completely out');
  }
  const mc = mcLine(g.coin);
  if (mc) lines.push(mc);
  if (g.trip) lines.push(`📈 This trip: in ${fmtSol(g.trip.in)} SOL → out ${fmtSol(g.trip.out)} SOL = <b>${g.trip.pnl >= 0 ? '+' : ''}${fmtSol(g.trip.pnl)} SOL</b> (${fmtPct(g.trip.pct)})${g.trip.heldMs > 0 ? ` · held ${fmtAgo(g.trip.heldMs)}` : ''}`);
  if (g.pnl) lines.push(`🧾 pump.fun PnL on this coin: <b>${fmtUsd(g.pnl.usd)}</b>${g.pnl.pct != null ? ` (${fmtPct(g.pnl.pct)})` : ''}`);
  if (g.kind === 'ENTRY' || g.kind === 'ADD') lines.push('', ...metaBlock(g.meta));
  lines.push('', `<code>${g.mint}</code>`);
  const lag = g.lagMs != null && g.lagMs >= 0 && g.lagMs < 600000 ? `⚡ ${fmtAgo(g.lagMs)} after his tx` : '';
  const wallet = multiWallet ? ` · wallet ${shortAddr(g.wallet)}` : '';
  lines.push(`<i>${lag}${lag ? ' · ' : ''}via ${g.source === 'chain' ? 'on-chain stream' : 'pump.fun feed'}${wallet}</i>`);
  return lines.join('\n');
}

export function calloutMessage(c, { name, coin, meta, holding, isUpdate, updateText }) {
  const n = e(name.toUpperCase());
  const lines = [];
  if (isUpdate) {
    lines.push(`📝 <b>${n} CALLOUT UPDATE</b> ${coinLine(coin, c.coinMint)}`);
    lines.push(updateText ? `💬 “${e(updateText.slice(0, 700))}”` : '💬 He posted an update — open the callout on pump.fun to read it');
    if (c.multiple != null) lines.push(`📈 Since his call: ${(+c.multiple).toFixed(2)}x now · peak ${(+c.maxMultiplier || 0).toFixed(1)}x`);
  } else {
    lines.push(`📣 <b>${n} CALLOUT</b> ${coinLine(coin, c.coinMint)}`);
    if (c.thesis) lines.push(`💬 “${e(String(c.thesis).slice(0, 700))}”`);
    const mcAt = c.marketCap ? `📊 MC at call ${fmtUsd(c.marketCap)}` : null;
    const mcNow = coin?.mc ? `now ${fmtUsd(coin.mc)}` : null;
    if (mcAt || mcNow) lines.push([mcAt, mcNow].filter(Boolean).join(' · '));
  }
  if (holding) {
    if (holding.held) {
      lines.push(`👜 He's holding it${holding.costUsd ? ` · cost ${fmtUsd(holding.costUsd)}` : ''}${holding.pnlPct != null ? ` · ${fmtPct(holding.pnlPct)}` : ''}`);
    } else if (holding.exited) {
      lines.push('⚠️ pump.fun shows he has already exited this coin');
    } else {
      lines.push("⚠️ He doesn't hold it (yet)");
    }
  }
  if (!isUpdate) lines.push('', ...metaBlock(meta));
  lines.push('', `<code>${c.coinMint}</code>`);
  return lines.join('\n');
}

export function launchMessage(l, { name, coin, meta, solPrice }) {
  const n = e(name.toUpperCase());
  const lines = [`🚀 <b>${n} LAUNCHED A COIN</b> ${coinLine(coin, l.mint)}`];
  if (l.devBuy?.solAmount) {
    const usd = solPrice ? ` (~${fmtUsd(l.devBuy.solAmount * solPrice)})` : '';
    lines.push(`💰 Dev buy: <b>${fmtSol(l.devBuy.solAmount)} SOL</b>${usd}`);
  }
  const mc = mcLine(coin);
  if (mc) lines.push(mc);
  lines.push('', ...metaBlock(meta), '', `<code>${l.mint}</code>`);
  return lines.join('\n');
}

export function metaSummary(profile, name) {
  const top = profile.topTags(8);
  if (!top.length) return 'Still learning his meta — try again in a minute.';
  const lines = [`🧠 <b>${e(name)}'s meta</b> (from ${profile.coins.size} coins: his bags, callouts, trades, launches)`, ''];
  for (const t of top) {
    const ex = profile.examples(t.tag, 3).map((c) => `$${e(c.symbol)}`).join(' ');
    lines.push(`${TAGS[t.tag]?.emoji || ''} <b>${TAGS[t.tag]?.label || t.tag}</b> — ${Math.round(t.share * 100)}%  <i>${ex}</i>`);
  }
  const formula = [...profile.coins.values()].filter((c) => c.cls.bigTittyMeta).sort((a, b) => (b.valueUsd || 0) - (a.valueUsd || 0)).slice(0, 8);
  if (formula.length) {
    lines.push('', '🔥 <b>Big Titty Coin formula</b> = take a real ticker, spell it out dirty:');
    lines.push(formula.map((c) => `$${e(c.symbol)} ${e(c.name)}`).join(' · '));
  }
  return lines.join('\n');
}
