import { fetchJson, withTimeout } from './util.js';
import { log } from './log.js';

// Coin name / ticker / market cap lookups with a cache.
// pump.fun first (covers pump + PumpSwap coins), DexScreener as a fallback for everything else.
export class Coins {
  constructor({ pump, dexApi, rpcUrl = '' }) {
    this.pump = pump;
    this.dexApi = dexApi;
    // Helius RPC also answers getAsset (name/ticker/image) for any token, including brand-new pump coins
    this.dasUrl = /helius-rpc\.com/.test(rpcUrl) ? rpcUrl : '';
    this.cache = new Map();
  }

  remember(mint, info) {
    if (!mint || !info) return;
    const prev = this.cache.get(mint) || {};
    const next = { ...prev };
    for (const [k, v] of Object.entries(info)) if (v != null && v !== '') next[k] = v;
    this.cache.set(mint, next);
  }

  peek(mint) {
    return this.cache.get(mint) || null;
  }

  async _fromPump(mint) {
    const c = await this.pump.getCoin(mint);
    if (!c?.mint) return null;
    return {
      name: c.name,
      symbol: c.symbol,
      image: c.image_uri,
      twitter: c.twitter,
      nsfw: !!c.nsfw,
      complete: !!c.complete,
      isPump: /pump/i.test(c.program || '') || mint.endsWith('pump') || !!c.bonding_curve,
      mc: +c.usd_market_cap || +c.market_cap_usd || null,
      createdAt: c.created_timestamp || null,
      creator: c.creator,
      mcAt: Date.now(),
    };
  }

  async _fromDex(mint) {
    const j = await fetchJson(`${this.dexApi}/latest/dex/tokens/${mint}`, { timeout: 4000 });
    const pairs = (j?.pairs || []).filter((p) => p.baseToken?.address === mint);
    if (!pairs.length) return null;
    pairs.sort((a, b) => (b.liquidity?.usd || 0) - (a.liquidity?.usd || 0));
    const p = pairs[0];
    return {
      name: p.baseToken.name,
      symbol: p.baseToken.symbol,
      mc: p.marketCap || p.fdv || null,
      createdAt: p.pairCreatedAt || null,
      isPump: false,
      mcAt: Date.now(),
    };
  }

  async _fromDas(mint) {
    if (!this.dasUrl) return null;
    const j = await fetchJson(this.dasUrl, { method: 'POST', headers: { 'content-type': 'application/json' }, body: { jsonrpc: '2.0', id: 1, method: 'getAsset', params: { id: mint } }, timeout: 4000 });
    const a = j?.result;
    const md = a?.content?.metadata;
    if (!md?.name && !md?.symbol) return null;
    const price = +a.token_info?.price_info?.price_per_token || 0;
    const supply = +a.token_info?.supply / 10 ** (+a.token_info?.decimals || 0) || 0;
    return {
      name: md.name,
      symbol: md.symbol,
      image: a.content?.links?.image || a.content?.files?.[0]?.uri,
      isPump: mint.endsWith('pump'),
      ...(price && supply ? { mc: price * supply, mcAt: Date.now() } : {}),
    };
  }

  // How long ago the coin was launched (its first pool on DexScreener, i.e. the pump.fun curve).
  // null = unknown; 0 = no pool listed yet (brand new).
  async ageMs(mint) {
    const j = await fetchJson(`${this.dexApi}/latest/dex/tokens/${mint}`, { timeout: 2500 }).catch(() => null);
    if (!j) return null;
    const ts = (j.pairs || []).filter((p) => p.baseToken?.address === mint && +p.pairCreatedAt > 0).map((p) => +p.pairCreatedAt);
    return ts.length ? Math.max(0, Date.now() - Math.min(...ts)) : 0;
  }

  // SOL price per token for many coins at once. mint -> SOL per token.
  // DexScreener returns at most 30 pools per call across all the coins asked, so ask 5 coins at a time.
  async pricesSol(mints, solUsd) {
    const out = {};
    for (let i = 0; i < mints.length; i += 5) {
      const chunk = mints.slice(i, i + 5);
      const j = await fetchJson(`${this.dexApi}/latest/dex/tokens/${chunk.join(',')}`, { timeout: 5000 }).catch(() => null);
      const best = {};
      for (const p of j?.pairs || []) {
        const m = p.baseToken?.address;
        if (!chunk.includes(m)) continue;
        let px = null;
        if (p.quoteToken?.address === 'So11111111111111111111111111111111111111112' || p.quoteToken?.symbol === 'SOL') px = +p.priceNative;
        else if (+p.priceUsd > 0 && solUsd > 0) px = +p.priceUsd / solUsd;
        if (!(px > 0)) continue;
        const liq = +p.liquidity?.usd || 0;
        if (!best[m] || liq > best[m].liq) best[m] = { px, liq, p };
      }
      for (const [m, b] of Object.entries(best)) {
        out[m] = b.px;
        // trading activity from the same answer (no extra calls): used to spot dead coins
        const t = b.p.txns || {};
        const v = b.p.volume || {};
        (this.activity ||= new Map()).set(m, {
          at: Date.now(),
          buysM5: +t.m5?.buys || 0,
          sellsM5: +t.m5?.sells || 0,
          buysH1: +t.h1?.buys || 0,
          sellsH1: +t.h1?.sells || 0,
          volM5: +v.m5 || 0,
          volH1: +v.h1 || 0,
          liq: b.liq,
        });
      }
    }
    return out;
  }

  // fresh=true re-fetches market cap if the cached one is older than 15s.
  async get(mint, { hint, fresh = true, timeoutMs = 2500 } = {}) {
    if (hint) this.remember(mint, hint);
    const cached = this.cache.get(mint);
    if (cached?.name && (!fresh || Date.now() - (cached.mcAt || 0) < 15000)) return this._withAge(cached);
    const info = await withTimeout(
      (async () => {
        try {
          const p = await this._fromPump(mint);
          if (p) return p;
        } catch (e) {
          log.debug('pump coin lookup failed', mint.slice(0, 6), e.message);
        }
        let dex = null;
        try {
          dex = await this._fromDex(mint);
        } catch (e) {
          log.debug('dex lookup failed', mint.slice(0, 6), e.message);
        }
        if (dex?.name) return dex;
        try {
          const das = await this._fromDas(mint);
          if (das) return { ...das, ...(dex?.mc ? { mc: dex.mc, mcAt: dex.mcAt, createdAt: dex.createdAt } : {}) };
        } catch (e) {
          log.debug('helius asset lookup failed', mint.slice(0, 6), e.message);
        }
        return dex;
      })(),
      timeoutMs,
      null,
    );
    if (info) this.remember(mint, info);
    return this._withAge(this.cache.get(mint) || { name: null, symbol: null });
  }

  _withAge(c) {
    return { ...c, ageMs: c.createdAt ? Date.now() - c.createdAt : null };
  }
}
