// Gets back the ~0.002 SOL "rent" each coin's token account holds, once the bot has sold out of it.
// Only empty accounts of coins the bot traded are closed, never one with tokens left in it
// (the token program refuses that anyway), and never one for a coin we're still buying or holding.
import { b58decode } from './solana.js';
import { log } from './log.js';

export const TOKEN_PROGRAM = 'TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA';
export const TOKEN_2022 = 'TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb';
const WSOL = 'So11111111111111111111111111111111111111112';
const CLOSE_ACCOUNT = 9;
const MAX_PER_TX = 8;

function shortVec(n) {
  const out = [];
  for (;;) {
    let b = n & 0x7f;
    n >>= 7;
    if (n) b |= 0x80;
    out.push(b);
    if (!n) return out;
  }
}

// Legacy transaction: owner pays the fee and receives the rent of every closed account.
// accounts: [{ pubkey, programId }]
export function buildCloseTx(owner, accounts, blockhash) {
  if (!accounts.length || accounts.length > MAX_PER_TX) throw new Error('bad account count');
  const programs = [...new Set(accounts.map((a) => a.programId))];
  const keys = [owner, ...accounts.map((a) => a.pubkey), ...programs];
  if (new Set(keys).size !== keys.length) throw new Error('duplicate accounts');
  const idx = (k) => keys.indexOf(k);
  const msg = [];
  msg.push(1, 0, programs.length); // 1 signer (writable), 0 read-only signers, programs read-only
  msg.push(...shortVec(keys.length));
  for (const k of keys) msg.push(...b58decode(k));
  const bh = b58decode(blockhash);
  if (bh.length !== 32) throw new Error('bad blockhash');
  msg.push(...bh);
  msg.push(...shortVec(accounts.length));
  for (const a of accounts) {
    msg.push(idx(a.programId));
    msg.push(...shortVec(3), idx(a.pubkey), idx(owner), idx(owner)); // account, destination, owner
    msg.push(...shortVec(1), CLOSE_ACCOUNT);
  }
  return Uint8Array.from([...shortVec(1), ...new Uint8Array(64), ...msg]);
}

export class RentReclaimer {
  constructor({ rpc, swapper, owner, isBusy, isOurs = () => true, notify, minAgeMs = 120000 }) {
    this.isOurs = isOurs; // only coins the bot itself traded
    this.rpc = rpc;
    this.swapper = swapper;
    this.owner = owner;
    this.isBusy = isBusy; // mint -> true while we hold / are buying it
    this.notify = notify;
    this.minAgeMs = minAgeMs;
    this.emptySince = new Map(); // account -> first time we saw it empty
    this.failures = new Map();
    this.total = 0;
    this.running = false;
  }

  async findEmpty() {
    const out = [];
    for (const programId of [TOKEN_PROGRAM, TOKEN_2022]) {
      const r = await this.rpc.call('getTokenAccountsByOwner', [this.owner, { programId }, { encoding: 'jsonParsed', commitment: 'confirmed' }]);
      for (const a of r?.value || []) {
        const info = a.account?.data?.parsed?.info;
        if (!info || info.mint === WSOL || info.isNative) continue;
        if (info.state !== 'initialized' || info.tokenAmount?.amount !== '0') continue;
        if (info.closeAuthority && info.closeAuthority !== this.owner) continue;
        const ext = info.extensions || [];
        if (ext.some((x) => x.extension === 'transferFeeAmount' && +x.state?.withheldAmount > 0)) continue;
        out.push({ pubkey: a.pubkey, mint: info.mint, programId, lamports: a.account.lamports || 0 });
      }
    }
    return out;
  }

  // One pass: close empty accounts that have been empty for a couple of minutes.
  async run() {
    if (this.running) return 0;
    this.running = true;
    try {
      const now = Date.now();
      const empty = await this.findEmpty();
      const seen = new Set(empty.map((a) => a.pubkey));
      for (const k of this.emptySince.keys()) if (!seen.has(k)) this.emptySince.delete(k);
      const ready = empty.filter((a) => {
        if (!this.emptySince.has(a.pubkey)) this.emptySince.set(a.pubkey, now);
        return now - this.emptySince.get(a.pubkey) >= this.minAgeMs && this.isOurs(a.mint) && !this.isBusy(a.mint) && (this.failures.get(a.pubkey) || 0) < 3;
      });
      if (!ready.length) return 0;
      // accounts that failed before go one per transaction, so one bad account can't block the rest
      const batches = [];
      const solo = ready.filter((a) => this.failures.has(a.pubkey));
      const rest = ready.filter((a) => !this.failures.has(a.pubkey));
      for (const a of solo) batches.push([a]);
      for (let i = 0; i < rest.length; i += MAX_PER_TX) batches.push(rest.slice(i, i + MAX_PER_TX));
      let got = 0;
      let closed = 0;
      for (const b of batches) {
        if (b.some((a) => this.isBusy(a.mint))) continue;
        try {
          const bh = await this.rpc.call('getLatestBlockhash', [{ commitment: 'confirmed' }]);
          const tx = buildCloseTx(this.owner, b, bh.value.blockhash);
          const r = await this.swapper.send(tx);
          const sol = b.reduce((s, a) => s + a.lamports, 0) / 1e9;
          got += sol;
          closed += b.length;
          for (const a of b) this.emptySince.delete(a.pubkey);
          log.info(`Reclaimed ${sol.toFixed(5)} SOL rent from ${b.length} empty token account(s) (${r.sig})`);
        } catch (err) {
          for (const a of b) this.failures.set(a.pubkey, (this.failures.get(a.pubkey) || 0) + 1);
          log.warn(`Couldn't close ${b.length} empty token account(s): ${err.message}`);
        }
      }
      if (closed) {
        this.total += got;
        await this.notify?.(`♻️ Got back <b>${got.toFixed(4)} SOL</b> from ${closed} empty coin account${closed > 1 ? 's' : ''} (coins the bot sold out of).`);
      }
      return got;
    } finally {
      this.running = false;
    }
  }
}
