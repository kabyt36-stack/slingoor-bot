import fs from 'node:fs';
import path from 'node:path';
import { BoundedSet } from './util.js';
import { log } from './log.js';

// Everything the bot needs to remember between restarts.
export class State {
  constructor(file) {
    this.file = file;
    this.chats = [];
    this.seenTrades = new BoundedSet(4000);
    this.seenCallouts = {}; // calloutId -> updateCount
    this.seenUpdates = new BoundedSet(3000);
    this.createdMints = new BoundedSet(5000);
    this.positions = {}; // mint -> {ui, symbol, name, solIn, solOut, buys, sells, openedAt, cycleId}
    this.recent = []; // last alerts (short text)
    this.callers = {}; // wallet -> {userId, username}
    this.launchSeeded = false;
    this.calloutsSeeded = false;
    this.tradesSeeded = false;
    this._timer = null;
    this.load();
  }

  load() {
    let j = null;
    for (const f of [this.file, this.file + '.tmp']) {
      try {
        if (fs.existsSync(f)) j = JSON.parse(fs.readFileSync(f, 'utf8'));
        if (j) break;
      } catch (e) {
        log.warn(`Could not read ${f} (${e.message})`);
      }
    }
    if (!j) return;
    try {
      this.chats = j.chats || [];
      this.seenTrades = new BoundedSet(4000, j.seenTrades || []);
      this.seenCallouts = j.seenCallouts || {};
      this.seenUpdates = new BoundedSet(3000, j.seenUpdates || []);
      this.createdMints = new BoundedSet(5000, j.createdMints || []);
      this.positions = j.positions || {};
      this.recent = j.recent || [];
      this.callers = j.callers || {};
      this.launchSeeded = !!j.launchSeeded;
      this.calloutsSeeded = !!j.calloutsSeeded;
      this.tradesSeeded = !!j.tradesSeeded;
    } catch (e) {
      log.warn('Could not read state file, starting fresh:', e.message);
    }
  }

  // Batches writes: at most one save every 500ms, and a pending save is never postponed.
  save() {
    if (this._timer) return;
    this._timer = setTimeout(() => this.saveNow(), 500);
  }

  saveNow() {
    clearTimeout(this._timer);
    this._timer = null;
    try {
      fs.mkdirSync(path.dirname(this.file), { recursive: true });
      const data = {
        chats: this.chats,
        seenTrades: this.seenTrades.toJSON(),
        seenCallouts: this.seenCallouts,
        seenUpdates: this.seenUpdates.toJSON(),
        createdMints: this.createdMints.toJSON(),
        positions: this.positions,
        recent: this.recent.slice(-60),
        callers: this.callers,
        launchSeeded: this.launchSeeded,
        calloutsSeeded: this.calloutsSeeded,
        tradesSeeded: this.tradesSeeded,
      };
      const tmp = this.file + '.tmp';
      fs.writeFileSync(tmp, JSON.stringify(data));
      fs.renameSync(tmp, this.file);
    } catch (e) {
      log.error('Could not save state:', e.message);
    }
  }

  pushRecent(line) {
    this.recent.push({ t: Date.now(), line });
    if (this.recent.length > 60) this.recent.splice(0, this.recent.length - 60);
    this.save();
  }
}
