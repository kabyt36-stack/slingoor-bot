import fs from 'node:fs';
import path from 'node:path';
import { redact } from './util.js';

let logFile = null;
const MAX = 5 * 1024 * 1024;

export function setLogFile(file) {
  logFile = file;
  try {
    fs.mkdirSync(path.dirname(file), { recursive: true });
  } catch {}
}

function write(level, args) {
  const ts = new Date().toISOString().replace('T', ' ').slice(0, 19);
  const msg = args
    .map((a) => (a instanceof Error ? a.message : typeof a === 'object' ? JSON.stringify(a) : String(a)))
    .join(' ');
  const line = redact(`[${ts}] ${level} ${msg}`);
  (level === 'ERR' ? console.error : console.log)(line);
  if (!logFile) return;
  try {
    if (fs.existsSync(logFile) && fs.statSync(logFile).size > MAX) fs.renameSync(logFile, `${logFile}.old`);
    fs.appendFileSync(logFile, line + '\n');
  } catch {}
}

export const log = {
  info: (...a) => write('INF', a),
  warn: (...a) => write('WRN', a),
  error: (...a) => write('ERR', a),
  debug: (...a) => {
    if (process.env.DEBUG) write('DBG', a);
  },
};
