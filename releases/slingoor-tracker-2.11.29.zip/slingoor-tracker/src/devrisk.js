// V2.11.23 dev check (Khalil, Nov 13 10:22-10:27am: "look at the devs of the coins ... if it's a newer dev the
// probability of a rug is very high" / "just make sure the dev wallet has prior trades, doesn't matter the size").
// Before a copy buy, the coin's creator is looked up on pump.fun:
//   fresh : his wallet has no trades before this coin   -> rug risk: the main wallet skips it, side wallets buy and
//           get out fast (+10% to +25%)
//   ok    : he has prior trades (any size)              -> normal
// It also notes how many coins he made and how many graduated (shown, not used). It learns: every coin's dev kind is
// remembered, and when the coin closes in the pretend wallets the bot counts how often each kind went to zero.
// Fresh devs stop counting as risky only if, after 20+ coins of each, their coins don't rug clearly more.
import fs from 'node:fs';
import path from 'node:path';

const DAY = 24 * 3600000;

export class DevRisk {
  constructor({ file, coins, pump, now = () => Date.now(), ttlMs = 30 * 60000 } = {}) {
    this.file = file;
    this.coins = coins; // .get(mint) -> { creator, ... }
    this.pump = pump; // .getCreatedCoins(wallet, limit) -> { count, coins: [{ complete, ... }] }
    this.now = now;
    this.ttlMs = ttlMs;
    this.devs = new Map(); // creator -> { at, n, grad }
    this.byMint = new Map(); // mint -> { at, kind, n, grad, creator } (lookup done)
    this.pending = new Map(); // mint -> promise
    this.d = { kinds: {}, outcomes: [] }; // mint -> kind (kept for learning), outcomes [{ kind, rug }]
    try {
      this.d = { ...this.d, ...JSON.parse(fs.readFileSync(file, 'utf8')) };
    } catch {}
    this._dirty = false;
  }

  save(force) {
    if (!this.file || (!this._dirty && !force)) return;
    this._dirty = false;
    try {
      fs.mkdirSync(path.dirname(this.file), { recursive: true });
      fs.writeFileSync(this.file + '.tmp', JSON.stringify(this.d));
      fs.renameSync(this.file + '.tmp', this.file);
    } catch {}
  }

  // priorTrades: his trades on other coins than this one (null = couldn't tell)
  static kindOf(priorTrades) {
    if (priorTrades == null) return null;
    return priorTrades > 0 ? 'ok' : 'fresh';
  }

  // his prior trades: how many, and on how many of his own earlier coins he sold within 30 min of launching it
  static dumps(created, trades, mint) {
    const mine = new Map(created.filter((c) => c?.mint && c.mint !== mint).map((c) => [c.mint, +c.created_timestamp || 0]));
    const seen = new Set();
    let dumped = 0;
    for (const t of trades) {
      if (t?.isBuy || !mine.has(t?.mint) || seen.has(t.mint)) continue;
      const at = Date.parse(t.timestamp) || (+t.timestamp > 1e12 ? +t.timestamp : +t.timestamp * 1000) || 0;
      const born = mine.get(t.mint);
      if (born && at && at - born <= 30 * 60000) {
        seen.add(t.mint);
        dumped++;
      }
    }
    // prior = his earlier coins we can see trades for
    const traded = new Set(trades.filter((t) => mine.has(t?.mint)).map((t) => t.mint));
    return { dumped, prior: traded.size };
  }

  // start the lookup (cheap to call again: one per coin, devs cached 30 min)
  check(mint) {
    if (!mint) return Promise.resolve(null);
    const done = this.byMint.get(mint);
    if (done) return Promise.resolve(done);
    if (this.pending.has(mint)) return this.pending.get(mint);
    const p = (async () => {
      const c = await Promise.resolve(this.coins?.get?.(mint)).catch(() => null);
      const creator = c?.creator;
      if (!creator) return null;
      let dev = this.devs.get(creator);
      if (!dev || this.now() - dev.at > this.ttlMs) {
        const [r, ut] = await Promise.all([
          Promise.resolve(this.pump?.getCreatedCoins?.(creator, 50)).catch(() => null),
          Promise.resolve(this.pump?.getUserTrades?.(creator, 100)).catch(() => null),
        ]);
        if (!r && !ut) return null;
        const list = Array.isArray(r?.coins) ? r.coins : [];
        const trades = Array.isArray(ut?.trades) ? ut.trades : null;
        const dd = trades ? DevRisk.dumps(list, trades, mint) : { dumped: 0, prior: 0 };
        dev = { at: this.now(), n: Math.max(r?.count || 0, list.length), grad: list.filter((x) => x?.complete).length, trades: trades ? trades.filter((t) => t?.mint !== mint).length : null, ...dd };
        this.devs.set(creator, dev);
        if (this.devs.size > 3000) this.devs.delete(this.devs.keys().next().value);
      }
      const out = { at: this.now(), kind: DevRisk.kindOf(dev.trades), n: dev.n, grad: dev.grad, trades: dev.trades, dumped: dev.dumped, prior: dev.prior, creator };
      this.byMint.set(mint, out);
      if (this.byMint.size > 3000) this.byMint.delete(this.byMint.keys().next().value);
      if (out.kind) {
        this.d.kinds[mint] = { kind: out.kind, at: this.now() };
        this._dirty = true;
      }
      return out;
    })().finally(() => this.pending.delete(mint));
    this.pending.set(mint, p);
    return p;
  }

  // what's known right now (no waiting)
  known(mint) {
    return this.byMint.get(mint) || null;
  }

  // a coin closed in the pretend wallets (main): x = what came back / what went in
  outcome(mint, x) {
    const k = this.d.kinds[mint];
    if (!k || !(x >= 0)) return;
    delete this.d.kinds[mint];
    this.d.outcomes.push({ kind: k.kind, rug: x < 0.5 });
    if (this.d.outcomes.length > 3000) this.d.outcomes.splice(0, this.d.outcomes.length - 3000);
    this._dirty = true;
  }

  // forget coins that never closed (a day old)
  prune() {
    const t = this.now();
    for (const [m, k] of Object.entries(this.d.kinds)) if (t - k.at > DAY) delete this.d.kinds[m];
  }

  stats() {
    const s = {};
    for (const o of this.d.outcomes) {
      const r = (s[o.kind] ||= { coins: 0, rugs: 0 });
      r.coins++;
      if (o.rug) r.rugs++;
    }
    return s;
  }

  // is this kind of dev risky right now? Learned once 20+ coins of it and of "ok" devs closed
  risky(kind) {
    if (kind !== 'fresh') return false;
    const s = this.stats();
    const k = s[kind];
    const ok = s.ok;
    if (!k || k.coins < 20 || !ok || ok.coins < 20) return true;
    return k.rugs / k.coins >= 1.5 * (ok.rugs / ok.coins) && k.rugs / k.coins >= 0.2;
  }

  text() {
    const s = this.stats();
    const names = { fresh: 'fresh dev', ok: 'dev with history' };
    const parts = Object.entries(names)
      .filter(([k]) => s[k]?.coins)
      .map(([k, label]) => `${label} ${Math.round((100 * s[k].rugs) / s[k].coins)}% (${s[k].coins})`);
    return parts.length ? `🧑‍💻 Rugs by dev: ${parts.join(' · ')}` : '';
  }
}
