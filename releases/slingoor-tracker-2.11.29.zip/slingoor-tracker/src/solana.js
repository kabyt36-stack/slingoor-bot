// Just enough Solana to sign a transaction someone else built: base58, ed25519 keys and
// putting our signature in the right slot of a (legacy or versioned) transaction. No dependencies.
import crypto from 'node:crypto';

const ALPHA = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
const MAP = Object.fromEntries([...ALPHA].map((c, i) => [c, BigInt(i)]));

export function b58encode(bytes) {
  let n = 0n;
  for (const b of bytes) n = (n << 8n) | BigInt(b);
  let s = '';
  while (n > 0n) {
    s = ALPHA[Number(n % 58n)] + s;
    n /= 58n;
  }
  for (const b of bytes) {
    if (b !== 0) break;
    s = '1' + s;
  }
  return s;
}

export function b58decode(str) {
  let n = 0n;
  for (const c of str) {
    const v = MAP[c];
    if (v == null) throw new Error('not base58');
    n = n * 58n + v;
  }
  const out = [];
  while (n > 0n) {
    out.unshift(Number(n & 0xffn));
    n >>= 8n;
  }
  for (const c of str) {
    if (c !== '1') break;
    out.unshift(0);
  }
  return Uint8Array.from(out);
}

const PKCS8_PREFIX = Buffer.from('302e020100300506032b657004220420', 'hex');

// Accepts what wallets export: base58 (Phantom/Solflare/Backpack "private key"), or a JSON
// array of 64 numbers (solana-keygen id.json). Returns {publicKey (base58), sign(msg)}.
export function loadKeypair(text) {
  const s = String(text || '').trim().replace(/^["'“”]+|["'“”]+$/g, '');
  if (!s) throw new Error('no private key');
  let bytes;
  if (s.startsWith('[')) {
    let arr;
    try {
      arr = JSON.parse(s);
    } catch {
      throw new Error('private key looks like a list of numbers but is not valid');
    }
    bytes = Uint8Array.from(arr);
  } else {
    try {
      bytes = b58decode(s);
    } catch {
      throw new Error('private key has characters that are not allowed (it should be the base58 key your wallet exports)');
    }
  }
  if (bytes.length !== 64 && bytes.length !== 32) throw new Error(`private key has the wrong length (${bytes.length} bytes, expected 64) — paste the full key from your wallet`);
  const seed = bytes.slice(0, 32);
  const key = crypto.createPrivateKey({ key: Buffer.concat([PKCS8_PREFIX, Buffer.from(seed)]), format: 'der', type: 'pkcs8' });
  const pub = crypto.createPublicKey(key).export({ format: 'der', type: 'spki' }).subarray(-32);
  if (bytes.length === 64 && !Buffer.from(bytes.slice(32)).equals(pub)) throw new Error('private key is damaged (its two halves do not match) — copy it again from your wallet');
  return {
    publicKey: b58encode(pub),
    publicKeyBytes: Uint8Array.from(pub),
    sign: (msg) => Uint8Array.from(crypto.sign(null, Buffer.from(msg), key)),
  };
}

function readShortVec(buf, off) {
  let len = 0;
  let size = 0;
  for (;;) {
    const b = buf[off + size];
    len |= (b & 0x7f) << (7 * size);
    size++;
    if ((b & 0x80) === 0) break;
    if (size > 3) throw new Error('bad transaction');
  }
  return [len, size];
}

// Splits a wire transaction into signatures / message and lists the signer keys.
export function parseTx(bytes) {
  const buf = Uint8Array.from(bytes);
  const [nSig, l1] = readShortVec(buf, 0);
  const sigStart = l1;
  const msgStart = sigStart + nSig * 64;
  if (msgStart > buf.length) throw new Error('bad transaction');
  let o = msgStart;
  const versioned = (buf[o] & 0x80) !== 0;
  if (versioned) o++;
  const numRequired = buf[o];
  o += 3;
  const [nKeys, l2] = readShortVec(buf, o);
  o += l2;
  const keys = [];
  for (let i = 0; i < nKeys; i++) keys.push(buf.slice(o + i * 32, o + i * 32 + 32));
  return { buf, nSig, sigStart, msgStart, numRequired, keys: keys.map((k) => b58encode(k)), versioned };
}

// Signs as `kp` and returns the signed wire bytes and the transaction id (= our signature).
export function signTx(bytes, kp) {
  const t = parseTx(bytes);
  const idx = t.keys.slice(0, t.numRequired).indexOf(kp.publicKey);
  if (idx < 0) throw new Error('this transaction is not for our wallet');
  if (idx >= t.nSig) throw new Error('bad transaction (missing signature slot)');
  const sig = kp.sign(t.buf.subarray(t.msgStart));
  const out = Uint8Array.from(t.buf);
  out.set(sig, t.sigStart + idx * 64);
  // every other required signature must already be present (none are, for our swaps)
  for (let i = 0; i < t.numRequired; i++) {
    if (i === idx) continue;
    if (out.subarray(t.sigStart + i * 64, t.sigStart + i * 64 + 64).every((b) => b === 0)) throw new Error('transaction needs another signer');
  }
  return { bytes: out, sig: b58encode(sig), feePayer: t.keys[0] };
}

export function verifyTxSignature(bytes, publicKey) {
  const t = parseTx(bytes);
  const idx = t.keys.indexOf(publicKey);
  const sig = t.buf.subarray(t.sigStart + idx * 64, t.sigStart + idx * 64 + 64);
  const spki = Buffer.concat([Buffer.from('302a300506032b6570032100', 'hex'), Buffer.from(b58decode(publicKey))]);
  return crypto.verify(null, Buffer.from(t.buf.subarray(t.msgStart)), crypto.createPublicKey({ key: spki, format: 'der', type: 'spki' }), Buffer.from(sig));
}
