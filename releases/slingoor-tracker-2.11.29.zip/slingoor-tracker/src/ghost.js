// V2.9.9 ghost wallets: every tracked trader is copied by two pretend wallets of its own, without any SOL
// or any trade ever being sent:
//   main-style  (0.1 SOL per coin): follows his sells (10%+), his exit, the -20% stop loss, the safety-net
//               mini cook of his sell rules, and the 8h limit — like your main wallet
//   side-style  (0.05 SOL per coin): sells 100% at +25%, at -20%, or when he's out — like your side wallets
// Fills are estimated: his price + COPY delay (we land ~1.5s after him) + the real fee cap on each trade.
// Prices come from the same price site the bot already uses, in a background pass that never touches
// Jupiter, so real and paper trading are never slowed down.
import fs from 'node:fs';
import path from 'node:path';
import { log } from './log.js';

// V2.9.10 four pretend wallets per trader, like your real set: a main + 3 sides (sides buy a moment after
// the main, like the real ones: +2% more on their price)
const STYLES = {
  main: { sol: 0.1 },
  W2: { sol: 0.05, tpX: 1.25, side: true, late: 1.02 },
  W3: { sol: 0.05, tpX: 1.25, side: true, late: 1.02 },
  W4: { sol: 0.05, tpX: 1.25, side: true, late: 1.02 },
  // V2.11 test exits (not part of the 4-wallet totals): same coins, other ways of selling, so the bot can
  // pick the exit that makes the most per trader. All of them still sell on his exit, the stop loss and 8h.
  t15: { sol: 0.05, test: true, rule: { from: 1.5, to: 1.5, pull: 1, pct: 100 }, label: 'sell all at 1.5x' },
  t2: { sol: 0.05, test: true, rule: { from: 2, to: 2, pull: 1, pct: 100 }, label: 'sell all at 2x' },
  trail: { sol: 0.05, test: true, rule: { from: 1.3, to: 100, pull: 20, pct: 100 }, label: 'ride it, sell 20% off the top (after 1.3x)' },
  xb: { sol: 0.05, test: true, before: true, label: 'sell half just before where he usually sells' },
};
const SIDES = Object.keys(STYLES).filter((k) => STYLES[k].side);
const isTest = (style) => !!STYLES[style]?.test;
export const EXIT_STYLES = STYLES;

// V2.9.12 market-cap ranges: which ones each trader makes money in
export const MC_BANDS = [
  [0, 10000, '<$10k'],
  [10000, 30000, '$10-30k'],
  [30000, 100000, '$30-100k'],
  [100000, 500000, '$100-500k'],
  [500000, Infinity, '$500k+'],
];
export const hourName = (h) => `${h % 12 || 12}${h < 12 ? 'am' : 'pm'}`;
export const bandOf = (mc) => (mc > 0 ? MC_BANDS.find(([a, b]) => mc >= a && mc < b)?.[2] : null);

export class GhostBook {
  constructor({ file, now = () => Date.now(), fee = 0.000505, entryPenaltyPct = 5, stopLossX = 0.8, maxHoldMs = 8 * 3600000, rulesFor = () => ({}), maxOpen = 300, solUsd = () => 0, accept = () => true, onMainClose = () => {}, runnerX = 2, runnerForce = {}, afterMs = 6 * 3600000, sideRule = { from: 1.25, to: 1.25, pull: 1 } }) {
    this.sideRule = sideRule;
    this.afterMs = afterMs; // V2.11.19 how long after a trader's buy a coin still counts as his runner
    this.runnerForce = runnerForce; // V2.11.18 trader -> runner rate you set (kimchi: 0.99), instead of learned
    this.onMainClose = onMainClose; // V2.11.23 (mint, x) a coin's main pretend wallet closed (dev check learns from it)
    this.runnerX = runnerX; // V2.11.16 a coin that went this x from a trader's buy = a runner
    this.accept = accept; // (trader, mc) -> would the bot copy this buy at all (his own filters, e.g. cupsey's max MC)
    this.solUsd = solUsd; // for the market cap at the buy (pump.fun coins: 1B supply)
    this.file = file;
    this.now = now;
    this.fee = fee; // per trade (real priority-fee cap + base fee)
    this.entryPenalty = 1 + entryPenaltyPct / 100; // we buy after him: a bit higher than his fill
    this.stopLossX = stopLossX;
    this.maxHoldMs = maxHoldMs;
    this.rulesFor = rulesFor; // trader -> his sell rules (mini cook settings)
    this.maxOpen = maxOpen;
    this.d = { open: {}, closed: [], since: this.now() };
    try {
      this.d = { ...this.d, ...JSON.parse(fs.readFileSync(file, 'utf8')) };
    } catch {}
    this._dirty = false;
  }

  save(force) {
    if (!this._dirty && !force) return;
    if (!force && this._savedAt && this.now() - this._savedAt < 60000) return;
    this._savedAt = this.now();
    this._dirty = false;
    try {
      fs.mkdirSync(path.dirname(this.file), { recursive: true });
      fs.writeFileSync(this.file + '.tmp', JSON.stringify(this.d));
      fs.renameSync(this.file + '.tmp', this.file);
    } catch (err) {
      log.warn('ghost save failed', err.message);
    }
  }

  reset() {
    this.d = { open: {}, closed: [], since: this.now() };
    this._dirty = true;
    this.save(true);
  }

  // he bought (ENTRY): both ghost wallets of his buy at his price + the delay penalty
  // priceSol unknown: the ghosts buy at the first price the bot sees for the coin (a bit later than him)
  open(trader, mint, priceSol, sym = null) {
    if (!trader || !mint) return false;
    if (!(priceSol > 0)) priceSol = null;
    if (priceSol && this.solUsd() > 0 && !this.accept(trader, priceSol * 1e9 * this.solUsd())) return false;
    if (Object.keys(this.d.open).length >= this.maxOpen * Object.keys(STYLES).length) return false;
    const beforeX = this.beforeX(trader);
    let opened = false;
    for (const style of Object.keys(STYLES)) {
      const key = `${trader}|${style}|${mint}`;
      if (this.d.open[key]) continue;
      if (this.d.closed.some((c) => c.key === key)) continue; // one buy per coin, like the real bot
      const entry = priceSol ? priceSol * this.entryPenalty * (STYLES[style].late || 1) : null;
      const mc = priceSol && this.solUsd() > 0 ? priceSol * 1e9 * this.solUsd() : null; // his market cap when he bought
      this.d.open[key] = { key, trader, style, mint, sym, entry, mc, left: 1, got: 0, cost: STYLES[style].sol + this.fee, at: this.now(), peak: 1, low: 0, ...(style === 'main' && priceSol ? { his: priceSol } : {}), ...(STYLES[style].before && beforeX ? { beforeX } : {}) };
      opened = true;
    }
    if (opened) this._dirty = true;
    return opened;
  }

  // he sold part (pct of his bag) or all
  hisSell(trader, mint, pct, out) {
    for (const g of Object.values(this.d.open)) {
      if (g.trader !== trader || g.mint !== mint) continue;
      const px = g.lastPx;
      if (!(px > 0)) {
        if (out) g.hisOut = true; // sell at the next price we get
        continue;
      }
      if (out && g.style === 'main' && g.his > 0) this._noteExit(trader, px / g.his);
      if (isTest(g.style)) {
        if (out) this._sell(g, 1, px, 'his exit');
        continue;
      }
      if (out || STYLES[g.style]?.side) {
        if (out || pct >= 10) this._sell(g, 1, px, out ? 'his exit' : 'he sold');
      } else if (pct >= 10) this._sell(g, Math.min(1, pct / 100), px, 'he sold');
    }
  }

  // coins to price: every open pretend wallet + V2.11.19 coins still in their after-window (did it run after he sold?)
  watching() {
    this._afterExpire();
    return [...new Set([...Object.values(this.d.open).map((g) => g.mint), ...Object.keys(this.d.after || {})])];
  }

  // V2.11.19 a trader "picked a runner" when the coin went 2x+ from his buy within AFTER_MS of it — even if he sold
  // first (UwU: t25 bought at $8k, sold at $6k, then it went to $320k). His runner % counts it.
  _afterExpire() {
    const t = this.now();
    for (const [m, a] of Object.entries(this.d.after || {})) {
      if (t < a.until) continue;
      delete this.d.after[m];
      this._outcome(m, true);
    }
  }

  _afterPrice(mint, px) {
    const a = this.d.after?.[mint];
    if (!a || !(px > 0)) return;
    for (const e of a.list) {
      if (!(e.entry > 0)) continue;
      const x = px / e.entry;
      for (let i = this.d.closed.length - 1, n = 0; i >= 0 && n < 2000; i--, n++) {
        const c = this.d.closed[i];
        if (c.key !== e.key) continue;
        if (x > (c.peak || 0)) {
          c.peak = Math.round(x * 1000) / 1000;
          this._dirty = true;
        }
        break;
      }
    }
  }

  // a price (SOL per token) for a coin some ghosts hold: run the sell rules
  price(mint, px) {
    if (!(px > 0)) return;
    this._afterPrice(mint, px);
    for (const g of Object.values(this.d.open)) {
      if (g.mint !== mint) continue;
      if (!(g.entry > 0)) {
        g.entry = px * (STYLES[g.style]?.late || 1); // first price we got = its buy (already later than his)
        g.at = this.now();
        if (g.style === 'main' && !g.his) g.his = px;
        if (!g.mc && this.solUsd() > 0) g.mc = px * 1e9 * this.solUsd();
      }
      g.lastPx = px;
      const x = px / g.entry;
      g.peak = Math.max(g.peak, x);
      if (g.hisOut) {
        if (g.style === 'main' && g.his > 0) this._noteExit(g.trader, px / g.his);
        this._sell(g, 1, px, 'his exit');
        continue;
      }
      // stop loss: twice in a row, after 60s (same guard as the real bot)
      if (x <= this.stopLossX && this.now() - g.at > 60000) {
        if ((g.low || 0) >= 1) {
          this._sell(g, 1, px, 'stop loss');
          continue;
        }
        g.low = (g.low || 0) + 1;
      } else g.low = 0;
      // test exits: sell pct% once it reaches `to`, or pulls back `pull`% from its top after reaching `from`
      const T = STYLES[g.style]?.rule || (g.beforeX ? { from: g.beforeX, to: g.beforeX, pull: 1, pct: 50 } : null);
      if (T && isTest(g.style) && !g.miniDone) {
        if (x >= T.from) g.armed = true;
        if (g.armed) {
          g.mpk = Math.max(g.mpk || 0, x);
          if (x >= T.to || (x <= g.mpk * (1 - T.pull / 100) && x > 1.05)) {
            g.miniDone = true;
            this._sell(g, T.pct / 100, px, 'test exit');
            continue;
          }
        }
      }
      // side wallets: V2.11.21 like the real ones — armed at sideRule.from, sold all at sideRule.to or once it pulls
      // back sideRule.pull% from its top (default the old +25%)
      if (STYLES[g.style]?.side) {
        const S = this.sideRule;
        if (x >= S.from) g.sArmed = true;
        if (g.sArmed) {
          g.sPeak = Math.max(g.sPeak || 0, x);
          if (x >= S.to || (x <= g.sPeak * (1 - S.pull / 100) && x > 1.05)) {
            this._sell(g, 1, px, S.to > S.from ? 'side profit' : '+25%');
            continue;
          }
        }
      }
      if (g.style === 'main') {
        const R = this.rulesFor(g.trader) || {};
        if (R.miniToX > 0 && !g.miniDone) {
          const from = R.miniFromX ?? 1.5;
          const pull = (R.miniPullbackPct ?? 12) / 100;
          if (g.peak >= from && (x >= R.miniToX || x <= g.peak * (1 - pull))) {
            g.miniDone = true;
            this._sell(g, Math.min(1, (R.miniPct ?? 100) / 100), px, 'safety net');
            continue;
          }
        }
      }
      if (this.now() - g.at > this.maxHoldMs) this._sell(g, 1, px, '8h limit');
    }
  }

  _sell(g, part, px, why) {
    const share = Math.min(g.left, g.left * part);
    if (!(share > 0)) return;
    const solIn = (STYLES[g.style] || STYLES.W2).sol;
    g.got += solIn * share * (px / g.entry) - this.fee;
    g.left -= share;
    this._dirty = true;
    if (g.left > 1e-6) return;
    delete this.d.open[g.key];
    // V2.11.6 all-time PnL per trader (your 4 pretend wallets, never trimmed)
    if (!isTest(g.style)) (this.d.life ||= {})[g.trader] = Math.round(((this.d.life?.[g.trader] || 0) + (g.got - g.cost)) * 1e6) / 1e6;
    this.d.closed.push({ key: g.key, trader: g.trader, style: g.style, sym: g.sym, pnl: +(g.got - g.cost).toFixed(6), x: +(g.got / g.cost).toFixed(3), why, at: this.now(), held: this.now() - g.at, ...(g.mc ? { mc: Math.round(g.mc) } : {}), ...(g.style === 'main' ? { peak: Math.round((g.peak || 1) * 1000) / 1000 } : {}) });
    if (g.style === 'main') {
      try {
        this.onMainClose(g.mint, g.cost > 0 ? g.got / g.cost : null);
      } catch {}
      // keep watching the coin until AFTER_MS after his buy, then decide if it ran
      const until = g.at + this.afterMs;
      if (this.afterMs > 0 && this.now() < until && g.entry > 0) {
        const a = ((this.d.after ||= {})[g.mint] ||= { until, list: [] });
        a.until = Math.max(a.until, until);
        a.list.push({ key: g.key, entry: g.entry });
        if (Object.keys(this.d.after).length > 600) {
          const oldest = Object.entries(this.d.after).sort((x, y) => x[1].until - y[1].until)[0][0];
          delete this.d.after[oldest];
          this._outcome(oldest, true);
        }
      } else this._outcome(g.mint);
    }
    if (this.d.closed.length > 8000) this.d.closed.splice(0, this.d.closed.length - 8000);
  }

  // ---- V2.11.16 runners (Khalil, Nov 13 7:49am): which wallets' coins become runners (2x+ from their buy),
  // and what that says about a coin when several tracked wallets are in it. Adapts as coins close.

  // runner share over all of the last 1000 coins (each trader's main pretend wallet)
  baseRate() {
    let n = 0;
    let r = 0;
    for (let i = this.d.closed.length - 1; i >= 0 && n < 1000; i--) {
      const c = this.d.closed[i];
      if (c.style !== 'main' || c.peak == null) continue;
      n++;
      if (c.peak >= this.runnerX) r++;
    }
    return { coins: n, rate: n ? r / n : 0 };
  }

  // one trader's runners over his last 50 coins
  runnerStats(trader, last = 50) {
    let coins = 0;
    let runners = 0;
    for (let i = this.d.closed.length - 1; i >= 0 && coins < last; i--) {
      const c = this.d.closed[i];
      if (c.trader !== trader || c.style !== 'main' || c.peak == null) continue;
      coins++;
      if (c.peak >= this.runnerX) runners++;
    }
    return { coins, runners };
  }

  // his runner rate, pulled toward the overall rate while he has few coins (5 coins' worth of the average)
  walletRate(trader, base = this.baseRate().rate) {
    if (this.runnerForce?.[trader] > 0) return Math.min(0.999, this.runnerForce[trader]);
    const s = this.runnerStats(trader);
    return (s.runners + 5 * base) / (s.coins + 5);
  }

  // tracked wallets holding this coin right now (their main pretend wallet is open)
  inCoin(mint) {
    const out = new Set();
    for (const g of Object.values(this.d.open)) if (g.mint === mint && g.style === 'main') out.add(g.trader);
    return [...out];
  }

  // chance this coin runs, from every tracked wallet in it (buyer included). Raw: any of them is right
  // (1 - product of misses); then corrected by what actually happened to past coins with as many wallets and a
  // similar raw chance (once 15+ such coins closed).
  runnerChance(mint, buyer) {
    const b = this.baseRate();
    const traders = [...new Set([buyer, ...this.inCoin(mint)].filter(Boolean))];
    const rates = traders.map((t) => this.walletRate(t, b.rate));
    const raw = 1 - rates.reduce((p, r) => p * (1 - r), 1);
    const k = traders.length;
    const kb = Math.min(3, k);
    const sb = Math.min(9, Math.floor(raw * 10));
    const same = (this.d.calib || []).filter((c) => Math.min(3, c.k) === kb && Math.min(9, Math.floor(c.s * 10)) === sb);
    const pct = same.length >= 15 ? same.filter((c) => c.r).length / same.length : raw;
    const forced = traders.filter((t) => this.runnerForce?.[t] >= 0.9);
    return { pct: forced.length ? Math.max(pct, raw) : pct, raw, k, traders, base: b.rate, ready: b.coins >= 50 || forced.length > 0, calibrated: same.length >= 15, forced };
  }

  // remember what was predicted for a coin (the latest, with the most wallets in it)
  notePred(mint, raw, k) {
    if (!mint) return;
    const p = ((this.d.preds ||= {})[mint] ||= { s: raw, k, at: this.now() });
    if (k >= p.k) Object.assign(p, { s: raw, k });
    const keys = Object.keys(this.d.preds);
    if (keys.length > 2000) for (const m of keys.slice(0, keys.length - 2000)) delete this.d.preds[m];
    this._dirty = true;
  }

  // the coin's last main pretend wallet closed: was it a runner? -> calibration
  _outcome(mint, final = false) {
    const p = this.d.preds?.[mint];
    if (!p || Object.values(this.d.open).some((g) => g.mint === mint && g.style === 'main')) return;
    if (!final && this.d.after?.[mint]) return; // still watching it
    let runner = false;
    for (let i = this.d.closed.length - 1, seen = 0; i >= 0 && seen < 400; i--, seen++) {
      const c = this.d.closed[i];
      if (c.style === 'main' && c.key.endsWith(`|${mint}`) && c.peak >= this.runnerX) runner = true;
    }
    (this.d.calib ||= []).push({ s: Math.round(p.s * 1000) / 1000, k: p.k, r: runner });
    if (this.d.calib.length > 3000) this.d.calib.splice(0, this.d.calib.length - 3000);
    delete this.d.preds[mint];
  }

  // V2.11.22 how long he usually holds (median, main pretend wallet, coins he sold himself; 10+ of them)
  medianHoldMs(trader, last = 30) {
    const h = [];
    for (let i = this.d.closed.length - 1; i >= 0 && h.length < last; i--) {
      const c = this.d.closed[i];
      if (c.trader === trader && c.style === 'main' && (c.why === 'his exit' || c.why === 'he sold') && c.held >= 0) h.push(c.held);
    }
    if (h.length < 10) return null;
    h.sort((a, b) => a - b);
    return h[Math.floor(h.length / 2)];
  }

  lifePnl(trader) {
    return this.d.life?.[trader] || 0;
  }

  // V2.11 (#1 sell before him) where he sells his winners: x of his own buy price at his exit, last 30
  _noteExit(trader, x) {
    if (!(x > 0) || !isFinite(x)) return;
    const a = ((this.d.exits ||= {})[trader] ||= []);
    a.push(Math.round(x * 1000) / 1000);
    if (a.length > 30) a.splice(0, a.length - 30);
    this._dirty = true;
  }

  // his usual winning exit (median of his exits above 1.05x); null until he has 8 of them
  typicalExit(trader) {
    const w = (this.d.exits?.[trader] || []).filter((x) => x > 1.05).sort((a, b) => a - b);
    if (w.length < 8) return null;
    return w[Math.floor(w.length / 2)];
  }

  // sell-before-him level, as x of OUR buy (we buy ~5% above him): 90% of the way to his usual exit, at
  // least 1.15x. null when he usually sells under 1.3x (nothing to get in front of) or there's no data yet.
  beforeX(trader) {
    const t = this.typicalExit(trader);
    if (!(t >= 1.3)) return null;
    return Math.round(Math.max(1.15, (0.9 * t) / this.entryPenalty) * 100) / 100;
  }

  // V2.11 (#3 his big bets) his buy sizes, last 50
  noteSize(trader, sol) {
    if (!trader || !(sol > 0)) return;
    const a = ((this.d.sizes ||= {})[trader] ||= []);
    a.push(Math.round(sol * 1e4) / 1e4);
    if (a.length > 50) a.splice(0, a.length - 50);
    this._dirty = true;
  }

  usualSize(trader) {
    const a = [...(this.d.sizes?.[trader] || [])].sort((x, y) => x - y);
    return a.length >= 10 ? a[Math.floor(a.length / 2)] : null;
  }

  // 'big' (2x+ his usual buy), 'small' (under 40% of it) or null (normal, or not enough data)
  betKind(trader, sol) {
    const u = this.usualSize(trader);
    if (!u || !(sol > 0)) return null;
    if (sol >= 2 * u) return 'big';
    if (sol <= 0.4 * u) return 'small';
    return null;
  }

  // V2.11 (#4 his best hours) per hour of the day (when the coin was bought): coins (main) and set PnL
  hourStats(trader) {
    const out = {};
    for (const c of this.d.closed) {
      if (c.trader !== trader || isTest(c.style)) continue;
      const h = new Date(c.at - (c.held || 0)).getHours();
      const r = (out[h] ||= { coins: 0, won: 0, pnl: 0 });
      if (c.style === 'main') {
        r.coins++;
        if (c.pnl > 0) r.won++;
      }
      r.pnl += c.pnl;
    }
    return out;
  }

  // copy his buy at this time? "no" only when that hour has minCoins+ coins and lost money
  hourAllowed(trader, ts = this.now(), minCoins = 8) {
    const r = this.hourStats(trader)[new Date(ts).getHours()];
    return !(r && r.coins >= minCoins && r.pnl < 0);
  }

  badHours(trader, minCoins = 8) {
    return Object.entries(this.hourStats(trader))
      .filter(([, r]) => r.coins >= minCoins && r.pnl < 0)
      .map(([h]) => +h)
      .sort((a, b) => a - b);
  }

  // V2.11 (#5 best exit per trader) on his last n coins, what each way of selling returned (PnL / SOL in),
  // compared on the same coins. kind 'main' (your main wallet's way) or 'side' (+25%).
  // Returns { base, best, rule, rets } — rule is null when your current way is still the best (or no data).
  exitPick(trader, kind = 'main', { n = 30, minCoins = 15, margin = 0.03 } = {}) {
    const base = kind === 'side' ? 'W2' : 'main';
    const coins = [];
    for (let i = this.d.closed.length - 1; i >= 0 && coins.length < n; i--) {
      const c = this.d.closed[i];
      if (c.trader === trader && c.style === 'main') coins.push(c.key.split('|')[2]);
    }
    const want = new Set(coins);
    const by = {}; // style -> mint -> pnl
    for (const c of this.d.closed) {
      if (c.trader !== trader) continue;
      const m = c.key.split('|')[2];
      if (!want.has(m)) continue;
      ((by[c.style] ||= {}))[m] = c.pnl;
    }
    const cost = (st) => (STYLES[st]?.sol || 0.05) + this.fee;
    const rets = {};
    let best = base;
    for (const st of [base, 't15', 't2', 'trail', 'xb']) {
      if (st !== base && !by[base]) break;
      const both = Object.keys(by[st] || {}).filter((m) => by[base]?.[m] != null);
      if (both.length < minCoins) continue;
      const ret = both.reduce((s, m) => s + by[st][m], 0) / (both.length * cost(st));
      const bret = both.reduce((s, m) => s + by[base][m], 0) / (both.length * cost(base));
      rets[st] = { ret, vs: bret, coins: both.length };
      if (st !== base && ret > 0 && ret > bret + margin && ret > (rets[best]?.ret ?? -Infinity)) best = st;
    }
    if (best === base) return { base, best, rule: null, rets };
    let rule;
    if (best === 'xb') {
      const bx = this.beforeX(trader);
      if (!bx) return { base, best: base, rule: null, rets };
      rule = { miniFromX: bx, miniToX: bx, miniPullbackPct: 1, miniPct: kind === 'side' ? 100 : 50 };
    } else {
      const T = STYLES[best].rule;
      rule = { miniFromX: T.from, miniToX: T.to, miniPullbackPct: T.pull, miniPct: T.pct };
    }
    return { base, best, rule: { ...rule, exitStyle: best }, rets, label: best === 'xb' ? `sell ${kind === 'side' ? 'all' : 'half'} at ${rule.miniToX}x (just before where he usually sells)` : STYLES[best].label };
  }

  // V2.10.1 his last n coins (by when they closed): PnL of all 4 pretend wallets, what the winners made, what
  // the losers lost, and the newest 10 coins on their own (is he still winning right now?)
  lastTrades(trader, n = 30) {
    const coins = [];
    for (let i = this.d.closed.length - 1; i >= 0 && coins.length < n; i--) {
      const c = this.d.closed[i];
      if (c.trader === trader && c.style === 'main') coins.push(c.key.split('|')[2]);
    }
    const set = new Set(coins);
    const newest = new Set(coins.slice(0, 10));
    const r = { coins: coins.length, pnl: 0, gains: 0, losses: 0, last10: 0, won: 0 };
    const per = {};
    for (const c of this.d.closed) {
      if (c.trader !== trader || isTest(c.style)) continue;
      const m = c.key.split('|')[2];
      if (!set.has(m)) continue;
      per[m] = (per[m] || 0) + c.pnl;
      if (newest.has(m)) r.last10 += c.pnl;
    }
    for (const v of Object.values(per)) {
      r.pnl += v;
      if (v > 0) {
        r.gains += v;
        r.won++;
      } else r.losses += -v;
    }
    for (const k of ['pnl', 'gains', 'losses', 'last10']) r[k] = Math.round(r[k] * 1e6) / 1e6;
    return r;
  }

  // V2.10 one trader's pretend wallets in a window: coins (counted once, main wallet), coins won, PnL of all 4
  recent(trader, ms) {
    const from = this.now() - ms;
    const r = { coins: 0, won: 0, pnl: 0 };
    for (const c of this.d.closed) {
      if (c.trader !== trader || c.at < from || isTest(c.style)) continue;
      if (c.style === 'main') {
        r.coins++;
        if (c.pnl > 0) r.won++;
      }
      r.pnl += c.pnl;
    }
    r.pnl = Math.round(r.pnl * 1e6) / 1e6;
    return r;
  }

  // V2.9.12 per market-cap range for one trader: coins (counted once), coins won (main wallet), PnL of all 4 wallets
  bandStats(trader, sinceMs = null) {
    const from = sinceMs ? this.now() - sinceMs : 0;
    const out = {};
    for (const c of this.d.closed) {
      if (c.trader !== trader || c.at < from || isTest(c.style)) continue;
      const b = bandOf(c.mc);
      if (!b) continue;
      const r = (out[b] ||= { coins: 0, won: 0, pnl: 0 });
      if (c.style === 'main') {
        r.coins++;
        if (c.pnl > 0) r.won++;
      }
      r.pnl += c.pnl;
    }
    return out;
  }

  // V2.11.8 the same per range, but only his LAST `last` coins in each range — so a range that starts
  // winning again is copied again (the pretend wallets keep buying every range, copied or not)
  recentBandStats(trader, last = 30) {
    const want = {}; // band -> Set of mints (newest first)
    for (let i = this.d.closed.length - 1; i >= 0; i--) {
      const c = this.d.closed[i];
      if (c.trader !== trader || c.style !== 'main') continue;
      const b = bandOf(c.mc);
      if (!b) continue;
      const s = (want[b] ||= new Set());
      if (s.size < last) s.add(c.key.split('|')[2]);
    }
    const out = {};
    for (const c of this.d.closed) {
      if (c.trader !== trader || isTest(c.style)) continue;
      const b = bandOf(c.mc);
      if (!b || !want[b]?.has(c.key.split('|')[2])) continue;
      const r = (out[b] ||= { coins: 0, won: 0, pnl: 0 });
      if (c.style === 'main') {
        r.coins++;
        if (c.pnl > 0) r.won++;
      }
      r.pnl += c.pnl;
    }
    return out;
  }

  // sweet spot: copy this trader's buy at this market cap? Only "no" when his last 30 pretend coins in that
  // range (at least minCoins of them) lost money. Not enough data (or no market cap) = yes.
  allowed(trader, mc, minCoins = 8) {
    const b = bandOf(mc);
    if (!b) return true;
    const r = this.recentBandStats(trader)[b];
    if (!r || r.coins < minCoins) return true;
    return r.pnl > 0;
  }

  sweetSpotText(traders, minCoins = 8) {
    const lines = [`🎯 <b>Sweet spots</b> (market caps where each trader's last 30 pretend coins made money; needs ${minCoins}+ coins in a range — it adapts as they win or lose)`];
    const sg = (n) => `${n >= 0 ? '+' : '-'}${Math.abs(n).toFixed(3)}`;
    for (const t of traders) {
      const bs = this.recentBandStats(t);
      const rows = MC_BANDS.map(([, , name]) => [name, bs[name]]).filter(([, r]) => r);
      if (!rows.length) continue;
      const cell = ([name, r]) => `${r.coins >= minCoins ? (r.pnl > 0 ? '✅' : '⛔') : '⏳'} ${name} ${sg(r.pnl)} (${r.won}/${r.coins})`;
      lines.push(`<b>${t}</b>: ${rows.map(cell).join(' · ')}`);
    }
    if (lines.length === 1) lines.push('No market-cap data yet — it builds up as the traders buy.');
    lines.push('✅ copied · ⛔ skipped (lost money there) · ⏳ not enough coins yet (copied)');
    return lines.join('\n');
  }

  // per trader and style: closed coins, wins, PnL (+ open ghosts valued at their last price)
  stats(sinceMs = null) {
    const from = sinceMs ? this.now() - sinceMs : 0;
    const by = {};
    const grp = (s) => (s === 'main' ? 'main' : 'side'); // W2 + W3 + W4 (and older 'side' ghosts) together
    const row = (t, s) => ((by[t] ||= { main: null, side: null })[grp(s)] ||= { n: 0, won: 0, pnl: 0, open: 0, openPnl: 0 });
    for (const c of this.d.closed) {
      if (c.at < from || isTest(c.style)) continue;
      const r = row(c.trader, c.style);
      r.n++;
      if (c.pnl > 0) r.won++;
      r.pnl += c.pnl;
    }
    for (const g of Object.values(this.d.open)) {
      if (isTest(g.style)) continue;
      const r = row(g.trader, g.style);
      r.open++;
      if (g.lastPx > 0) r.openPnl += (STYLES[g.style] || STYLES.W2).sol * g.left * (g.lastPx / g.entry) + g.got - g.cost;
    }
    return by;
  }

  report({ sinceMs = null, title = '👻 <b>Ghost wallets</b>' } = {}) {
    const by = this.stats(sinceMs);
    const names = Object.keys(by);
    if (!names.length) return `${title}: nothing yet — every trader's buys are simulated from now on.`;
    const sg = (n) => `${n >= 0 ? '+' : '-'}${Math.abs(n).toFixed(3)}`;
    const tot = (b) => (b.main?.pnl || 0) + (b.side?.pnl || 0);
    names.sort((a, b) => tot(by[b]) - tot(by[a]));
    const cell = (r, label) => (r ? `${label} ${sg(r.pnl)} (${r.won}/${r.n})${r.open ? ` +${r.open} open ${sg(r.openPnl)}` : ''}` : `${label} —`);
    const lines = [`${title} (4 pretend wallets per trader, like yours: main 0.1 SOL/coin + ${SIDES.length} sides 0.05 SOL/coin)`];
    for (const n of names) {
      const b = by[n];
      const best = (b.main?.pnl || 0) >= (b.side?.pnl || 0) ? 'main' : 'sides';
      const t = tot(b);
      lines.push(`${t > 0 ? '🟢' : '🔴'} <b>${n}</b>: set ${sg(t)} · ${cell(b.main, 'main')} · ${cell(b.side, `${SIDES.length} sides`)}${t > 0 ? ` → best: ${best}` : ''}`);
      const bs = Object.entries(this.bandStats(n, sinceMs)).filter(([, r]) => r.coins >= 3).sort((a, b2) => b2[1].pnl - a[1].pnl);
      if (bs.length) lines.push(`   📊 MC: ${bs.map(([name, r]) => `${name} ${sg(r.pnl)} (${r.won}/${r.coins})`).join(' · ')}`);
      const ex = this.exitPick(n, 'main');
      if (ex.rule) lines.push(`   🎯 best exit: ${ex.label} (${Math.round(ex.rets[ex.best].ret * 100)}% vs ${Math.round(ex.rets[ex.best].vs * 100)}% following him)`);
      const bh = this.badHours(n);
      if (bh.length) lines.push(`   ⏰ not copied at: ${bh.map(hourName).join(', ')}`);
    }
    const hrs = Math.max(0.1, (this.now() - (this.d.since || this.now())) / 3600000);
    lines.push(`<i>Since ${hrs < 24 ? `${hrs.toFixed(1)}h` : `${(hrs / 24).toFixed(1)} days`} ago · estimates: his price +${Math.round((this.entryPenalty - 1) * 100)}% for our delay, real fees · /ghosts reset to start over</i>`);
    return lines.join('\n');
  }
}
