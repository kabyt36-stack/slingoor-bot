import { fetchJson, sleep } from './util.js';
import { log } from './log.js';

const toPlain = (html) =>
  String(html).replace(/<[^>]+>/g, '').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&amp;/g, '&');

// Telegram Bot API client: send / edit messages with a rate-limited queue, and long-poll commands.
export class Telegram {
  constructor({ token, apiBase }) {
    this.token = token;
    this.base = `${apiBase}/bot${token}`;
    this.queue = [];
    this.busy = false;
    this.offset = 0;
    this.stopped = false;
    this.lastSendAt = 0;
    this.me = null;
  }

  async api(method, params = {}, timeout = 15000) {
    const j = await fetchJson(`${this.base}/${method}`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: params,
      timeout,
    }).catch((e) => {
      // Telegram puts the reason in the body on 4xx
      if (e.status === 429) {
        const m = /retry_after\D+(\d+)/.exec(e.message);
        e.retryAfter = m ? +m[1] : 3;
      }
      throw e;
    });
    if (!j?.ok) throw new Error(`Telegram ${method}: ${j?.description || 'failed'}`);
    return j.result;
  }

  _enqueue(fn) {
    return new Promise((resolve, reject) => {
      this.queue.push({ fn, resolve, reject });
      this._drain();
    });
  }

  async _drain() {
    if (this.busy) return;
    this.busy = true;
    while (this.queue.length) {
      const job = this.queue.shift();
      const gap = 60 - (Date.now() - this.lastSendAt);
      if (gap > 0) await sleep(gap);
      for (let attempt = 0; ; attempt++) {
        try {
          this.lastSendAt = Date.now();
          job.resolve(await job.fn());
          break;
        } catch (e) {
          if (e.status === 429 && attempt < 4) {
            await sleep((e.retryAfter || 3) * 1000 + 200);
            continue;
          }
          if ((e.timeout || e.status >= 500 || /fetch failed/i.test(e.message)) && attempt < 2) {
            await sleep(1000);
            continue;
          }
          job.reject(e);
          break;
        }
      }
    }
    this.busy = false;
  }

  send(chatId, html, buttons) {
    // V2.11.4 Telegram's limit is 4096 characters: long messages (dozens of traders) go out in parts, cut
    // between lines; the buttons go on the last part
    if (String(html).length > 3900) {
      const parts = [];
      let cur = '';
      for (const line of String(html).split('\n')) {
        const l = line.length > 3900 ? line.slice(0, 3900) : line;
        if (cur && cur.length + 1 + l.length > 3900) {
          parts.push(cur);
          cur = l;
        } else cur = cur ? `${cur}\n${l}` : l;
      }
      if (cur) parts.push(cur);
      return parts.reduce((p, part, i) => p.then(() => this.send(chatId, part, i === parts.length - 1 ? buttons : undefined)), Promise.resolve());
    }
    const params = {
      chat_id: chatId,
      text: html,
      parse_mode: 'HTML',
      link_preview_options: { is_disabled: true },
    };
    if (buttons?.length) params.reply_markup = { inline_keyboard: buttons };
    return this._enqueue(async () => {
      try {
        return (await this.api('sendMessage', params)).message_id;
      } catch (e) {
        // Never lose an alert over formatting: resend as plain text
        if (/can't parse entities|unsupported start tag|can't find end tag/i.test(e.message)) {
          const plain = { ...params, text: toPlain(html) };
          delete plain.parse_mode;
          return (await this.api('sendMessage', plain)).message_id;
        }
        const m = /migrate_to_chat_id"?\s*:\s*(-?\d+)/.exec(e.message);
        if (m) e.migrateTo = m[1]; // group was upgraded to a supergroup
        throw e;
      }
    });
  }

  edit(chatId, messageId, html, buttons) {
    const params = {
      chat_id: chatId,
      message_id: messageId,
      text: html,
      parse_mode: 'HTML',
      link_preview_options: { is_disabled: true },
    };
    if (buttons?.length) params.reply_markup = { inline_keyboard: buttons };
    return this._enqueue(() =>
      this.api('editMessageText', params).catch((e) => {
        if (/message is not modified/i.test(e.message)) return null;
        if (/can't parse entities/i.test(e.message)) {
          const plain = { ...params, text: toPlain(html) };
          delete plain.parse_mode;
          return this.api('editMessageText', plain);
        }
        throw e;
      }),
    );
  }

  async getMe() {
    this.me = await this.api('getMe');
    return this.me;
  }

  // Long-poll for messages. onMessage(msg) handles commands.
  async poll(onMessage) {
    // On startup skip anything older than 60s so we don't replay old commands
    while (!this.stopped) {
      try {
        const updates = await this.api(
          'getUpdates',
          { offset: this.offset, timeout: 25, allowed_updates: ['message', 'channel_post'] },
          35000,
        );
        for (const u of updates) {
          this.offset = u.update_id + 1;
          const msg = u.message || u.channel_post;
          if (!msg?.text) continue;
          if (Date.now() / 1000 - msg.date > 120) continue;
          try {
            await onMessage(msg);
          } catch (e) {
            log.error('Command failed:', e.message);
          }
        }
      } catch (e) {
        if (/409|Conflict/i.test(e.message)) {
          log.error('Another copy of this bot is already running with the same token. Close it, then restart.');
          await sleep(15000);
        } else if (/401|Unauthorized|404/i.test(e.message)) {
          log.error('Telegram rejected the bot token. Check TELEGRAM_BOT_TOKEN in settings.txt.');
          await sleep(30000);
        } else {
          log.debug('getUpdates error:', e.message);
          await sleep(3000);
        }
      }
    }
  }

  stop() {
    this.stopped = true;
  }
}
