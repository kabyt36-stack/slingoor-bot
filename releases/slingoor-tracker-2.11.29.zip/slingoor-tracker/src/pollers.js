import { EventEmitter } from 'node:events';
import { log } from './log.js';
import { sleep } from './util.js';

const TRADE_MAX_AGE = 10 * 60 * 1000; // don't alert trades older than this (e.g. after the bot was off)
const CALLOUT_MAX_AGE = 30 * 60 * 1000;
const LAUNCH_MAX_AGE = 60 * 60 * 1000;

// Runs fn every intervalMs, never overlapping, with backoff on errors.
class Loop {
  constructor(name, intervalMs, fn) {
    this.name = name;
    this.intervalMs = intervalMs;
    this.fn = fn;
    this.stopped = false;
    this.errors = 0;
    this.lastOkAt = 0;
    this.lastError = null;
  }
  async run() {
    while (!this.stopped) {
      const t0 = Date.now();
      try {
        await this.fn();
        this.errors = 0;
        this.lastOkAt = Date.now();
      } catch (e) {
        this.errors++;
        this.lastError = e.message;
        if (this.errors === 1 || this.errors % 20 === 0) log.warn(`${this.name}: ${e.message}`);
      }
      const backoff = this.errors ? Math.min(60000, this.intervalMs * 2 ** Math.min(this.errors, 5)) : this.intervalMs;
      await sleep(Math.max(200, backoff - (Date.now() - t0)));
    }
  }
  stop() {
    this.stopped = true;
  }
}

// His trades straight from pump.fun's activity feed. Backup for the chain stream, and works
// even without a good RPC.
export class PumpTradesPoller extends EventEmitter {
  constructor({ pump, state, userId, wallet, intervalMs }) {
    super();
    this.pump = pump;
    this.wallet = wallet;
    this.state = state;
    this.userId = userId;
    this.loop = new Loop('pump.fun trades feed', intervalMs, () => this.tick());
    // After a restart, trades made while the bot was down (last 10 min) still get alerted;
    // only on the very first run is the existing history skipped.
    this.seeded = !!state.tradesSeeded;
  }
  start() {
    this.loop.run();
  }
  stop() {
    this.loop.stop();
  }
  async tick() {
    const { trades, coins } = await this.pump.getUserTrades(this.userId, 20);
    const now = Date.now();
    // oldest first; slotIndexId is a fixed-width on-chain position, so it orders trades within the same second
    const order = (t) => (typeof t.slotIndexId === 'string' && t.slotIndexId ? t.slotIndexId : String(Date.parse(t.timestamp) || 0).padStart(26, '0'));
    const rows = [...trades].sort((a, b) => (order(a) < order(b) ? -1 : order(a) > order(b) ? 1 : 0));
    for (const t of rows) {
      if (!t?.tx || !t.mint) continue;
      const side = t.isBuy ? 'BUY' : 'SELL';
      const key = `${t.tx}:${t.mint}`;
      if (this.state.seenTrades.has(key)) continue;
      const time = Date.parse(t.timestamp) || now;
      if (!this.seeded || now - time > TRADE_MAX_AGE) {
        this.state.seenTrades.add(key); // history: remember, don't alert
        continue;
      }
      const c = coins[t.mint];
      this.emit('trade', {
        key,
        sig: t.tx,
        wallet: t.walletAddress || this.wallet,
        mint: t.mint,
        side,
        amountUi: +t.baseAmount || 0,
        preUi: null,
        postUi: null,
        quote: 'SOL',
        solAmount: +t.amountSol || 0,
        usdAmount: +t.amountUsd || 0,
        time,
        detectedAt: now,
        source: 'pump',
        coinHint: c ? { name: c.name, symbol: c.symbol, image: c.image } : null,
      });
    }
    if (!this.seeded) {
      this.seeded = true;
      this.state.tradesSeeded = true;
      this.state.save();
      log.info(`pump.fun trades feed live (${rows.length} recent trades marked as history)`);
    }
    // keep a SOL price estimate from real fills
    const withUsd = rows.filter((t) => +t.amountSol > 0.05 && +t.amountUsd > 0);
    if (withUsd.length) this.emit('solPrice', +withUsd.at(-1).amountUsd / +withUsd.at(-1).amountSol);
  }
}

// pump.fun's callout list endpoint sometimes refuses requests that aren't from a logged-in
// browser (503). When that happens we read his callouts from his positions instead: each
// position carries the latest callout he made on that coin.
function calloutFromPosition(p) {
  const c = p.callout;
  return {
    calloutId: c.calloutId,
    coinMint: p.coinMint,
    marketCap: +c.calledOutAtMcap || null,
    createdAt: Date.parse(c.calloutTimestamp) || 0,
    thesis: c.thesis,
    updateCount: +c.updateCount || 0,
    updates: c.updates || [],
    multiple: c.multiple,
    maxMultiplier: c.maxMultiplier,
  };
}

export class CalloutPoller extends EventEmitter {
  constructor({ pump, state, userId, wallet, intervalMs, listEveryMs = 20000, watchMints = () => [] }) {
    super();
    this.pump = pump;
    this.state = state;
    this.userId = userId;
    this.wallet = wallet;
    this.watchMints = watchMints;
    this.via = 'list';
    this.lastListAt = 0;
    this.listCooldownUntil = 0;
    this.listEveryMs = listEveryMs; // pump.fun throttles this endpoint if hit much more often
    this.loop = new Loop('callout feed', intervalMs, () => this.tick());
  }

  // Every ~20s read his callout list; in between (and whenever pump.fun throttles the list)
  // check his positions, which carry his latest callout on each coin.
  async _fetch() {
    const now = Date.now();
    if (now - this.lastListAt >= this.listEveryMs && now >= this.listCooldownUntil) {
      this.lastListAt = now;
      try {
        const list = await this.pump.getCallouts(this.userId, 10);
        if (this.via === 'positions') log.info('Callout list is reachable again');
        this.via = 'list';
        return list;
      } catch (e) {
        this.listCooldownUntil = now + 120000;
        if (this.via !== 'positions') log.warn(`Callout list unavailable (${e.message.slice(0, 60)}), reading callouts from his positions instead`);
        this.via = 'positions';
      }
    }
    const mints = this.watchMints().slice(0, 120);
    if (!mints.length) {
      if (this.via === 'positions') throw new Error('callout list unavailable and no coins to watch yet');
      return [];
    }
    const ps = await this.pump.getPositions(this.wallet, mints);
    return ps.filter((p) => p?.callout?.calloutId).map(calloutFromPosition);
  }
  start() {
    this.loop.run();
  }
  stop() {
    this.loop.stop();
  }
  async tick() {
    const list = await this._fetch();
    this.lastList = [...list].sort((a, b) => b.createdAt - a.createdAt);
    const seen = this.state.seenCallouts;
    const now = Date.now();
    const firstRun = !this.state.calloutsSeeded;
    for (const c of [...list].sort((a, b) => a.createdAt - b.createdAt)) {
      if (!c?.calloutId || !c.coinMint) continue;
      const uc = +c.updateCount || 0;
      if (!(c.calloutId in seen)) {
        seen[c.calloutId] = uc;
        if (firstRun || now - c.createdAt > CALLOUT_MAX_AGE) continue;
        this.emit('callout', c, this.wallet);
      } else if (uc > seen[c.calloutId]) {
        seen[c.calloutId] = uc;
        if (firstRun) continue;
        await this._updates(c);
      }
    }
    if (firstRun) {
      this.state.calloutsSeeded = true;
      log.info(`Callout feed live (${list.length} existing callouts marked as history)`);
    }
    const ids = Object.keys(seen);
    if (ids.length > 400) for (const id of ids.slice(0, ids.length - 300)) delete seen[id];
    this.state.save();
  }
  async _updates(c) {
    let replies = Array.isArray(c.updates) && c.updates.length ? c.updates : null;
    if (!replies) {
      try {
        replies = await this.pump.getCalloutUpdates(c.calloutId);
      } catch {
        // couldn't read the text; still tell you he posted an update
        if (this.state.seenUpdates.add(`${c.calloutId}#${c.updateCount}`)) this.emit('calloutUpdate', c, this.wallet, null);
        return;
      }
    }
    replies = replies
      .filter((r) => r && !r.tombstone && !r.parentMessageId && (r.content || r.text))
      .sort((a, b) => Date.parse(a.createdAt) - Date.parse(b.createdAt));
    for (const r of replies) {
      const id = r.id || `${c.calloutId}:${r.createdAt}`;
      if (!this.state.seenUpdates.add(id)) continue;
      this.emit('calloutUpdate', c, this.wallet, r.content || r.text);
    }
  }
}

export class LaunchPoller extends EventEmitter {
  constructor({ pump, state, wallet, intervalMs }) {
    super();
    this.pump = pump;
    this.state = state;
    this.wallet = wallet;
    this.loop = new Loop('launch feed', intervalMs, () => this.tick());
  }
  start() {
    this.loop.run();
  }
  stop() {
    this.loop.stop();
  }
  async tick() {
    const all = [];
    let offset = 0;
    let count = Infinity;
    while (offset < count && offset < 500) {
      const j = await this.pump.getCreatedCoins(this.wallet, 100, offset);
      count = j.count;
      all.push(...j.coins);
      if (!j.coins.length) break;
      offset += j.coins.length;
    }
    const firstRun = !this.state.launchSeeded;
    const now = Date.now();
    for (const c of all) {
      if (!c?.mint || this.state.createdMints.has(c.mint)) continue;
      if (firstRun || (c.created_timestamp && now - c.created_timestamp > LAUNCH_MAX_AGE)) {
        this.state.createdMints.add(c.mint);
        continue;
      }
      this.emit('launch', { mint: c.mint, wallet: this.wallet, coin: c, source: 'pump', time: c.created_timestamp || now });
    }
    if (firstRun) {
      this.state.launchSeeded = true;
      log.info(`Launch feed live (${all.length} coins he already created marked as history)`);
    }
    this.state.save();
  }
}
