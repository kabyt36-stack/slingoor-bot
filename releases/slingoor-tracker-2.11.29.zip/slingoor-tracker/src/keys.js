// Helius key failover: the main (paid) key is used first; when a key runs out of credits (or is
// rejected), the bot switches to the next backup key, and goes back to the main key once it works again.
import { log } from './log.js';

export function isOutOfCredits(e) {
  return e?.status === 401 || e?.status === 403 || /max usage|usage limit|out of credits|credits? (?:exhausted|limit)|exceeded your|plan limit|invalid api key/i.test(e?.message || '');
}

export class KeyPool {
  constructor(keys, { deadMs = 60 * 60000, now = () => Date.now() } = {}) {
    this.keys = [...new Set(keys.filter(Boolean))];
    this.dead = new Map(); // key -> retry after
    this.deadMs = deadMs;
    this.now = now;
    this.last = null;
  }

  // first key (in order: main first) that isn't resting
  current() {
    const t = this.now();
    const k = this.keys.find((x) => !(this.dead.get(x) > t)) || this.keys[0];
    if (this.last && k !== this.last) log.warn(`Helius: switched to ${k === this.keys[0] ? 'the main key' : `backup key #${this.keys.indexOf(k)}`}`);
    this.last = k;
    return k;
  }

  markDead(key, why = '') {
    if (!key || this.dead.get(key) > this.now()) return;
    this.dead.set(key, this.now() + this.deadMs);
    log.warn(`Helius key ${key === this.keys[0] ? '(main)' : `#${this.keys.indexOf(key)}`} out of credits/rejected${why ? ` (${why.slice(0, 80)})` : ''} — using the next one`);
  }

  rpcUrl() {
    return `https://mainnet.helius-rpc.com/?api-key=${this.current()}`;
  }

  wsUrl() {
    return `wss://mainnet.helius-rpc.com/?api-key=${this.current()}`;
  }
}
