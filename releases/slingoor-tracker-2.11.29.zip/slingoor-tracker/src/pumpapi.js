import { fetchJson, sleep } from './util.js';
import { log } from './log.js';

// Client for pump.fun's public web API (the same endpoints pump.fun's own site uses).
// All calls are paced so we never hammer pump.fun, and back off when it rate-limits us.
const HEADERS = {
  Accept: 'application/json',
  Origin: 'https://pump.fun',
  Referer: 'https://pump.fun/',
  'User-Agent':
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36',
};

export class PumpApi {
  constructor({ base, profileBase, dexApi = '', minGapMs = 150, enabled = true }) {
    this.enabled = enabled;
    this.base = base;
    this.dexApi = dexApi;
    this.profileBase = profileBase;
    this.minGapMs = minGapMs;
    this.nextAt = 0;
    this.blocked = new Map(); // endpoint -> paused until
    this.ok = 0;
    this.fail = 0;
    this.lastError = null;
    this.lastOkAt = 0;
  }

  // Pace request start times (requests can still overlap, so one slow call never blocks the others).
  // Rate limits are tracked per endpoint: if pump.fun throttles callouts, the trades feed keeps going.
  async _paced(fn, family) {
    const now = Date.now();
    const slot = Math.max(now, this.nextAt);
    this.nextAt = slot + this.minGapMs;
    const blocked = Math.max(this.blocked.get(family) || 0, this.cfUntil || 0);
    if (blocked > slot) {
      const cf = (this.cfUntil || 0) > slot;
      const err = new Error(cf ? 'pump.fun is blocking this computer (Cloudflare "Just a moment"), waiting' : `pump.fun is rate-limiting ${family}, waiting`);
      err.status = cf ? 403 : 429;
      err.cloudflare = cf;
      err.local = true;
      throw err;
    }
    if (slot > now) await sleep(slot - now);
    return fn();
  }

  async get(url, { timeout = 8000 } = {}) {
    if (!this.enabled) {
      const err = new Error('pump.fun is not used (USE_PUMPFUN=off)');
      err.disabled = true;
      throw err;
    }
    // endpoint family = first path segment after the API base, e.g. "callout", "user-trades"
    const rel = url.startsWith(this.base) ? url.slice(this.base.length) : url.startsWith(this.profileBase) ? 'profile' + url.slice(this.profileBase.length) : new URL(url).pathname;
    const family = rel.split('?')[0].split('/').filter(Boolean)[0] || 'root';
    return this._paced(async () => {
      try {
        const j = await fetchJson(url, { headers: HEADERS, timeout });
        this.ok++;
        this.lastOkAt = Date.now();
        if (this.cfHits) {
          this.cfHits = 0;
          log.info('pump.fun API reachable again');
        }
        return j;
      } catch (e) {
        this.fail++;
        this.lastError = `${e.status || ''} ${e.message}`.trim();
        if (e.status === 403 && /Just a moment|cloudflare|challenge/i.test(e.message)) {
          // Cloudflare challenge: hammering makes it last longer, so back off everything for a while
          e.cloudflare = true;
          this.cfHits = (this.cfHits || 0) + 1;
          const mins = Math.min(15, 2 * this.cfHits);
          this.cfUntil = Date.now() + mins * 60000;
          this.lastError = 'blocked by Cloudflare ("Just a moment")';
          if (!this.cfLoggedAt || Date.now() - this.cfLoggedAt > 30 * 60000) {
            this.cfLoggedAt = Date.now();
            log.warn(`pump.fun's website API is blocking this computer (Cloudflare check). Trades and copy trading keep working from the chain; callouts and the pump.fun backup feeds pause and retry every ${mins} min.`);
          }
        } else if (e.status === 429 || e.status === 503) {
          const secs = Math.min(120, Math.max(15, e.retryAfter || 20));
          this.blocked.set(family, Date.now() + secs * 1000);
          log.warn(`pump.fun is limiting /${family} (${e.status}), pausing that endpoint ${secs}s`);
        }
        throw e;
      }
    }, family);
  }

  getUser(wallet) {
    return this.get(`${this.base}/users/${wallet}`);
  }

  async getCallouts(userId, limit = 10) {
    const j = await this.get(
      `${this.base}/callout/list/${encodeURIComponent(userId)}?limit=${limit}&sortBy=TIMESTAMP&sortOrder=DESC`,
    );
    if (!j || !Array.isArray(j.callouts)) throw new Error('callout list format changed');
    return j.callouts;
  }

  async getCalloutUpdates(calloutId) {
    const j = await this.get(
      `${this.base}/callout/${encodeURIComponent(calloutId)}/replies?limit=50&filter=AUTHOR_ONLY`,
    );
    return Array.isArray(j?.replies) ? j.replies : [];
  }

  // His trades as indexed by pump.fun. types=trades skips the spam token transfers people send him.
  async getUserTrades(userId, limit = 20) {
    const j = await this.get(`${this.base}/user-trades/${encodeURIComponent(userId)}?types=trades&limit=${limit}`);
    if (!j || !Array.isArray(j.trades)) throw new Error('user-trades format changed');
    const coins = {};
    for (const c of j.coins || []) coins[c.mint] = c;
    return { trades: j.trades, coins };
  }

  // pump.fun's own position record per coin: amountHeld, isExited, pnlUsd, costBasisUsd...
  async getPositions(wallet, mints) {
    if (!mints.length) return [];
    const j = await this.get(`${this.base}/user-positions/${wallet}?mints=${mints.join(',')}&updatesLimit=0`);
    return Array.isArray(j?.positions) ? j.positions : [];
  }

  getCoin(mint) {
    return this.get(`${this.base}/coins-v2/${mint}`, { timeout: 4000 });
  }

  async getCreatedCoins(wallet, limit = 100, offset = 0) {
    const j = await this.get(`${this.base}/coins-v2/user-created-coins/${wallet}?limit=${limit}&offset=${offset}`);
    return { count: j?.count ?? 0, coins: Array.isArray(j?.coins) ? j.coins : [] };
  }

  // Current bags (spam tokens are already hidden by pump.fun).
  async getHoldings(wallet, page = 1, size = 50) {
    const j = await this.get(`${this.profileBase}/balance/tokens/${wallet}?page=${page}&size=${size}&chain=solana`);
    const tokens = j?.data?.tokens || [];
    return { tokens, totalPages: j?.pagination?.totalPages || 1 };
  }

  async getSolPrice() {
    try {
      const j = await this.get(`${this.base}/sol-price`, { timeout: 4000 });
      if (+j?.solPrice) return +j.solPrice;
    } catch {}
    // fallback: DexScreener's biggest SOL/USDC pool
    if (!this.dexApi) return null;
    const j = await fetchJson(`${this.dexApi}/latest/dex/tokens/So11111111111111111111111111111111111111112`, { timeout: 5000 }).catch(() => null);
    const p = (j?.pairs || []).filter((x) => x.baseToken?.address === 'So11111111111111111111111111111111111111112' && /^USD/.test(x.quoteToken?.symbol || '')).sort((a, b) => (b.liquidity?.usd || 0) - (a.liquidity?.usd || 0))[0];
    return +p?.priceUsd || null;
  }
}
