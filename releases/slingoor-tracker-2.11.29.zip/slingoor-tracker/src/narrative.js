// Narrative ("meta") engine.
// 1) classify(coin) tags a coin with narratives using its name + ticker.
// 2) MetaProfile learns which narratives HE plays (from his bags, callouts, trades, launches)
//    and scores how well a new coin fits that pattern.

const W = (s) => s.split(/\s+/).filter(Boolean);

export const TAGS = {
  titty: { emoji: '🍈', label: 'Big Titty' },
  nsfw: { emoji: '🔞', label: 'NSFW / degen' },
  backronym: { emoji: '🔤', label: 'Ticker backronym' },
  ticker: { emoji: '📈', label: 'Real-ticker vamp' },
  kol: { emoji: '🎤', label: 'KOL / self-shill' },
  self: { emoji: '🪞', label: 'Coin about him' },
  animal: { emoji: '🐾', label: 'Animal' },
  ai: { emoji: '🤖', label: 'AI / bots' },
  celeb: { emoji: '🌟', label: 'Celeb / politics' },
  cryptoculture: { emoji: '🪙', label: 'Crypto culture' },
  finance: { emoji: '🏦', label: 'Stonks / finance' },
  tech: { emoji: '💻', label: 'Tech hardware' },
  anime: { emoji: '🎌', label: 'Anime' },
  slang: { emoji: '😂', label: 'Internet slang' },
  seasonal: { emoji: '🎃', label: 'Seasonal' },
  tweet: { emoji: '🐦', label: 'Tweet-based' },
};

const KEYWORDS = {
  titty: W(`tit tits titty titties tittie tiddy tiddies tiddie boob boobs boobies boobie bewbs busty milkers milker jugs
    melons yams knockers honkers bazongas badonkers cleavage bra dumplings hooters rack chesticles mammaries breasts`),
  nsfw: W(`ass booty butt cheeks peach peaches peachy thicc thick rear moist wet dripping cum nut nutting sperm squirt orgasm
    orgasmic horny goon gooner gooning moan moaner sex sexy sexbot erotic pussy cock dick hoe hoes oiled onlyfans lewd nsfw
    naked nude nudes milf gilf kinky fetish lust luscious seductive pleasure pleasah munching stripper porn xxx hentai bussy
    cunt whore slut thot fap virgin virgins ripe tight trashy squirting freaky`),
  kol: W(`slingoor sling slingtoshi ansem toly cupsey orangie cented gake murad hsaka cobie zachxbt alon kook jalen euris
    frankdegods frank mitch nate kev otta loopier dingaling`),
  animal: W(`dog doge dogs inu shiba cat cats kitten kitty neko moneko frog pepe toad hippo bull bear monkey ape chimp penguin
    pengu fish bird birds moonbirds chameleon crab rat mouse hamster bunny rabbit wolf fox lion tiger goat cow pig duck owl
    bat otter seal panda koala sloth snake longcat loooongcat pumpcat chatcat brangus frongus capybara`),
  ai: W(`ai agent agents gpt grok grokbot bot robot llm claude openai chatgpt neural sentient agi`),
  celeb: W(`elon musk trump biden kamala kanye drake theo von theovan rogan tate mrbeast ishowspeed putin obama president
    vance barron melania mika kim`),
  cryptoculture: W(`satoshi nakamoto bitcoin ethereum vitalik onchain chain crypto blockchain wen lambo hodl degen moon rug
    jeet trader boss memecoin pumpfun pump onecoin`),
  finance: W(`stonk stonks stock stocks bank trust money laundering wall street nasdaq index dumper market inflation fed gold
    dollar xstock housecoin house`),
  tech: W(`cpu gpu ram psu ssd hdd nvidia intel chip unit processing computer pc factory`),
  anime: W(`anime waifu chan kun senpai akira manga otaku kawaii`),
  slang: W(`lmao lmfao rofl xd epic face meme retard retardatide neet based chad wojak npc sigma brainrot skibidi rizz gyatt
    bruh shhh goyim`),
  seasonal: W(`halloween spooky christmas xmas santa thanksgiving turkey easter valentine`),
};

// Well-known crypto + stock tickers and acronyms he loves to "vamp" (BTC -> Big Titty Coin).
export const REAL_TICKERS = new Set(
  W(`BTC XBT ETH SOL XRP BNB LTC XMR ADA DOGE SHIB AVAX DOT LINK TRX TON SUI APT NEAR ATOM HYPE BASE MON CAKE TAO PEPE
  BONK WIF JUP ARB OP UNI AAVE MKR ETC BCH XLM HBAR FIL ICP VET ALGO EOS XTZ SEI TIA INJ RNDR RENDER FET WLD PYTH JTO RAY
  ORCA PUMP USDC USDT DAI ENA ONDO PENGU TRUMP FARTCOIN POPCAT MEW BOME GOAT ZEC KAS STX IMX GRT SAND MANA AXS APE LDO
  CRV SNX COMP YFI ENS GMX DYDX PENDLE FLOKI BRETT TOSHI DEGEN AERO VIRTUAL GRASS TNSR ZRO STRK TOLY WBTC CBBTC
  AAPL NVDA NVIDIA AMD TSLA MSFT GOOG GOOGL AMZN META NFLX UBER HOOD GME AMC COIN MSTR PLTR INTC IBM ORCL CRM ADBE PYPL
  SHOP SNAP PINS RBLX DIS NKE SBUX MCD WMT COST TGT JPM BAC GS WFC SPY QQQ DIA IWM VOO VTI ETF GLD SLV USO TLT ARKK DJT
  RDDT CRCL SMCI AVGO TSM ASML QCOM BABA NIO RIVN LCID XOM CVX PFE MRNA LLY UNH ABNB LYFT DASH ROKU SPOT
  CPU GPU RAM PSU SSD HDD USB RGB LED RSI MACD EMA IPO CEO GDP CPI FOMC SEC IRS NASA FBI CIA`),
);

const CONNECTORS = new Set(W('and or of in da dat the a an on to for is my ur n & at with'));
const GENERIC = new Set(W('coin coins token official sol solana pump fun the'));

const norm = (s) => String(s || '').toLowerCase();

// Keyword hidden inside a compound word: "LOOOONGCAT", "PlasticInu", "Titster", "Sexbot".
const SUBSTRING_TAGS = new Set(['titty', 'nsfw', 'animal', 'kol', 'ai']);
const SHORT_SUB_OK = new Set(W('tits boob pepe doge sexy milf goon neko grok thicc'));
const END_OK = new Set(W('inu cat dog'));
function inCompound(word, k) {
  if (word === k || word.length <= k.length) return false;
  if (k.length >= 5 || SHORT_SUB_OK.has(k)) return word.includes(k);
  if (END_OK.has(k)) return word.endsWith(k) || (word.startsWith(k) && word.length <= k.length + 3);
  return false;
}
export const tickerOf = (sym) => String(sym || '').toUpperCase().replace(/[^A-Z0-9]/g, '');

function wordsOf(name) {
  return String(name || '')
    .replace(/[_\-./]/g, ' ')
    .split(/\s+/)
    .map((w) => w.replace(/[^\p{L}\p{N}&]/gu, ''))
    .filter(Boolean);
}

// Does the name spell the ticker? "Big Titty Coin" -> BTC, "Extra Massive Rear" -> XMR,
// "Tight and Orgasmic" -> TAO, "Nut Vigorously In Dat Ass" -> NVDA.
export function isBackronym(name, symbol) {
  const t = tickerOf(symbol);
  if (t.length < 2 || t.length > 8 || /\d/.test(t)) return false;
  const words = wordsOf(name);
  if (words.length < 2 || words.length > t.length + 2) return false;
  const opts = words.map((w) => {
    const lw = w.toLowerCase();
    const set = new Set([w[0].toUpperCase()]);
    if (lw.startsWith('ex')) set.add('X');
    return { set, connector: CONNECTORS.has(lw) };
  });
  // DP: match ticker letters in order; connector words may be skipped freely,
  // at most one other word may be skipped.
  const memo = new Map();
  const go = (i, j, skips) => {
    if (j === t.length) {
      for (let k = i; k < opts.length; k++) if (!opts[k].connector) return false;
      return true;
    }
    if (i === opts.length) return false;
    const key = `${i},${j},${skips}`;
    if (memo.has(key)) return memo.get(key);
    let ok = false;
    if (opts[i].set.has(t[j])) ok = go(i + 1, j + 1, skips);
    if (!ok && opts[i].connector) ok = go(i + 1, j, skips);
    if (!ok && skips < 1 && i > 0) ok = go(i + 1, j, skips + 1);
    memo.set(key, ok);
    return ok;
  };
  return go(0, 0, 0);
}

export function isRealTickerVamp(symbol) {
  const t = tickerOf(symbol);
  if (t.length < 2) return false;
  if (REAL_TICKERS.has(t)) return true;
  // one-letter prefix/suffix of a big ticker: ABTC (Anime BTC), AETH, GLDX
  if (t.length >= 4 && (REAL_TICKERS.has(t.slice(1)) || REAL_TICKERS.has(t.slice(0, -1)))) {
    const core = REAL_TICKERS.has(t.slice(1)) ? t.slice(1) : t.slice(0, -1);
    return core.length >= 3;
  }
  return false;
}

export function classify(coin, opts = {}) {
  const name = coin?.name || '';
  const symbol = coin?.symbol || '';
  const words = [...wordsOf(name), ...wordsOf(symbol)].map(norm);
  const tags = new Set();
  for (const [tag, list] of Object.entries(KEYWORDS)) {
    for (const k of list) {
      if (words.includes(k) || (SUBSTRING_TAGS.has(tag) && words.some((w) => inCompound(w, k)))) {
        tags.add(tag);
        break;
      }
    }
  }
  const squashed = norm(name + ' ' + symbol).replace(/[^a-z0-9]/g, '');
  if (squashed.includes('sling')) tags.add('kol');
  if ((opts.selfWords || []).some((w) => w && squashed.includes(w))) tags.add('self');
  if (coin?.nsfw) tags.add('nsfw');
  const spelled = isBackronym(name, symbol);
  const ticker = isRealTickerVamp(symbol);
  // Plain initials ("Peanut Butter" = PB) are normal coin naming, not a meta.
  // It only counts when the ticker is a real one, or the spelled-out name is dirty.
  const backronym = spelled && (ticker || tags.has('titty') || tags.has('nsfw'));
  if (backronym) tags.add('backronym');
  if (ticker) tags.add('ticker');
  if (/x\.com\/[^/]+\/status\/|twitter\.com\/[^/]+\/status\//.test(coin?.twitter || '')) tags.add('tweet');
  return {
    tags: [...tags],
    backronym,
    ticker,
    // The "Big Titty Coin" formula: a real ticker spelled out as something dirty/funny
    bigTittyMeta: backronym,
    words: [...new Set(words.filter((w) => w.length >= 3 && !CONNECTORS.has(w)))],
  };
}

export function tagText(tags) {
  return tags.map((t) => `${TAGS[t]?.emoji || ''} ${TAGS[t]?.label || t}`).join(' · ');
}

export class MetaProfile {
  constructor({ selfWords = [] } = {}) {
    this.selfWords = selfWords.map((w) => w.toLowerCase().replace(/[^a-z0-9]/g, '')).filter((w) => w.length >= 3);
    this.coins = new Map(); // mint -> {mint, name, symbol, weight, sources:Set, cls}
    this.tagWeight = {};
    this.total = 0;
    this.updatedAt = 0;
  }

  add(coin, weight = 1, source = 'trade') {
    if (!coin?.mint || (!coin.name && !coin.symbol)) return;
    const cls = classify(coin, { selfWords: this.selfWords });
    const prev = this.coins.get(coin.mint);
    if (prev) {
      prev.weight += weight;
      prev.sources.add(source);
      if (coin.valueUsd) prev.valueUsd = coin.valueUsd;
    } else {
      this.coins.set(coin.mint, {
        mint: coin.mint,
        name: coin.name,
        symbol: coin.symbol,
        weight,
        valueUsd: coin.valueUsd || 0,
        sources: new Set([source]),
        cls,
      });
    }
    this._recount();
  }

  _recount() {
    this.tagWeight = {};
    this.total = 0;
    for (const c of this.coins.values()) {
      this.total += c.weight;
      for (const t of c.cls.tags) this.tagWeight[t] = (this.tagWeight[t] || 0) + c.weight;
    }
    this.updatedAt = Date.now();
  }

  share(tag) {
    return this.total ? (this.tagWeight[tag] || 0) / this.total : 0;
  }

  topTags(n = 6) {
    return Object.keys(this.tagWeight)
      .map((t) => ({ tag: t, share: this.share(t) }))
      .sort((a, b) => b.share - a.share)
      .slice(0, n);
  }

  // Coins of his with this tag, biggest first
  examples(tag, n = 4) {
    return [...this.coins.values()]
      .filter((c) => c.cls.tags.includes(tag))
      .sort((a, b) => b.weight - a.weight)
      .slice(0, n);
  }

  match(coin) {
    const cls = classify(coin, { selfWords: this.selfWords });
    const top = this.topTags(3);
    const core = new Set(this.topTags(6).filter((t) => t.share >= 0.15).map((t) => t.tag));
    const topSum = top.reduce((s, t) => s + t.share, 0) || 1;
    const hit = cls.tags.reduce((s, t) => s + this.share(t), 0);
    let score = Math.round(Math.min(1, hit / topSum) * 100);
    if (cls.bigTittyMeta) score = Math.max(score, 90);
    const coreHits = cls.tags.filter((t) => core.has(t));
    const similar = this.similar(coin, cls, 3);
    const series = this.series(coin, cls);
    // level: 3 = Big Titty Coin formula, 2 = strong match, 1 = partial, 0 = off-meta
    let level = 0;
    if (cls.bigTittyMeta) level = 3;
    else if (score >= 50 || coreHits.length >= 2 || series.length || cls.tags.includes('self')) level = 2;
    else if (coreHits.length === 1 || score >= 30) level = 1;
    return { ...cls, name: coin.name, symbol: coin.symbol, score, coreHits, level, isMatch: level >= 2, similar, series };
  }

  // Coins of his from the same "series": same ticker, or 2+ name words in common
  // ("Cute Crypto Faucet" -> his "Cute Crypto Carrot", "Cute Crypto Bottom").
  series(coin, cls = classify(coin, { selfWords: this.selfWords }), n = 3) {
    const t = tickerOf(coin.symbol);
    const words = cls.words.filter((w) => !GENERIC.has(w));
    const out = [];
    const seen = new Set();
    const list = [...this.coins.values()].sort((a, b) => b.weight - a.weight);
    for (const c of list) {
      if (c.mint === coin.mint) continue;
      const shared = words.filter((w) => c.cls.words.includes(w)).length;
      const bothSelf = cls.tags.includes('self') && c.cls.tags.includes('self');
      if (shared < 2 && !bothSelf && !(t.length >= 2 && tickerOf(c.symbol) === t)) continue;
      const k = `${tickerOf(c.symbol)}|${String(c.name).toLowerCase()}`;
      if (seen.has(k)) continue;
      seen.add(k);
      out.push(c);
      if (out.length >= n) break;
    }
    return out;
  }

  similar(coin, cls = classify(coin, { selfWords: this.selfWords }), n = 3) {
    const t = tickerOf(coin.symbol);
    const scored = [];
    for (const c of this.coins.values()) {
      if (c.mint === coin.mint) continue;
      let s = 0;
      for (const tag of cls.tags) if (c.cls.tags.includes(tag)) s += tag === 'tweet' ? 0.5 : 2;
      for (const w of cls.words) if (c.cls.words.includes(w)) s += 1.5;
      if (t && tickerOf(c.symbol) === t) s += 3;
      if (cls.bigTittyMeta && c.cls.bigTittyMeta) s += 2;
      if (s < 3) continue;
      s += Math.log10(1 + c.weight);
      scored.push({ c, s });
    }
    const out = [];
    const seen = new Set();
    for (const { c } of scored.sort((a, b) => b.s - a.s)) {
      const k = `${tickerOf(c.symbol)}|${String(c.name).toLowerCase()}`;
      if (seen.has(k)) continue;
      seen.add(k);
      out.push(c);
      if (out.length >= n) break;
    }
    return out;
  }
}
