// V2.9.1 hourly PnL goal: once this clock hour's closed trades (all wallets) reach the goal, the bot
// makes no NEW buys until the next hour starts (1:35 hit -> buying again at 2:00). Coins it already
// holds keep every sell rule, so a coin still running up still sells for profit (and that counts too).
// V2.9.2 adaptive: an hour that hit the goal raises the next hour's goal (to what that hour made, and at
// least +10%); an hour that missed keeps it the same (never lower). A new day goes back to your goal.
import fs from 'node:fs';
import path from 'node:path';

export const hourKey = (t) => {
  const d = new Date(t);
  return `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}-${d.getHours()}`;
};
const dayKey = (t) => {
  const d = new Date(t);
  return `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;
};
const RAISE = 1.1; // at least +10% after an hour that hit the goal

export class HourlyGoal {
  constructor({ file, sol = 0, pnl, onHit = () => {}, onRaise = () => {}, now = () => Date.now() }) {
    this.file = file;
    this.pnl = pnl; // () => SOL made by closed trades since the start of this hour
    this.onHit = onHit;
    this.onRaise = onRaise;
    this.now = now;
    this.d = { base: sol, sol, hitHour: null, hitAt: null, day: null, hour: null, made: 0 };
    try {
      const f = JSON.parse(fs.readFileSync(file, 'utf8'));
      this.d = { ...this.d, ...f, base: f.base ?? f.sol ?? sol };
    } catch {}
  }

  save() {
    try {
      fs.mkdirSync(path.dirname(this.file), { recursive: true });
      fs.writeFileSync(this.file, JSON.stringify(this.d));
    } catch {}
  }

  get sol() {
    return this.d.sol; // this hour's goal
  }

  get base() {
    return this.d.base; // the goal you set (where each day starts)
  }

  hourPnl() {
    return this.pnl() || 0;
  }

  // keeps the hour/day bookkeeping current: raise after a hit hour, back to your goal on a new day
  _roll() {
    const t = this.now();
    const hk = hourKey(t);
    const dk = dayKey(t);
    if (this.d.hour === hk) {
      this.d.made = this.hourPnl(); // latest number for this hour (used when it ends)
      return;
    }
    let changed = this.d.hour != null;
    if (this.d.day !== dk) {
      if (this.d.day != null && this.d.sol !== this.d.base) changed = true;
      this.d.sol = this.d.base; // new day: back to normal
    } else if (this.d.hour && this.d.hitHour === this.d.hour && this.d.base > 0) {
      const was = this.d.sol;
      this.d.sol = Math.round(Math.max(was * RAISE, this.d.made || 0) * 10000) / 10000;
      this.onRaise({ from: was, to: this.d.sol, made: this.d.made });
    }
    this.d.day = dk;
    this.d.hour = hk;
    this.d.made = this.hourPnl();
    if (changed) this.save();
  }

  // true = goal reached this hour: don't buy
  reached() {
    if (!(this.d.base > 0)) return false;
    this._roll();
    const key = hourKey(this.now());
    if (this.d.hitHour === key) return true;
    const p = this.hourPnl();
    if (p + 1e-9 < this.d.sol) return false;
    this.d.hitHour = key;
    this.d.hitAt = this.now();
    this.save();
    const next = new Date(this.now());
    next.setMinutes(60, 0, 0);
    this.onHit({ pnl: p, goal: this.d.sol, until: next.getTime() });
    return true;
  }

  // /goal 0.05: your goal (today restarts from it) · 0 = off
  set(sol) {
    const v = sol > 0 ? sol : 0;
    this.d = { base: v, sol: v, hitHour: null, hitAt: null, day: dayKey(this.now()), hour: hourKey(this.now()), made: this.hourPnl() };
    this.save();
    this.reached(); // already past the new goal this hour -> stops now
  }

  line() {
    if (!(this.d.base > 0)) return [];
    this._roll();
    const p = this.hourPnl();
    const hit = this.d.hitHour === hourKey(this.now());
    const t = (ms) => new Date(ms).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
    const up = this.d.sol > this.d.base + 1e-9 ? ` (raised from ${this.d.base})` : '';
    return [`🎯 Hourly goal ${this.d.sol} SOL${up}: ${hit ? `hit at ${t(this.d.hitAt)} ✅ (this hour ${p >= 0 ? '+' : '-'}${Math.abs(p).toFixed(3)})` : `this hour ${p >= 0 ? '+' : '-'}${Math.abs(p).toFixed(3)}`}`];
  }
}

// V2.11.12 daily goal (Khalil, Nov 13: "1 sol a day daily goal"): once today's closed trades (all wallets)
// made this much SOL, no NEW buys until midnight. Coins already held keep every sell rule.
export class DailyGoal {
  constructor({ file, sol = 0, pnl, onHit = () => {}, now = () => Date.now() }) {
    this.file = file;
    this.pnl = pnl; // () => SOL made by closed trades today
    this.onHit = onHit;
    this.now = now;
    this.d = { sol, hitDay: null, hitAt: null };
    try {
      this.d = { ...this.d, ...JSON.parse(fs.readFileSync(file, 'utf8')) };
    } catch {}
  }

  save() {
    try {
      fs.mkdirSync(path.dirname(this.file), { recursive: true });
      fs.writeFileSync(this.file, JSON.stringify(this.d));
    } catch {}
  }

  get sol() {
    return this.d.sol;
  }

  dayPnl() {
    return this.pnl() || 0;
  }

  // true = today's goal is reached: don't buy until midnight
  reached() {
    if (!(this.d.sol > 0)) return false;
    const key = dayKey(this.now());
    if (this.d.hitDay === key) return true;
    const p = this.dayPnl();
    if (p + 1e-9 < this.d.sol) return false;
    this.d.hitDay = key;
    this.d.hitAt = this.now();
    this.save();
    this.onHit({ pnl: p, goal: this.d.sol });
    return true;
  }

  // /daygoal 1 · /daygoal off
  set(sol) {
    this.d = { sol: sol > 0 ? sol : 0, hitDay: null, hitAt: null };
    this.save();
    this.reached();
  }

  line() {
    if (!(this.d.sol > 0)) return [];
    const p = this.dayPnl();
    const hit = this.d.hitDay === dayKey(this.now());
    const sg = `${p >= 0 ? '+' : '-'}${Math.abs(p).toFixed(3)}`;
    return [`🏁 Daily goal ${this.d.sol} SOL: today ${sg}${hit ? ' — hit ✅ (no new buys until midnight)' : ` (${Math.max(0, Math.min(100, Math.round((p / this.d.sol) * 100)))}%)`}`];
  }
}
