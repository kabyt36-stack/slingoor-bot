import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { HourlyGoal } from '../src/goal.js';

const at = (h, m) => new Date(2026, 10, 12, h, m, 0).getTime();
const file = () => path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'goal-')), 'goal.json');

test('hourly goal: hit at 1:35 -> no new buys until 2:00, then buying again', () => {
  let now = at(13, 10);
  let pnl = 0.02;
  const hits = [];
  const f = file();
  const g = new HourlyGoal({ file: f, sol: 0.05, pnl: () => pnl, now: () => now, onHit: (x) => hits.push(x) });
  assert.equal(g.reached(), false, 'under the goal: keeps buying');
  now = at(13, 35);
  pnl = 0.064;
  assert.equal(g.reached(), true, 'goal hit');
  assert.equal(hits.length, 1);
  assert.equal(new Date(hits[0].until).getHours(), 14, 'paused until 2:00');
  assert.equal(new Date(hits[0].until).getMinutes(), 0);
  // a held coin keeps running and sells for more profit: still counted, still paused, no second alert
  pnl = 0.12;
  now = at(13, 50);
  assert.equal(g.reached(), true);
  assert.equal(hits.length, 1);
  assert.match(g.line()[0], /hit at 1:35 PM ✅ \(this hour \+0\.120\)/);
  // dipping back under the goal later in the same hour doesn't restart buying
  pnl = 0.01;
  assert.equal(g.reached(), true);
  // restart keeps it
  assert.equal(new HourlyGoal({ file: f, pnl: () => pnl, now: () => now }).reached(), true);
  // next hour: buying again
  now = at(14, 0);
  pnl = 0;
  assert.equal(g.reached(), false);
});

test('hourly goal: off by default, /goal off stops it, setting it under what this hour already made stops buys now', () => {
  let pnl = 0.08;
  const g = new HourlyGoal({ file: file(), pnl: () => pnl, now: () => at(9, 20) });
  assert.equal(g.reached(), false, 'no goal');
  assert.deepEqual(g.line(), []);
  g.set(0.05);
  assert.equal(g.reached(), true, 'already +0.08 this hour');
  g.set(0);
  assert.equal(g.reached(), false, 'off');
});

test('V2.9.2 adaptive: a hit hour raises the next goal (to what it made, at least +10%), a missed hour keeps it, a new day resets', () => {
  let now = at(13, 5);
  let pnl = 0;
  const f = file();
  const raises = [];
  const g = new HourlyGoal({ file: f, pnl: () => pnl, now: () => now, onRaise: (r) => raises.push(r) });
  g.set(0.05);
  pnl = 0.08; // 1pm: hit (held coins kept selling: +0.08 by the end of the hour)
  now = at(13, 40);
  assert.equal(g.reached(), true);
  now = at(14, 0);
  pnl = 0;
  assert.equal(g.reached(), false, '2pm: buying again');
  assert.equal(g.sol, 0.08, 'raised to what 1pm made');
  pnl = 0.06; // 2pm: missed the 0.08 goal
  now = at(14, 50);
  assert.equal(g.reached(), false);
  now = at(15, 1);
  pnl = 0.0;
  g.reached();
  assert.equal(g.sol, 0.08, 'missed hour: stays the same, never lower');
  pnl = 0.081; // 3pm: just hit it -> next at least +10%
  now = at(15, 30);
  assert.equal(g.reached(), true);
  now = at(16, 0);
  pnl = 0;
  g.reached();
  assert.equal(g.sol, 0.088, '+10% minimum');
  assert.equal(raises.length, 2);
  assert.match(g.line()[0], /Hourly goal 0\.088 SOL \(raised from 0\.05\)/);
  // survives a restart
  const g2 = new HourlyGoal({ file: f, pnl: () => pnl, now: () => now });
  g2.reached();
  assert.equal(g2.sol, 0.088);
  // next day: back to normal
  now = at(16, 0) + 24 * 3600000;
  g2.reached();
  assert.equal(g2.sol, 0.05, 'new day: back to your goal');
  assert.equal(g2.base, 0.05);
});

test('V2.11.12 daily goal: once today made 1 SOL, no new buys until midnight; tomorrow buys again', async () => {
  const { DailyGoal } = await import('../src/goal.js');
  const fs2 = await import('node:fs');
  const os2 = await import('node:os');
  const path2 = await import('node:path');
  let now = new Date(2026, 10, 13, 6, 0).getTime();
  let pnl = 0;
  const hits = [];
  const g = new DailyGoal({ file: path2.join(fs2.mkdtempSync(path2.join(os2.tmpdir(), 'dg-')), 'g.json'), sol: 1, pnl: () => pnl, now: () => now, onHit: (x) => hits.push(x) });
  pnl = 0.6;
  assert.equal(g.reached(), false);
  assert.match(g.line()[0], /Daily goal 1 SOL: today \+0\.600 \(60%\)/);
  pnl = 1.02;
  assert.equal(g.reached(), true);
  assert.equal(hits.length, 1);
  pnl = 0.8; // a loss later today: still stopped for today
  assert.equal(g.reached(), true);
  assert.match(g.line()[0], /hit ✅/);
  now = new Date(2026, 10, 14, 0, 1).getTime();
  pnl = 0;
  assert.equal(g.reached(), false, 'new day: buying again');
  g.set(0);
  assert.equal(g.reached(), false);
  assert.deepEqual(g.line(), []);
});
