// V2.10 auto-rotate (Khalil, Nov 12 7:08pm): the bot follows every trader with pretend wallets and decides
// who your wallets copy:
//   hot  (his pretend wallets made money over the last 24h, with enough coins) -> start copying him
//   cold (not copied, not hot)                                                 -> stays off until hot again
//   copied and winning                                                          -> keeps being copied
//   copied and losing (last 24h under zero)                                     -> gets a day; still losing a
//                                                                                  day later -> stopped
//   new wallet (tracked under 2 days)                                           -> not used yet
import fs from 'node:fs';
import path from 'node:path';

const DAY = 24 * 3600000;

export class Rotator {
  constructor({ file, now = () => Date.now(), recent, traders, minCoins = 8, newMs = 2 * DAY, graceMs = DAY, start = [] }) {
    this.file = file;
    this.now = now;
    this.recent = recent; // (trader, ms) -> { coins, pnl } of his pretend wallets in that window
    this.traders = traders; // () => names that can be copied
    this.minCoins = minCoins;
    this.newMs = newMs;
    this.graceMs = graceMs;
    this.d = { on: true, copying: [...start], losingSince: {}, firstSeen: {}, log: [] };
    try {
      this.d = { ...this.d, ...JSON.parse(fs.readFileSync(file, 'utf8')) };
    } catch {}
  }

  save() {
    try {
      fs.mkdirSync(path.dirname(this.file), { recursive: true });
      fs.writeFileSync(this.file + '.tmp', JSON.stringify(this.d));
      fs.renameSync(this.file + '.tmp', this.file);
    } catch {}
  }

  get on() {
    return this.d.on;
  }

  set on(v) {
    this.d.on = !!v;
    this.save();
  }

  get copying() {
    return [...this.d.copying];
  }

  // a trader the ghosts just saw buying (starts his 2-day trial)
  seen(trader) {
    if (!trader || this.d.firstSeen[trader]) return;
    this.d.firstSeen[trader] = this.now();
    this.save();
  }

  ageMs(trader) {
    const f = this.d.firstSeen[trader];
    return f ? this.now() - f : 0;
  }

  // one decision round. Returns { added: [{name, pnl, coins}], dropped: [...], warned: [...] }
  run() {
    const out = { added: [], dropped: [], warned: [] };
    if (!this.d.on) return out;
    const names = this.traders();
    const copying = new Set(this.d.copying.filter((n) => names.includes(n)));
    for (const n of names) {
      const r = this.recent(n, DAY) || { coins: 0, pnl: 0 };
      if (copying.has(n)) {
        if (r.coins >= Math.min(3, this.minCoins) && r.pnl < 0) {
          // losing: one day of grace from the first time it went red
          if (!this.d.losingSince[n]) {
            this.d.losingSince[n] = this.now();
            out.warned.push({ name: n, ...r });
          } else if (this.now() - this.d.losingSince[n] >= this.graceMs) {
            copying.delete(n);
            delete this.d.losingSince[n];
            out.dropped.push({ name: n, ...r });
          }
        } else if (r.pnl >= 0) delete this.d.losingSince[n]; // back to winning (or quiet): clock reset
        continue;
      }
      // not copied: needs 2 days of tracking, enough coins in the last day, and a profit
      if (this.ageMs(n) < this.newMs) continue;
      if (r.coins >= this.minCoins && r.pnl > 0) {
        copying.add(n);
        delete this.d.losingSince[n];
        out.added.push({ name: n, ...r });
      }
    }
    this.d.copying = [...copying];
    const at = this.now();
    for (const x of out.added) this.d.log.push({ at, name: x.name, what: 'added', pnl: x.pnl });
    for (const x of out.dropped) this.d.log.push({ at, name: x.name, what: 'dropped', pnl: x.pnl });
    if (this.d.log.length > 200) this.d.log.splice(0, this.d.log.length - 200);
    this.d.lastRun = at;
    this.save();
    return out;
  }

  statusText() {
    const names = this.traders();
    const sg = (n) => `${n >= 0 ? '+' : '-'}${Math.abs(n).toFixed(3)}`;
    const lines = [`🔄 <b>Auto-rotate</b> is <b>${this.d.on ? 'ON' : 'OFF'}</b> — copying: <b>${this.d.copying.join(', ') || 'nobody yet'}</b>`];
    for (const n of names) {
      const r = this.recent(n, DAY) || { coins: 0, pnl: 0 };
      const age = this.ageMs(n);
      let state;
      if (this.d.copying.includes(n)) state = this.d.losingSince[n] ? `🟠 copied, losing — stops ${new Date(this.d.losingSince[n] + this.graceMs).toLocaleString('en-US', { weekday: 'short', hour: 'numeric', minute: '2-digit' })} unless it turns around` : '🟢 copied';
      else if (age < this.newMs) state = `🆕 new — usable in ${Math.ceil((this.newMs - age) / 3600000)}h`;
      else if (r.coins < this.minCoins) state = `⚪ quiet (${r.coins} coins in 24h, needs ${this.minCoins})`;
      else state = r.pnl > 0 ? '🔥 hot — added at the next check' : '🧊 cold';
      lines.push(`• <b>${n}</b>: ${state} · last 24h ${sg(r.pnl)} SOL (${r.coins} coins)`);
    }
    lines.push('', '<i>Hot = his 4 pretend wallets made SOL in the last 24h. Losing traders get a day before they stop. New wallets wait 2 days.</i>', '/rotate on|off');
    return lines.join('\n');
  }
}
