import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { Rotator } from '../src/rotate.js';

const H = 3600000;
const file = () => path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'rot-')), 'r.json');

test('auto-rotate: hot traders get copied, losers get a day, new wallets wait 2 days, cold ones wait to get hot', () => {
  let now = 1_000 * H;
  const res = { dilly: { coins: 30, pnl: -0.2 }, schoen: { coins: 12, pnl: 0.15 }, t1: { coins: 20, pnl: 0.4 }, ansem: { coins: 2, pnl: 0.05 }, killua: { coins: 15, pnl: -0.1 } };
  const r = new Rotator({ file: file(), now: () => now, recent: (n) => res[n], traders: () => Object.keys(res), start: ['dilly'] });
  for (const n of ['dilly', 'schoen', 'ansem', 'killua']) {
    now -= 49 * H; // these have been tracked 2+ days
    r.seen(n);
    now += 49 * H;
  }
  r.seen('t1'); // brand new
  let out = r.run();
  assert.deepEqual(out.added.map((x) => x.name), ['schoen'], 'schoen is hot; t1 too new; ansem too few coins; killua cold');
  assert.deepEqual(out.warned.map((x) => x.name), ['dilly'], 'dilly copied but losing: warned, still copied');
  assert.deepEqual(r.copying.sort(), ['dilly', 'schoen']);
  // 12h later dilly still red: still inside his day
  now += 12 * H;
  out = r.run();
  assert.ok(r.copying.includes('dilly'));
  // a day after he turned red, still red: dropped
  now += 13 * H;
  out = r.run();
  assert.deepEqual(out.dropped.map((x) => x.name), ['dilly']);
  assert.deepEqual(r.copying, ['schoen']);
  // t1 is past his 2 days now and still hot: added
  now += 24 * H;
  out = r.run();
  assert.deepEqual(out.added.map((x) => x.name), ['t1']);
  // schoen dips red then recovers inside his day: kept, clock reset
  res.schoen = { coins: 10, pnl: -0.05 };
  out = r.run();
  assert.deepEqual(out.warned.map((x) => x.name), ['schoen']);
  now += 6 * H;
  res.schoen = { coins: 10, pnl: 0.02 };
  r.run();
  assert.equal(r.d.losingSince.schoen, undefined, 'recovered: clock reset');
  now += 30 * H;
  r.run();
  assert.ok(r.copying.includes('schoen'), 'kept');
  // killua turns hot later: added
  res.killua = { coins: 9, pnl: 0.03 };
  assert.deepEqual(r.run().added.map((x) => x.name), ['killua']);
  // survives a restart; off = no changes
  const r2 = new Rotator({ file: r.file, now: () => now, recent: (n) => res[n], traders: () => Object.keys(res) });
  assert.deepEqual(r2.copying.sort(), ['killua', 'schoen', 't1']);
  r2.on = false;
  res.t1 = { coins: 20, pnl: -1 };
  now += 48 * H;
  r2.run();
  r2.run();
  assert.ok(r2.copying.includes('t1'), 'off: nothing changes');
  const st = r2.statusText();
  assert.match(st, /Auto-rotate<\/b> is <b>OFF/);
  assert.match(st, /<b>schoen<\/b>: 🟢 copied/);
});

test('auto-rotate status shows new wallets\' wait and quiet/cold ones', () => {
  let now = 500 * H;
  const res = { t9: { coins: 1, pnl: 0 }, dilly: { coins: 20, pnl: -0.3 } };
  const r = new Rotator({ file: file(), now: () => now, recent: (n) => res[n], traders: () => Object.keys(res) });
  r.seen('t9');
  now -= 72 * H;
  r.seen('dilly');
  now += 72 * H;
  const st = r.statusText();
  assert.match(st, /<b>t9<\/b>: 🆕 new — usable in 48h/);
  assert.match(st, /<b>dilly<\/b>: 🧊 cold · last 24h -0\.300 SOL \(20 coins\)/);
  assert.match(st, /copying: <b>nobody yet<\/b>/);
});
