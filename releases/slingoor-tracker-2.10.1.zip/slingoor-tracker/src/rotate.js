// V2.10 auto-rotate (Khalil, Nov 12 7:08pm / 7:11pm): the bot follows every trader with pretend wallets and
// decides on its own who your wallets copy — judged on his LAST 30 TRADES (a trader can get hot at any time
// of day), not on the clock:
//   hot  : his last 30 pretend trades clearly made money (winners made at least 2x what the losers lost,
//          e.g. +31 vs -3) -> start copying him
//   copied and winning -> keeps being copied
//   copied and losing  : he lost more than he won over his last 30 trades -> stop (break-even stays)
//   cold : not copied until he's hot again
//   new wallet (tracked under 2 days) -> not used yet
import fs from 'node:fs';
import path from 'node:path';

const DAY = 24 * 3600000;

export class Rotator {
  constructor({ file, now = () => Date.now(), recent, traders, minCoins = 20, window = 30, hotRatio = 2, newMs = 2 * DAY, start = [] }) {
    this.file = file;
    this.now = now;
    this.recent = recent; // (trader, n) -> { coins, pnl, gains, losses, last10 } of his last n pretend trades
    this.window = window;
    this.hotRatio = hotRatio;
    this.traders = traders; // () => names that can be copied
    this.minCoins = minCoins;
    this.newMs = newMs;
    this.d = { on: true, copying: [...start], losingSince: {}, firstSeen: {}, log: [] };
    try {
      this.d = { ...this.d, ...JSON.parse(fs.readFileSync(file, 'utf8')) };
    } catch {}
  }

  save() {
    try {
      fs.mkdirSync(path.dirname(this.file), { recursive: true });
      fs.writeFileSync(this.file + '.tmp', JSON.stringify(this.d));
      fs.renameSync(this.file + '.tmp', this.file);
    } catch {}
  }

  get on() {
    return this.d.on;
  }

  set on(v) {
    this.d.on = !!v;
    this.save();
  }

  get copying() {
    return [...this.d.copying];
  }

  // a trader the ghosts just saw buying (starts his 2-day trial)
  seen(trader) {
    if (!trader || this.d.firstSeen[trader]) return;
    this.d.firstSeen[trader] = this.now();
    this.save();
  }

  ageMs(trader) {
    const f = this.d.firstSeen[trader];
    return f ? this.now() - f : 0;
  }

  isHot(r) {
    return r.coins >= this.minCoins && r.pnl > 0 && r.gains >= this.hotRatio * r.losses;
  }

  // one decision round. Returns { added: [...], dropped: [...] } with each trader's last-30 numbers
  run() {
    const out = { added: [], dropped: [], warned: [] };
    if (!this.d.on) return out;
    const names = this.traders();
    const copying = new Set(this.d.copying.filter((n) => names.includes(n)));
    for (const n of names) {
      const r = this.recent(n, this.window) || { coins: 0, pnl: 0, gains: 0, losses: 0, last10: 0 };
      if (copying.has(n)) {
        // lost more than he won over his last 30: stop (break-even or better stays)
        if (r.coins >= Math.min(10, this.minCoins) && r.pnl < 0) {
          copying.delete(n);
          out.dropped.push({ name: n, ...r });
        }
        continue;
      }
      if (this.ageMs(n) < this.newMs) continue; // new wallets: 2 days first
      if (this.isHot(r)) {
        copying.add(n);
        out.added.push({ name: n, ...r });
      }
    }
    this.d.copying = [...copying];
    const at = this.now();
    for (const x of out.added) this.d.log.push({ at, name: x.name, what: 'added', pnl: x.pnl });
    for (const x of out.dropped) this.d.log.push({ at, name: x.name, what: 'dropped', pnl: x.pnl });
    if (this.d.log.length > 200) this.d.log.splice(0, this.d.log.length - 200);
    this.d.lastRun = at;
    this.save();
    return out;
  }

  statusText() {
    const names = this.traders();
    const sg = (n) => `${n >= 0 ? '+' : '-'}${Math.abs(n).toFixed(3)}`;
    const lines = [`🔄 <b>Copying now</b> (picked automatically): <b>${this.d.copying.join(', ') || 'nobody yet'}</b>`];
    for (const n of names) {
      const r = this.recent(n, this.window) || { coins: 0, pnl: 0, gains: 0, losses: 0, last10: 0 };
      const age = this.ageMs(n);
      let state;
      if (this.d.copying.includes(n)) state = '🟢 copied';
      else if (age < this.newMs) state = `🆕 new — usable in ${Math.ceil((this.newMs - age) / 3600000)}h`;
      else if (r.coins < this.minCoins) state = `⚪ not enough trades yet (${r.coins}/${this.minCoins})`;
      else state = this.isHot(r) ? '🔥 hot — copied from the next check' : '🧊 cold';
      lines.push(`• <b>${n}</b>: ${state} · last ${r.coins}: ${sg(r.pnl)} (won ${sg(r.gains)}, lost -${r.losses.toFixed(3)})`);
    }
    lines.push(`<i>Copied when his last ${this.window} pretend trades clearly made money (winners ${this.hotRatio}x+ the losers); stopped when he's lost more than he won over his last ${this.window}. New wallets wait 2 days.</i>`);
    return lines.join('\n');
  }
}
