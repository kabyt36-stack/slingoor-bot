import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { GhostBook } from '../src/ghost.js';

const file = () => path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'gh-')), 'g.json');
const near = (a, b, e = 1e-6) => assert.ok(Math.abs(a - b) < e, `${a} vs ${b}`);

test('ghosts: side style sells all at +25%; main style rides; fees and our delay are counted', () => {
  let now = 1_000_000;
  const g = new GhostBook({ file: file(), now: () => now, fee: 0.0005, entryPenaltyPct: 5, rulesFor: () => ({}) });
  assert.equal(g.open('dilly', 'M1', 1e-7), true);
  assert.equal(g.open('dilly', 'M1', 1e-7), false, 'one buy per coin');
  const entry = 1.05e-7;
  now += 30000;
  g.price('M1', entry * 1.3); // +30% vs our (late) entry
  const sides = g.d.closed.filter((c) => c.style !== 'main');
  assert.deepEqual(sides.map((c) => c.style).sort(), ['W2', 'W3', 'W4'], 'three side wallets');
  for (const side of sides) {
    near(side.pnl, 0.05 * (1.3 / 1.02) - 0.0005 - (0.05 + 0.0005)); // they bought 2% later than the main
    assert.equal(side.why, '+25%');
  }
  assert.ok(Object.values(g.d.open).some((x) => x.style === 'main'), 'main still holding');
  // he sells everything: main sells at the last price
  g.hisSell('dilly', 'M1', 100, true);
  const main = g.d.closed.find((c) => c.style === 'main');
  near(main.pnl, 0.1 * 1.3 - 0.0005 - (0.1 + 0.0005));
  assert.equal(main.why, 'his exit');
  assert.equal(g.open('dilly', 'M1', 1e-7), false, 'no second buy after closing');
});

test('ghosts: stop loss -20% (two low prices in a row, after 60s), his partial sells, report ranks traders', () => {
  let now = 2_000_000;
  const g = new GhostBook({ file: file(), now: () => now, fee: 0, entryPenaltyPct: 0 });
  g.open('bot', 'L1', 1);
  now += 10000;
  g.price('L1', 0.7);
  g.price('L1', 0.7);
  assert.equal(g.d.closed.length, 0, 'not in the first 60s');
  now += 60000;
  g.price('L1', 0.7);
  assert.equal(g.d.closed.length, 0, 'first low check waits');
  g.price('L1', 0.7);
  assert.equal(g.d.closed.length, 4, 'all four wallets stopped out');
  assert.ok(g.d.closed.every((c) => c.why === 'stop loss'));
  // schoen: he sells half -> main sells half, side sells all
  g.open('schoen', 'W1', 1);
  now += 5000;
  g.price('W1', 1.2);
  g.hisSell('schoen', 'W1', 50, false);
  assert.equal(g.d.closed.filter((c) => c.trader === 'schoen' && c.style !== 'main' && c.why === 'he sold').length, 3);
  const m = Object.values(g.d.open).find((x) => x.trader === 'schoen');
  near(m.left, 0.5);
  g.hisSell('schoen', 'W1', 5, false); // tiny sells are ignored, like the real bot
  near(m.left, 0.5);
  g.price('W1', 2);
  g.hisSell('schoen', 'W1', 100, true);
  const r = g.report();
  // sides bought at 1.02: 0.05 x 1.2/1.02 = 0.0588 each -> +0.0088 x 3 = +0.026
  assert.match(r, /🟢 <b>schoen<\/b>: set \+0\.086 · main \+0\.060 \(1\/1\) · 3 sides \+0\.026 \(3\/3\) → best: main/);
  assert.match(r, /🔴 <b>bot<\/b>: set -0\.07\d · main -0\.030 \(0\/1\) · 3 sides -0\.04\d \(0\/3\)/);
  assert.ok(r.indexOf('schoen') < r.indexOf('bot'), 'best trader first');
  // survives a restart, reset clears
  g.save(true);
  assert.equal(new GhostBook({ file: g.file }).d.closed.length, 8);
  g.reset();
  assert.match(g.report(), /nothing yet/);
});

test('V2.9.11 a buy without a price (coins already on PumpSwap / Raydium) still opens the ghosts: they buy at the first price seen', () => {
  let now = 3_000_000;
  const g = new GhostBook({ file: file(), now: () => now, fee: 0, entryPenaltyPct: 5 });
  assert.equal(g.open('dilly', 'AMM1', null), true);
  assert.equal(Object.values(g.d.open).length, 4);
  g.hisSell('dilly', 'AMM1', 50, false); // no price yet: nothing happens
  assert.equal(g.d.closed.length, 0);
  now += 15000;
  g.price('AMM1', 2); // first price: the buy
  const m = Object.values(g.d.open).find((x) => x.style === 'main');
  near(m.entry, 2);
  near(Object.values(g.d.open).find((x) => x.style === 'W2').entry, 2.04, 1e-9);
  g.price('AMM1', 2.6); // sides: +27% -> sold
  assert.equal(g.d.closed.filter((c) => c.style !== 'main').length, 3);
  assert.match(g.report(), /<b>dilly<\/b>: set \+/);
});

test('V2.9.12 market-cap ranges: each trader\'s pretend wallets by market cap; sweet spot skips a range only after 8+ coins lost there', async () => {
  const { bandOf } = await import('../src/ghost.js');
  assert.equal(bandOf(8000), '<$10k');
  assert.equal(bandOf(45000), '$30-100k');
  assert.equal(bandOf(null), null);
  let now = 4_000_000;
  const g = new GhostBook({ file: file(), now: () => now, fee: 0, entryPenaltyPct: 0, solUsd: () => 100 });
  // price 1e-7 SOL x 1B x $100 = $10k... use 5e-8 -> $5k (under $10k) and 4e-7 -> $40k
  for (let i = 0; i < 9; i++) {
    g.open('dilly', `LOW${i}`, 5e-8);
    now += 61000;
    g.price(`LOW${i}`, 3e-8);
    g.price(`LOW${i}`, 3e-8); // -40%: stopped out
    g.open('dilly', `MID${i}`, 4e-7);
    g.price(`MID${i}`, 4e-7 * 1.5);
    g.hisSell('dilly', `MID${i}`, 100, true);
  }
  const bs = g.bandStats('dilly');
  assert.equal(bs['<$10k'].coins, 9);
  assert.ok(bs['<$10k'].pnl < 0);
  assert.equal(bs['$30-100k'].coins, 9);
  assert.equal(bs['$30-100k'].won, 9);
  assert.equal(g.allowed('dilly', 6000), false, 'low caps lost money: skipped');
  assert.equal(g.allowed('dilly', 50000), true, 'his good range: copied');
  assert.equal(g.allowed('dilly', 200000), true, 'no data there yet: copied');
  assert.equal(g.allowed('schoen', 6000), true, 'another trader: his own ranges');
  assert.equal(g.allowed('dilly', null), true, 'no market cap: copied');
  const t = g.sweetSpotText(['dilly', 'schoen']);
  assert.match(t, /<b>dilly<\/b>: ⛔ <\$10k -[\d.]+ \(0\/9\) · ✅ \$30-100k \+[\d.]+ \(9\/9\)/);
  assert.doesNotMatch(t, /schoen/, 'no data, no line');
  assert.match(g.report(), /📊 MC: \$30-100k \+[\d.]+ \(9\/9\) · <\$10k -/);
});
