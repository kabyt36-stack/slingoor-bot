import { accountKeysOf } from './parse.js';
import fs from 'node:fs';
import path from 'node:path';
import { log } from './log.js';
import { signTx } from './solana.js';
import { sleep, escHtml as e, fmtSol, fmtNum, fmtPct, fmtAgo, shortAddr, withTimeout } from './util.js';
import { linkButtons } from './format.js';

const LAMPORTS = 1e9;
const DUST_TOKENS = 1e-6;

const SOL_MINT = 'So11111111111111111111111111111111111111112';

// Builds swaps with Jupiter (free, routes pump.fun bonding-curve coins within seconds of launch,
// PumpSwap, Raydium, Meteora…) and falls back to PumpPortal if Jupiter has no route.
// Every transaction is signed with OUR key here on this computer and sent through our own RPC;
// the key never leaves this machine.
export class Swapper {
  constructor({ rpc, kp, jupBase, jupKey, portalBase, slippage, priorityFee, pool = 'auto', confirmTimeoutMs = 60000, jitoUrls = [] }) {
    this.jitoUrls = jitoUrls;
    this.rpc = rpc;
    this.kp = kp;
    this.jupBase = jupBase;
    this.jupKey = jupKey;
    this.portalBase = portalBase;
    this.slippage = slippage;
    this.priorityFee = priorityFee;
    this.pool = pool;
    this.confirmTimeoutMs = confirmTimeoutMs;
    this.jupNextAt = 0;
    this.lastVenue = null;
  }

  // background = a check that must never take a slot a trade might need right now
  async _jup(pathAndQuery, body, { background = false } = {}) {
    for (let attempt = 0; ; attempt++) {
      // free Jupiter API: 5 calls per 10s. Calls go out instantly while there's room in the window
      // (so a buy's quote + swap never wait), and only queue up when the window is full.
      if (background && this.jupBlockedUntil > Date.now()) throw Object.assign(new Error('busy: Jupiter is rate-limiting'), { busy: true });
      // calls allowed per ~10s window: keyless 5 (0.5/s); free key 10 (1/s); paid keys set JUPITER_RPS
      const max = this.jupWindowMax || (this.jupKey ? 10 : 5);
      if (background) {
        this.jupCalls = (this.jupCalls || []).filter((t) => Date.now() - t < 10500);
        // leave room for a full buy or sell (quote + swap) plus one retry
        if (this.jupCalls.length > max - 4) throw Object.assign(new Error('busy: Jupiter slots kept free for trades'), { busy: true });
      }
      for (;;) {
        this.jupCalls = (this.jupCalls || []).filter((t) => Date.now() - t < 10500);
        if (this.jupCalls.length < max) break;
        await sleep(Math.max(50, 10500 - (Date.now() - this.jupCalls[0])));
      }
      this.jupCalls.push(Date.now());
      const ctl = new AbortController();
      const t = setTimeout(() => ctl.abort(), 8000);
      let res;
      let text;
      try {
        res = await fetch(`${this.jupBase}${pathAndQuery}`, {
          method: body ? 'POST' : 'GET',
          headers: { 'content-type': 'application/json', ...(this.jupKey ? { 'x-api-key': this.jupKey } : {}) },
          body: body ? JSON.stringify(body) : undefined,
          signal: ctl.signal,
        });
        text = await res.text();
      } catch (err) {
        if (attempt < 2) continue;
        throw new Error(err.name === 'AbortError' ? 'Jupiter did not answer in 8s' : `Jupiter unreachable: ${err.message}`);
      } finally {
        clearTimeout(t);
      }
      if (res.status === 429 && attempt < 5) {
        // free tier: 5 calls per ~10s window. Wait until the window frees up.
        const reset = Number(res.headers.get('x-ratelimit-reset')) * 1000;
        const wait = reset > Date.now() ? Math.min(10000, reset - Date.now() + 150) : 2000;
        this.jupBlockedUntil = Date.now() + wait;
        log.debug(`Jupiter rate limit, waiting ${wait}ms`);
        await sleep(wait);
        continue;
      }
      if (res.status >= 500 && attempt < 2) {
        await sleep(800 * (attempt + 1));
        continue;
      }
      let j = null;
      try {
        j = JSON.parse(text);
      } catch {}
      if (res.status !== 200) throw Object.assign(new Error(`Jupiter ${res.status}: ${(j?.error || j?.message || text || '').toString().slice(0, 160)}`), { status: res.status, noRoute: /ROUTE|TRADABLE|not tradable|No route/i.test(text) });
      return j;
    }
  }

  async _jupBuild({ inputMint, outputMint, amount, slippage }, { allowSimError = false } = {}) {
    const q = await this._jup(`/quote?inputMint=${inputMint}&outputMint=${outputMint}&amount=${amount}&slippageBps=${Math.round((slippage || this.slippage) * 100)}&restrictIntermediateTokens=true`);
    if (!q?.outAmount) throw Object.assign(new Error('Jupiter found no route'), { noRoute: true });
    const s = await this._jup('/swap', {
      quoteResponse: q,
      userPublicKey: this.kp.publicKey,
      wrapAndUnwrapSol: true,
      dynamicComputeUnitLimit: true,
      prioritizationFeeLamports: { priorityLevelWithMaxLamports: { maxLamports: Math.round(this.priorityFee * LAMPORTS), priorityLevel: this.priorityLevel || 'veryHigh' } },
    });
    if (!s?.swapTransaction) throw new Error('Jupiter returned no transaction');
    if (s.simulationError && !allowSimError) throw new Error(`Jupiter's test run of the swap failed: ${explainSim(s.simulationError)}`);
    return new Uint8Array(Buffer.from(s.swapTransaction, 'base64'));
  }

  async _portalBuild({ action, mint, amount, denominatedInSol }) {
    const ctl = new AbortController();
    const t = setTimeout(() => ctl.abort(), 8000);
    try {
      const res = await fetch(`${this.portalBase}/trade-local`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          publicKey: this.kp.publicKey,
          action,
          mint,
          amount,
          denominatedInSol: denominatedInSol ? 'true' : 'false',
          slippage: this.slippage,
          priorityFee: this.priorityFee,
          pool: this.pool,
        }),
        signal: ctl.signal,
      });
      const buf = new Uint8Array(await res.arrayBuffer());
      if (res.status !== 200) {
        const msg = new TextDecoder().decode(buf).slice(0, 200);
        throw Object.assign(new Error(`PumpPortal ${res.status}: ${msg || 'no transaction'}`), { status: res.status });
      }
      if (buf.length < 100) throw new Error('PumpPortal returned an empty transaction');
      return buf;
    } catch (err) {
      if (err.name === 'AbortError') throw new Error('PumpPortal did not answer in 8s');
      throw err;
    } finally {
      clearTimeout(t);
    }
  }

  // Can Jupiter sell this coin right now? (some new pump.fun coin types can be bought but not sold yet)
  async canSell(mint) {
    const bal = await this.rpc.getTokenBalance(this.kp.publicKey, mint);
    if (!(bal.raw > 0n)) return null;
    try {
      const q = await this._jup(`/quote?inputMint=${mint}&outputMint=${SOL_MINT}&amount=${bal.raw}&slippageBps=${Math.round(this.slippage * 100)}`, null, { background: true });
      return !!q?.outAmount;
    } catch (err) {
      if (err.noRoute) return false;
      if (err.busy) return 'busy';
      return null; // unknown (rate limit / network)
    }
  }

  // buy: amount = SOL to spend. sell: amount = "40%" of what we hold.
  async build({ action, mint, amount, knownRaw = null, slippage = null }) {
    let jupReq;
    let portalReq;
    if (action === 'buy') {
      jupReq = { inputMint: SOL_MINT, outputMint: mint, amount: Math.round(amount * LAMPORTS), slippage };
      portalReq = { action, mint, amount, denominatedInSol: true };
    } else {
      const pct = Math.min(100, Math.max(0, parseFloat(amount)));
      // knownRaw = our exact token amount from our own last trade: saves a network round trip
      const bal = knownRaw != null ? { raw: BigInt(knownRaw) } : await this.rpc.getTokenBalance(this.kp.publicKey, mint);
      if (!(bal.raw > 0n)) throw Object.assign(new Error('wallet holds none of this coin'), { nothing: true });
      const raw = pct >= 100 ? bal.raw : (bal.raw * BigInt(Math.round(pct * 100))) / 10000n;
      if (raw <= 0n) throw Object.assign(new Error('amount to sell rounds to 0'), { nothing: true });
      jupReq = { inputMint: mint, outputMint: SOL_MINT, amount: raw.toString() };
      portalReq = { action, mint, amount: `${pct}%`, denominatedInSol: false };
    }
    try {
      const tx = await this._jupBuild(jupReq);
      this.lastVenue = 'Jupiter';
      return tx;
    } catch (err) {
      if (!this.portalBase) throw err;
      log.warn(`Jupiter couldn't build the ${action} (${err.message}), trying PumpPortal`);
      try {
        const tx = await this._portalBuild(portalReq);
        // PumpPortal builds a SOL trade even for coins priced in another token (his $BTC / $PUMP pairs),
        // which then fails on-chain ("UnsupportedQuoteMint") and still costs the fee. Check it first.
        const sim = typeof this.rpc?.call !== 'function' ? null : await this.rpc
          .call('simulateTransaction', [Buffer.from(tx).toString('base64'), { encoding: 'base64', sigVerify: false, replaceRecentBlockhash: true, commitment: 'processed' }], { priority: true })
          .catch(() => null);
        const simErr = sim?.value?.err;
        if (simErr) {
          const why = (sim.value.logs || []).map((l) => l.match(/Error Message: (.+)$|Error Code: (\w+)/)).filter(Boolean).map((m) => m[1] || m[2])[0];
          throw Object.assign(new Error(`PumpPortal's ${action} would fail${why ? `: ${why}` : ''}`), { simFailed: true });
        }
        this.lastVenue = 'PumpPortal';
        return tx;
      } catch (err2) {
        // no route on Jupiter AND PumpPortal can't do it: a fresh pool Jupiter hasn't indexed yet -> worth waiting
        throw Object.assign(new Error(`${err.message} · ${err2.message}`), { noRoute: !!err.noRoute || !!err2.simFailed });
      }
    }
  }

  async send(bytes) {
    const { bytes: signed, sig } = signTx(bytes, this.kp);
    const b64 = Buffer.from(signed).toString('base64');
    const opts = { encoding: 'base64', skipPreflight: true, maxRetries: 0 };
    const t0 = Date.now();
    // Send to our RPC and Jito's relay at the same time (Jito validators make most blocks, so it
    // usually lands sooner). The same signed transaction can only ever execute once.
    const viaJito = this.jitoSend(b64);
    const viaRpc = this.rpc.call('sendTransaction', [b64, opts], { priority: true });
    try {
      await viaRpc;
    } catch (err) {
      if (!(await viaJito)) throw err; // only fail if neither route took it
    }
    const sentAt = this.jitoUrls?.length ? t0 : Date.now(); // Jito got it at t0
    let lastSend = Date.now();
    while (Date.now() - t0 < this.confirmTimeoutMs) {
      await sleep(400);
      const st = await this.rpc.call('getSignatureStatuses', [[sig], { searchTransactionHistory: false }], { priority: true }).catch(() => null);
      const s = st?.value?.[0];
      if (s?.err) throw Object.assign(new Error(`transaction failed on-chain: ${explainErr(s.err)}`), { sig, onChain: true });
      if (s && (s.confirmationStatus === 'confirmed' || s.confirmationStatus === 'finalized')) return { sig, ms: Date.now() - sentAt, sentAt };
      if (Date.now() - lastSend > 2000) {
        lastSend = Date.now();
        this.rpc.call('sendTransaction', [b64, opts], { priority: true }).catch(() => {});
        this.jitoSend(b64);
      }
    }
    throw Object.assign(new Error('not confirmed in 60s (network busy — it probably expired)'), { sig, expired: true });
  }

  // Fire-and-forget to Jito's relay(s). Resolves true if any relay accepted it.
  jitoSend(b64) {
    const urls = this.jitoUrls || [];
    if (!urls.length) return Object.assign(Promise.resolve(false), { firstAt: null });
    const started = Date.now();
    const p = Promise.all(
      urls.map(async (u) => {
        const ctl = new AbortController();
        const t = setTimeout(() => ctl.abort(), 3000);
        try {
          const r = await fetch(u, {
            method: 'POST',
            headers: { 'content-type': 'application/json' },
            body: JSON.stringify({ jsonrpc: '2.0', id: 1, method: 'sendTransaction', params: [b64, { encoding: 'base64' }] }),
            signal: ctl.signal,
          });
          const j = await r.json().catch(() => null);
          return r.ok && j?.result != null;
        } catch {
          return false;
        } finally {
          clearTimeout(t);
        }
      }),
    ).then((rs) => rs.some(Boolean));
    p.firstAt = started;
    return p;
  }

  // SOL and token change for our wallet in a confirmed transaction.
  async result(sig, mint) {
    for (let i = 0; i < 6; i++) {
      const tx = await this.rpc.getTransaction(sig).catch(() => null);
      if (tx?.meta) {
        const m = tx.meta;
        const sol = ((m.postBalances?.[0] ?? 0) - (m.preBalances?.[0] ?? 0)) / LAMPORTS;
        const tok = (list) =>
          (list || []).filter((b) => b.mint === mint && b.owner === this.kp.publicKey).reduce((a, b) => a + +(b.uiTokenAmount?.uiAmountString || 0), 0);
        const raw = (list) => (list || []).filter((b) => b.mint === mint && b.owner === this.kp.publicKey).reduce((a, b) => a + BigInt(b.uiTokenAmount?.amount || 0), 0n);
        return {
          solDelta: sol,
          tokenDelta: tok(m.postTokenBalances) - tok(m.preTokenBalances),
          tokenRawAfter: raw(m.postTokenBalances).toString(),
          feeSol: (m.fee || 0) / LAMPORTS,
        };
      }
      await sleep(800 * (i + 1));
    }
    return null;
  }

  async trade(req, prebuilt = null) {
    const bytes = prebuilt || (await this.build(req));
    const { sig, ms, sentAt } = await this.send(bytes);
    const r = await this.result(sig, req.mint);
    return { sig, ms, sentAt, venue: this.lastVenue, ...(r || {}) };
  }
}

function explainSim(e) {
  const s = typeof e === 'string' ? e : JSON.stringify(e);
  if (/insufficient|InsufficientFunds|no record of a prior credit|0x1\b|"Custom":1\b/i.test(s)) return 'not enough SOL in your wallet';
  if (/slippage|0x1771|6001|6002|TooLittle|TooMuch/i.test(s)) return 'price moved more than your slippage';
  return s.slice(0, 140);
}

function explainErr(err) {
  const s = JSON.stringify(err);
  if (/"Custom":6001|"Custom":6002|Slippage|TooMuchSol|TooLittle/i.test(s)) return 'price moved more than your slippage';
  if (/"Custom":1\b|InsufficientFunds|insufficient/i.test(s)) return 'not enough SOL';
  return s.slice(0, 120);
}

// Copies the target's trades with our own wallet: buys a fixed amount when he enters a coin,
// sells the same % of our bag when he sells, everything when he's out, and takes profit at Nx.
export class CopyTrader {
  constructor({ cfg, rpc, kp, swapper, pump, coins, broadcast, getSolPrice, file, targets = [], targetName = '' }) {
    this.targets = targets;
    this.targetName = targetName;
    this.cfg = cfg; // cfg.copy
    this.rpc = rpc;
    this.kp = kp;
    this.swapper = swapper;
    this.pump = pump;
    this.coins = coins;
    this.broadcast = broadcast;
    this.getSolPrice = getSolPrice;
    this.file = file;
    this.positions = {}; // mint -> {symbol, tokens, costSol, proceedsSol, openedAt, tpDone, buySig}
    this.paused = false;
    this.spentToday = { day: '', sol: 0 };
    this.locks = new Map();
    this.retries = new Map();
    this.prebuilt = new Map(); // mint -> Promise<{bytes, at}>: a buy built while his entry is being confirmed
    this.inflight = new Set();
    this.traded = new Set();
    this.history = new Map(); // mint -> Promise: has he traded this coin before? // coins we've bought with him before (his re-buys of these are copied)
    this.stats = { buys: 0, sells: 0, failed: 0, skipped: 0 };
    this.lastSkip = null;
    this.load();
  }

  load() {
    try {
      if (!fs.existsSync(this.file)) return;
      const j = JSON.parse(fs.readFileSync(this.file, 'utf8'));
      this.positions = j.positions || {};
      this.paused = !!j.paused;
      this.spentToday = j.spentToday || this.spentToday;
      this.traded = new Set([...(j.traded || []), ...Object.keys(this.positions)]);
    } catch (err) {
      log.warn('Could not read copy-trade file:', err.message);
    }
  }

  save() {
    try {
      fs.mkdirSync(path.dirname(this.file), { recursive: true });
      const tmp = this.file + '.tmp';
      fs.writeFileSync(tmp, JSON.stringify({ positions: this.positions, paused: this.paused, spentToday: this.spentToday, traded: [...this.traded].slice(-3000) }, null, 1));
      fs.renameSync(tmp, this.file);
    } catch (err) {
      log.error('Could not save copy-trade file:', err.message);
    }
  }

  setPaused(v) {
    this.paused = v;
    this.save();
  }

  // Runs jobs for the same coin one after another (a sell waits for our buy to land).
  _locked(mint, fn) {
    const prev = this.locks.get(mint) || Promise.resolve();
    const run = prev.then(fn).catch((err) => log.error('Copy trade error:', err.stack || err.message));
    this.locks.set(mint, run);
    run.finally(() => {
      if (this.locks.get(mint) === run) this.locks.delete(mint);
    });
    return run;
  }

  async _sym(mint) {
    const c = await withTimeout(this.coins.get(mint, { fresh: false, timeoutMs: 2000 }), 2500, null);
    return c?.symbol ? `$${c.symbol}` : shortAddr(mint);
  }

  // Every buy of his that the bot doesn't copy is told in Telegram with the reason (once per coin per 5 min).
  _skip(mint, why, { notify = true } = {}) {
    this.stats.skipped++;
    this.lastSkip = { mint, why, at: Date.now() };
    log.info(`Copy: skipped ${shortAddr(mint)} — ${why}`);
    if (!notify || this.cfg.skipAlerts === false) return;
    this.skipAlerted ||= new Map();
    const last = this.skipAlerted.get(mint);
    if (last && Date.now() - last < 300000) return;
    this.skipAlerted.set(mint, Date.now());
    if (this.skipAlerted.size > 500) this.skipAlerted.delete(this.skipAlerted.keys().next().value);
    this._sym(mint)
      .then((sym) => this._notify(`⏭ <b>BOT SKIPPED</b> <b>${e(sym)}</b>\n❓ Why: ${e(why)}\n<code>${mint}</code>`, mint))
      .catch(() => {});
  }

  async _notify(html, mint, sig) {
    try {
      await this.broadcast(html, linkButtons(mint, { sig }));
    } catch {}
  }

  // How much SOL to spend when he buys `hisSol`. Scales with his size (1 SOL -> 0.5, 1000 SOL -> 1 by
  // default), and never more than COPY_MAX_WALLET_PERCENT of the wallet or COPY_MAX_PER_COIN_SOL per coin.
  // Returns null if the buy would be too small to bother.
  sizeFor(hisSol, mint, { pending = 0 } = {}) {
    const c = this.cfg;
    let amt;
    if (c.sizeMode !== 'scale') amt = c.buySol;
    else if (!(hisSol > 0)) amt = c.scaleAt1; // his size unknown (some new coin types don't log it): size as if he bought 1 SOL
    else if (hisSol <= 1) amt = hisSol * c.scaleAt1;
    else amt = c.scaleAt1 + (c.maxBuySol - c.scaleAt1) * Math.min(1, Math.log10(hisSol) / Math.log10(Math.max(10, c.scaleMaxAt)));
    // his small buys: buy at least COPY_FLOOR_BUY_SOL (then the wallet/per-coin caps below still apply)
    if (c.floorBuySol > 0) amt = Math.max(amt, c.floorBuySol);
    if (c.maxBuySol > 0) amt = Math.min(amt, c.maxBuySol);
    if (c.maxWalletPct > 0 && this.balCache?.sol > 0) amt = Math.min(amt, (this.balCache.sol * c.maxWalletPct) / 100);
    if (c.maxPerCoinSol > 0) {
      const p = this.positions[mint];
      const already = (p?.tokens > 0 ? p.costSol || 0 : 0) + pending;
      amt = Math.min(amt, c.maxPerCoinSol - already);
    }
    amt = Math.floor(amt * 1e4) / 1e4;
    return amt >= (c.minBuySol || 0.005) ? amt : null;
  }

  // Has he traded this coin before this buy? Looks at the history of his token account for it:
  // anything older than a few minutes means it's an old coin of his, not a fresh entry.
  // 'new' | 'old' | null (couldn't tell).
  checkHistory(ev) {
    const mint = ev.mint;
    const cached = this.history.get(mint);
    if (cached && Date.now() - cached.at < 120000) return cached.p;
    const p = (async () => {
      const wallet = ev.wallet;
      if (!wallet) return null;
      const cutoff = (ev.time || ev.detectedAt || Date.now()) - (this.cfg.newCoinWindowMs ?? 10 * 60000);
      for (let attempt = 0; attempt < 2; attempt++) {
        try {
          const r = await this.rpc.call('getTokenAccountsByOwner', [wallet, { mint }, { encoding: 'jsonParsed', commitment: 'confirmed' }], { priority: true });
          const accts = (r?.value || []).map((a) => a.pubkey).filter(Boolean);
          if (!accts.length) return 'new';
          for (const a of accts) {
            const sigs = (await this.rpc.call('getSignaturesForAddress', [a, { limit: 25, commitment: 'confirmed' }], { priority: true })) || [];
            const older = sigs.find((s) => s.signature !== ev.sig && s.blockTime && s.blockTime * 1000 < cutoff);
            if (older) return { old: true, at: older.blockTime * 1000 };
          }
          return 'new';
        } catch (e) {
          log.debug('history check failed', e.message);
          await sleep(300);
        }
      }
      return null;
    })().then((v) => (v && v.old ? 'old:' + v.at : v));
    this.history.set(mint, { at: Date.now(), p });
    if (this.history.size > 500) this.history.delete(this.history.keys().next().value);
    return p;
  }

  // true while we hold, are buying or are selling this coin (its token account must not be closed)
  isBusy(mint) {
    return !!(this.positions[mint]?.tokens > 0 || this.inflight.has(mint) || this.locks.has(mint) || this.pendingBuy?.has(mint) || this.prebuilt.has(mint) || this.retries?.has?.(mint));
  }

  // He bought a coin we don't know he held: build our buy right away (it's only sent if this turns
  // out to be a new entry). Saves the time of the "did he already hold it?" check.
  onMaybeEntry(ev) {
    if (!this.cfg.enabled || this.paused) return;
    const mint = ev.mint;
    if (this.cfg.onlyNewCoins && !this.cfg.copyReentries && !this.traded.has(mint)) this.checkHistory(ev); // runs alongside the build
    if (!this.swapper.build) return;
    if (this.positions[mint]?.tokens > 0 || this.inflight.has(mint) || this.prebuilt.has(mint)) return;
    if (ev.time && Date.now() - ev.time > this.cfg.maxDelayMs) return;
    const amount = this.sizeFor(ev.solAmount, mint);
    if (!amount) return;
    const pr = this.swapper
      .build({ action: 'buy', mint, amount, denominatedInSol: true })
      .then((bytes) => ({ bytes, at: Date.now(), amount }))
      .catch(() => null);
    this.prebuilt.set(mint, pr);
    setTimeout(() => this.prebuilt.get(mint) === pr && this.prebuilt.delete(mint), 20000).unref?.();
  }

  // Called by the tracker for every trade of his it understands.
  onSignal({ ev, kind, pre, post, sol }) {
    if (!this.cfg.enabled) return;
    const mint = ev.mint;
    if (kind !== 'ENTRY') this.prebuilt.delete(mint); // it was an add: drop the prepared buy
    if (kind === 'ENTRY') this.hisOut?.delete(mint);
    // One buy per coin (default): while our buy of a coin is being decided or sent, more buys of his in the
    // same coin are ignored (no double buys), and once we've bought a coin we never buy it again
    // (no adds, no buying back in after selling) — sells and take-profit still work as normal.
    if ((kind === 'ENTRY' || kind === 'ADD') && this.cfg.oneBuyPerCoin !== false) {
      if (this.inflight.has(mint) || this.pendingBuy?.has(mint) || this.entryPending?.has(mint) || this.locks.has(mint)) return;
      if (this.traded.has(mint) || this.positions[mint]) {
        if (kind === 'ADD' && !(this.positions[mint]?.tokens > 0) && !this.traded.has(mint)) return;
        return this._skip(mint, this.positions[mint]?.tokens > 0 ? 'already holding it — one buy per coin, no adds' : 'already bought and sold this coin once — one buy per coin, no rebuys');
      }
    }
    if (kind === 'ENTRY' || (kind === 'ADD' && this.cfg.copyAdds)) {
      // Adds are only followed in coins we bought with him. His old bags (held from before, or coins
      // we skipped) are never bought into; a fresh entry of his (or a re-buy after selling out) is.
      if (kind === 'ADD' && !(this.positions[mint]?.tokens > 0) && !this.inflight.has(mint)) return;
      if (this.paused) return this._skip(mint, 'copy trading is paused');
      const age = ev.time ? Date.now() - ev.time : 0;
      if (age > this.cfg.maxDelayMs) return this._skip(mint, `his buy was ${fmtAgo(age)} ago (older than ${this.cfg.maxDelayMs / 1000}s)`);
      if (this.cfg.minHisBuySol > 0 && sol > 0 && sol < this.cfg.minHisBuySol) return this._skip(mint, `his buy ${fmtSol(sol)} SOL is under COPY_MIN_HIS_BUY_SOL`);
      if (!this.cfg.copyAdds && (this.positions[mint]?.tokens > 0 || this.inflight.has(mint))) return;
      // Only his brand-new coins: a coin he traded before (and we never bought with him) is skipped.
      if (kind === 'ENTRY' && this.cfg.onlyNewCoins && !this.traded.has(mint) && !(this.positions[mint]?.tokens > 0)) return this._entryIfNew(mint, ev, sol);
      return this._queueBuy(mint, ev, sol);
    }
    if (!this.cfg.mirrorSells) {
      if (kind !== 'EXIT' && !(kind === 'MOVED' && post <= 0)) return;
    }
    if (kind === 'EXIT' || ((kind === 'MOVED' || kind === 'PARTIAL') && post <= 0)) {
      (this.hisOut ||= new Set()).add(mint);
      if (this.hisOut.size > 500) this.hisOut.delete(this.hisOut.values().next().value);
    }
    if (kind === 'PARTIAL' || kind === 'EXIT' || kind === 'MOVED') {
      const out = kind === 'EXIT' || post <= 0 || (pre > 0 && post / pre < 0.03);
      if (kind === 'MOVED' && !out) return; // he only moved part of his bag to another wallet
      if (!this.positions[mint] && !this.inflight.has(mint)) return;
      const pct = out ? 100 : Math.max(1, Math.min(100, Math.round(((pre - post) / pre) * 100)));
      return this._locked(mint, () => this._sell(mint, pct, out ? 'exit' : 'mirror', ev));
    }
  }

  // "New" = he held none of this coin right before this buy (a first buy, or buying back in after selling
  // out — even if he traded it days ago). Adds to a bag he's holding are never copied.
  async heldBefore(ev) {
    if (ev.preUi != null) return ev.preUi > 0; // read from his transaction itself
    for (let i = 0; i < 2; i++) {
      try {
        const b = await this.rpc.getTokenBalance(ev.wallet, ev.mint, this.cfg.chainCommitment || 'processed');
        return b.ui - (ev.amountUi || 0) > (ev.amountUi || 0) * 0.01;
      } catch {
        await sleep(200);
      }
    }
    return null;
  }

  // Old coins (launched more than COPY_MAX_COIN_AGE_HOURS ago) are never bought, whoever is buying.
  async _tooOld(mint) {
    const max = this.cfg.maxCoinAgeMs ?? 3 * 3600000;
    if (!(max > 0) || !this.coins?.ageMs) return null;
    const age = await withTimeout(this.coins.ageMs(mint), 2500, null).catch(() => null);
    return age != null && age > max ? age : null;
  }

  async _entryIfNew(mint, ev, sol) {
    const ageP = this._tooOld(mint); // runs alongside the other checks and the build
    // COPY_REENTRIES=on: "new" = he held none right before (buying back in after selling counts)
    if (this.cfg.copyReentries) {
      if (ev.preUi != null || ev.preChecked) {
        const old = await ageP;
        if (old) return this._skip(mint, `the coin was launched ${fmtAgo(old)} ago — only new coins are copied (COPY_MAX_COIN_AGE_HOURS)`);
        return this._queueBuy(mint, ev, sol);
      }
      if (!this.prebuilt.has(mint)) this.onMaybeEntry({ ...ev, solAmount: sol || ev.solAmount });
      this.inflight.add(mint);
      let held;
      try {
        held = await withTimeout(this.heldBefore(ev), 4000, null);
      } finally {
        this.inflight.delete(mint);
      }
      const old = await ageP;
      if (held === false && !old) return this._queueBuy(mint, ev, sol);
      if (old) {
        this.prebuilt.delete(mint);
        return this._skip(mint, `the coin was launched ${fmtAgo(old)} ago — only new coins are copied (COPY_MAX_COIN_AGE_HOURS)`);
      }
      this.prebuilt.delete(mint);
      if (held == null) return this._skip(mint, "couldn't check whether he already held it (Solana RPC didn't answer)");
      return this._skip(mint, 'he already holds this coin, so this is an add to his bag, not a new entry');
    }
    // default: only coins he has NEVER traded before (his token account has no history older than a few minutes)
    if (!this.prebuilt.has(mint)) this.onMaybeEntry({ ...ev, solAmount: sol || ev.solAmount });
    this.entryPending ||= new Set();
    this.entryPending.add(mint);
    setTimeout(() => this.entryPending.delete(mint), 6000).unref?.();
    this.inflight.add(mint);
    let h;
    try {
      h = await withTimeout(this.checkHistory(ev), 5000, null);
    } finally {
      this.inflight.delete(mint);
    }
    this.entryPending.delete(mint);
    const old = h === 'new' ? await ageP : null;
    if (old) {
      this.prebuilt.delete(mint);
      return this._skip(mint, `the coin was launched ${fmtAgo(old)} ago — only new coins are copied (COPY_MAX_COIN_AGE_HOURS)`);
    }
    if (h === 'new') return this._queueBuy(mint, ev, sol);
    this.prebuilt.delete(mint);
    if (h == null) return this._skip(mint, "couldn't confirm it's a new coin of his (Solana RPC didn't answer)");
    const at = +h.split(':')[1];
    return this._skip(mint, `not a new coin for him: he first traded it ${fmtAgo(Date.now() - at)} ago (only brand-new coins are copied; COPY_REENTRIES=on in settings.txt to also copy re-buys)`);
  }

  // His buys of the same coin that arrive while we're still buying are added up into one follow-up buy
  // (he often buys in quick bursts), so we don't fire a dozen small trades.
  _queueBuy(mint, ev, hisSol) {
    this.pendingBuy ||= new Map();
    const q = this.pendingBuy.get(mint) || { his: 0, ev, queued: false };
    q.his += hisSol > 0 ? hisSol : 0;
    q.ev = ev;
    this.pendingBuy.set(mint, q);
    if (q.queued) return;
    q.queued = true;
    this.inflight.add(mint);
    return this._locked(mint, async () => {
      const job = this.pendingBuy.get(mint);
      this.pendingBuy.delete(mint);
      try {
        await this._buy(mint, job.ev, job.his);
      } finally {
        if (!this.pendingBuy.has(mint)) this.inflight.delete(mint);
      }
    });
  }

  async _buy(mint, ev, hisSol) {
    // limits are checked and a slot reserved before anything async, so a burst of entries can't overshoot them
    const day = new Date().toISOString().slice(0, 10);
    if (this.spentToday.day !== day) this.spentToday = { day, sol: 0 };
    this.reserved ||= 0;
    this.reservedAmt ||= 0;
    const isAdd = this.positions[mint]?.tokens > 0;
    const amount = this.sizeFor(hisSol, mint);
    if (!amount) {
      const p = this.positions[mint];
      return this._skip(mint, p && this.cfg.maxPerCoinSol > 0 && p.costSol >= this.cfg.maxPerCoinSol - 0.005 ? `already ${fmtSol(p.costSol)} SOL in this coin (COPY_MAX_PER_COIN_SOL)` : 'buy would be too small');
    }
    const open = Object.values(this.positions).filter((p) => p.tokens > 0).length + this.reserved;
    if (!isAdd && open >= this.cfg.maxOpen) return this._skipNotify(mint, await this._sym(mint), `you already have ${open} open copy positions (COPY_MAX_OPEN_POSITIONS=${this.cfg.maxOpen})`);
    if (this.cfg.dailyLimitSol > 0 && this.spentToday.sol + this.reservedAmt + amount > this.cfg.dailyLimitSol + 1e-9)
      return this._skipNotify(mint, await this._sym(mint), `daily limit reached (${fmtSol(this.spentToday.sol)} of ${fmtSol(this.cfg.dailyLimitSol)} SOL today)`);
    if (!isAdd) this.reserved++;
    this.reservedAmt += amount;
    try {
      return await this._doBuy(mint, ev, hisSol, amount, isAdd);
    } finally {
      if (!isAdd) this.reserved--;
      this.reservedAmt -= amount;
    }
  }

  async _doBuy(mint, ev, hisSol, amount = this.cfg.buySol, isAdd = false) {
    // nothing slow before the buy: the coin name is looked up in parallel, and the wallet balance
    // comes from a copy refreshed in the background
    const symP = this._sym(mint);
    const need = amount + this.cfg.keepSol + this.cfg.priorityFee + 0.003;
    const bal = this.balCache && Date.now() - this.balCache.at < 60000 ? this.balCache.sol - this.reservedSol(amount) : null;
    if (bal != null && bal < need) return this._skipNotify(mint, await symP, `not enough SOL in your wallet (${fmtSol(bal)} SOL, need ${fmtSol(need)})`);
    let sym = mint.slice(0, 6);

    let lastErr;
    const t0 = Date.now();
    let waitedForRoute = false;
    let slipFails = 0;
    for (let attempt = 1; attempt <= 2 || (lastErr?.waitRoute && attempt <= 60) || (lastErr?.slipped && attempt <= 3); attempt++) {
      try {
        let ready = null;
        if (attempt === 1 && this.prebuilt.has(mint)) {
          const pb = await this.prebuilt.get(mint);
          this.prebuilt.delete(mint);
          if (pb && Date.now() - pb.at < 20000 && Math.abs(pb.amount - amount) < 1e-9) ready = pb.bytes; // fresh and the same size
        }
        // the price ran past our slippage (a launch pumping): try again at up to double the slippage
        const slip = slipFails ? Math.min(this.cfg.maxSlippage ?? 50, (this.cfg.slippage || 25) * 2) : null;
        const r = await this.swapper.trade({ action: 'buy', mint, amount, denominatedInSol: true, ...(slip ? { slippage: slip } : {}) }, slip ? null : ready);
        sym = await symP;
        this.refreshBalance();
        const spent = r.solDelta != null ? -r.solDelta : amount;
        let tokens = r.tokenDelta;
        if (!(tokens > 0)) tokens = Math.max(0, ((await this.tokenBalance(mint).catch(() => 0)) || 0) - (this.positions[mint]?.tokens || 0));
        const rawAfter = BigInt(r.tokenRawAfter || 0) > 0n ? r.tokenRawAfter : null;
        const old = this.positions[mint];
        const big = hisSol > this.cfg.quickTpHisMinSol;
        if (old && old.tokens > 0) {
          // add to the position (average cost)
          old.tokens += tokens;
          old.boughtTokens = (old.boughtTokens || old.tokens - tokens) + tokens;
          old.costSol += spent;
          old.raw = rawAfter;
          old.buys = (old.buys || 1) + 1;
          if (big && !old.quickDone) old.quickTp = true;
        } else {
          this.positions[mint] = { symbol: sym, tokens, boughtTokens: tokens, raw: rawAfter, costSol: spent, proceedsSol: 0, openedAt: Date.now(), tpDone: false, quickTp: big, quickDone: false, buys: 1, buySig: r.sig };
        }
        const pos = this.positions[mint];
        this.spentToday.sol += spent;
        this.traded.add(mint);
        this.stats.buys++;
        this.save();
        const lag = ev.time ? Date.now() - ev.time : null;
        const sinceSeen = ev.detectedAt && r.sentAt ? r.sentAt - ev.detectedAt : null;
        log.info(`Copy: bought ${sym} for ${fmtSol(spent)} SOL (${r.sig})`);
        this._checkSellable(mint, sym);
        await this._notify(
          [
            `🤖 <b>${isAdd ? 'COPY ADD' : 'COPY BUY'}</b> <b>${e(sym)}</b> ✅`,
            `💰 Spent <b>${fmtSol(spent)} SOL</b> → ${fmtNum(tokens)} tokens${isAdd ? ` · now ${fmtSol(pos.costSol)} SOL in this coin` : ''}`,
            `👤 He bought${hisSol ? ' ' + fmtSol(hisSol) + ' SOL' : ''}${lag != null ? ` · you were in ${fmtAgo(lag)} after him` : ''}`,
            sinceSeen != null ? `⚡ Your buy was sent ${(sinceSeen / 1000).toFixed(2)}s after his buy was spotted${r.ms ? `, landed ${(r.ms / 1000).toFixed(1)}s later` : ''}` : '',
            pos.quickTp && !pos.quickDone && this.cfg.quickTpX > 0 ? `⚡ Quick profit: sells ${this.cfg.quickTpPercent}% at ${this.cfg.quickTpX}x (keeps the rest)` : '',
            this.cfg.tpX > 0 && this.cfg.tpPercent > 0 && !pos.tpDone ? `🎯 Take profit: sells ${this.cfg.tpPercent}% at ${this.cfg.tpX}x` : '',
            `<code>${mint}</code>`,
          ].filter(Boolean).join('\n'),
          mint,
          r.sig,
        );
        return;
      } catch (err) {
        lastErr = err;
        sym = await symP;
        this.refreshBalance();
        log.warn(`Copy buy ${sym} attempt ${attempt} failed: ${err.message}`);
        if (err.expired) {
          // it may still have landed late: never buy twice
          await sleep(3000);
          const have = await this.tokenBalance(mint).catch(() => 0);
          if (have > (isAdd ? (this.positions[mint]?.tokens || 0) * 1.001 : 0)) {
            this.traded.add(mint);
            if (!isAdd) this.positions[mint] = { symbol: sym, tokens: have, boughtTokens: have, costSol: amount, proceedsSol: 0, openedAt: Date.now(), tpDone: false, buys: 1, buySig: err.sig };
            else Object.assign(this.positions[mint], { tokens: have, costSol: this.positions[mint].costSol + amount, raw: null });
            this.spentToday.sol += amount;
            this.stats.buys++;
            this.save();
            await this._notify(`🤖 <b>COPY BUY</b> <b>${e(sym)}</b> ✅ (landed late)
💰 ~${fmtSol(amount)} SOL → ${fmtNum(have)} tokens
<code>${mint}</code>`, mint, err.sig);
            return;
          }
        }
        err.slipped = err.onChain && /slippage/i.test(err.message);
        if (err.slipped) slipFails++;
        // A brand-new pool (a fresh launch, or a coin paired with another token like his $BTC) can take
        // Jupiter a little while to find. Keep trying for COPY_ROUTE_WAIT_SECONDS unless he's already out.
        const noRoute = err.noRoute || /no routes|could_not_find|not tradable|route/i.test(err.message);
        err.waitRoute = false;
        if (noRoute && Date.now() - t0 < (this.cfg.routeWaitMs ?? 45000) && !this.hisOut?.has(mint)) {
          err.waitRoute = true;
          if (!waitedForRoute) {
            waitedForRoute = true;
            this._notify(`⏳ <b>COPY BUY WAITING</b> <b>${e(await symP)}</b>\nBrand-new pool, no route to buy it yet — retrying for up to ${Math.round((this.cfg.routeWaitMs ?? 45000) / 1000)}s.\n<code>${mint}</code>`, mint);
          }
          await sleep(1500);
          continue;
        }
        if (/not enough SOL|4\d\d/.test(err.message) && !/429/.test(err.message)) break;
      }
    }
    this.stats.failed++;
    await this._notify(`🤖 <b>COPY BUY FAILED</b> <b>${e(sym)}</b> ❌\n${e(lastErr.message)}\n<code>${mint}</code>`, mint, lastErr.sig);
  }

  // Right after buying (never before — that would slow the buy): warn if Jupiter can't sell it.
  _checkSellable(mint, sym, tries = 0) {
    if (!this.swapper.canSell) return;
    // Without a Jupiter key the free request limit is shared with everything else on your internet
    // connection, so every request is kept for trades. (A coin Jupiter can't sell is still handled
    // when he sells: retries + Padre button.)
    if (!this.swapper.jupKey && !this.cfg.forceSellCheck) return;
    setTimeout(async () => {
      if (!this.positions[mint] || this.locks.has(mint)) {
        if (this.positions[mint] && tries < 6) this._checkSellable(mint, sym, tries + 1);
        return;
      }
      const ok = await this.swapper.canSell(mint).catch(() => null);
      if (ok === 'busy' && tries < 6) return this._checkSellable(mint, sym, tries + 1); // trades first; try later
      if (ok !== false || !this.positions[mint]) return;
      this.positions[mint].noSellRoute = true;
      this.save();
      await this._notify(
        `⚠️ <b>HEADS UP</b> <b>${e(sym)}</b>: Jupiter can't sell this coin type yet (a newer pump.fun coin). When he sells, the bot will keep retrying, but you may need to sell it in Padre yourself.\n<code>${mint}</code>`,
        mint,
      );
    }, this.cfg.sellCheckDelayMs).unref?.();
  }

  async _skipNotify(mint, sym, why) {
    this._skip(mint, why, { notify: false });
    await this._notify(`🤖 <b>COPY BUY SKIPPED</b> <b>${e(sym)}</b>\n${e(why)}\n<code>${mint}</code>`, mint);
  }

  // reason: 'mirror' (he sold some) | 'exit' (he's out) | 'tp' (take profit) | 'manual'
  async _sell(mint, pct, reason, ev, retry = 0) {
    const p = this.positions[mint];
    if (!p) return;
    // a newer sell signal replaces a pending retry of an older one
    if (retry === 0 && this.retries.has(mint)) {
      clearTimeout(this.retries.get(mint));
      this.retries.delete(mint);
    }
    const sym = p.symbol || (await this._sym(mint));
    // no balance check here: the swap reads our exact balance once, right before it builds the sell
    const before = p.tokens > 0 ? p.tokens : null;
    let lastErr;
    const attempts = reason === 'exit' || reason === 'manual' ? 3 : 2;
    for (let attempt = 1; attempt <= attempts; attempt++) {
      try {
        const r = await this.swapper.trade({ action: 'sell', mint, amount: `${pct}%`, denominatedInSol: false, knownRaw: attempt === 1 ? p.raw : null });
        const got = r.solDelta != null ? r.solDelta : 0;
        p.proceedsSol += got;
        const bal = await this.rpc.getTokenBalance(this.kp.publicKey, mint).catch(() => null);
        const left = bal ? bal.ui : null;
        p.tokens = left ?? Math.max(0, (p.tokens || 0) + (r.tokenDelta || 0));
        p.raw = bal && bal.raw != null ? String(bal.raw) : null;
        this.stats.sells++;
        if (pct >= 100 && left != null && left > DUST_TOKENS && !p.sweeping) {
          // tokens still showing after selling 100%: either the RPC is a moment behind, or our saved
          // amount was out of date. Look again shortly and sell whatever is really left.
          p.sweeping = true;
          this._locked(mint, async () => {
            await sleep(2500);
            const b = await this.tokenBalance(mint).catch(() => null);
            if (b != null && b > DUST_TOKENS && this.positions[mint]) {
              this.positions[mint].raw = null;
              this.positions[mint].sweepPass = true;
              return this._sell(mint, 100, reason, ev);
            }
            delete this.positions[mint];
            this.save();
          });
        }
        const closed = p.tokens <= DUST_TOKENS || (pct >= 100 && !p.sweeping);
        const head = { mirror: `🤖 <b>COPY SELL ${pct}%</b>`, exit: '🤖 <b>COPY SELL — ALL OUT</b>', tp: `🎯 <b>TAKE PROFIT ${this.cfg.tpX}x — SOLD ${pct}%</b>`, quick: `⚡ <b>QUICK PROFIT ${this.cfg.quickTpX}x — SOLD ${pct}%</b>`, manual: `🤖 <b>MANUAL SELL ${pct}%</b>`, ladder: `🎯 <b>TAKE PROFIT ${p.ladderX}x — SOLD ${pct}%</b>`, timeout: `⏰ <b>${this.cfg.maxHoldHours}H UP — SOLD ALL</b>`, crash: '📉 <b>DUMPING — SOLD ALL</b>', trail: '🛡 <b>PROFIT LOCK — SOLD ALL</b>', protect: '🛡 <b>PROFIT LOCK — SOLD ALL</b>' }[reason];
        const why = { mirror: `👤 He sold ~${pct}% of his bag`, exit: '👤 He fully sold out', tp: `📈 Your bag hit ${this.cfg.tpX}x`, quick: `📈 Up ${this.cfg.quickTpX}x on a big buy of his — locking some in, keeping the rest`, manual: '👤 You asked for it', crash: `📉 Dropped fast: ${p.protectX ? `${p.protectX.recent.toFixed(2)}x → ${p.protectX.now.toFixed(2)}x in a few minutes` : 'falling fast'} — getting out`, trail: `🛡 Gave back too much from the top (${p.protectX ? `${p.protectX.peak.toFixed(2)}x → ${p.protectX.now.toFixed(2)}x` : ''}) — locking in the rest`, protect: `🛡 It ran to ${p.protectX ? p.protectX.peak.toFixed(2) : '?'}x and is sliding back to your entry — selling before it goes red`, timeout: null, ladder: p.ladderDone === 1 ? `📈 Up ${p.ladderX}x — initial taken out, the rest rides for free` : `📈 Up ${p.ladderX}x — locking in more, keeping the rest` }[reason];
        const lines = [`${head} <b>${e(sym)}</b> ✅`, ...(why ? [why] : []), `💸 Got <b>${fmtSol(got)} SOL</b>`];
        if (closed) {
          const pnl = p.proceedsSol - p.costSol;
          lines.push(`📊 Trip: in ${fmtSol(p.costSol)} → out ${fmtSol(p.proceedsSol)} SOL = <b>${pnl >= 0 ? '+' : ''}${fmtSol(pnl)} SOL</b> (${fmtPct(p.costSol ? (pnl / p.costSol) * 100 : 0)})${reason === 'timeout' ? '' : ` · held ${fmtAgo(Date.now() - p.openedAt)}`}`);
          const mult = p.costSol > 0 ? p.proceedsSol / p.costSol : 0;
          if (mult >= 2) lines.unshift(`🔥 <b>COOKED ${mult.toFixed(1)}x</b> on <b>${e(sym)}</b> — in ${fmtSol(p.costSol)} SOL, out ${fmtSol(p.proceedsSol)} SOL`);
          delete this.positions[mint];
        } else lines.push(`👜 Still holding ${fmtNum(p.tokens)} tokens`);
        if (reason === 'tp') p.tpDone = true;
        this.save();
        log.info(`Copy: sold ${pct}% of ${sym} for ${fmtSol(got)} SOL (${reason}, ${r.sig})`);
        // when a sweep follows, only its final "all out" message is sent
        if (!(pct >= 100 && !closed && p.sweeping && !p.sweepPass)) await this._notify(lines.join('\n'), mint, r.sig);
        return;
      } catch (err) {
        lastErr = err;
        if (err.nothing) {
          delete this.positions[mint];
          this.save();
          return;
        }
        log.warn(`Copy sell ${sym} attempt ${attempt} failed: ${err.message}`);
        if (err.expired && before != null) {
          await sleep(3000);
          const now = await this.tokenBalance(mint).catch(() => null);
          if (now != null && now < before * 0.99) {
            // it landed late — don't sell again
            p.tokens = now;
            if (now <= DUST_TOKENS) delete this.positions[mint];
            this.save();
            await this._notify(`🤖 <b>COPY SELL ${pct}%</b> <b>${e(sym)}</b> ✅ (landed late)\n<code>${mint}</code>`, mint, err.sig);
            return;
          }
        }
        if (err.noRoute) break; // retrying right away won't help; handled below
        if (attempt < attempts) await sleep(1000);
      }
    }
    // No route yet (e.g. a new pump.fun coin type Jupiter can't sell): keep trying instead of giving up
    if (lastErr.noRoute && reason !== 'manual' && retry < this.cfg.sellRetryMax) {
      if (retry === 0) {
        await this._notify(
          `🤖 <b>COPY SELL DELAYED</b> <b>${e(sym)}</b> ⏳ (${pct}%)\nJupiter can't sell this coin right now. The bot retries every ${fmtAgo(this.cfg.sellRetryMs)} for ${fmtAgo(this.cfg.sellRetryMs * this.cfg.sellRetryMax)}.\n👉 To get out now, sell it in Padre (button below).\n<code>${mint}</code>`,
          mint,
        );
      }
      const t = setTimeout(() => {
        this.retries.delete(mint);
        this._locked(mint, () => this._sell(mint, pct, reason, ev, retry + 1));
      }, this.cfg.sellRetryMs);
      t.unref?.();
      this.retries.set(mint, t);
      return;
    }
    this.stats.failed++;
    await this._notify(
      `🤖 <b>COPY SELL FAILED</b> <b>${e(sym)}</b> ❌ (${pct}%)\n${e(lastErr.message)}\n⚠️ You still hold it — sell it yourself (Padre button), or send /sell ${mint} ${pct}\n<code>${mint}</code>`,
      mint,
      lastErr.sig,
    );
  }

  manualSell(mint, pct) {
    if (!this.positions[mint]) this.positions[mint] = { symbol: null, tokens: 1, costSol: 0, proceedsSol: 0, openedAt: Date.now(), tpDone: true };
    return this._locked(mint, () => this._sell(mint, pct, 'manual'));
  }

  reservedSol(own = 0) {
    return Math.max(0, (this.reservedAmt || 0) - own); // SOL other buys in flight are about to spend
  }

  refreshBalance() {
    return this.solBalance()
      .then((sol) => (this.balCache = { sol, at: Date.now() }))
      .catch(() => {});
  }

  async solBalance() {
    const r = await this.rpc.call('getBalance', [this.kp.publicKey, { commitment: 'confirmed' }], { priority: true });
    return (r?.value ?? 0) / LAMPORTS;
  }

  async tokenBalance(mint) {
    return (await this.rpc.getTokenBalance(this.kp.publicKey, mint)).ui;
  }

  // Current SOL value of our bag from pump.fun's price.
  async valueSol(mint, tokens) {
    const px = this.pxCache?.[mint];
    if (px > 0) return tokens * px;
    const c = await this.pump.getCoin(mint).catch(() => null);
    if (!c) return null;
    const supply = c.total_supply ? +c.total_supply / 1e6 : 1e9;
    if (+c.market_cap > 0) return (tokens * +c.market_cap) / supply;
    const sp = this.getSolPrice();
    if (+c.usd_market_cap > 0 && sp) return (tokens * +c.usd_market_cap) / supply / sp;
    return null;
  }

  async checkTakeProfit() {
    if (!this.cfg.enabled) return;
    const ladder = this.cfg.tpLadder || [];
    // the ladder replaces the single take-profit and the quick profit
    const doTp = !ladder.length && this.cfg.tpX > 0 && this.cfg.tpPercent > 0;
    const doQuick = !ladder.length && this.cfg.quickTpX > 0 && this.cfg.quickTpPercent > 0;
    if (!doTp && !doQuick && !ladder.length && !(this.cfg.maxHoldHours > 0)) return;
    // one price lookup for every open position
    const open = Object.entries(this.positions).filter(([, p]) => p.tokens > 0).map(([m]) => m);
    this.pxCache = open.length && this.coins.pricesSol ? await this.coins.pricesSol(open, this.getSolPrice()).catch(() => ({})) : {};
    for (const [mint, p] of Object.entries(this.positions)) {
      if (!(p.tokens > 0) || !(p.costSol > 0) || this.locks.has(mint)) continue;
      // /hold: this coin only sells when he sells (no take-profit, no dying-coin sells, no 8h limit)
      if (p.keep) continue;
      // held too long: sell everything (whatever profit it took along the way is already banked)
      const limitAt = p.openedAt + this.cfg.maxHoldHours * 3600000;
      if (this.cfg.maxHoldHours > 0 && p.openedAt && !p.keep && !p.holdWarned && limitAt - Date.now() < 30 * 60000 && limitAt > Date.now()) {
        p.holdWarned = true;
        this.save();
        const sym = await this._sym(mint);
        // what the sale would bring in at today's price, and the trip's profit/loss
        let money = '';
        const v = await withTimeout(this.valueSol(mint, p.tokens), 2500, null).catch(() => null);
        if (v != null && v >= 0) {
          const out = v + (p.proceedsSol || 0);
          const pnl = out - p.costSol;
          money =
            `\n💰 At today's price you'd get <b>~${fmtSol(v)} SOL</b> for it` +
            `\n📊 Trip: in ${fmtSol(p.costSol)} SOL${p.proceedsSol > 0 ? ` (already took out ${fmtSol(p.proceedsSol)})` : ''} → ${pnl >= 0 ? `🟢 <b>+${fmtSol(pnl)} SOL</b> profit (${(out / p.costSol).toFixed(2)}x)` : `🔴 <b>-${fmtSol(-pnl)} SOL</b> loss (-${(-pnl / p.costSol).toFixed(2)}x)`}`;
        } else money = `\n💰 Couldn't get its price right now (in ${fmtSol(p.costSol)} SOL)`;
        this._notify(`⏰ <b>${e(sym)}</b> gets sold in ~${Math.max(1, Math.round((limitAt - Date.now()) / 60000))} min (${this.cfg.maxHoldHours}h limit).${money}\nTo hold it until ${e(this.targetName || 'he')} sells instead: <code>/hold ${mint}</code>`, mint);
      }
      if (this.cfg.maxHoldHours > 0 && p.openedAt && !p.keep && Date.now() > limitAt && !p.timeoutSent) {
        p.timeoutSent = true;
        this.save();
        this._locked(mint, () => this._sell(mint, 100, 'timeout'));
        continue;
      }
      const wantQuick = doQuick && p.quickTp && !p.quickDone;
      const wantTp = doTp && !p.tpDone;
      const step = ladder[p.ladderDone || 0];
      const protect = this.cfg.protect !== false;
      if (!wantQuick && !wantTp && !step && !protect) continue;
      const v = await this.valueSol(mint, p.tokens);
      p.lastValueSol = v;
      if (v == null) continue;
      // what the tokens we still hold cost us (average price), so earlier sells don't move the target
      const cost = p.costSol * Math.min(1, p.tokens / (p.boughtTokens || p.tokens));
      const x = v / cost;
      p.lastX = x;
      // Dying coin: sell everything that's left while there's still profit to take.
      if (protect) {
        const now = Date.now();
        p.peakX = Math.max(p.peakX || 0, x);
        p.hist = (p.hist || []).filter((h) => now - h.t < (this.cfg.crashWindowMs ?? 300000));
        p.hist.push({ t: now, x });
        const recentHigh = Math.max(...p.hist.map((h) => h.x));
        const armX = this.cfg.trailArmX ?? 1.5;
        let why = null;
        // 1) falling fast: down 35% from its high of the last 5 minutes (e.g. $1.3M -> $800K)
        if (x <= recentHigh * (1 - (this.cfg.crashDropPct ?? 35) / 100)) why = 'crash';
        // 2) once it ran (1.5x+), never give more than 40% of the top back
        else if (p.peakX >= armX && x <= p.peakX * (1 - (this.cfg.trailDropPct ?? 40) / 100)) why = 'trail';
        // 3) once it ran, never let it slide back toward what we paid
        else if (p.peakX >= armX && x <= (this.cfg.floorX ?? 1.15)) why = 'protect';
        if (why) {
          p.protectX = { peak: p.peakX, recent: recentHigh, now: x };
          this.save();
          this._locked(mint, () => this._sell(mint, 100, why));
          continue;
        }
      }
      if (step && x >= step.x) {
        p.ladderDone = (p.ladderDone || 0) + 1; // one rung per check; the next rung is checked 10s later
        p.ladderX = step.x;
        this.save();
        this._locked(mint, () => this._sell(mint, step.pct, 'ladder'));
      } else if (wantTp && x >= this.cfg.tpX) {
        p.tpDone = true; // only once per position
        if (wantQuick) p.quickDone = true; // the bigger take-profit covers it
        this.save();
        this._locked(mint, () => this._sell(mint, this.cfg.tpPercent, 'tp'));
      } else if (wantQuick && x >= this.cfg.quickTpX) {
        p.quickDone = true;
        this.save();
        this._locked(mint, () => this._sell(mint, this.cfg.quickTpPercent, 'quick'));
      }
    }
  }


  // After a restart: forget positions that were sold by hand in the wallet app.
  async resync() {
    for (const [mint, p] of Object.entries(this.positions)) {
      const bal = await this.tokenBalance(mint).catch(() => null);
      if (bal == null) continue;
      if (bal <= DUST_TOKENS) delete this.positions[mint];
      else {
        p.tokens = bal;
        p.raw = null; // re-read on the next sell
      }
    }
    this.save();
  }

  // Coins sitting in our wallet that the bot doesn't know about (bought by hand, or a buy that landed
  // after the bot gave up) are taken over as if the bot had bought them: they then sell when he sells
  // and follow the take-profit ladder. Only coins HE currently holds (so airdropped spam is ignored).
  async adoptStrays() {
    if (!this.targets?.length || this._adopting) return;
    this._adopting = true;
    try {
      for (const programId of ['TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA', 'TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb']) {
        const r = await this.rpc.call('getTokenAccountsByOwner', [this.kp.publicKey, { programId }, { encoding: 'jsonParsed', commitment: 'confirmed' }]).catch(() => null);
        for (const a of r?.value || []) {
          const info = a.account?.data?.parsed?.info;
          const mint = info?.mint;
          const ui = +info?.tokenAmount?.uiAmount || 0;
          if (!mint || ui <= DUST_TOKENS || this.positions[mint] || this.isBusy(mint)) continue;
          if (/^(So11111111111111111111111111111111111111112|EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v|Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB)$/.test(mint)) continue;
          if ((this.adoptChecked?.get(mint) || 0) > Date.now() - 600000) continue;
          (this.adoptChecked ||= new Map()).set(mint, Date.now());
          let his = 0;
          for (const w of this.targets) his += (await this.rpc.getTokenBalance(w, mint).catch(() => ({ ui: 0 }))).ui || 0;
          if (!(his > 0)) continue;
          // what we paid: SOL spent on the transactions that added this coin to our account
          let cost = 0;
          let got = 0;
          const sigs = (await this.rpc.call('getSignaturesForAddress', [a.pubkey, { limit: 40 }]).catch(() => [])) || [];
          for (const s of sigs.filter((x) => !x.err)) {
            const tx = await this.rpc.getTransaction(s.signature).catch(() => null);
            if (!tx?.meta) continue;
            const keys = accountKeysOf(tx);
            const i = keys.indexOf(this.kp.publicKey);
            if (i < 0) continue;
            const solD = ((tx.meta.postBalances[i] ?? 0) - (tx.meta.preBalances[i] ?? 0)) / LAMPORTS;
            const amt = (bs) => (bs || []).filter((b) => b.owner === this.kp.publicKey && b.mint === mint).reduce((x, b) => x + (+b.uiTokenAmount.uiAmountString || 0), 0);
            const tokD = amt(tx.meta.postTokenBalances) - amt(tx.meta.preTokenBalances);
            if (tokD > 0 && solD < 0) cost += -solD;
            if (tokD < 0 && solD > 0) got += solD;
          }
          const sym = await this._sym(mint);
          this.positions[mint] = { symbol: sym, tokens: ui, boughtTokens: ui, costSol: Math.max(0, cost - got) || cost, proceedsSol: 0, openedAt: Date.now(), tpDone: false, buys: 1, adopted: true };
          this.traded.add(mint);
          this.save();
          log.info(`Copy: adopted ${sym} (${ui} tokens, cost ~${fmtSol(cost)} SOL) found in the wallet`);
          await this._notify(`👜 <b>TAKING OVER</b> <b>${e(sym)}</b>\nFound ${fmtNum(ui)} tokens in your bot wallet (cost ~${fmtSol(cost)} SOL). The bot now manages them like its own buy: sells when ${e(this.targetName || 'he')} sells, take-profit ladder from your cost.\n<code>${mint}</code>`, mint);
        }
      }
    } finally {
      this._adopting = false;
    }
  }

  start() {
    this.resync().catch(() => {});
    setTimeout(() => this.adoptStrays().catch((err) => log.warn('adopt check failed', err.message)), 5000).unref?.();
    this._adopt = setInterval(() => this.adoptStrays().catch(() => {}), 120000);
    this.refreshBalance();
    this._bal = setInterval(() => this.refreshBalance(), 15000);
    this._tp = setInterval(() => this.checkTakeProfit().catch((err) => log.warn('take-profit check failed', err.message)), this.cfg.tpCheckMs);
  }

  stop() {
    clearInterval(this._tp);
    clearInterval(this._adopt);
    for (const t of this.retries.values()) clearTimeout(t);
    clearInterval(this._bal);
  }

  // /hold <CA>: this coin only sells when he sells (no take-profit, no dying-coin sells, no 8h limit). /unhold undoes it.
  setKeep(mint, keep) {
    const p = this.positions[mint];
    if (!p) return false;
    p.keep = !!keep;
    if (!keep) p.holdWarned = false;
    this.save();
    return true;
  }

  async statusText() {
    const bal = await this.solBalance().catch(() => null);
    const c = this.cfg;
    const lines = [
      `🤖 <b>Copy trading: ${!c.enabled ? 'OFF' : this.paused ? '⏸ PAUSED' : '🟢 LIVE'}</b>`,
      `👛 Your wallet <code>${this.kp.publicKey}</code>${bal != null ? ` · ${fmtSol(bal)} SOL` : ''}`,
      `⚙️ ${c.sizeMode === 'scale' ? `Buys scaled to his (1 SOL → ${fmtSol(c.scaleAt1)}, max ${fmtSol(c.maxBuySol)}) · max ${c.maxWalletPct}% of wallet per buy · max ${fmtSol(c.maxPerCoinSol)} SOL per coin` : `Buys ${fmtSol(c.buySol)} SOL`}${c.copyAdds ? ' · copies adds + re-entries' : ' · new entries only'} · mirrors his sells${c.mirrorSells ? '' : ' (full exits only)'} · quick profit ${c.quickTpX > 0 ? `${c.quickTpPercent}% at ${c.quickTpX}x on his >${c.quickTpHisMinSol} SOL buys` : 'off'} · TP ${c.tpPercent > 0 && c.tpX > 0 ? `${c.tpPercent}% at ${c.tpX}x` : 'off'} · slippage ${c.slippage}%`,
      `📈 Since start: ${this.stats.buys} buys · ${this.stats.sells} sells · ${this.stats.failed} failed · ${this.stats.skipped} skipped`,
    ];
    if (c.dailyLimitSol > 0) lines.push(`📅 Spent today: ${fmtSol(this.spentToday.sol)} / ${fmtSol(c.dailyLimitSol)} SOL`);
    const open = Object.entries(this.positions).filter(([, p]) => p.tokens > 0);
    if (open.length) {
      lines.push('', '<b>Open copy positions</b>');
      for (const [mint, p] of open) {
        const v = p.lastValueSol ?? (await this.valueSol(mint, p.tokens).catch(() => null));
        const x = v != null && p.costSol > 0 ? (v + p.proceedsSol) / p.costSol : null;
        lines.push(`• <b>${e(p.symbol || shortAddr(mint))}</b> in ${fmtSol(p.costSol)} SOL${p.buys > 1 ? ` (${p.buys} buys)` : ''}${v != null ? ` · now ~${fmtSol(v)} SOL` : ''}${x != null ? ` (${x.toFixed(2)}x)` : ''}${p.quickDone ? ' · quick profit taken' : ''}${p.tpDone ? ' · TP taken' : ''}\n   <code>${mint}</code>`);
      }
    } else lines.push('', 'No open copy positions.');
    if (this.lastSkip && Date.now() - this.lastSkip.at < 6 * 3600000) lines.push('', `Last skip: ${shortAddr(this.lastSkip.mint)} — ${e(this.lastSkip.why)}`);
    lines.push('', '/pause · /resume · /sell &lt;CA&gt; [percent]');
    return lines.join('\n');
  }
}
