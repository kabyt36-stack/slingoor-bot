import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
process.env.PAPER_LAND_MS = '0';
const { PaperBook, PaperRpc, PaperSwapper, traderReport } = await import('../src/paper.js');

const tmp = () => path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'paper-')), 'book.json');
const SOLM = 'So11111111111111111111111111111111111111112';

function setup() {
  const book = new PaperBook(tmp());
  book.reset({ main: 0.5, W2: 0.2 });
  const sent = [];
  const realRpc = { call: async (m) => (m === 'sendTransaction' ? sent.push(1) : m === 'getTokenSupply' ? { value: { decimals: 6 } } : null), getTokenBalance: async () => ({ ui: 999 }) };
  let pricePerTokenSol = 0.000001; // 1 SOL = 1M tokens
  const real = {
    slippage: 10,
    kp: { publicKey: 'ME' },
    _jup: async (q) => {
      const p = new URLSearchParams(q.split('?')[1]);
      const amt = Number(p.get('amount'));
      if (p.get('inputMint') === SOLM) return { outAmount: String(Math.floor((amt / 1e9 / pricePerTokenSol) * 1e6)) };
      return { outAmount: String(Math.floor((amt / 1e6) * pricePerTokenSol * 1e9)) };
    },
    quoteSellSol: async () => null,
  };
  return { book, rpc: new PaperRpc(realRpc, book, 'main', 'ME'), sw: new PaperSwapper(real, book, 'main', realRpc), sent, setPx: (v) => (pricePerTokenSol = v) };
}

test('paper: buys and sells fill at real quotes against the fake balance; nothing is ever sent', async () => {
  const { book, rpc, sw, sent, setPx } = setup();
  const b = await sw.trade({ action: 'buy', mint: 'C1', amount: 0.1 });
  assert.ok(Math.abs(b.solDelta + 0.1001) < 1e-9);
  assert.ok(Math.abs(b.tokenDelta - 100000) < 1e-6);
  assert.ok(Math.abs((await rpc.call('getBalance', ['ME'])).value / 1e9 - (0.3999 - 0.00203928)) < 1e-6, 'main paper SOL went down (incl. new account rent)');
  assert.equal((await rpc.getTokenBalance('ME', 'C1')).ui, 100000);
  assert.equal((await rpc.getTokenBalance('OTHER', 'C1')).ui, 999, 'other wallets: real RPC');
  setPx(0.000002); // price doubled
  const s1 = await sw.trade({ action: 'sell', mint: 'C1', amount: '50%' });
  assert.ok(Math.abs(s1.solDelta - (0.1 - 0.0001)) < 1e-9);
  const s2 = await sw.trade({ action: 'sell', mint: 'C1', amount: '100%' });
  assert.ok(s2.solDelta > 0);
  assert.equal((await rpc.getTokenBalance('ME', 'C1')).ui, 0);
  assert.ok(book.w('main').sol > 0.5, 'doubled: paper profit');
  assert.ok(Math.abs(book.w('main').sol - (0.5 - 0.1001 + 0.0999 + 0.0999)) < 1e-6, 'rent came back after selling out');
  assert.equal(sent.length, 0);
  assert.equal((await rpc.call('getBalance', ['ME'])).value > 0, true);
});

test('paper: not enough fake SOL -> the buy fails; reset puts every wallet back to its starting amount', async () => {
  const { book, sw } = setup();
  await assert.rejects(sw.trade({ action: 'buy', mint: 'C2', amount: 0.9 }), /only 0\.500 SOL/);
  book.w('main').sol = 0.01;
  book.reset({ main: 0.5, W2: 0.2, W3: 0.2, W4: 0.1 });
  assert.deepEqual(Object.fromEntries(Object.entries(book.d.wallets).map(([k, v]) => [k, v.sol])), { main: 0.5, W2: 0.2, W3: 0.2, W4: 0.1 });
});

test('trader report card: rating per trader and a replace hint for losers', () => {
  const sign = (n) => `${n >= 0 ? '+' : '-'}${Math.abs(n).toFixed(3)}`;
  const trips = [
    ...[0.05, 0.04, 0.03, -0.01].map((pnl) => ({ leader: 'schoen', pnl })),
    ...[-0.02, -0.03, -0.01].map((pnl) => ({ leader: 'killua', pnl })),
  ];
  const { lines } = traderReport(trips, { sign });
  assert.match(lines[0], /schoen<\/b> \[A\] \+0\.110 SOL · 3\/4 won/);
  assert.match(lines[1], /killua<\/b> \[F\] -0\.060 SOL · 0\/3 won → consider replacing/);
});

test('paper fills like a real trade: price ~1s later, fails past slippage (fee still paid), rent on new coin', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'pp-'));
  const book = new PaperBook(path.join(dir, 'b.json'));
  book.reset({ main: 1 });
  let outs = [];
  const real = { slippage: 10, _jup: async () => ({ outAmount: String(outs.shift()) }), kp: null };
  const rpc = { call: async () => ({ value: { decimals: 6 } }) };
  const sw = new PaperSwapper(real, book, 'main', rpc, { landMs: 5 });
  // moved 5% against us: still inside 10% slippage, filled at the later (worse) price
  outs = [1_000_000, 950_000];
  const r = await sw.trade({ action: 'buy', mint: 'M', amount: 0.1 });
  assert.equal(book.w('main').tokens.M.raw, '950000');
  assert.ok(Math.abs(book.w('main').sol - (1 - 0.1001 - 0.00203928)) < 1e-9);
  assert.ok(Math.abs(r.solDelta + 0.1001) < 1e-9);
  // moved 20%: fails on-chain like the real one, only the fee is lost
  outs = [1_000_000, 800_000];
  const before = book.w('main').sol;
  await assert.rejects(sw.trade({ action: 'buy', mint: 'M', amount: 0.1 }), (e) => e.onChain && /slippage/.test(e.message));
  assert.ok(Math.abs(book.w('main').sol - (before - 0.0001)) < 1e-9);
  // retry with bigger slippage (what the bot does) goes through
  outs = [1_000_000, 800_000];
  await sw.trade({ action: 'buy', mint: 'M', amount: 0.1, slippage: 25 });
  assert.equal(book.w('main').tokens.M.raw, '1750000');
});
