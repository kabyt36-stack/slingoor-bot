import { fileURLToPath } from 'node:url';
import fs from 'node:fs';
import path from 'node:path';
import { isAddress } from './util.js';
import { parseDevs } from './devs.js';

export const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

const DEFAULTS = {
  TELEGRAM_BOT_TOKEN: '',
  TELEGRAM_CHAT_ID: '',
  TARGET_NAME: 'slingoor',
  SELF_KEYWORDS: 'sling',
  TARGET_WALLETS: '5YRgrP3mjGzrzirYYN5HAQH19cTYREYwGxW6XRJQUzij',
  // V2.3: more traders to copy, as name:wallet (several wallets: name:w1;w2), comma separated.
  // Pause/unpause each one in Telegram: /mode <name> off|on
  TRADERS: 'schoen:5hAgYC8TJCcEZV7LTXAzkTrm7YL29YXyQQJPCNrG84zM,ansem:GV6UUmNxz2RpKxmNAPadYKb7uQpszwqQAu3qLJxVdC52,killua:95TWoKkvv2z85EXBzd2z6NwbxH2f54AvwuCA9x3NoKep,dilly:G9gmk9msvd6wT4hDJFm64vKra5z82YvD9je9WqjBvnuk,bot:BUkpShoEWRiPckdFs3kzYGjBPfUhL6G39ufo84QeogPP,decu:4vw54BmAogeRV3vPKWyFet5yf8DTLcREzdSzx4rw9Ud9,cupsey:6DQAGJT7VZPVBsuG4kn3AvpyHCEi7B2RFFvMZdbqQqqP',
  // V2.5 mini toaster: known farmers -> always quick profit (sell 100% at +20% to +40%)
  MINI_TOASTER: 'bot,decu',
  // V2.7.6: hold toaster coins a bit longer (catch the green candle): sell all at +80%, or once it falls
  // 10% from its top after being up 25%+
  MINI_TOASTER_SELL_X: '1.8',
  MINI_TOASTER_PULLBACK_PERCENT: '10',
  // fixed buy size per trader (name:SOL), e.g. decu is risky -> small
  TRADER_BUY_SOL: 'decu:0.05',
  // don't copy these traders' buys when the coin has fewer holders than this (name:holders)
  TRADER_MIN_HOLDERS: 'bot:20,cupsey:100', // cupsey farms: only coins lots of people hold
  TRADER_MAX_MC: 'cupsey:40000', // V2.10.1 his buys above this market cap (USD) are not copied
  // if the second trader buys a coin we copied from the first, hold for the jump and sell 100% when either sells
  TRADER_BOOSTERS: 'decu>bot',
  // V2.4 devs: coins these devs launch get bought. name:wallet:mode (instant | dip | momentum)
  DEVS: 'pattersin:AoGefnxF5CbZvbd2cvxv4Ex1E5j86dqEjehazRuMcMFe:instant,claudia:bwamJzztZsepfkteWRChggmXuiiCQvpLqPietdNfSXa:momentum,ya:21s7TyYFofbS9vAvLrxWVhKQScJAv7rrTSm1gTtt1dqv:dip,nig:gVDXhoGbePACvSqN7CZBtQXFW9eyJwsgudPEwSydAkx:dip,rugdev:H9SaZazTkfFYgqXoEYDzfQNVLnDLph7C65BB4vX9c9Sw:rug',
  // V2.5 rug-dev experiment: only buy while the market cap is at most this (USD), sell very fast
  DEV_RUG_MAX_MC_USD: '3000',
  DEV_RUG_MAX_HOLD_MINUTES: '5',
  // V2.4 watch-only wallets (never copied): if one buys into a coin the bot holds AFTER the bot bought,
  // the bot holds that coin longer for more profit. name:wallet, comma separated.
  WATCH_WALLETS: 'jackduval:BAr5csYtpWoNpwhUjixX7ZPHXkUciFZzjBp9uNxZXJPh;5m1GCXJqvYv9wC5qf8njetG39pBwCSTb11XwY3sQkW7a,kimchi:Gs5FHwYLrDBmCmiv5VhBLCvyiBmBYfcPedZDqR88GYeX,million:4ugDhHJ8XDXAeABmrNmGffFaLbJb9BkPyiFGVSV9ocwo,henry:CuDe51GPh5qGsmYBJDxSsufhQQhA618uDbkaXFZ4pztL,cyberleek:PrEytJ4nKqKcLwzHrxLZT3JcZHfr2NnMGMDcQWkj8dS',
  DEV_BUY_SOL: '0.1',
  DEV_QUICK_WALLET_BUY_SOL: '0.05',
  DEV_DIP_PERCENT: '20',
  DEV_MOMENTUM_HOLDERS: '40',
  DEV_MOMENTUM_UP_PERCENT: '30',
  DEV_WATCH_MINUTES: '20',
  // Cupsey mode: also copy cupsey's brand-new coins, same rules, same bot wallet
  CUPSEY_MODE: 'off', // V2.3: cupsey removed (not profitable)
  CUPSEY_NAME: 'cupsey',
  CUPSEY_WALLETS: '6DQAGJT7VZPVBsuG4kn3AvpyHCEi7B2RFFvMZdbqQqqP',
  // V2.11.3 wallets Khalil sends without names (t1, t2 ...): always followed on top of TRADERS (even when an
  // older settings.txt has its own TRADERS list); auto-rotate decides whether they're copied
  NEW_TRADERS: 'henry:CuDe51GPh5qGsmYBJDxSsufhQQhA618uDbkaXFZ4pztL,t2:FPrWHsHS2SVqSpCZrsdqfiND2un8d4rQN1tNQJ8febNs,t3:CyaE1VxvBrahnPWkqm5VsdCvyS2QmNht2UFrKJHga54o,t4:DVMkhiQe1D8yenuEgsW44NjRn9LfVQjGEpZcez5x7Mff,t5:5iZvwfoMdnxXpPGw9hBKEz3tHv2jYG3TgExHDsWrpTyV,t6:sAdNbe1cKNMDqDsa4npB3TfL62T14uAo2MsUQfLvzLT,t7:3yjR5VTyda92jJUF9fueMYjoMNoHxZ6aQfULsZ3oFAxx,t8:Fyr3eVTySpfyczEzUFcJ3SPtEKRwWKhxsmAWLghwP3FL,t9:HodLXSGKApwv2ZYi1BTwo5DAwwxWV4zhMGa4Wz17URvd,t10:AQnK8FB6JhSmMR4wpHHTdjSmGxXgpFMLgSbpUav9wL4P,t11:8dDGrCsdiNQzhwZXLrRe8T8vJ1YRzwCNgQPE4MRe8cp5,t12:FLyBjfWGsxH4zDDfoUJHwA9774TmPVpR8kB5B46PtbaZ,t13:98Gfo4iGa2tfn9wT7i9o3tAZeP8B9z2ZqP3Epqs6n5Zu,t14:CTv6NRzjajG4nE98RLzxvPJHBiSHtJn3dLNokimAYe1x,t15:HrDLkiLCoh8ZX845cYmNPH577Ds8wkLzzwTWJYFjYUTo,t16:ENjbhDJNuj4TnTNU4sJb4hsaMaSAGjqKeFyZxbnDVCCV,t17:3tAF3TnN7KMbRvuHn2ebjPnu24zZ7nRUk5rof3Bp7EXf,t18:JB8LkFgN7U5UJMwYrBcHCheB3z789rbAsJRYcwKmeAaz,t19:CzhcDR6tE2tTHRNcwHsqDpfSGxkYxXkjXCL7nH82LP2e,t20:6dC4Rvt1c6mv6M27QeAxRCCbXjUaZPFRZPxZn2rLXN7s,t21:kkqiX8UefMWqyf5cPyvRiS18BBtoxZszhjByvXDWCpB,t22:BmThZsp3nnApBEt5XBb6fwWpAr2r964YWTMLAS9Rp5Mw,t23:3tNPvytXB9yTZLgh5RGdjrXVxHp89vGeCiwx9juqgp7q,t24:Gx6yY8zwqwvcMbkHDZVv2ViJ1bBY5o3Zv7P1dDfJzk35,t25:HHn8v2t68ZAUfjo62JW6qyK8SHatoC9i5cZnzZL2LPB,t26:3MF4fvRBxVt2kAtWoTyoXvExSUkoi8NNe1svVa6PRXJm,t27:n62QUDHwXWCnZyArC9KsP3PqeBzf7WwAMqRLtwUgR7z,t28:75YkFbM2K6P4zAXhB9B9k76hdsubAKn8nNDuGxL652mY,t29:B2oCruKe8e4s44n47myzD7TnNaGLqT7brNzforQx2Bjg,t30:ARC5JvKVCcnitPgTmmqV9xc1FJUPB43AEWPU1iMdYM7k,t31:J898BLdjUWFPsvqwraj1rjg33rE9B6zJY6HvWFKx71fo,t32:BEFo1bApSaFUKqhXq9Cc9M9We5evXkpH5zthVrBhSi7V,t33:2MJQCrvZjdRD1n6tym2Wf6zPPynyyGq4RCdfJc6M4nsb,t34:5qMp9p2oFJx1Y2rLZ1X5kUbmXnpMvn5THtDP5NLsxaHK,t35:HSeCG7T2KCTuVAARGXZuxBNZg6pas1EdJdjn7Xyy1ENB,t36:AYEHKbGooTCishm755ArC88YZPJ29Rfh3b4q2hpyJPAQ,t37:CXWk3ar6NaYtgk4GqC7Sq2evVAWTsNc2J2sbHVdu4XGG,t38:93KdB1SYF7MQyJXHEHcCjbYucWcPYzgiqKB4VRrqDAhA,t39:66B95ED19CLsJtsVYPkTBQT3EZPPpEawCimCPruVucSX,t40:8Ry1vK2M76igs4rPhQhtwjdAYigyHnpPGTVdeof3vBy4,t41:F3xbw8g2bJT4h9EPzKgPrXxXbySZezM8nFsZubrbyBwb,t42:6X7Ln5KPurRfNiNroyZxxi7VstEzuhd4jMefNEqAu7uV,t43:8eGqytw6HWhykdBoA9gNWZv7t7vYr6X8KeoDABU1731y,t44:BPvgA9bLaTwoWRfbC1xzf2BRTcFvTBMw57Z29A3UM8Mz,t45:GnqguTwbdpyirLNMRiYDB5MpMF9gARgYy5JuiQLETnbq,t46:G92RdzZVrrHsVx1r6XvUt8qERepYLXCF475c56z8UHE8,t47:5ekW7PUgNvXSZ7hFhmV1eQ7Qn1TYdvFR6vTxMaNHEoDd,t48:7GZeuQXMP9dKhMmAGwX47J8TQL54yfuUNWj5V7faEY1n,t49:HJvA1AuetuTPYdeEqntxroXWjw8iTBwx1Ly5w6UsJxXp,t50:GZ1yiJKTq8Mc6RiY2WQrzph8wJcizSLGgyhr4RSgnuUo,t51:649ot18fccD6Mc9V4aHWTdoSVCuqAEtg9aWuxBA9cRoU,t52:VTd8fTsCkWTdtxtJvURJemNDuq9RCDh5uBhggUrBU15,t53:CE44oKS3wpUerx8afyeii56u5oQjBLZknzm4Q2CYHUz9,t54:9z332Pxs4xaz7CdE4sYPEHu9a9qrxcUTkbvMXVo1q1Q8,t55:4y2T1ghykCTq4EddoXjptZamk4qAsqcZw6eKxS8jdvE1,t56:6DtEedWf9Wk5hA7Xth82Eq441yf5DA4aGLqaQAVfDokm,t57:EGB6v3y5oS7Whv4KHYp8ksL2wRfqdfAF5Dbqq8kHXsZH,t58:DULX3e6vt1ZpHq3AdCUBZLPZ1CrhApdNKcewMPxZQRXf,t59:9BMzTpSo4URse1oN666pmexhdjpU1vA5p7LtroCFQdLU,t60:8d1xm25XWhSbJws1fXFr5GNcxgRsAeTAywg26AtsuFwt,t61:VJSDW6S74YXR4rRR9P4xwhMvLZJQMhrUb8XMFirUsy1,t62:FczAVrSD8WPAymBhWrcFy8QsRjgDqmFkuqWa1KkAbzuD,t63:9bmZBYi45rQeBkLryc6e72eQ3bQdQEavRMt1rR6oCtyR,jackduval:BAr5csYtpWoNpwhUjixX7ZPHXkUciFZzjBp9uNxZXJPh;5m1GCXJqvYv9wC5qf8njetG39pBwCSTb11XwY3sQkW7a,kimchi:Gs5FHwYLrDBmCmiv5VhBLCvyiBmBYfcPedZDqR88GYeX,million:4ugDhHJ8XDXAeABmrNmGffFaLbJb9BkPyiFGVSV9ocwo,cyberleek:PrEytJ4nKqKcLwzHrxLZT3JcZHfr2NnMGMDcQWkj8dS',
  // V2.11.4 farmers (Khalil: cupsey, t3): only coins lots of people hold, at a low market cap — applied even when
  // an older settings.txt has its own TRADER_MIN_HOLDERS / TRADER_MAX_MC lines
  FARMERS: 'cupsey,t3,t27,decu',
  FARMER_MIN_HOLDERS: '100',
  FARMER_MAX_MC: '40000',
  // cupsey trades fresh new pairs that often rug: his coins sell faster (see settings.txt)
  CUPSEY_FAST_EXIT: 'on',
  // dead coin: sell all when a losing coin goes quiet and more people are selling than buying
  // sling's coins: sell all if the coin has fewer holders than this (after the first minutes)
  COPY_MIN_HOLDERS: '80',
  COPY_MIN_HOLDERS_AFTER_MINUTES: '10',
  // sells at a loss: no Telegram alert, listed in the 11:59pm daily recap instead
  COPY_LOSS_ALERTS: 'off',
  // V2 weak-buy rule: trader bought under this much SOL and the chart is fading -> sell all (0 = off)
  COPY_WEAK_BUY_SOL: '3',
  COPY_WEAK_MIN_MINUTES: '3',
  COPY_WEAK_MAX_X: '1.1',
  // V2: traders the bot does NOT copy by default (sling retired). /mode <name> on to copy again.
  COPY_TRADERS_OFF: '', // V2.11.8 decu on (Khalil)
  // V2: one-line Telegram alerts (bought X for Y SOL; Nx cook / mini cook / sold, got Y SOL)
  SHORT_ALERTS: 'on',
  COPY_DEAD_COIN: 'on',
  COPY_DEAD_MIN_MINUTES: '20',
  COPY_DEAD_MAX_TRADES_5M: '10',
  COPY_DEAD_MAX_VOLUME_5M_USD: '300',
  CUPSEY_MINI_SELL_PERCENT: '100',
  CUPSEY_STOP_LOSS_X: '0.7',
  CUPSEY_CRASH_DROP_PERCENT: '20',
  CUPSEY_TRAIL_AFTER_X: '1.3',
  CUPSEY_TRAIL_DROP_PERCENT: '25',
  CUPSEY_PROFIT_FLOOR_X: '1.05',
  HELIUS_API_KEY: '',
  HELIUS_BACKUP_KEYS: '',
  USE_PUMPFUN: 'off',
  CHAIN_COMMITMENT: 'auto',
  RPC_URL: 'https://api.mainnet-beta.solana.com',
  WS_URL: 'wss://api.mainnet-beta.solana.com',
  PUMP_TRADES_POLL_SECONDS: '2',
  CALLOUT_POLL_SECONDS: '5',
  CALLOUT_LIST_SECONDS: '20',
  LAUNCH_POLL_SECONDS: '60',
  MERGE_WINDOW_SECONDS: '20',
  MIN_ALERT_SOL: '0',
  QUIET_MODE: 'on',
  // V2.8 learning: how each wallet's coins move -> better sell settings, sent for you to /apply
  LEARN: 'on',
  LEARN_MIN_TRADES: '15',
  SUGGEST_HOURS: '0,6,12,18',
  SUMMARY_MINUTE: '0',
  ALERT_NEW_ENTRIES: 'on',
  ALERT_ADDS: 'on',
  ALERT_PARTIAL_SELLS: 'on',
  ALERT_FULL_EXITS: 'on',
  ALERT_TRANSFERS: 'on',
  ALERT_CALLOUTS: 'on',
  ALERT_CALLOUT_UPDATES: 'on',
  ALERT_LAUNCHES: 'on',
  META_ONLY_ENTRIES: 'off',
  // Copy trading
  COPY_TRADE: 'off',
  COPY_PRIVATE_KEY: '',
  COPY_KEY_FILE: 'wallet-key.txt',
  // V2 quick-profit wallets: extra wallets that buy the same coins as the main wallet and sell 100% at +25%
  QUICK_WALLETS: 'on',
  // V2.11.9 up to 10 side wallets (W2-W11): wallet-key-2.txt ... wallet-key-11.txt (missing files are skipped)
  QUICK_WALLET_KEY_FILES: 'wallet-key-2.txt,wallet-key-3.txt,wallet-key-4.txt,wallet-key-5.txt,wallet-key-6.txt,wallet-key-7.txt,wallet-key-8.txt,wallet-key-9.txt,wallet-key-10.txt,wallet-key-11.txt',
  QUICK_WALLET_BUY_SOL: '0.05',
  QUICK_WALLET_SELL_X: '1.25',
  // V2.11.21 Khalil: side wallets take a more aggressive +50% to +100%: armed at 1.5x, sell all at 2x or once it pulls
  // back this % from its top (applies over QUICK_WALLET_SELL_X)
  // V2.11.35 (Khalil, Nov 13 7:06pm: "it has to reach .10x-.25x profit, sides will sell all and take profit, look for
  // the most aggressive good profit for the sides"): side wallets sell all between +10% and +25% (the exact point
  // adapts to the market). New keys: the old SIDE_SELL_* (+50%..+100%) in settings.txt are no longer used.
  SIDE_TAKE_FROM_X: '1.15', // V2.11.36 Khalil 7:35pm: +15% (a +10% sell was mostly eaten by fees)
  SIDE_TAKE_TO_X: '1.35', // V2.11.59 Khalil Nov 14 8:05pm: side take +15% to +35%
  SIDE_TAKE_PULLBACK_PERCENT: '5',
  // V2.11.35 paper: a side wallet too low to make a buy is topped back up to its starting SOL from main (main keeps
  // at least its own starting SOL)
  PAPER_REFILL_SIDES: 'on',
  // V2.11.38 real trading too: a side wallet too low to buy is topped back up to TOP_UP_TO_SOL from main, any time
  TOP_UP_SIDES: 'on',
  TOP_UP_TO_SOL: '0.25',
  TOP_UP_MAIN_MIN_SOL: '1', // only while main has more than this, and never takes main under it
  SIDE_PRIORITY_FEE: '0.0005', // V2.11.35 side wallets' most tip per trade (0 = same as COPY_PRIORITY_FEE)
  // V2.6 auto-fund: each time the main wallet reaches a new whole AUTO_FUND_EVERY_SOL, send AUTO_FUND_SOL to each side wallet
  // V2.7 paper trading (/paper on|off): fake balances that reset to these every time it's turned on
  PAPER_START_SOL: 'main:0.5,W2:0.2,W3:0.2,W4:0.1',
  AUTO_FUND: 'on',
  AUTO_FUND_EVERY_SOL: '1',
  AUTO_FUND_SOL: '0.1',
  AUTO_FUND_KEEP_SOL: '0.3',
  AUTO_FUND_MAIN_SHARE_PERCENT: '70', // main wallet always keeps at least this share of all your SOL
  // V2.8.4 end-of-day refill: at this time, a side wallet too low to buy gets AUTO_FUND_REFILL_SOL from main
  AUTO_FUND_REFILL: 'on',
  AUTO_FUND_REFILL_SOL: '0.05',
  AUTO_FUND_REFILL_AT: '23:55',
  AUTO_FUND_REFILL_MAIN_MIN_SOL: '0.1', // refill only while the main wallet keeps at least this much
  COPY_BUY_SOL: '0.1',
  COPY_SIZE_MODE: 'scale',
  COPY_SCALE_AT_1_SOL: '0.5',
  COPY_MAX_BUY_SOL: '1',
  COPY_SCALE_MAX_AT_SOL: '1000',
  COPY_MAX_WALLET_PERCENT: '20',
  COPY_MAX_PER_COIN_SOL: '2',
  COPY_MIN_BUY_SOL: '0.01',
  COPY_ADDS: 'on',
  COPY_ONLY_NEW_COINS: 'on',
  COPY_REENTRIES: 'off',
  COPY_SKIP_ALERTS: 'on',
  COPY_ONE_BUY_PER_COIN: 'on',
  COPY_FEE_MODE: 'low',
  COPY_MAX_SLIPPAGE: '50',
  COPY_MAX_COIN_AGE_HOURS: '3',
  COPY_PROTECT: 'on',
  COPY_CRASH_DROP_PERCENT: '35',
  COPY_CRASH_MINUTES: '5',
  COPY_TRAIL_AFTER_X: '1.5',
  COPY_TRAIL_DROP_PERCENT: '40',
  COPY_PROFIT_FLOOR_X: '1.15',
  COPY_MAX_HOLD_HOURS: '8',
  COPY_FLOOR_BUY_SOL: '0.1',
  COPY_ROUTE_WAIT_SECONDS: '45',
  COPY_TP_LADDER: '2x:50,4x:25,6x:25,8x:25',
  // Quick profit mode (also /quick on|off in Telegram): every coin sells 100% once up 25%, on the
  // first 7% dip, or at +75% at the latest
  QUICK_PROFIT_MODE: 'off',
  QUICK_PROFIT_FROM_X: '1.25',
  QUICK_PROFIT_TO_X: '1.75',
  QUICK_PROFIT_PULLBACK_PERCENT: '7',
  COPY_MINI_COOK: 'on',
  COPY_MINI_COOK_FROM_X: '1.75',
  COPY_MINI_COOK_TO_X: '2.5',
  COPY_MINI_COOK_PULLBACK_PERCENT: '10',
  COPY_MINI_COOK_SELL_PERCENT: '50',
  COPY_MINI_COOK_MIN_SOL: '0.1',
  COPY_NEW_COIN_MINUTES: '10',
  COPY_RECLAIM_RENT: 'on',
  JUPITER_RPS: '',
  COPY_QUICK_TP_X: '1.5',
  COPY_QUICK_TP_PERCENT: '35',
  COPY_QUICK_TP_HIS_MIN_SOL: '1',
  COPY_SLIPPAGE: '10',
  // V2.9 one trader per wallet set: each wallet only copies the traders listed for it (all = everyone).
  // Everyone else stays tracked + learned from, just not copied by that wallet.
  WALLET_TRADERS: 'main:dilly,W2:dilly,W3:dilly,W4:dilly',
  // V2.9.3 more wallet sets, each with its own main wallet + mini wallets and its own traders:
  // name:trader+trader. Keys: wallet-key-<name>.txt (its main) and wallet-key-<name>-2.txt, -3 ... (its minis).
  // A set whose main key file isn't there is simply not started.
  WALLET_SETS: 'devs:pattersin+claudia+ya+nig',
  WALLET_SET_DIR: '', // where the wallet-key-<set>.txt files are (empty = the bot folder)
  HOURLY_GOAL_SOL: '0', // V2.9.1 starting hourly goal (0 = none); /goal changes it
  DAILY_GOAL_SOL: '1', // V2.11.12 Khalil: 1 SOL a day — reached -> no new buys until midnight (0 = off); /daygoal changes it
  DAILY_GOAL_STEP_SOL: '0.5',
  COOK_SHOW_TOTAL_SOL: '10',
  // V2.11.25 growth sizing: every wallet buys at least GROWTH_MIN_BUY_SOL, or GROWTH_PERCENT of its SOL when that's
  // more (buys grow as the wallet grows); multipliers never take it under the minimum or over GROWTH_MAX_PERCENT
  GROWTH_SIZE: 'on',
  GROWTH_MIN_BUY_SOL: '0.1', // V2.11.28 Khalil 1:35pm: buys at least 0.1
  // V2.11.29 paper auto-restart: paper wallets fall to this share of what they started with -> the bot finds the
  // traders who lost it (and why), benches them (24h, doubling each time) and restarts paper (0 = off)
  PAPER_AUTO_RESTART_AT: '0.6',
  // V2.11.30 market adapt: losing kinds of coins (market cap, volume, holders, narrative, dev) over the last
  // MARKET_HOURS are skipped by every wallet, and the side wallets' sell point follows what works
  // V2.11.37 traders whose coins are sold their way (quick in-and-out): all out at their usual take, -10% stop, out by
  // their usual hold time. Learned from their pretend wallets; until then +8% / 3 min.
  COPY_STYLE: 'henry',
  COPY_STYLE_ALL: 'on', // V2.11.44 every trader's style is learned and copied (once there's data)
  // V2.11.44 each wallet copies a trader only where copying him its way made money (his last STYLE_FIT_COINS coins)
  STYLE_FIT: 'on',
  STYLE_FIT_COINS: '20',
  SIDE_OWN_PICKS: 'on', // V2.11.55 side wallets also copy every trader whose side-style pretend trades + real copies make money
  // V2.11.41 cautious hours (learned losing hours + 12am-7am until proven good): only hot traders, no fresh-dev coins
  CAUTIOUS_HOURS: 'on',
  // V2.12.0 new-pair sniper: its own PAPER wallet trading brand-new pump.fun launches (off = no sniper)
  SNIPE_MODE: 'paper',
  SNIPE_BUY_SOL: '0.1',
  SNIPE_START_SOL: '0.25',
  SNIPE_MAX_OPEN: '3',
  SNIPE_MAX_AGE_SECONDS: '60',
  SNIPE_MAX_MC_USD: '6000',
  SNIPE_MIN_INSIDERS_PERCENT: '1',
  SNIPE_MAX_INSIDERS_PERCENT: '20',
  SNIPE_TAKE_FROM_PERCENT: '15',
  SNIPE_TAKE_TO_PERCENT: '75',
  SNIPE_STOP_PERCENT: '10',
  SNIPE_MAX_HOLD_MINUTES: '5',
  SNIPE_MAX_FRESH_PERCENT: '100', // V2.12.7 fresh buyers alone are fine
  SNIPE_TOP_FRESH_HOLDERS: '3', // V2.12.7 skip when the biggest 3 holders are all fresh wallets (0 = off)
  SNIPE_VAMP_MAX_FRESH_PERCENT: '25',
  SNIPE_MAX_DEV_COINS: '0', // V2.12.5 off (Khalil: buy devs who launched many coins); >0 = skip devs with more launches
  SNIPE_MAX_DEV_LAUNCHES: '0', // V2.12.5 off (Khalil); >0 = skip a dev with this many other launches in 24h
  SNIPE_LEARN: 'on', // V2.12.3 skip kinds of coins that keep rugging
  SNIPE_LEARN_MIN_COINS: '15', // V2.12.8 (Khalil: "Yes make learner"): a kind is only skipped after 15+ coins of it
  SNIPE_MIN_BUYERS: '2', // V2.12.1 other buyers that must show up and pass the wallet check before it buys
  SNIPE_WS_URL: 'wss://pumpportal.fun/api/data',
  MAIN_TP_LADDER: '1.25x:25,2x:25,4x:25,6x:25,8x:25', // V2.11.60 main's take profit (of what's left); same = use COPY_TP_LADDER
  // V2.11.53 no late chases (a coin already up 10x in 5 min, unless 2 other traders buy up there too) and copycats
  // (same name as an older coin) need their own website; a held coin is sold when a newer same-name coin passes it
  LATE_CHASE_X: '10',
  LATE_CHASE_MINUTES: '5',
  LATE_CHASE_OK_TRADERS: '2',
  VERSION_CHECK: 'on',
  MARKET_ADAPT: 'on',
  SUGGESTIONS: 'off', // V2.11.32 Khalil: no /suggestions (they'd fight the market adapt)
  MARKET_HOURS: '6',
  GROWTH_PERCENT: '25',
  GROWTH_MAX_PERCENT: '50',
  // V2.11.22 not copied: traders who usually sell within this many seconds (we can't keep up), and traders whose
  // real/paper copies lost money over their last 10+ closed coins (0 = off)
  COPY_MIN_HOLD_SECONDS: '120',
  COPY_CONFIRM_SECONDS: '30', // V2.11.24 a fast trader's buy is copied if he still holds it this many seconds later
  // V2.11.23 dev check: a coin whose dev wallet has no trades before it -> the main wallet skips it, side wallets
  // buy and sell all between +10% and +25% (5% pullback)
  DEV_CHECK: 'on',
  FRESH_DEV_FROM_X: '1.1',
  FRESH_DEV_TO_X: '1.25',
  FRESH_DEV_PULLBACK_PERCENT: '5',
  COPY_REAL_VETO_COINS: '10', // V2.11.22 a cook that made this much SOL also shows your total PnL today (0 = never) // V2.11.13 the goal grows this much every day (1, 1.5, 2 ...)
  // V2.9.6 Khalil's fixes for unprofitable dilly copies: sell all at -20%, and don't buy his pump
  AUTO_ROTATE: 'on', // V2.10 copy whoever is hot (pretend wallets, last 24h); /rotate on|off
  ROTATE_MIN_COINS: '20', // trades needed before a trader can be judged (judged on his last 30)
  ROTATE_NEW_WALLET_HOURS: '48', // new wallets wait this long before they can be copied
  ROTATE_RETIRE_COLD_DAYS: '7', // V2.11.5 a trader cold this many days in a row is removed (you're told; 0 = never)
  ROTATE_KEEP_IF_MADE_SOL: '1', // V2.11.6 ...unless he made you this much SOL in total (real copies or pretend wallets)
  TARGET_ONLY_ALERTS: 'on', // V2.11.8 only sling's own trades get a message, not every tracked trader's
  REVIVE_TRADERS: '', // names removed for being cold that you sent again (followed again)
  // V2.11.1 Khalil (Nov 12 9pm): wallets he sent tonight don't wait; V2.11.11 (11:13pm "Turn 48 hour rule on"): from then on 48h
  ROTATE_NO_WAIT_UNTIL: '2026-11-13T04:13:00Z',
  // V2.11 Khalil's picks 1-5: sizes from the signals, best hours, best exit per trader (all learned from the
  // pretend wallets; each only kicks in once there's enough data)
  COPY_SMART_SIZE: 'on',
  COPY_NEUTRAL_SIZE: '0.5', // V2.11.2 neutral traders (not hot, not losing): this x the normal buy
  COPY_PROVEN_SIZE: '0.75', // V2.11.15 proven traders (20+ trades, making money, not hot): this x the normal buy
  COPY_HOT_RESERVE: '3', // open slots neutral traders can't use (kept for hot traders)
  COPY_STACK_BOOST: '1.5',
  // V2.11.16 runner chance: each wallet's share of coins that went 2x+ after he bought, combined for every tracked
  // wallet in the coin and corrected by what happened to past coins. 2x the usual chance -> bigger buy,
  // half or less -> smaller buy. Learns from the pretend wallets (needs 50 closed coins first).
  COPY_RUNNER_SIZE: 'on',
  COPY_RUNNER_X: '2',
  COPY_RUNNER_BOOST: '1.5',
  COPY_RUNNER_CUT: '0.5',
  // V2.11.18 Khalil: "kimchi def 99 percentage chance runner if he buys" — runner chance you set per trader,
  // and traders always copied at full size (no 48h wait, never dropped by auto-rotate)
  RUNNER_FORCE: 'kimchi:0.99',
  RUNNER_FORCE_EXTRA: 'ansem:0.5', // V2.11.33 Khalil 6:30pm: ansem has a big word in the scene (RUNNER_FORCE wins if it names him)
  ALWAYS_COPY: 'kimchi',
  // V2.11.18 traders whose coins every wallet holds: 25% off at 2x, the rest when he sells, -75% stop loss only
  HOLD_TRADERS: 'kimchi',
  HOLD_TAKE_X: '2',
  HOLD_TAKE_PERCENT: '25',
  HOLD_STOP_LOSS_X: '0.25',
  // V2.11.19 likely runners (high runner chance, any trader): every wallet holds — 25% off at 1.5x, the rest when
  // the trader sells; the normal stop loss stays
  RUNNER_HOLD: 'on',
  RUNNER_HOLD_TAKE_X: '1.5',
  RUNNER_HOLD_TAKE_PERCENT: '25',
  COPY_BIG_BET_BOOST: '1.5',
  COPY_TEST_BUY_CUT: '0.5',
  COPY_BEST_HOURS: 'on',
  COPY_EXIT_PICK: 'on',
  COPY_STOP_LOSS_X: '0.8',
  SIDE_STOP_LOSS_X: '0.85', // V2.12.6 (Khalil, Nov 15: "Stop loss -15"): side wallets sell all at -15% (main keeps COPY_STOP_LOSS_X)
  COPY_MAX_CHASE_PERCENT: '15',
  COPY_MIN_HOLDERS_TO_BUY: '0', // V2.9.4 (off since 2.9.5, Khalil's call): no copy buy into a coin with fewer holders
  COPY_MIN_MIRROR_PERCENT: '10', // his partial sells smaller than this are not copied (his full exit always is)
  COPY_PRIORITY_FEE: '0.002',
  COPY_MIRROR_SELLS: 'on',
  COPY_TAKE_PROFIT_X: '2',
  COPY_TAKE_PROFIT_SELL_PERCENT: '25',
  COPY_MAX_OPEN_POSITIONS: '10',
  COPY_DAILY_LIMIT_SOL: '0',
  COPY_MIN_HIS_BUY_SOL: '0',
  COPY_MAX_DELAY_SECONDS: '30',
  COPY_KEEP_SOL: '0.02',
  COPY_TP_CHECK_SECONDS: '5',
  COPY_SELL_RETRY_SECONDS: '15',
  COPY_SELL_RETRY_MINUTES: '10',
  COPY_SELL_CHECK_DELAY_SECONDS: '3',
  PUMPPORTAL_API_BASE: 'https://pumpportal.fun/api',
  JUPITER_API_BASE: 'https://lite-api.jup.ag/swap/v1',
  JUPITER_API_KEY: '',
  COPY_JITO: 'on',
  JITO_URLS: 'https://mainnet.block-engine.jito.wtf/api/v1/transactions,https://ny.mainnet.block-engine.jito.wtf/api/v1/transactions',
  COPY_FILE: 'data/copytrade.json',
  // Advanced / testing overrides
  PUMP_API_BASE: 'https://frontend-api-v3.pump.fun',
  PROFILE_API_BASE: 'https://profile-api.pump.fun',
  TELEGRAM_API_BASE: 'https://api.telegram.org',
  DEX_API_BASE: 'https://api.dexscreener.com',
  STATE_FILE: 'data/state.json',
  LOG_FILE: 'logs/bot.log',
};

function parseFile(file) {
  const out = {};
  if (!fs.existsSync(file)) return out;
  for (const raw of fs.readFileSync(file, 'utf8').replace(/^\uFEFF/, '').split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith('#')) continue;
    const i = line.indexOf('=');
    if (i < 1) continue;
    const k = line.slice(0, i).trim();
    let v = line.slice(i + 1).trim();
    // strip inline comment " # ..." and surrounding quotes
    const hash = v.search(/\s+#/);
    if (hash >= 0) v = v.slice(0, hash).trim();
    v = v.replace(/^["'“”‘’]+|["'“”‘’]+$/g, ''); // TextEdit may turn quotes into “smart quotes”
    out[k] = v;
  }
  return out;
}

// V2.11.9 side wallet key files; the standard list wallet-key-2.txt, -3, -4 is extended to -11 (10 side wallets)
export const quickKeyFiles = (text) => {
  const q = String(text || '').split(/[\s,]+/).filter(Boolean);
  if (q.length && q.every((f, i) => f === `wallet-key-${i + 2}.txt`)) for (let n = q.length + 2; n <= 11; n++) q.push(`wallet-key-${n}.txt`);
  return q;
};
const on = (v) => /^(on|true|yes|1)$/i.test(String(v).trim());
// farmers get the farmer limit unless their own line sets one
const farmerRule = (map, list, v) => {
  const m = { ...(map || {}) };
  if (v > 0) for (const n of String(list || '').split(/[\s,]+/).filter(Boolean)) if (!(m[n] > 0)) m[n] = v;
  return m;
};
const num = (v, d) => (Number.isFinite(+v) && String(v).trim() !== '' ? +v : d);

export function cleanHeliusKey(v) {
  let k = String(v || '').trim().replace(/^["'“”‘’<]+|["'“”‘’>]+$/g, '');
  const m = k.match(/api[-_]key=([^&\s"'<>]+)/i);
  if (m) k = m[1];
  const uuid = k.match(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i);
  if (uuid) k = uuid[0];
  return k.replace(/[^\w-]/g, '');
}

// WALLET_TRADERS: wallet:trader+trader, comma separated ("main:dilly,W2:dilly"). A wallet not listed, or
// listed as "all", copies everyone. Returns { main: ['dilly'], W2: null (= all) ... }
export function parseWalletTraders(text) {
  const out = {};
  for (const part of String(text || '').split(',').map((x) => x.trim()).filter(Boolean)) {
    const [w, list = ''] = part.split(':').map((x) => x.trim());
    if (!w) continue;
    const names = list.split(/[+\s/|]+/).map((x) => x.trim()).filter(Boolean);
    out[w] = !names.length || names.some((n) => n.toLowerCase() === 'all') ? null : names;
  }
  return out;
}

export function loadConfig(settingsFile = process.env.SETTINGS_FILE || path.join(ROOT, 'settings.txt')) {
  const fileVals = parseFile(settingsFile);
  const raw = { ...DEFAULTS, ...fileVals };
  // Environment variables win (used by tests and power users)
  for (const k of Object.keys(DEFAULTS)) if (process.env[k] != null && process.env[k] !== '') raw[k] = process.env[k];

  let rpcUrl = raw.RPC_URL;
  let wsUrl = raw.WS_URL;
  // People paste the whole Helius URL (https://mainnet.helius-rpc.com/?api-key=...) instead of the key.
  raw.HELIUS_API_KEY = cleanHeliusKey(raw.HELIUS_API_KEY);
  // ...or put the Helius link in RPC_URL / WS_URL: use its key for both, so the live stream
  // never ends up on the public Solana server (which blocks many home connections).
  if (!raw.HELIUS_API_KEY) {
    for (const u of [raw.RPC_URL, raw.WS_URL]) if (/helius/i.test(u || '') && /api[-_]key=/i.test(u)) raw.HELIUS_API_KEY ||= cleanHeliusKey(u);
  }
  if (raw.HELIUS_API_KEY) {
    rpcUrl = `https://mainnet.helius-rpc.com/?api-key=${raw.HELIUS_API_KEY}`;
    wsUrl = `wss://mainnet.helius-rpc.com/?api-key=${raw.HELIUS_API_KEY}`;
  }
  // a custom RPC_URL without its own WS_URL: use the same server for the live stream
  if (!raw.HELIUS_API_KEY && rpcUrl !== DEFAULTS.RPC_URL && wsUrl === DEFAULTS.WS_URL) wsUrl = rpcUrl.replace(/^http/i, 'ws');
  const isPublicRpc = /api\.mainnet-beta\.solana\.com/.test(rpcUrl);
  // V2.5 backup Helius keys (keys or full links, comma separated): used when the main key runs out
  const heliusKeys = raw.HELIUS_API_KEY
    ? [raw.HELIUS_API_KEY, ...String(raw.HELIUS_BACKUP_KEYS || '').split(/[\s,]+/).filter(Boolean).map((k) => cleanHeliusKey(k)).filter((k) => /^[0-9a-f-]{20,}$/i.test(k || ''))]
    : [];

  const wallets = raw.TARGET_WALLETS.split(/[\s,]+/).filter(Boolean);
  const bad = wallets.filter((w) => !isAddress(w));
  if (bad.length) throw new Error(`TARGET_WALLETS has invalid address(es): ${bad.join(', ')}`);
  if (!wallets.length) throw new Error('TARGET_WALLETS is empty');
  // every trader the bot follows: [{ name, wallets }]; the main one (TARGET_*) first
  const traders = [{ name: raw.TARGET_NAME || 'target', wallets: [...wallets] }];
  if (on(raw.CUPSEY_MODE)) {
    const cw = raw.CUPSEY_WALLETS.split(/[\s,]+/).filter(Boolean).filter((w) => !wallets.includes(w));
    const badC = cw.filter((w) => !isAddress(w));
    if (badC.length) throw new Error(`CUPSEY_WALLETS has invalid address(es): ${badC.join(', ')}`);
    if (cw.length) {
      traders.push({ name: raw.CUPSEY_NAME || 'cupsey', wallets: cw });
      wallets.push(...cw);
    }
  }
  for (const part of String(raw.TRADERS || '').split(',').map((x) => x.trim()).filter(Boolean)) {
    const [name, ws] = part.split(':').map((x) => (x || '').trim());
    const tw = String(ws || '').split(/[;\s]+/).filter(Boolean).filter((w) => !wallets.includes(w));
    if (!name || !tw.length) continue;
    const badT = tw.filter((w) => !isAddress(w));
    if (badT.length) throw new Error(`TRADERS: ${name} has invalid wallet(s): ${badT.join(', ')}`);
    traders.push({ name, wallets: tw });
    wallets.push(...tw);
  }
  // V2.10.1 cupsey is always followed again (even when an older settings.txt has its own TRADERS list
  // or CUPSEY_MODE=off): auto-rotate decides whether he's copied
  if (!traders.some((t) => t.name === (raw.CUPSEY_NAME || 'cupsey')) && String(raw.TRADERS || '').toLowerCase() !== 'none') {
    const cw = String(raw.CUPSEY_WALLETS || '').split(/[\s,]+/).filter(Boolean).filter((w) => isAddress(w) && !wallets.includes(w));
    if (cw.length) {
      traders.push({ name: raw.CUPSEY_NAME || 'cupsey', wallets: cw });
      wallets.push(...cw);
    }
  }
  // V2.11.4 their buys come from the chain only (no pump.fun feeds: dozens of wallets would get pump.fun to block you)
  const chainOnly = [];
  for (const part of String(String(raw.TRADERS || '').toLowerCase() === 'none' ? '' : raw.NEW_TRADERS || '').split(',').map((x) => x.trim()).filter(Boolean)) {
    const [name, ws] = part.split(':').map((x) => (x || '').trim());
    const tw = String(ws || '').split(/[;\s]+/).filter(Boolean).filter((w) => isAddress(w) && !wallets.includes(w));
    if (!name || !tw.length || traders.some((t) => t.name === name)) continue;
    traders.push({ name, wallets: tw });
    wallets.push(...tw);
    chainOnly.push(...tw);
  }
  // devs are followed like traders (their launches come in as their buys), flagged isDev
  const devs = parseDevs(raw.DEVS, isAddress).filter((d) => !wallets.includes(d.wallet));
  for (const d of devs) {
    traders.push({ name: d.name, wallets: [d.wallet], isDev: true, devMode: d.mode });
    wallets.push(d.wallet);
  }
  const traderOf = (w) => (traders.find((t) => t.wallets.includes(w)) || traders[0]).name;

  const resolve = (p) => (path.isAbsolute(p) ? p : path.join(ROOT, p));

  return {
    settingsFile,
    telegramToken: raw.TELEGRAM_BOT_TOKEN,
    chatIds: raw.TELEGRAM_CHAT_ID.split(/[\s,]+/).filter(Boolean),
    targetName: raw.TARGET_NAME || 'target',
    selfWords: raw.SELF_KEYWORDS.split(/[\s,]+/).filter(Boolean),
    wallets,
    traders,
    traderOf,
    chainOnlyWallets: chainOnly,
    reviveTraders: raw.REVIVE_TRADERS || '',
    devs,
    rpcUrl,
    wsUrl,
    heliusKeys: [...new Set(heliusKeys)],
    isPublicRpc,
    tradesPollMs: Math.max(1, num(raw.PUMP_TRADES_POLL_SECONDS, 2)) * 1000,
    calloutPollMs: Math.max(2, num(raw.CALLOUT_POLL_SECONDS, 5)) * 1000,
    calloutListMs: Math.max(2, num(raw.CALLOUT_LIST_SECONDS, 20)) * 1000,
    launchPollMs: Math.max(5, num(raw.LAUNCH_POLL_SECONDS, 60)) * 1000,
    mergeWindowMs: Math.max(0, num(raw.MERGE_WINDOW_SECONDS, 20)) * 1000,
    minAlertSol: num(raw.MIN_ALERT_SOL, 0),
    // one summary every hour instead of an alert per trade (urgent ones still ping right away)
    quietMode: on(raw.QUIET_MODE),
    learn: { on: on(raw.LEARN), suggest: on(raw.SUGGESTIONS), minTrades: Math.max(3, Math.round(num(raw.LEARN_MIN_TRADES, 15))), hours: String(raw.SUGGEST_HOURS || '').split(/[\s,]+/).map(Number).filter((h) => Number.isInteger(h) && h >= 0 && h <= 23) },
    summaryMinute: Math.min(59, Math.max(0, Math.round(num(raw.SUMMARY_MINUTE, 0)))),
    targetOnlyAlerts: on(raw.TARGET_ONLY_ALERTS),
    alerts: {
      entry: on(raw.ALERT_NEW_ENTRIES),
      add: on(raw.ALERT_ADDS),
      partial: on(raw.ALERT_PARTIAL_SELLS),
      exit: on(raw.ALERT_FULL_EXITS),
      transfer: on(raw.ALERT_TRANSFERS),
      callout: on(raw.ALERT_CALLOUTS),
      calloutUpdate: on(raw.ALERT_CALLOUT_UPDATES),
      launch: on(raw.ALERT_LAUNCHES),
    },
    metaOnlyEntries: on(raw.META_ONLY_ENTRIES),
    // processed = sees his trades ~0.3s sooner; the public Solana server is slower at it, so only on others
    usePumpfun: on(raw.USE_PUMPFUN),
    chainCommitment: /^(processed|confirmed)$/i.test(raw.CHAIN_COMMITMENT) ? raw.CHAIN_COMMITMENT.toLowerCase() : isPublicRpc ? 'confirmed' : 'processed',
    copy: copyConfig(raw, resolve),
    pumpApi: raw.PUMP_API_BASE.replace(/\/$/, ''),
    profileApi: raw.PROFILE_API_BASE.replace(/\/$/, ''),
    telegramApi: raw.TELEGRAM_API_BASE.replace(/\/$/, ''),
    dexApi: raw.DEX_API_BASE.replace(/\/$/, ''),
    stateFile: resolve(raw.STATE_FILE),
    logFile: resolve(raw.LOG_FILE),
  };
}

// Sell rules for dev coins. instant devs (pump fast, dump fast): take the best quick profit, +25% to +40%.
// dip / momentum devs: ride it up and sell near the top, sell all fast if it turns down.
function pairs(text) {
  const out = {};
  for (const p of String(text || '').split(/[\s,]+/).filter(Boolean)) {
    const [k, v] = p.split(':');
    if (k && +v > 0) out[k.trim()] = +v;
  }
  return out;
}

function devRules(raw) {
  const out = {};
  // mini toaster traders: quick profit, all out
  for (const n of String(raw.MINI_TOASTER || '').split(/[\s,]+/).filter(Boolean)) out[n] = { miniFromX: 1.25, miniToX: Math.max(1.3, num(raw.MINI_TOASTER_SELL_X, 1.8)), miniPullbackPct: Math.min(50, Math.max(3, num(raw.MINI_TOASTER_PULLBACK_PERCENT, 10))), miniPct: 100, stopLossX: 0.8, crashDropPct: 20, trailArmX: 1.2, trailDropPct: 20, floorX: 1.05 };
  for (const d of parseDevs(raw.DEVS, isAddress)) {
    out[d.name] =
      d.mode === 'rug'
        ? { miniFromX: 1.1, miniToX: 1.3, miniPullbackPct: 3, miniPct: 100, stopLossX: 0.85, crashDropPct: 10, trailArmX: 1.08, trailDropPct: 8, floorX: 1.02, maxHoldMinutes: Math.max(1, num(raw.DEV_RUG_MAX_HOLD_MINUTES, 5)) }
        : d.mode === 'instant'
        ? { miniFromX: 1.25, miniToX: 1.4, miniPullbackPct: 5, miniPct: 100, stopLossX: 0.8, crashDropPct: 20, trailArmX: 1.15, trailDropPct: 15, floorX: 1.03 }
        : { miniFromX: 1.5, miniToX: 3, miniPullbackPct: 12, miniPct: 100, stopLossX: 0.85, crashDropPct: 20, trailArmX: 1.2, trailDropPct: 15, floorX: 1.05 };
  }
  return out;
}

function copyConfig(raw, resolve) {
  const mainLadder = /^same$/i.test(String(raw.MAIN_TP_LADDER || '').trim()) ? '' : String(raw.MAIN_TP_LADDER || '').trim();
  let key = raw.COPY_PRIVATE_KEY;
  const keyFile = resolve(raw.COPY_KEY_FILE);
  if (!key && fs.existsSync(keyFile)) key = fs.readFileSync(keyFile, 'utf8').replace(/^\uFEFF/, '').trim();
  // quick-profit wallets: one key per file (missing files are skipped)
  // V2.11.9 wallet-key-5.txt ... wallet-key-11.txt are always looked for too (an older settings.txt lists only 2-4)
  const qFiles = quickKeyFiles(raw.QUICK_WALLET_KEY_FILES);
  const quickWallets = on(raw.QUICK_WALLETS)
    ? qFiles
        .map((f, i) => {
          const p = resolve(f);
          if (!fs.existsSync(p)) return null;
          const k = fs.readFileSync(p, 'utf8').replace(/^\uFEFF/, '').trim();
          return k ? { label: `W${i + 2}`, key: k, file: p } : null;
        })
        .filter(Boolean)
    : [];
  const readKey = (p) => (fs.existsSync(p) ? fs.readFileSync(p, 'utf8').replace(/^\uFEFF/, '').trim() : '');
  const walletSets = [];
  for (const part of String(raw.WALLET_SETS || '').split(',').map((x) => x.trim()).filter(Boolean)) {
    const [name, list = ''] = part.split(':').map((x) => x.trim());
    if (!/^[a-z0-9_]{1,16}$/i.test(name || '') || /^(main|w\d+)$/i.test(name)) continue;
    const dir = raw.WALLET_SET_DIR || ''; // where the key files are (default: the bot folder)
    const mainFile = resolve(path.join(dir, `wallet-key-${name}.txt`));
    const mainKey = readKey(mainFile);
    if (!mainKey) continue;
    const minis = [];
    for (let n = 2; n <= 9; n++) {
      const p = resolve(path.join(dir, `wallet-key-${name}-${n}.txt`));
      const k = readKey(p);
      if (k) minis.push({ label: `${name}-W${n}`, key: k, file: p });
    }
    walletSets.push({ name, traders: list.split(/[+\s/|]+/).filter(Boolean), main: { label: name, key: mainKey, file: mainFile }, minis });
  }
  const c = {
    enabled: on(raw.COPY_TRADE),
    privateKey: key || '',
    quickWallets,
    walletSets,
    quickWalletBuySol: Math.max(0.001, num(raw.QUICK_WALLET_BUY_SOL, 0.05)),
    quickWalletSellX: Math.max(1.03, num(raw.QUICK_WALLET_SELL_X, 1.25)),
    sideFromX: num(raw.SIDE_TAKE_FROM_X, 0) > 1 ? num(raw.SIDE_TAKE_FROM_X, 0) : 0,
    sideToX: num(raw.SIDE_TAKE_TO_X, 0) > 1 ? Math.max(num(raw.SIDE_TAKE_TO_X, 0), num(raw.SIDE_TAKE_FROM_X, 0)) : 0,
    sidePullbackPct: Math.max(1, num(raw.SIDE_TAKE_PULLBACK_PERCENT, 5)),
    paperRefillSides: on(raw.PAPER_REFILL_SIDES),
    topUpSides: on(raw.TOP_UP_SIDES),
    topUpToSol: Math.max(0.01, num(raw.TOP_UP_TO_SOL, 0.25)),
    topUpMainMinSol: Math.max(0, num(raw.TOP_UP_MAIN_MIN_SOL, 1)),
    sidePriorityFee: Math.max(0, num(raw.SIDE_PRIORITY_FEE, 0.0005)),
    paperStart: Object.fromEntries(String(raw.PAPER_START_SOL || '').split(/[\s,]+/).filter(Boolean).map((p) => p.split(':')).filter(([k, v]) => k && +v >= 0).map(([k, v]) => [k.trim(), +v])),
    autoFund: on(raw.AUTO_FUND),
    autoFundEverySol: Math.max(0.1, num(raw.AUTO_FUND_EVERY_SOL, 1)),
    autoFundSol: Math.max(0.001, num(raw.AUTO_FUND_SOL, 0.1)),
    autoFundKeepSol: Math.max(0, num(raw.AUTO_FUND_KEEP_SOL, 0.3)),
    autoFundMainSharePct: Math.min(100, Math.max(0, num(raw.AUTO_FUND_MAIN_SHARE_PERCENT, 70))),
    autoFundRefill: on(raw.AUTO_FUND_REFILL),
    autoFundRefillSol: Math.max(0.01, num(raw.AUTO_FUND_REFILL_SOL, 0.05)),
    autoFundRefillMainMin: Math.max(0, num(raw.AUTO_FUND_REFILL_MAIN_MIN_SOL, 0.1)),
    autoFundRefillAt: (() => {
      const m = /^(\d{1,2}):(\d{2})$/.exec(String(raw.AUTO_FUND_REFILL_AT || '23:55').trim());
      return m && +m[1] < 24 && +m[2] < 60 ? { h: +m[1], m: +m[2] } : { h: 23, m: 55 };
    })(),
    keyFile,
    buySol: num(raw.COPY_BUY_SOL, 0.1),
    sizeMode: /^fixed$/i.test(raw.COPY_SIZE_MODE) ? 'fixed' : 'scale',
    scaleAt1: Math.max(0, num(raw.COPY_SCALE_AT_1_SOL, 0.5)),
    maxBuySol: Math.max(0, num(raw.COPY_MAX_BUY_SOL, 1)),
    scaleMaxAt: Math.max(10, num(raw.COPY_SCALE_MAX_AT_SOL, 1000)),
    maxWalletPct: Math.min(100, Math.max(0, num(raw.COPY_MAX_WALLET_PERCENT, 20))),
    maxPerCoinSol: Math.max(0, num(raw.COPY_MAX_PER_COIN_SOL, 2)),
    minBuySol: Math.max(0.001, num(raw.COPY_MIN_BUY_SOL, 0.01)),
    copyAdds: on(raw.COPY_ADDS),
    onlyNewCoins: on(raw.COPY_ONLY_NEW_COINS),
    copyReentries: on(raw.COPY_REENTRIES),
    skipAlerts: on(raw.COPY_SKIP_ALERTS),
    oneBuyPerCoin: on(raw.COPY_ONE_BUY_PER_COIN),
    maxSlippage: Math.min(90, Math.max(1, num(raw.COPY_MAX_SLIPPAGE, 50))),
    maxCoinAgeMs: Math.max(0, num(raw.COPY_MAX_COIN_AGE_HOURS, 3)) * 3600000,
    protect: on(raw.COPY_PROTECT),
    crashDropPct: Math.min(90, Math.max(5, num(raw.COPY_CRASH_DROP_PERCENT, 35))),
    crashWindowMs: Math.max(1, num(raw.COPY_CRASH_MINUTES, 5)) * 60000,
    trailArmX: Math.max(1.05, num(raw.COPY_TRAIL_AFTER_X, 1.5)),
    trailDropPct: Math.min(90, Math.max(5, num(raw.COPY_TRAIL_DROP_PERCENT, 40))),
    floorX: Math.max(0, num(raw.COPY_PROFIT_FLOOR_X, 1.15)),
    maxHoldHours: Math.max(0, num(raw.COPY_MAX_HOLD_HOURS, 8)),
    floorBuySol: Math.max(0, num(raw.COPY_FLOOR_BUY_SOL, 0.1)),
    deadCoin: on(raw.COPY_DEAD_COIN),
    shortAlerts: on(raw.SHORT_ALERTS),
    weakBuySol: Math.max(0, num(raw.COPY_WEAK_BUY_SOL, 3)),
    weakMinMs: Math.max(0, num(raw.COPY_WEAK_MIN_MINUTES, 3)) * 60000,
    weakMaxX: Math.max(1, num(raw.COPY_WEAK_MAX_X, 1.1)),
    tradersOffDefault: String(raw.COPY_TRADERS_OFF || '').split(/[\s,]+/).filter(Boolean),
    lossAlerts: on(raw.COPY_LOSS_ALERTS),
    minHolders: Math.max(0, Math.round(num(raw.COPY_MIN_HOLDERS, 80))),
    minHoldersAfterMs: Math.max(0, num(raw.COPY_MIN_HOLDERS_AFTER_MINUTES, 10)) * 60000,
    deadMinMs: Math.max(1, num(raw.COPY_DEAD_MIN_MINUTES, 20)) * 60000,
    deadMaxTrades5m: Math.max(0, num(raw.COPY_DEAD_MAX_TRADES_5M, 10)),
    deadMaxVol5m: Math.max(0, num(raw.COPY_DEAD_MAX_VOLUME_5M_USD, 300)),
    // per-trader sell rules: coins copied from these traders use them instead of the normal ones
    leaderRules: Object.assign(devRules(raw), on(raw.CUPSEY_MODE) && on(raw.CUPSEY_FAST_EXIT)
      ? {
          [raw.CUPSEY_NAME || 'cupsey']: {
            miniPct: Math.min(100, Math.max(1, Math.round(num(raw.CUPSEY_MINI_SELL_PERCENT, 100)))),
            stopLossX: Math.min(0.99, Math.max(0, num(raw.CUPSEY_STOP_LOSS_X, 0.7))),
            crashDropPct: Math.min(90, Math.max(5, num(raw.CUPSEY_CRASH_DROP_PERCENT, 20))),
            trailArmX: Math.max(1.05, num(raw.CUPSEY_TRAIL_AFTER_X, 1.3)),
            trailDropPct: Math.min(90, Math.max(5, num(raw.CUPSEY_TRAIL_DROP_PERCENT, 25))),
            floorX: Math.max(0, num(raw.CUPSEY_PROFIT_FLOOR_X, 1.05)),
          },
        }
      : {}),
    devNames: parseDevs(raw.DEVS, isAddress).map((d) => d.name),
    toasters: String(raw.MINI_TOASTER || '').split(/[\s,]+/).filter(Boolean),
    // V2.11.8 decu is a normal wallet now (normal sizes, Khalil), even if settings.txt still says decu:0.05
    traderBuySol: Object.fromEntries(Object.entries(pairs(raw.TRADER_BUY_SOL) || {}).filter(([n]) => !/^decu$/i.test(n))),
    traderMinHolders: farmerRule(pairs(raw.TRADER_MIN_HOLDERS), raw.FARMERS, num(raw.FARMER_MIN_HOLDERS, 100)),
    traderMaxMc: farmerRule(pairs(raw.TRADER_MAX_MC), raw.FARMERS, num(raw.FARMER_MAX_MC, 40000)),
    boosters: String(raw.TRADER_BOOSTERS || '').split(/[\s,]+/).filter((x) => x.includes('>')).map((x) => x.split('>').map((y) => y.trim())),
    watchWallets: String(raw.WATCH_WALLETS || '')
      .split(',')
      .map((x) => x.trim().split(':').map((y) => y.trim()))
      .filter(([n, w]) => n && w && isAddress(w))
      .map(([name, wallet]) => ({ name, wallet })),
    devBuySol: Math.max(0.001, num(raw.DEV_BUY_SOL, 0.1)),
    rugNames: parseDevs(raw.DEVS, isAddress).filter((d) => d.mode === 'rug').map((d) => d.name),
    rugMaxMcUsd: Math.max(100, num(raw.DEV_RUG_MAX_MC_USD, 3000)),
    devQuickWalletBuySol: Math.max(0.001, num(raw.DEV_QUICK_WALLET_BUY_SOL, 0.05)),
    devDipPct: Math.min(90, Math.max(1, num(raw.DEV_DIP_PERCENT, 20))),
    devMomentumHolders: Math.max(1, Math.round(num(raw.DEV_MOMENTUM_HOLDERS, 40))),
    devMomentumUpPct: Math.max(1, num(raw.DEV_MOMENTUM_UP_PERCENT, 30)),
    devWatchMs: Math.max(1, num(raw.DEV_WATCH_MINUTES, 20)) * 60000,
    // Mini cook (safety net): on buys of COPY_MINI_COOK_MIN_SOL+, once a coin is up 75%+ (1.75x) sell part of it
    // when it starts to pull back, or at 2.5x at the latest. The rest keeps riding the ladder.
    miniCook: on(raw.COPY_MINI_COOK) && !(mainLadder && !/^(off|no|0)$/i.test(mainLadder)),
    quickMode: on(raw.QUICK_PROFIT_MODE),
    quickFromX: Math.max(1.03, num(raw.QUICK_PROFIT_FROM_X, 1.25)),
    quickToX: Math.max(1.05, num(raw.QUICK_PROFIT_TO_X, 1.75)),
    quickPullbackPct: Math.min(50, Math.max(1, num(raw.QUICK_PROFIT_PULLBACK_PERCENT, 7))),
    miniFromX: Math.max(1.05, num(raw.COPY_MINI_COOK_FROM_X, 1.75)),
    miniToX: Math.max(1.1, num(raw.COPY_MINI_COOK_TO_X, 2.5)),
    miniPullbackPct: Math.min(50, Math.max(1, num(raw.COPY_MINI_COOK_PULLBACK_PERCENT, 10))),
    miniPct: Math.min(100, Math.max(1, Math.round(num(raw.COPY_MINI_COOK_SELL_PERCENT, 50)))),
    miniMinSol: Math.max(0, num(raw.COPY_MINI_COOK_MIN_SOL, 0.1)),
    routeWaitMs: Math.max(0, num(raw.COPY_ROUTE_WAIT_SECONDS, 45)) * 1000,
    // "2x:50,4x:25,..." -> at 2x the entry price sell 50% of what's left, at 4x 25%, ... (never 100%: the rest
    // follows his sells). off/empty = use COPY_TAKE_PROFIT_X and the quick profit instead.
    // V2.11.60 (Khalil, Nov 14 8:22pm "take little profit, we have a stop loss"): MAIN_TP_LADDER (new key, so it wins
    // over the COPY_TP_LADDER line in an older settings.txt): 25% at 1.25x, 25% at 2x, then 25% at 4x, 6x, 8x (of
    // what's left). With it, the plain mini cook is off on main (the ladder takes the profit).
    tpLadder: /^(off|no|0)?$/i.test(String(mainLadder || raw.COPY_TP_LADDER).trim())
      ? []
      : String(mainLadder || raw.COPY_TP_LADDER)
          .split(/[,\s]+/)
          .map((s) => s.match(/^(\d+(?:\.\d+)?)x?:(\d+(?:\.\d+)?)%?$/i))
          .filter(Boolean)
          .map((m) => ({ x: +m[1], pct: Math.min(90, Math.max(1, Math.round(+m[2]))) }))
          .filter((s) => s.x > 1)
          .sort((a, b) => a.x - b.x),
    reclaimRent: on(raw.COPY_RECLAIM_RENT),
    newCoinWindowMs: Math.max(1, num(raw.COPY_NEW_COIN_MINUTES, 10)) * 60000,
    quickTpX: Math.max(0, num(raw.COPY_QUICK_TP_X, 1.5)),
    quickTpPercent: Math.min(90, Math.max(0, num(raw.COPY_QUICK_TP_PERCENT, 35))), // never sells out on profit
    quickTpHisMinSol: Math.max(0, num(raw.COPY_QUICK_TP_HIS_MIN_SOL, 1)),
    slippage: num(raw.COPY_SLIPPAGE, 25),
    hourlyGoalSol: Math.max(0, num(raw.HOURLY_GOAL_SOL, 0)),
    dailyGoalSol: Math.max(0, num(raw.DAILY_GOAL_SOL, 1)),
    dailyGoalStepSol: Math.max(0, num(raw.DAILY_GOAL_STEP_SOL, 0.5)),
    cookShowTotalSol: Math.max(0, num(raw.COOK_SHOW_TOTAL_SOL, 10)),
    growthSize: on(raw.GROWTH_SIZE),
    growthMinSol: Math.max(0.005, num(raw.GROWTH_MIN_BUY_SOL, 0.1)),
    paperRestartAt: Math.min(0.95, Math.max(0, num(raw.PAPER_AUTO_RESTART_AT, 0.6))),
    marketAdapt: on(raw.MARKET_ADAPT),
    cautiousHours: on(raw.CAUTIOUS_HOURS),
    styleTraders: String(raw.COPY_STYLE || '').split(/[\s,]+/).filter(Boolean),
    styleAll: on(raw.COPY_STYLE_ALL),
    styleFit: on(raw.STYLE_FIT),
    snipe: /^(off|no|0)$/i.test(String(raw.SNIPE_MODE || '').trim())
      ? null
      : {
          buySol: Math.max(0.01, num(raw.SNIPE_BUY_SOL, 0.1)),
          startSol: Math.max(0.01, num(raw.SNIPE_START_SOL, 0.25)),
          maxOpen: Math.max(1, Math.round(num(raw.SNIPE_MAX_OPEN, 3))),
          maxAgeMs: Math.max(5, num(raw.SNIPE_MAX_AGE_SECONDS, 60)) * 1000,
          maxMcUsd: Math.max(1000, num(raw.SNIPE_MAX_MC_USD, 6000)),
          minInsiderPct: Math.max(0, num(raw.SNIPE_MIN_INSIDERS_PERCENT, 1)),
          maxInsiderPct: Math.max(1, num(raw.SNIPE_MAX_INSIDERS_PERCENT, 20)),
          takeFromX: 1 + Math.max(1, num(raw.SNIPE_TAKE_FROM_PERCENT, 15)) / 100,
          takeToX: 1 + Math.max(2, num(raw.SNIPE_TAKE_TO_PERCENT, 75)) / 100,
          stopX: 1 - Math.min(50, Math.max(2, num(raw.SNIPE_STOP_PERCENT, 10))) / 100,
          maxHoldMs: Math.max(0.5, num(raw.SNIPE_MAX_HOLD_MINUTES, 5)) * 60000,
          maxFreshPct: Math.max(0, num(raw.SNIPE_MAX_FRESH_PERCENT, 100)),
          topFreshN: Math.max(0, Math.round(num(raw.SNIPE_TOP_FRESH_HOLDERS, 3))),
          vampMaxFreshPct: Math.max(0, num(raw.SNIPE_VAMP_MAX_FRESH_PERCENT, 25)),
          minBuyers: Math.max(0, Math.round(num(raw.SNIPE_MIN_BUYERS, 2))),
          maxDevLaunches: Math.max(0, Math.round(num(raw.SNIPE_MAX_DEV_LAUNCHES, 0))),
          maxDevCoins: Math.max(0, Math.round(num(raw.SNIPE_MAX_DEV_COINS, 0))),
          learnMinTrips: on(raw.SNIPE_LEARN) ? Math.max(3, Math.round(num(raw.SNIPE_LEARN_MIN_COINS, 15))) : 1e9,
          wsUrl: String(raw.SNIPE_WS_URL || 'wss://pumpportal.fun/api/data').trim(),
        },
    sideOwnPicks: on(raw.SIDE_OWN_PICKS),
    lateChaseX: Math.max(0, num(raw.LATE_CHASE_X, 10)),
    lateChaseMinutes: Math.max(1, num(raw.LATE_CHASE_MINUTES, 5)),
    lateChaseOkTraders: Math.max(0, num(raw.LATE_CHASE_OK_TRADERS, 2)),
    versionCheck: on(raw.VERSION_CHECK),
    styleFitCoins: Math.max(5, Math.round(num(raw.STYLE_FIT_COINS, 20))),
    styleRules: Object.fromEntries(String(raw.COPY_STYLE || '').split(/[\s,]+/).filter(Boolean).map((n) => [n, { miniFromX: 1.05, miniToX: 1.08, miniPullbackPct: 3, miniPct: 100, stopLossX: 0.9, maxHoldMinutes: 3 }])),
    marketHours: Math.max(1, num(raw.MARKET_HOURS, 6)),
    sideMinBuySol: Math.max(0, num(raw.SIDE_MIN_BUY_SOL, 0.1)), // V2.11.28 side wallets' smallest buy (0 = same as GROWTH_MIN_BUY_SOL)
    growthPct: Math.min(100, Math.max(1, num(raw.GROWTH_PERCENT, 25))),
    growthMaxPct: Math.min(100, Math.max(1, num(raw.GROWTH_MAX_PERCENT, 50))),
    minHoldSec: Math.max(0, num(raw.COPY_MIN_HOLD_SECONDS, 120)),
    confirmSec: Math.max(0, num(raw.COPY_CONFIRM_SECONDS, 30)),
    devCheck: on(raw.DEV_CHECK),
    freshFromX: Math.max(1.01, num(raw.FRESH_DEV_FROM_X, 1.1)),
    freshToX: Math.max(1.01, num(raw.FRESH_DEV_TO_X, 1.25)),
    freshPullbackPct: Math.max(1, num(raw.FRESH_DEV_PULLBACK_PERCENT, 5)),
    realVetoCoins: Math.max(0, Math.round(num(raw.COPY_REAL_VETO_COINS, 10))),
    stopLossX: Math.min(0.99, Math.max(0, num(raw.COPY_STOP_LOSS_X, 0.8))),
    sideStopLossX: Math.min(0.99, Math.max(0, num(raw.SIDE_STOP_LOSS_X, 0.85))),
    autoRotate: on(raw.AUTO_ROTATE),
    rotateMinCoins: Math.max(1, Math.round(num(raw.ROTATE_MIN_COINS, 20))),
    rotateNewMs: Math.max(0, num(raw.ROTATE_NEW_WALLET_HOURS, 48)) * 3600000,
    retireColdDays: Math.max(0, num(raw.ROTATE_RETIRE_COLD_DAYS, 7)),
    keepIfMadeSol: Math.max(0, num(raw.ROTATE_KEEP_IF_MADE_SOL, 1)),
    rotateNoWaitUntil: Date.parse(raw.ROTATE_NO_WAIT_UNTIL || '') || 0,
    smartSize: on(raw.COPY_SMART_SIZE),
    neutralSize: Math.min(1, Math.max(0.1, num(raw.COPY_NEUTRAL_SIZE, 0.5))),
    provenSize: Math.min(1, Math.max(0.1, num(raw.COPY_PROVEN_SIZE, 0.75))),
    hotReserve: Math.max(0, Math.round(num(raw.COPY_HOT_RESERVE, 3))),
    stackBoost: Math.min(2, Math.max(1, num(raw.COPY_STACK_BOOST, 1.5))),
    runnerSize: on(raw.COPY_RUNNER_SIZE),
    runnerX: Math.max(1.2, num(raw.COPY_RUNNER_X, 2)),
    runnerBoost: Math.min(2, Math.max(1, num(raw.COPY_RUNNER_BOOST, 1.5))),
    runnerCut: Math.min(1, Math.max(0.25, num(raw.COPY_RUNNER_CUT, 0.5))),
    runnerForce: Object.fromEntries(Object.entries({ ...(pairs(raw.RUNNER_FORCE_EXTRA) || {}), ...(pairs(raw.RUNNER_FORCE) || {}) }).map(([k, v]) => [k, Math.min(0.999, Math.max(0, v > 1 ? v / 100 : v))])),
    alwaysCopy: String(raw.ALWAYS_COPY || '').split(/[\s,]+/).filter(Boolean),
    runnerHold: on(raw.RUNNER_HOLD),
    runnerHoldRule: { miniFromX: num(raw.RUNNER_HOLD_TAKE_X, 1.5), miniToX: num(raw.RUNNER_HOLD_TAKE_X, 1.5), miniPullbackPct: 1, miniPct: Math.min(100, Math.max(1, num(raw.RUNNER_HOLD_TAKE_PERCENT, 25))), stopLossX: Math.max(0, num(raw.COPY_STOP_LOSS_X, 0.8)) },
    holdRules: Object.fromEntries(
      String(raw.HOLD_TRADERS || '')
        .split(/[\s,]+/)
        .filter(Boolean)
        .map((n) => [n, { miniFromX: num(raw.HOLD_TAKE_X, 2), miniToX: num(raw.HOLD_TAKE_X, 2), miniPullbackPct: 1, miniPct: Math.min(100, Math.max(1, num(raw.HOLD_TAKE_PERCENT, 25))), stopLossX: Math.max(0, num(raw.HOLD_STOP_LOSS_X, 0.25)) }]),
    ),
    bigBetBoost: Math.min(2, Math.max(1, num(raw.COPY_BIG_BET_BOOST, 1.5))),
    testBuyCut: Math.min(1, Math.max(0.25, num(raw.COPY_TEST_BUY_CUT, 0.5))),
    bestHours: on(raw.COPY_BEST_HOURS),
    exitPick: on(raw.COPY_EXIT_PICK),
    maxChasePct: Math.max(0, num(raw.COPY_MAX_CHASE_PERCENT, 15)),
    minHoldersToBuy: Math.max(0, Math.round(num(raw.COPY_MIN_HOLDERS_TO_BUY, 0))),
    minMirrorPct: Math.min(100, Math.max(0, num(raw.COPY_MIN_MIRROR_PERCENT, 10))),
    walletTraders: parseWalletTraders(raw.WALLET_TRADERS),
    // low (default): Jupiter's 'high' fee level, at most 0.0005 SOL a trade (measured: usually ~0.00001 SOL);
    // fast: 'veryHigh' up to COPY_PRIORITY_FEE (was ~0.0018 SOL a trade).
    feeMode: /^fast$/i.test(raw.COPY_FEE_MODE) ? 'fast' : 'low',
    priorityFee: /^fast$/i.test(raw.COPY_FEE_MODE) ? num(raw.COPY_PRIORITY_FEE, 0.002) : Math.min(num(raw.COPY_PRIORITY_FEE, 0.002), 0.0005),
    priorityLevel: /^fast$/i.test(raw.COPY_FEE_MODE) ? 'veryHigh' : 'high',
    mirrorSells: on(raw.COPY_MIRROR_SELLS),
    tpX: num(raw.COPY_TAKE_PROFIT_X, 2),
    tpPercent: Math.min(90, Math.max(0, num(raw.COPY_TAKE_PROFIT_SELL_PERCENT, 25))), // take-profit never sells out
    maxOpen: Math.max(1, num(raw.COPY_MAX_OPEN_POSITIONS, 10)),
    dailyLimitSol: num(raw.COPY_DAILY_LIMIT_SOL, 0),
    minHisBuySol: num(raw.COPY_MIN_HIS_BUY_SOL, 0),
    maxDelayMs: Math.max(3, num(raw.COPY_MAX_DELAY_SECONDS, 30)) * 1000,
    keepSol: Math.max(0, num(raw.COPY_KEEP_SOL, 0.02)),
    tpCheckMs: Math.max(3, num(raw.COPY_TP_CHECK_SECONDS, 5)) * 1000,
    sellRetryMs: Math.max(0.05, num(raw.COPY_SELL_RETRY_SECONDS, 15)) * 1000,
    sellRetryMax: Math.max(0, Math.round(num(raw.COPY_SELL_RETRY_MINUTES, 10) * 60 / Math.max(0.05, num(raw.COPY_SELL_RETRY_SECONDS, 15)))),
    sellCheckDelayMs: Math.max(0, num(raw.COPY_SELL_CHECK_DELAY_SECONDS, 3)) * 1000,
    portalBase: raw.PUMPPORTAL_API_BASE.replace(/\/$/, ''),
    jupKey: raw.JUPITER_API_KEY,
    jupRps: Math.max(0, num(raw.JUPITER_RPS, 0)),
    jitoUrls: on(raw.COPY_JITO) ? raw.JITO_URLS.split(/[\s,]+/).filter(Boolean) : [],
    // with a key, use the main Jupiter API (higher limits)
    jupBase: (raw.JUPITER_API_KEY && raw.JUPITER_API_BASE === DEFAULTS.JUPITER_API_BASE ? 'https://api.jup.ag/swap/v1' : raw.JUPITER_API_BASE).replace(/\/$/, ''),
    file: resolve(raw.COPY_FILE),
  };
  if (c.enabled) {
    if (!(c.buySol > 0)) throw new Error('COPY_BUY_SOL must be more than 0');
    if (c.buySol > 50) throw new Error('COPY_BUY_SOL is over 50 SOL — that looks like a typo');
    if (c.maxBuySol > 50) throw new Error('COPY_MAX_BUY_SOL is over 50 SOL — that looks like a typo');
    if (!(c.slippage > 0 && c.slippage <= 100)) throw new Error('COPY_SLIPPAGE must be between 1 and 100');
    if (c.priorityFee < 0 || c.priorityFee > 0.1) throw new Error('COPY_PRIORITY_FEE must be between 0 and 0.1 SOL');
  }
  return c;
}
